"""Build the visible scoring panel on the V26 interview flow."""
import hashlib
import re
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / '_site'

def mainline(source):
    before = """    return '<section aria-label="录完整回答"><div data-sam-recorder></div></section>';"""
    after = """    var practiceLink = state.recorderTarget.assessmentMode === 'free' && activeAnswer(item).length
      ? '<button type="button" data-sam-action="stage" data-value="3">跟读这题的参考答案并评分</button>' : '';
    return '<section aria-label="录完整回答"><div data-sam-recorder></div>'+practiceLink+'</section>';"""
    assert source.count(before) == 1
    return source.replace(before, after)

def build():
    with ZipFile(ROOT/'gospeak-v26-update.zip') as package:
        def previous(name):
            return package.read('_site/'+name).decode()
        (SITE/'assets/mainline-v21.js').write_text(mainline(previous('assets/mainline-v21.js')))
        html = previous('index.html').replace('V26 ·','V27 ·')
        for asset in ('recorder-v19.js','mainline-v21.js'):
            html = html.replace(asset+'?v=22&design=26',asset+'?v=22&design=27')
        html = html.replace('practice-v26.css?v=22','practice-v26.css?v=22&design=27')
        (SITE/'index.html').write_text(html)
        worker = previous('sw.js')
        worker = worker.replace('return u.href;','if(/(mainline-v21.js|recorder-v19.js|practice-v26.css)$/.test(u.pathname))u.searchParams.set("design","27"); return u.href;')
        style = previous('assets/practice-v26.css') + (ROOT/'assets/score-v27.css').read_text()
        (SITE/'assets/practice-v26.css').write_text(style)
    recorder = (ROOT/'assets/recorder-v27.js').read_bytes()
    (SITE/'assets/recorder-v19.js').write_bytes(recorder)
    digest = hashlib.sha256(recorder+html.encode()+style.encode()).hexdigest()[:12]
    (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,worker))
    files = ['_site/index.html','_site/sw.js','_site/assets/mainline-v21.js','_site/assets/practice-v26.css','_site/assets/recorder-v19.js',
             'assets/recorder-v27.js','assets/score-v27.css','scripts/build_v27.py','scripts/verify_v22.py','scripts/test_practice_v26.cjs']
    with ZipFile(ROOT/'gospeak-v27-update.zip','w',ZIP_DEFLATED) as package:
        for file in files: package.write(ROOT/file,file)
    workflow = ROOT/'.github/workflows/pages.yml'
    config = workflow.read_text().replace('Deploy 快乐出村计划 V26','Deploy 快乐出村计划 V27')
    if 'unzip -q -o gospeak-v27-update.zip' not in config:
        config = config.replace('unzip -q -o gospeak-v26-update.zip -d .','unzip -q -o gospeak-v26-update.zip -d .\n          unzip -q -o gospeak-v27-update.zip -d .')
    workflow.write_text(config)

if __name__ == '__main__':
    build()
