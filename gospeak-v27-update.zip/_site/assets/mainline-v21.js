/* SWT interview workbench. The original sentence course remains a separate view. */
(function () {
  'use strict';
  if (window.__samMainlineV21) return;
  var VERSION='22', STORE='gospeak-sam-v21-interview';
  var coreQuestionIds=['02','15','16','s01','i04','b01','i03','s03'];
  var state={root:null,data:null,questions:[],selected:'15',category:'all',mode:'prepare',practiceScope:'core',mockScope:'all',round:1,
    sentenceMode:true,sentenceIndex:0,variant:0,followup:-1,listeningFocus:true,listeningChoice:null,questionRevealed:false,reference:true,help:false,branchChoices:{},loop:1,
    clips:{},clipCounter:0,audio:null,audioElement:null,audioToken:0,audioTimer:null,watchdog:null,audioKey:'',
    recorder:null,recorderTarget:null,loading:false,loadingToken:0,scheduled:false,continuous:false,
    counts:{},rounds:{},gaps:{},seen:{},recorded:false,needsRender:true};
  try { var saved=JSON.parse(localStorage.getItem(STORE)||'{}');state.selected=saved.selected||'15';state.counts=saved.counts||{};state.rounds=saved.rounds||{};state.gaps=saved.gaps||{}; } catch (_) {}
  if(coreQuestionIds.indexOf(state.selected)<0)state.selected='15';
  var api={remount:mount,isRecording:isRecording,stopPlayback:stopSound};
  window.__samMainlineV21=api;window.__samMainlineV19=api;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function list(v){return Array.isArray(v)?v:[];}
  function q(){return state.questions.find(function(x){return x.id===state.selected;})||state.questions[0];}
  function text(lines){return list(lines).map(function(line){return line.en;}).join(' ');}
  function hasSlots(value){return /\[[^\]]+\]/.test(value||'');}
  function today(){return new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Shanghai'});}
  function roundKey(item){return today()+':'+item.id;}
  function selectedBranch(item){return list(item.branches).find(function(b){return b.id===state.branchChoices[item.id];});}
  function answerLines(item){var direct=list(item.short);if(direct.length)return direct;var branch=selectedBranch(item);return branch?list(branch.sentences).filter(function(line){return !hasSlots(line.en);}):[];}
  function variants(item){return [{en:item.question,zh:item.questionZh,audio:item.questionAudio}].concat(list(item.variants).filter(function(v){return !v.hint&&v.en!==item.question;}));}
  function activeQuestion(item){return state.followup>=0?list(item.followups)[state.followup]||variants(item)[0]:variants(item)[state.variant]||variants(item)[0];}
  function activeAnswer(item){return state.followup>=0?list(activeQuestion(item).answer):answerLines(item);}
  function persist(){try{localStorage.setItem(STORE,JSON.stringify({selected:state.selected,counts:state.counts,rounds:state.rounds,gaps:state.gaps}));}catch(_){}}
  function note(message,kind){return '<p class="sam21-note '+(kind||'')+'">'+esc(message)+'</p>';}
  function status(message){var node=state.root&&state.root.querySelector('[data-sam-status]');if(node)node.textContent=message;window.dispatchEvent(new CustomEvent('gospeak-audio-status',{detail:{message:message}}));}
  function isRecording(){return !!(state.recorder&&state.recorder.isRecording&&state.recorder.isRecording());}
  function safeToChange(){if(isRecording()){status('请先停止并保存录音，再换题或切换练习。');return false;}return true;}
  function disposeRecorder(){if(state.recorder){try{var result=state.recorder.destroy();if(result&&result.catch)result.catch(function(){});}catch(_){}state.recorder=null;}state.recorderTarget=null;}
  function mount(){
    var active=document.querySelector('.app-nav [data-view].active');
    var nav=document.querySelector('.app-nav [data-view="coach"]');if(nav&&nav.textContent!=='SWT口测主线')nav.textContent='SWT口测主线';
    var host=active&&active.getAttribute('data-view')==='coach'?document.querySelector('.coach-layout'):null;
    if(!host){if(state.root&&state.root.isConnected===false){stopSound();disposeRecorder();state.needsRender=true;}return;}
    if(!state.root){state.root=document.createElement('section');state.root.id='oral-mainline';state.root.className='sam21';state.root.innerHTML='<div class="sam21-app"><div data-sam-content>正在载入口测题库…</div><p class="sam21-status" data-sam-status role="status" aria-live="polite"></p></div>';state.root.addEventListener('click',handleClick);state.root.addEventListener('change',handleChange);}
    host.classList.add('sam21-coach-host');
    if(state.root.parentNode!==host){host.insertBefore(state.root,host.firstChild);state.needsRender=true;}
    state.root.classList.toggle('sam21-show-continuous',state.continuous);
    if(!state.data&&!state.loading)load();else if(state.data&&state.needsRender)render();
  }
  function scheduleMount(){if(state.scheduled)return;state.scheduled=true;(window.requestAnimationFrame||function(cb){setTimeout(cb,0);})(function(){state.scheduled=false;mount();});}
  function load(){
    if(state.loading)return;state.loading=true;var token=++state.loadingToken;
    var controller=typeof AbortController==='function'?new AbortController():null;
    var timer=setTimeout(function(){if(controller)controller.abort();if(token===state.loadingToken){state.loading=false;state.loadingToken++;loadError('网络等待较久，请点“重试载入”。');}},15000);
    fetch(new URL('interview-v21.json?v='+VERSION,document.baseURI).href,{cache:'no-cache',signal:controller?controller.signal:undefined}).then(function(r){if(!r.ok)throw new Error('课程暂时无法下载');return r.json();}).then(function(data){
      if(token!==state.loadingToken)return;clearTimeout(timer);state.loading=false;if(!Array.isArray(data.questions)||!data.questions.length)throw new Error('题库数据为空');
      state.data=data;state.questions=data.questions;var available=practiceQuestions();if(!available.length){state.questions=[];state.needsRender=false;loadError('基础题暂未载入，请重试载入课程。');return;}if(!available.some(function(item){return item.id===state.selected;}))state.selected=available.some(function(item){return item.id==='15';})?'15':available[0].id;state.needsRender=true;render();status('已载入，可以开始听题。');
    }).catch(function(error){if(token!==state.loadingToken)return;clearTimeout(timer);state.loading=false;loadError(error.name==='AbortError'?'题库载入超时，请重试。':error.message);});
  }
  function loadError(message){if(state.root)state.root.querySelector('[data-sam-content]').innerHTML='<h2>题库还没有载入</h2>'+note(message)+'<button data-sam-action="retry">重试载入</button>';}
  function registerAudio(audio,content,slow){var src=typeof audio==='string'?audio:audio&&(slow?audio.slow||audio.normal||audio.src:audio.normal||audio.src);var key='clip-'+(++state.clipCounter);state.clips[key]={src:src||'',text:content||'',rate:slow&&audio&&audio.slowRate?Number(audio.slowRate):1};return key;}
  function playButton(audio,content,slow,label,single){var key=registerAudio(audio,content,slow),disabled=hasSlots(content);return '<button type="button" data-sam-play="'+key+'" '+(single?'data-single="true" ':'')+(disabled?'disabled title="先填写真实信息" ':'')+'>'+esc(disabled?'先补真实信息':label||(slow?'▶ 慢速听整段':'▶ 正常听整段'))+'</button>';}
  function audioRow(audio,content){return '<div class="sam21-audio">'+playButton(audio,content,true)+playButton(audio,content,false)+'</div>';}
  /* V22_CORE_EIGHT */
  function practiceQuestions(){
    if(state.practiceScope==='all')return state.questions;
    return coreQuestionIds.map(function(id){return state.questions.find(function(item){return item.id===id;});}).filter(Boolean);
  }
  function setPracticeScope(scope){
    var next=scope==='all'?'all':'core';
    var available=next==='all'?state.questions:coreQuestionIds.map(function(id){return state.questions.find(function(item){return item.id===id;});}).filter(Boolean);
    if(!available.length){status(next==='core'?'基础题暂未载入，请重试载入课程。':'暂时没有可用题目。');return false;}
    state.practiceScope=next;state.category='all';
    if(!available.some(function(item){return item.id===state.selected;}))state.selected=available.some(function(item){return item.id==='15';})?'15':available[0].id;
    resetPrompt();persist();return true;
  }
  function filterQuestions(){return practiceQuestions().filter(function(item){return (state.category==='all'||item.category===state.category)&&(state.mode!=='mock'||state.mockScope!=='after-intro'||item.id!=='01');});}
  function categories(){return practiceQuestions().map(function(item){return item.category;}).filter(function(value,index,all){return value&&all.indexOf(value)===index;});}
  /* V22_POST_INTRO_ROUTE */
  function postIntroHtml(){
    var basics=[['02','学校专业'],['15','项目目的'],['16','为何美国'],['s01','救生员岗位'],['i04','游泳能力'],['b01','听不懂怎么办'],['i03','家人支持'],['s03','回国读书']];
    var shortcuts=basics.filter(function(pair){return state.questions.some(function(item){return item.id===pair[0];});}).map(function(pair){return '<button type="button" data-sam-action="topic" data-value="'+esc(pair[0])+'">'+esc(pair[1])+'</button>';}).join('');
    var core=state.practiceScope==='core';
    return '<section class="sam22-post-intro" aria-label="基础口测练习"><p>'+(core?'自我介绍后停下来听题；先把这几类基础问答练熟。':'这里是选练题目，可以随时回到基础题。')+'</p><div class="sam22-post-intro-actions">'+(core?'<button type="button" class="sam21-primary" data-sam-action="after-intro">随机听答这8题</button><button type="button" data-sam-action="scope-more">更多题目（选练）</button>':'<button type="button" class="sam21-primary" data-sam-action="scope-core">返回基础题</button><button type="button" data-sam-action="mock-all">全题模拟（选练）</button>')+'</div>'+(core?'<details class="sam22-topic-picker"><summary>选择基础题</summary><nav class="sam22-topic-shortcuts" aria-label="基础问题快捷入口">'+shortcuts+'</nav></details>':'')+'</section>';
  }
  function alternativeQuestionsHtml(item){
    var blind=state.mode==='mock'||state.round===3||(state.mode==='prepare'&&state.listeningFocus);
    if(blind&&!state.questionRevealed)return '';
    var current=activeQuestion(item),options=state.followup>=0?[]:variants(item).filter(function(option){return option.en!==current.en;});
    return '<details class="sam22-question-variants"><summary>考官可能还会这样问</summary>'+(options.length?'<ul>'+options.map(function(option){return '<li><div><p lang="en">'+esc(option.en)+'</p><p>'+esc(option.zh||'')+'</p></div>'+playButton(option.audio,option.en,false,'▶ 听这个问法',true)+'</li>';}).join('')+'</ul>':'<p>这题暂未添加其他同义问法，先用上面的问法练习。实际提问可能不同。</p>')+'</details>';
  }
  function pickRandomQuestion(){
    var available=filterQuestions(),pool=available.filter(function(item){return item.id!==state.selected;});
    if(!pool.length)pool=available;
    if(!pool.length){status('当前没有可抽题目，请先选择可用题目。');return false;}
    var picked=pool[Math.floor(Math.random()*pool.length)];state.selected=picked.id;resetPrompt();state.variant=Math.floor(Math.random()*variants(picked).length);persist();render();playQuestion();return true;
  }
  /* V22_LISTENING_FIRST */
  function listeningOptions(item){
    var question=activeQuestion(item),correct=String(question.zh||item.questionZh||'').trim();
    var ownMeanings=variants(item).map(function(option){return String(option.zh||'').trim();});
    ownMeanings.push(correct);
    var alternatives=[],pool=typeof practiceQuestions==='function'?practiceQuestions():state.questions;
    pool.forEach(function(other){var meaning=String(other.questionZh||'').trim();if(other.id!==item.id&&meaning&&ownMeanings.indexOf(meaning)<0&&alternatives.indexOf(meaning)<0)alternatives.push(meaning);});
    var seed=String(item.id)+':'+state.variant+':'+state.followup,total=0;
    for(var i=0;i<seed.length;i++)total+=seed.charCodeAt(i);
    var answers=[{zh:correct,correct:true}];
    if(alternatives.length){var start=total%alternatives.length;for(var offset=0;offset<Math.min(2,alternatives.length);offset++)answers.push({zh:alternatives[(start+offset)%alternatives.length],correct:false});}
    var rotate=answers.length?total%answers.length:0;
    return answers.slice(rotate).concat(answers.slice(0,rotate));
  }
  function listeningFirstHtml(item){
    var options=listeningOptions(item),selected=state.listeningChoice,chosen=selected===null?null:options[selected];
    var feedback=chosen?(chosen.correct?'选对了，这题在问：'+chosen.zh+' 再听一次，把声音和意思连起来。':'这次还没选对。请再听一遍；卡住时可以显示题目，也可以看帮助后继续。'):'';
    var question=activeQuestion(item),clues=state.questionRevealed&&state.followup<0?list(item.listeningClues).filter(function(clue){return clue&&clue.en&&clue.audio&&String(question.en||'').toLowerCase().includes(String(clue.en).toLowerCase());}).slice(0,2):[];
    var clueHtml=clues.length?'<div class="sam22-listening-clues"><p>点听题目里的关键词，把声音和中文意思连起来。</p>'+clues.map(function(clue){return playButton(clue.audio,clue.en,true,clue.en+' · '+clue.zh,true);}).join('')+'</div>':'';
    return '<section class="sam22-listening-first"><h3>第一步：先听懂考官在问什么</h3><p>先点“听问题”。暂时不用想英文答案，听完选一句最接近的中文意思。可以反复听，也可以用慢速。</p>'+clueHtml+'<div class="sam22-meaning-options" role="group" aria-label="这道问题是什么意思">'+options.map(function(option,index){return '<button type="button" data-sam-action="meaning" data-value="'+index+'" aria-pressed="'+(selected===index)+'">'+esc(option.zh)+'</button>';}).join('')+'</div>'+(feedback?'<p class="sam22-meaning-feedback" role="status">'+esc(feedback)+'</p>':'')+'<p class="sam22-listening-limit">这里只帮你检查是否听懂题意，不是机构口测评分；不会扣分，也不会强制卡关。</p><button type="button" class="sam21-primary" data-sam-action="answer-start">听懂了，开始练回答</button><p>没听懂也能先点“没听懂？显示题目”，看清意思后再继续。</p></section>';
  }
  function headerHtml(item){
    var completed=list(state.rounds[roundKey(item)]).length;
    return '<header class="sam21-header"><div><p class="sam21-eyebrow">英语口语练习</p><h1>SWT 口测训练</h1><p>听题、短答，再练随机追问。</p></div><span class="sam21-version">V22</span></header>'+postIntroHtml()+'<nav class="sam21-modes" aria-label="口测训练模式"><button data-sam-action="mode" data-value="prepare" aria-pressed="'+(state.mode==='prepare')+'">听懂再回答<span>先听题，再练短答</span></button><button data-sam-action="mode" data-value="mock" aria-pressed="'+(state.mode==='mock')+'">模拟口测<span>听题后自己答</span></button></nav>'+(state.mode==='prepare'&&state.listeningFocus?'<details class="sam22-listening-topic-picker"><summary>换练习题目（可选）</summary>':'')+'<div class="sam21-selectors"><label>题目类别<select data-sam-category>'+['all'].concat(categories()).map(function(value){return '<option value="'+esc(value)+'" '+(value===state.category?'selected':'')+'>'+esc(value==='all'?(state.practiceScope==='core'?'基础题目':'全部题目'):value)+'</option>';}).join('')+'</select></label>'+(state.mode==='prepare'?'<label>今天主攻一题<select data-sam-question>'+filterQuestions().map(function(item){return '<option value="'+esc(item.id)+'" '+(item.id===state.selected?'selected':'')+'>'+esc(item.title)+'</option>';}).join('')+'</select></label>':'<button class="sam21-primary" data-sam-action="random">随机抽题并听问题</button>')+'</div>'+(state.mode==='prepare'&&state.listeningFocus?'</details>':'')+(state.mode==='prepare'&&!state.listeningFocus?'<div class="sam21-progress"><b>今天这题：已录 <span data-round-count>'+completed+'</span> / 3 遍</b><span>录下才计数，次数不代表掌握。</span></div>':'<p class="sam21-brief">像视频口测：先听问题，停下来想一想，再用自己的短句回答。</p>');
  }
  function roundsHtml(){var labels=['① 看短答跟读','② 只看中文思路','③ 不看提示回答'];return '<nav class="sam21-rounds" aria-label="同题回答三遍">'+labels.map(function(label,index){return '<button data-sam-action="round" data-value="'+(index+1)+'" aria-pressed="'+(state.round===index+1)+'">'+label+'</button>';}).join('')+'</nav>';}
  function questionHtml(item){
    var question=activeQuestion(item),blind=state.mode==='mock'||state.round===3||(state.mode==='prepare'&&state.listeningFocus);
    return '<section class="sam21-question"><div class="sam21-question-label"><small>'+(state.followup>=0?'面试官追问':'面试官提问')+'</small><span>'+(blind?'先听，再开口':'听懂在问什么')+'</span></div>'+(blind&&!state.questionRevealed?'<h2>先听考官的问题</h2>':'<h2 lang="en">'+esc(question.en)+'</h2><p>'+esc(question.zh)+'</p>')+'<div class="sam21-audio">'+playButton(question.audio,question.en,false,'▶ 正常语速循环听题',true)+playButton(question.audio,question.en,true,'▶ 慢速循环听题',true)+(blind?'<button data-sam-action="question-hint">'+(state.questionRevealed?'收起题目文字':'没听懂？显示题目')+'</button>':'')+'</div><div class="sam21-question-tools">'+(state.followup>=0?'<button data-sam-action="base">回到主问题</button>':variants(item).length>1?'<button data-sam-action="wording">同一题，换个问法</button>':'')+'</div></section>';
  }
  function factGateHtml(item){
    var required=Array.isArray(item.requiresConfirmation)?item.requiresConfirmation.join('、'):'这道题涉及的个人经历';
    return '<section class="sam21-fact"><h3>先确认真实情况，再练回答</h3>'+note(required+'还没有确认。不会替你编经历；你可以选符合实际的答法，或直接脱稿回答。','sam21-caution')+list(item.branches).map(function(branch,index){var slots=hasSlots(text(branch.sentences));return '<article><h4>'+esc(branch.label||'条件答法')+'</h4>'+note(branch.condition||'只在与你的实际情况一致时使用')+(slots?note('这里需要填写你的真实信息。先告诉我具体内容，再生成专属答法。'):'<button data-sam-action="confirm-branch" data-value="'+index+'">这符合我的真实情况</button>')+'</article>';}).join('')+'</section>';
  }
  function branchChoiceHtml(item){var branch=!list(item.short).length&&selectedBranch(item);return branch?'<div class="sam21-branch"><span>真实情况：'+esc(branch.label||branch.id)+'</span><button data-sam-action="reset-branch">重新选择</button></div>':'';}
  function scaffoldHtml(item){var question=activeQuestion(item),cues=state.followup>=0?list(question.scaffold):list(item.scaffold);if(!cues.length)cues=[question.hint||'先直接回答问题','再补一句真实的理由或做法'];return '<section class="sam21-scaffold"><h3>我该回答什么</h3><ol>'+cues.slice(0,3).map(function(cue){return '<li>'+esc(cue)+'</li>';}).join('')+'</ol>'+note(state.followup>=0?question.hint||'追问要重新听懂，不能只重复刚才的答案。':item.examinerIntent||item.intent||'回答眼前的问题，补一句真实信息即可。')+'</section>';}
  function answerAudio(item,answer){if(state.followup>=0){var question=activeQuestion(item);return question.fullAudio||question.answerAudio||(answer.length===1?answer[0].audio:null);}var source=selectedBranch(item)||item;return source.fullAudio||list(source.cumulativeAudio)[answer.length-1]||(answer.length===1?answer[0].audio:null);}
  function referenceHtml(item){var answer=activeAnswer(item);return '<section class="sam21-reference"><button class="sam21-reference-toggle" data-sam-action="reference" aria-expanded="'+state.reference+'">'+(state.reference?'收起短答参考':'卡住了？展开短答参考')+'<span>会说自己的版本也可以</span></button>'+(state.reference?(answer.length?'<div class="sam21-reference-body">'+branchChoiceHtml(item)+'<p class="sam21-answer" lang="en">'+esc(text(answer))+'</p><p class="sam21-translation">'+esc(answer.map(function(line){return line.zh;}).join(' '))+'</p>'+audioRow(answerAudio(item,answer),text(answer))+'<details><summary>有一句没听清？单独慢速听</summary><ol class="sam21-lines">'+answer.map(function(line){return '<li><div><p lang="en">'+esc(line.en)+'</p><small>'+esc(line.zh)+'</small></div>'+playButton(line.audio,line.en,true,'▶ 慢速',true)+'</li>';}).join('')+'</ol></details></div>':state.followup>=0?note('这条追问没有预设个人答案。先用中文想清真实内容，再用会说的简单句表达。'):factGateHtml(item)):'')+'</section>';}
  function recorderHtml(item){
    var answer=activeAnswer(item),scripted=state.mode==='prepare'&&state.round===1&&answer.length>0;
    var branch=state.followup<0&&!list(item.short).length&&selectedBranch(item),suffix=state.followup>=0?'followup-'+state.followup:'main';
    state.recorderTarget={id:'sam-v21:'+(scripted?'scripted':'free')+':'+item.id+':'+suffix+':'+(state.mode==='mock'?'mock':'round-'+state.round)+(branch?':branch-'+branch.id:''),expectedText:scripted?text(answer):'',kind:'answer',assessmentMode:scripted?'scripted':'free',title:scripted?'第一遍：连起来跟读 · 录音识别与文字匹配':'自己回答 · 录音、识别和回听',lexicon:state.data.lexicon||{},onStart:stopSound};
    return '<section class="sam21-output"><h3>'+(scripted?'现在把短句连成一段，录下来。':'现在开口，用你会的短句回答。')+'</h3>'+note(scripted?'先展开短答，听一遍，再录音。句子之间可以停顿，不要求一口气读完。':'先直接回答，再补一个真实原因或做法。目标是说清楚，不要求和参考答案相同。')+'<div data-sam-recorder></div>'+(!scripted?'<p class="sam21-limits">自由回答不按范文逐字打分。看识别文字、回听录音，检查有没有答到问题；文字识别也可能听错。</p>':'<p class="sam21-limits">文字匹配分不等于发音分。标出的词只是需回听复核，不能据此断言哪个音发错。</p>')+'</section>';
  }
  function relatedHtml(item){var lesson=item.relatedLesson||list(item.relatedLessons)[0];return lesson?'<aside class="sam21-related"><div><b>句型不熟，再回句子课补一小段</b><p>'+esc(lesson.label||lesson.title||'相关基础句型')+' · 第 '+esc(lesson.day)+' 天 / 第 '+esc(lesson.sentence||1)+' 句</p><small>这是相关句型，不是本题完整答案。原句子课里的经历、家庭、计划是语言示例，符合真实情况才使用。</small></div><button data-sam-action="related">去原句子课复习 →</button></aside>':'';}
  function controlsHtml(){return '<div class="sam21-controls"><label>参考音频 <select data-sam-loop aria-label="参考播放次数">'+[[1,'播放1遍'],[3,'3遍，留空跟读'],[0,'循环直到停止']].map(function(x){return '<option value="'+x[0]+'" '+(state.loop===x[0]?'selected':'')+'>'+x[1]+'</option>';}).join('')+'</select></label><button data-sam-action="stop">■ 停止示范音</button></div>';}
  function reviewHtml(item){var gaps=list(state.gaps[item.id]);return '<details class="sam21-review"><summary>录完怎么改？只记最卡的 1～5 处</summary><ol><li>先听自己的录音，确认有没有回答问题。</li><li>对照识别文字，找漏词或没被听出的词；识别错误也可能来自环境。</li><li>只记最多 5 处卡点，听一遍示范，再重新说一遍。</li></ol><label>每行一处：不会说的意思 / 想复核的词<textarea data-sam-gaps rows="4" maxlength="500" placeholder="例如：没听懂问题里的 experience\n不知道怎么说“继续读书”">'+esc(gaps.join('\n'))+'</textarea></label><p data-gap-status>已记录 '+gaps.length+' / 5 处，仅保存在本机浏览器。</p></details>';}
  function actionsHtml(item){return '<div class="sam21-next"><span data-record-status>'+(state.recorded?'已录这一遍。先回听，再继续。':'听和看不计完成；至少留下一次自己的回答。')+'</span><div>'+(state.mode==='prepare'&&state.round<3?'<button class="sam21-primary" data-sam-action="round" data-value="'+(state.round+1)+'">进入第 '+(state.round+1)+' 遍 →</button>':'<button class="sam21-primary" data-sam-action="followup" '+(!list(item.followups).length?'disabled':'')+'>试一道追问 →</button>')+'<button data-sam-action="random">换一道题</button></div></div>';}
  function footerHtml(){return '<details class="sam21-help"><summary>每天怎么用？先做一题，不刷一堆题。</summary><p>先完成 1 道新题＋1 道旧题复测：1 条问题录音 → 最多 5 个表达缺口 → 同题回答 3 遍 → 明天先脱稿复测 1 次。</p><ol><li>10 分钟：复测昨天的问题。</li><li>15 分钟：听今天的问题，用中文想好 2～3 点。</li><li>25 分钟：从看短答到看中文，再到脱稿，实际录 3 遍。</li><li>10 分钟：练一道追问；有不同问法时再练听辨。</li></ol><p>有 90 分钟：完成上述保底后，再加 15 分钟旧题复测＋15 分钟问题听辨。有 120 分钟：再加 30 分钟随机模拟和回听纠正，不增加大量新题或新视频。</p><p>只有遇到不会的基础句型，才回原句子课补练。模拟回答不要求背长句、说得很快或逐字照搬。没有录音识别时不编造分数。</p></details><div class="sam21-secondary"><button data-sam-action="continuous">'+(state.continuous?'收起拓展连续听练':'拓展：连续听练（与本页题库不同）')+'</button></div>';}
  /* V25_SENTENCE_FIRST: one question, one visible learning step, one recording target. */
  function stage25(){return state.mode==='mock'?0:state.listeningFocus?1:state.sentenceMode?2:3;}
  function header25(item){
    var stage=stage25();
    return '<header class="sam25-header"><div><p>快乐出村计划 / SWT</p><h1>听懂，再开口。</h1></div><button data-sam-action="'+(stage===0?'mode':'after-intro')+'" data-value="prepare">'+(stage===0?'回到学习':'随机口测 ↗')+'</button></header>'+
      '<details class="sam25-picker"><summary>换一题 · '+(stage===0?'随机口测':esc(item.title))+'</summary><label>选择练习题<select data-sam-question>'+practiceQuestions().map(function(row){return '<option value="'+esc(row.id)+'" '+(row.id===state.selected?'selected':'')+'>'+esc(row.title)+'</option>';}).join('')+'</select></label><button data-sam-action="'+(state.practiceScope==='core'?'scope-more':'scope-core')+'">'+(state.practiceScope==='core'?'更多题目（选练）':'返回8类基础题')+'</button></details>'+
      (stage===0?'<div class="sam25-mock-label">模拟口测 · 听完问题，再自己回答</div>':'<nav class="sam25-steps" aria-label="口测学习步骤">'+[[1,'听懂问题'],[2,'一句一句学'],[3,'连起来说']].map(function(row){return '<button data-sam-action="stage" data-value="'+row[0]+'" data-step="'+row[0]+'" aria-current="'+(stage===row[0]?'step':'false')+'"><b>0'+row[0]+'</b><span>'+row[1]+'</span></button>';}).join('')+'</nav>');
  }
  function listening25(item){
    var options=listeningOptions(item),choice=state.listeningChoice===null?null:options[state.listeningChoice];
    var question=activeQuestion(item),clues=state.questionRevealed&&state.followup<0?list(item.listeningClues).filter(function(c){return c.audio&&question.en.toLowerCase().includes(c.en.toLowerCase());}).slice(0,2):[];
    return '<section class="sam25-listen"><h3>听完，选出考官的意思</h3><div class="sam22-meaning-options">'+options.map(function(option,index){return '<button data-sam-action="meaning" data-value="'+index+'" aria-pressed="'+(state.listeningChoice===index)+'">'+esc(option.zh)+'</button>';}).join('')+'</div>'+(choice?'<p role="status">'+(choice.correct?'✓ 选对了，可以开始学回答。':'再听一次，或点“显示题目”看中文。')+'</p>':'')+(clues.length?'<div class="sam25-clues">'+clues.map(function(c){return playButton(c.audio,c.en,true,c.en+' · '+c.zh,true);}).join('')+'</div>':'')+'<button class="sam25-next" data-sam-action="answer-start">开始学第1句 →</button></section>';
  }
  function loop25(audio,content,label){return playButton(audio,content,true,label,false).replace('data-sam-play=', 'data-loop-override="0" data-sam-play=');}
  function detail25(line){
    var words=(line.en.match(/[A-Za-z]+(?:[’\x27-][A-Za-z]+)*/g)||[]).filter(function(w,i,a){return a.map(function(x){return x.toLowerCase();}).indexOf(w.toLowerCase())===i;});
    return '<details class="sam25-detail"><summary>不懂这句？看单词、音标和句子结构</summary>'+(line.ipa?'<p class="sam25-ipa" lang="en">/'+esc(line.ipa)+'/</p>':'')+'<div class="sam25-words">'+words.map(function(word){var entry=(state.data.lexicon||{})[word.toLowerCase()];if(!entry)return '';return '<div>'+'<b lang="en">'+esc(word)+'</b>'+playButton(entry.src,word,false,'正常语速循环',true)+playButton({slow:entry.src,slowRate:.78},word,true,'慢速循环',true)+'<span>'+esc(entry.zh)+'</span><small>'+esc(entry.ipa||'')+'</small></div>';}).join('')+'</div>'+(line.grammar?'<p>'+esc(line.grammar)+'</p>':'')+'</details>';
  }
  function sentence25(item){
    var answer=activeAnswer(item);state.recorderTarget=null;
    if(!answer.length)return factGateHtml(item);
    state.sentenceIndex=Math.max(0,Math.min(answer.length-1,state.sentenceIndex||0));
    var index=state.sentenceIndex,line=answer[index],branch=selectedBranch(item);
    state.recorderTarget={id:'sam-v25:sentence:'+item.id+':'+(state.followup>=0?'followup-'+state.followup:'main')+':'+(branch?branch.id+':':'')+(line.id||index),expectedText:line.en,kind:'sentence',assessmentMode:'scripted',title:'第 '+(index+1)+' 句 · 录音与识别',lexicon:state.data.lexicon||{},onStart:stopSound};
    return '<section class="sam25-sentence" aria-label="逐句学习"><div class="sam25-sentence-top"><span>只练这一句</span><b>第 '+(index+1)+' 句 / 共 '+answer.length+' 句</b></div><nav class="sam25-sentence-tabs" aria-label="选择句子">'+answer.map(function(_,i){return '<button data-sam-action="sentence-index" data-value="'+i+'" aria-pressed="'+(i===index)+'">第'+(i+1)+'句</button>';}).join('')+'</nav><p class="sam25-en" lang="en">'+esc(line.en)+'</p><p class="sam25-zh">'+esc(line.zh)+'</p><div class="sam25-play">'+loop25(line.audio,line.en,'▶ 慢速循环跟读')+playButton(line.audio,line.en,false,'▶ 正常语速循环',true)+'<button data-sam-action="stop">■ 停止</button></div>'+'<section aria-label="录这一句"><div data-sam-recorder></div></section>'+detail25(line)+'<div class="sam25-sentence-next"><button data-sam-action="sentence-index" data-value="'+(index-1)+'" '+(index===0?'disabled':'')+'>← 上一句</button><button class="sam25-next" data-sam-action="'+(index===answer.length-1?'joined':'sentence-index')+'" data-value="'+(index+1)+'">'+(index===answer.length-1?'学完了，连起来说 →':'这句会了，下一句 →')+'</button></div></section>';
  }
  function answer25(item){
    var answer=activeAnswer(item),showEnglish=state.round===1||state.help,showChinese=state.round<3||state.help;
    if(!answer.length)return factGateHtml(item);
    return '<section class="sam25-joined">'+branchChoiceHtml(item)+(showChinese?'<ol class="sam25-answer-lines">'+answer.map(function(line,i){return '<li><span>'+String(i+1).padStart(2,'0')+'</span><div>'+(showEnglish?'<p lang="en">'+esc(line.en)+'</p>':'')+'<p class="sam25-zh">'+esc(line.zh)+'</p></div></li>';}).join('')+'</ol>':'<div class="sam25-blank"><b>现在，用你自己的话回答。</b><p>不必一口气说完，句子之间可以停一下。</p></div>')+(showEnglish?'<div class="sam25-play">'+playButton(answerAudio(item,answer),text(answer),true,'▶ 慢速循环 · 整段',true)+playButton(answerAudio(item,answer),text(answer),false,'▶ 正常语速循环 · 整段',true)+'<button data-sam-action="stop">■ 停止</button></div>':'<button data-sam-action="help">'+(state.help?'收起提示':'卡住了？看一下答案')+'</button>')+'<button class="sam25-back" data-sam-action="stage" data-value="2">有句不熟？回去逐句练</button></section>';
  }
  function rounds25(){return '<nav class="sam25-rounds" aria-label="逐步脱稿">'+['看英文跟读','只看中文说','脱稿回答'].map(function(label,index){return '<button data-sam-action="round" data-value="'+(index+1)+'" aria-pressed="'+(state.round===index+1)+'">'+label+'</button>';}).join('')+'</nav>';}
  function joinedRecorder25(item){
    recorderHtml(item); // Preserve the established whole-answer target and recording history.
    var practiceLink = state.recorderTarget.assessmentMode === 'free' && activeAnswer(item).length
      ? '<button type="button" data-sam-action="stage" data-value="3">跟读这题的参考答案并评分</button>' : '';
    return '<section aria-label="录完整回答"><div data-sam-recorder></div>'+practiceLink+'</section>';
  }
  function body25(item){
    var stage=stage25(),html='';
    if(stage===1){state.recorderTarget=null;html=questionHtml(item)+listening25(item)+alternativeQuestionsHtml(item);}
    else if(stage===2){html=branchChoiceHtml(item)+sentence25(item);}
    else if(stage===3){html=rounds25()+(state.help?'<button data-sam-action="help">收起临时答案</button>':'')+(state.round===3?questionHtml(item):'<p class="sam25-context">回答：'+esc(activeQuestion(item).zh)+'</p>')+answer25(item)+joinedRecorder25(item)+actionsHtml(item)+'<details class="sam25-extra"><summary>复盘与基础句型</summary>'+reviewHtml(item)+relatedHtml(item)+'</details>';}
    else{html=questionHtml(item)+(state.help?answer25(item):'<button data-sam-action="help">没思路？临时看提示</button>')+joinedRecorder25(item)+actionsHtml(item);}
    return header25(item)+'<div class="sam25-panel" data-stage="'+stage+'">'+html+'</div>';
  }

  function render(preserveRecorder){
    if(!state.data||!q()||!state.root)return;if(state.root.isConnected===false){state.needsRender=true;return;}var keepClip=preserveRecorder&&state.clips[state.audioKey];if(!keepClip)stopSound();
    var previousRecorder=preserveRecorder&&state.recorder,previousTarget=state.recorderTarget,previousNode=previousRecorder&&state.root.querySelector('[data-sam-recorder]');
    if(!previousRecorder)disposeRecorder();state.clips={};state.clipCounter=0;state.needsRender=false;
    state.root.querySelector('[data-sam-content]').innerHTML=body25(q())+'<button type="button" class="swt-loop-stop" data-loop-stop data-sam-action="stop" hidden>■ 停止点读</button>';
    if (keepClip && state.audio) {
      var key = Object.keys(state.clips).find(function (id) {
        var clip = state.clips[id];
        return clip.text===keepClip.text && clip.src===keepClip.src && clip.rate===keepClip.rate;
      });
      state.audioKey = key || 'playing-previous-clip';
      showLoopStop(true);
      state.root.querySelectorAll('[data-sam-play]').forEach(function (button) {
        if (button.getAttribute('data-sam-play')===key) {
          button.classList.add('playing');
          button.setAttribute('aria-pressed','true');
        }
      });
    }
    if(state.scrollLearning){state.scrollLearning=false;var steps=state.root.querySelector('.sam25-steps');if(steps&&steps.scrollIntoView)steps.scrollIntoView({block:'start'});}
    var placeholder=state.root.querySelector('[data-sam-recorder]');
    if(previousRecorder&&previousNode&&previousTarget&&state.recorderTarget&&previousTarget.id===state.recorderTarget.id&&placeholder&&placeholder.replaceWith){placeholder.replaceWith(previousNode);return;}
    if(previousRecorder){var nextTarget=state.recorderTarget;disposeRecorder();state.recorderTarget=nextTarget;}
    if(state.recorderTarget&&window.SamRecorder)state.recorder=window.SamRecorder.mount(placeholder,state.recorderTarget);else if(state.recorderTarget)placeholder.innerHTML=note('录音组件还没有载入，请刷新重试。');
  }
  function showLoopStop(visible) {
    var control = state.root && state.root.querySelector('[data-loop-stop]');
    if (control) control.hidden = !visible;
  }
  function stopSound(message){var wasActive=!!(state.audio||state.audioKey||state.audioTimer||state.watchdog);state.audioToken++;clearTimeout(state.audioTimer);clearTimeout(state.watchdog);state.audioTimer=state.watchdog=null;if(state.audio){var audio=state.audio;audio.onended=audio.onerror=audio.onplaying=audio.onwaiting=audio.onstalled=audio.onpause=null;audio.pause();audio.removeAttribute('src');audio.load();state.audio=null;}state.audioKey='';showLoopStop(false);if(state.root)state.root.querySelectorAll('[data-sam-play]').forEach(function(button){button.classList.remove('playing');button.setAttribute('aria-pressed','false');});if(wasActive)status(typeof message==='string'?message:'示范音已停止。');}
  function staticAudioUrl(src){var url=new URL(src,document.baseURI);if(url.protocol==='https:'||url.protocol==='http:')url.searchParams.set('v',VERSION);return url.href;}
  function playClip(clip,key,button,single){
    if(clip&&hasSlots(clip.text)){status('先补真实信息，不播放占位内容。');return;}if(!clip||!clip.src){status('这段示范音暂不可用，请先看文字练习。');return;}if(isRecording()){status('请先停止录音，再听示范音。');return;}if(state.audio&&state.audioKey===key)return;stopSound();
    window.dispatchEvent(new CustomEvent('gospeak-playback-request',{detail:{owner:'mainline-v21'}}));document.querySelectorAll('audio,video').forEach(function(audio){if(!audio.paused)audio.pause();});
    var token=state.audioToken,played=0,limit=button||!single?0:1,audio=state.audioElement||(state.audioElement=new Audio());audio.src=staticAudioUrl(clip.src);audio.preload='auto';audio.playbackRate=clip.rate||1;audio.preservesPitch=true;state.audio=audio;state.audioKey=key;showLoopStop(limit===0);if(button){button.classList.add('playing');button.setAttribute('aria-pressed','true');}
    function fail(message){if(token!==state.audioToken)return;stopSound();status(message);}
    function watch(){if(token!==state.audioToken)return;clearTimeout(state.watchdog);var from=audio.currentTime||0;state.watchdog=setTimeout(function(){if(token!==state.audioToken)return;if(!audio.paused&&audio.currentTime>from+0.2){state.watchdog=null;return;}fail('播放等待超时，已解除等待。请再点一次，或用顶部“恢复声音”。');},15000);}
    function attempt(){if(token!==state.audioToken)return;watch();try{Promise.resolve(audio.play()).then(function(){if(token!==state.audioToken)return;clearTimeout(state.watchdog);state.watchdog=null;status(limit===0?'正在循环点读。点「停止点读」结束。':'正在播放考官的问题。');}).catch(function(){fail('播放未启动，请检查网络和音量后再点一次。');});}catch(_){fail('暂时无法播放，请再试一次。');}}
    audio.onplaying=function(){if(token===state.audioToken){clearTimeout(state.watchdog);state.watchdog=null;}};audio.onwaiting=watch;audio.onstalled=function(){if(audio.readyState<3)watch();};audio.onpause=function(){if(token===state.audioToken&&!audio.ended){stopSound();status('示范音已暂停，可重新点读。');}};audio.onended=function(){if(token!==state.audioToken)return;played++;clearTimeout(state.watchdog);if(limit===0||played<limit)state.audioTimer=setTimeout(function(){if(token===state.audioToken){audio.currentTime=0;attempt();}},Math.min(2400,Math.max(900,(audio.duration||1)*500)));else stopSound('这段示范音已播放结束。');};audio.onerror=function(){fail('音频加载失败，已停止等待。检查网络后再点一次。');};status('正在载入音频…');attempt();
  }
  function playQuestion(){var item=activeQuestion(q()),key=registerAudio(item.audio,item.en,false);playClip(state.clips[key],key,null,true);}
  function resetPrompt(){state.sentenceMode=true;state.sentenceIndex=0;state.listeningFocus=state.mode==='prepare';state.listeningChoice=null;state.variant=0;state.followup=-1;state.questionRevealed=false;state.reference=state.mode==='prepare'&&state.round===1;state.help=false;state.recorded=false;}
  function choose(id){if(!safeToChange())return;if(!practiceQuestions().some(function(item){return item.id===id;}))return;state.selected=id;resetPrompt();persist();render();}
  function goRelated(){
    var item=q(),lesson=item.relatedLesson||list(item.relatedLessons)[0],day=Number(lesson&&lesson.day),sentence=Number(lesson&&(lesson.sentence||1));
    if(!lesson||!Number.isInteger(day)||day<1||day>14||!Number.isInteger(sentence)||sentence<1||sentence>5){status('这题暂时没有关联的基础句型，请使用顶部原句子课。');return;}if(!safeToChange())return;stopSound();disposeRecorder();state.needsRender=true;
    var nav=document.querySelector('.app-nav [data-view="lesson"]');if(!nav){status('请点击顶部“句子课”复习。');return;}nav.click();var dayButton=document.querySelector('.days [data-day="'+(day-1)+'"]');if(!dayButton)return;dayButton.click();for(var index=1;index<sentence;index++){var next=document.querySelector('main.layout #next');if(!next||next.disabled)break;next.click();}
  }
  function saveGaps(value){var gaps=String(value||'').split(/\n/).map(function(value){return value.trim();}).filter(Boolean).slice(0,5);state.gaps[q().id]=gaps;persist();var node=state.root.querySelector('[data-gap-status]');if(node)node.textContent='已记录 '+gaps.length+' / 5 处，仅保存在本机浏览器。';return gaps;}
  function handleChange(event){var target=event.target;if(target.matches('[data-sam-question]')){if(safeToChange())choose(target.value);else target.value=state.selected;}else if(target.matches('[data-sam-category]')){if(!safeToChange()){target.value=state.category;return;}state.category=target.value;var pool=filterQuestions();if(pool.length&&!pool.some(function(item){return item.id===state.selected;}))state.selected=pool[0].id;resetPrompt();persist();render();}else if(target.matches('[data-sam-loop]'))state.loop=Number(target.value);else if(target.matches('[data-sam-gaps]'))target.value=saveGaps(target.value).join('\n');}
  function handleClick(event){
    var button=event.target.closest('button');if(!button||!state.root.contains(button)||button.disabled)return;if(button.hasAttribute('data-sam-play')){var key=button.getAttribute('data-sam-play');var oldLoop=state.loop;if(button.hasAttribute('data-loop-override'))state.loop=Number(button.getAttribute('data-loop-override'));playClip(state.clips[key],key,button,button.hasAttribute('data-single'));state.loop=oldLoop;return;}
    var action=button.getAttribute('data-sam-action'),value=button.getAttribute('data-value');if(!action)return;if(action==='stop'){stopSound();status('示范音已停止。');return;}if(action==='retry'){load();return;}if(!safeToChange())return;
    if(['stage','answer-start','sentence-index','joined','round'].indexOf(action)>=0)state.scrollLearning=true;
    if(action==='stage'){
      var step=Number(value);if(step<1||step>3)return;state.mode='prepare';state.listeningFocus=step===1;state.sentenceMode=step!==3;state.round=1;state.help=false;state.recorded=false;render();
    }else if(action==='sentence-index'){
      var index=Number(value);if(!Number.isInteger(index)||index<0||index>=activeAnswer(q()).length)return;state.sentenceIndex=index;state.recorded=false;render();
    }else if(action==='joined'){
      state.sentenceMode=false;state.listeningFocus=false;state.round=1;state.help=false;state.recorded=false;render();
    }else if(action==='mode'){state.mode=value==='mock'?'mock':'prepare';state.mockScope=state.practiceScope==='core'?'after-intro':'all';state.round=1;resetPrompt();render();}
    else if(action==='after-intro'){if(!setPracticeScope('core'))return;state.mode='mock';state.mockScope='after-intro';state.round=1;pickRandomQuestion();}
    else if(action==='mock-all'){if(!setPracticeScope('all'))return;state.mode='mock';state.mockScope='all';state.round=1;pickRandomQuestion();}
    else if(action==='scope-more'){if(!setPracticeScope('all'))return;state.mode='prepare';state.mockScope='all';state.round=1;resetPrompt();render();}
    else if(action==='scope-core'){if(!setPracticeScope('core'))return;state.mode='prepare';state.mockScope='after-intro';state.round=1;resetPrompt();render();}
    else if(action==='topic'){if(!practiceQuestions().some(function(item){return item.id===value;}))return;state.mode='prepare';state.mockScope=state.practiceScope==='core'?'after-intro':'all';state.category='all';state.round=1;choose(value);}
    else if(action==='meaning'){if(state.mode!=='prepare'||!state.listeningFocus)return;var choice=Number(value),options=listeningOptions(q());if(!Number.isInteger(choice)||choice<0||choice>=options.length)return;state.listeningChoice=choice;render(true);}
    else if(action==='answer-start'){if(state.mode!=='prepare')return;state.sentenceMode=true;state.sentenceIndex=0;state.listeningFocus=false;state.round=1;state.reference=true;state.help=false;state.recorded=false;render();}
    else if(action==='listen-first'){if(state.mode!=='prepare')return;state.listeningFocus=true;state.listeningChoice=null;state.questionRevealed=false;state.help=false;state.reference=false;render();}
    else if(action==='round'){state.sentenceMode=false;state.listeningFocus=false;state.round=Math.max(1,Math.min(3,Number(value)||1));state.mode='prepare';state.followup=-1;state.questionRevealed=false;state.reference=state.round===1;state.help=false;state.recorded=false;render();}
    else if(action==='reference'){state.reference=!state.reference;render(true);}
    else if(action==='help'){state.help=!state.help;state.reference=false;render(true);}
    else if(action==='question-hint'){state.questionRevealed=!state.questionRevealed;render(true);}
    else if(action==='wording'){state.variant=(state.variant+1)%variants(q()).length;state.listeningChoice=null;if(state.mode==='prepare')state.listeningFocus=true;state.questionRevealed=false;state.recorded=false;render();playQuestion();}
    else if(action==='base'){state.followup=-1;state.questionRevealed=false;state.reference=false;state.help=false;state.recorded=false;render();playQuestion();}
    else if(action==='followup'){var followups=list(q().followups);state.followup=followups.length?(state.followup+1)%followups.length:-1;state.mode='mock';state.questionRevealed=false;state.reference=false;state.help=false;state.recorded=false;render();playQuestion();}
    else if(action==='random')pickRandomQuestion();
    else if(action==='related')goRelated();
    else if(action==='confirm-branch'){var branch=list(q().branches)[Number(value)];if(!branch||hasSlots(text(branch.sentences)))return;state.branchChoices[q().id]=branch.id;state.reference=true;render();status('已按你确认的真实情况选答法。情况改变时请重新选择。');}
    else if(action==='reset-branch'){delete state.branchChoices[q().id];state.recorded=false;render();status('已撤回这个选择。旧录音仍保留，请重新确认真实情况。');}
    else if(action==='continuous'){state.continuous=!state.continuous;state.root.classList.toggle('sam21-show-continuous',state.continuous);button.textContent=state.continuous?'收起拓展连续听练':'拓展：连续听练（与本页题库不同）';if(state.continuous){var player=state.root.querySelector('#swt-listening-v18');if(player)player.scrollIntoView({behavior:'smooth',block:'start'});}else{var media=state.root.querySelector('#swt-listening-v18 audio');if(media)media.pause();}}
  }
  function recordSaved(event){
    var d=event.detail||{},id=String(d.id||d.targetId||''),stamp=d.savedAt||d.createdAt||Date.now();if(!id.startsWith('sam-v21:')||Number(d.duration)<=0)return;var unique=id+':'+stamp;if(state.seen[unique])return;state.seen[unique]=true;var parts=id.split(':');state.counts[parts[2]]=(state.counts[parts[2]]||0)+1;
    if(state.recorderTarget&&state.recorderTarget.id===id){state.recorded=true;if(state.mode==='prepare'&&state.followup<0){var key=roundKey(q()),rounds=list(state.rounds[key]);if(rounds.indexOf(state.round)===-1)rounds.push(state.round);state.rounds[key]=rounds;var count=state.root.querySelector('[data-round-count]');if(count)count.textContent=String(rounds.length);}var hint=state.root.querySelector('[data-record-status]');if(hint)hint.textContent='已录这一遍。先回听，修正一处卡点，再继续；次数不代表答对。';}persist();
  }
  window.addEventListener('sam-recorder-start',stopSound);
  window.addEventListener('gospeak-playback-request',function(event){if(!event.detail||event.detail.owner!=='mainline-v21')stopSound();});
  window.addEventListener('sam-review-word',function(event){var detail=event.detail||{};if(!state.recorderTarget||detail.targetId!==state.recorderTarget.id)return;var key=registerAudio(detail.src,detail.word,false);playClip(state.clips[key],key,null,false);});
  window.addEventListener('sam-recorder-saved',recordSaved);
  document.addEventListener('click',function(event){var nav=event.target.closest('[data-view]');if(!nav)return;if(document.querySelector('main.layout .practice.listening')){event.preventDefault();event.stopImmediatePropagation();window.dispatchEvent(new CustomEvent('gospeak-audio-status',{detail:{message:'原句子课正在识别，请先完成这一句的录音再切换板块。'}}));return;}if(!safeToChange()){event.preventDefault();event.stopImmediatePropagation();return;}stopSound();document.querySelectorAll('audio,video').forEach(function(audio){if(!audio.paused)audio.pause();});disposeRecorder();state.needsRender=true;scheduleMount();},true);
  document.addEventListener('play',function(event){if(event.target!==state.audio)stopSound();},true);
  window.addEventListener('pagehide',function(){stopSound();disposeRecorder();state.needsRender=true;});
  function init(){mount();var app=document.getElementById('app');if(app)new MutationObserver(scheduleMount).observe(app,{childList:true});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
