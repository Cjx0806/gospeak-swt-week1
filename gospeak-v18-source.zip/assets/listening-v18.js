(function () {
  "use strict";

  var GLOBAL_KEY = "__gospeakListeningV18";
  var ROOT_ID = "swt-listening-v18";
  var STORAGE_KEY = "gospeak-listening-v18-preferences";
  var MODE_ORDER = ["teaching", "review", "mock"];
  var MODE_COPY = {
    teaching: {
      title: "教学精听",
      description: "英中对照后逐句听慢速、正常、自然语速，并留出动态跟读空白。"
    },
    review: {
      title: "纯英文复习",
      description: "只听英文问题和整段答案的慢速、标准、自然连读，不再逐句或播放中文。"
    },
    mock: {
      title: "模拟口测",
      description: "听题后准备三秒、独立作答三十秒，再听一次自然参考答案。"
    }
  };

  if (window[GLOBAL_KEY]) {
    window[GLOBAL_KEY].remount();
    return;
  }

  var siteBase = new URL("./", document.baseURI);
  var manifestUrls = [
    new URL("listening-v18.json", siteBase).href,
    new URL("audio/v18/manifest.json", siteBase).href
  ];

  var state = {
    root: null,
    audio: null,
    progress: null,
    manifest: null,
    modes: [],
    modules: [],
    modeId: "teaching",
    selection: null,
    rate: 1,
    loop: false,
    resume: null,
    expectedDuration: 0,
    pendingSeek: null,
    loadedUrl: "",
    lastProgressSaveSecond: -1,
    observer: null,
    mounting: false,
    interlockBusy: false,
    suppressProgressSave: false,
    mediaPositionSecond: -1
  };

  var api = {
    remount: ensureMounted
  };
  window[GLOBAL_KEY] = api;

  restorePreferences();
  startMounting();

  function startMounting() {
    ensureMounted();

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", ensureMounted, { once: true });
    }

    if (typeof MutationObserver === "function") {
      state.observer = new MutationObserver(function (records) {
        var shouldRemount = records.some(function (record) {
          return !state.root || !state.root.contains(record.target);
        });
        if (shouldRemount) ensureMounted();
      });
      state.observer.observe(document.documentElement, {
        childList: true,
        subtree: true
      });
    }
  }

  function ensureMounted() {
    if (state.mounting) return;

    var host = document.getElementById("oral-mainline");
    if (!host) return;

    state.mounting = true;
    try {
      if (!state.root) createPanel();
      if (host.firstChild !== state.root) {
        host.insertBefore(state.root, host.firstChild);
      }
    } finally {
      state.mounting = false;
    }
  }

  function createPanel() {
    var root = document.createElement("section");
    root.id = ROOT_ID;
    root.className = "sv18";
    root.setAttribute("aria-labelledby", "sv18-title");
    root.setAttribute("data-state", "loading");
    root.innerHTML = [
      '<header class="sv18__header">',
      '  <div class="sv18__heading">',
      '    <p class="sv18__eyebrow"><span>V18</span> SWT CONTINUOUS LISTENING</p>',
      '    <h2 id="sv18-title">连续听练</h2>',
      '    <p>选一种练法，再播一课或一次听完 14 课。每个按钮都直达预合成长音轨。</p>',
      "  </div>",
      '  <span class="sv18__version" data-version>正在载入</span>',
      "</header>",
      '<aside class="sv18__practice-note">',
      '  <span aria-hidden="true">!</span>',
      '  <p><strong>被动听只是加餐。</strong> 每天仍要至少完成一次不看稿的脱稿口测，听懂不能代替自己说出来。</p>',
      "</aside>",
      '<div class="sv18__content">',
      '  <div class="sv18__mode-block">',
      '    <p class="sv18__label" id="sv18-mode-label">选择听练模式</p>',
      '    <div class="sv18__modes" data-modes role="group" aria-labelledby="sv18-mode-label">',
      '      <span class="sv18__loading">正在读取三种模式…</span>',
      "    </div>",
      '    <p class="sv18__mode-description" data-mode-description>载入听练清单后即可播放。</p>',
      "  </div>",
      '  <button class="sv18__all" type="button" data-action="play-all" disabled>',
      '    <span class="sv18__all-icon" aria-hidden="true">▶</span>',
      '    <span><strong>一键连续播放 · 全 14 课</strong><small>单条长音轨，锁屏后可从系统播放器继续控制</small></span>',
      "  </button>",
      '  <button class="sv18__resume" type="button" data-action="resume" hidden>',
      '    <span aria-hidden="true">↺</span>',
      '    <span><strong>继续上次进度</strong><small data-resume-label></small></span>',
      '    <em>只恢复位置，不自动播放</em>',
      "  </button>",
      '  <section class="sv18__player" aria-label="连续听练播放器">',
      '    <div class="sv18__now">',
      '      <span class="sv18__pulse" aria-hidden="true"></span>',
      '      <div><small>当前音轨</small><strong data-now-title>请选择全集或单课</strong><span data-now-subtitle>尚未载入音频</span></div>',
      "    </div>",
      '    <div class="sv18__timeline">',
      '      <time data-current-time>0:00</time>',
      '      <label class="sv18__sr-only" for="sv18-progress">播放进度</label>',
      '      <input id="sv18-progress" data-progress type="range" min="0" max="0" value="0" step="0.1" disabled>',
      '      <time data-duration>--:--</time>',
      "    </div>",
      '    <audio data-audio controls preload="metadata" playsinline webkit-playsinline></audio>',
      '    <div class="sv18__controls">',
      '      <button type="button" data-action="rewind" disabled aria-label="回退 15 秒">↶ <span>15 秒</span></button>',
      '      <div class="sv18__rates" role="group" aria-label="播放速度">',
      '        <button type="button" data-action="rate" data-rate="0.85" aria-pressed="false">0.85×</button>',
      '        <button type="button" data-action="rate" data-rate="1" aria-pressed="true">1×</button>',
      '        <button type="button" data-action="rate" data-rate="1.1" aria-pressed="false">1.1×</button>',
      "      </div>",
      '      <button type="button" data-action="loop" aria-label="整条音轨循环" aria-pressed="false">↻ <span>循环</span></button>',
      '      <button class="sv18__stop" type="button" data-action="stop" aria-label="停止播放并回到起点" disabled>■ <span>停止</span></button>',
      "    </div>",
      '    <a class="sv18__download" data-download href="#" download hidden>↓ 下载当前 MP3 <small>建议连接 Wi‑Fi</small></a>',
      '    <details class="sv18__transcript" data-transcript hidden>',
      '      <summary><span>查看本课逐句文本</span><small>听不懂时再展开对照</small></summary>',
      '      <div class="sv18__transcript-lines" data-transcript-lines></div>',
      "    </details>",
      "  </section>",
      '  <details class="sv18__modules">',
      '    <summary><span>选择单课播放</span><small data-module-count>14 个预合成长音轨</small></summary>',
      '    <div class="sv18__module-grid" data-modules>',
      '      <p class="sv18__loading">正在载入课程…</p>',
      "    </div>",
      "  </details>",
      '  <p class="sv18__status" data-status role="status" aria-live="polite">正在准备听练清单…</p>',
      "</div>",
      '<footer class="sv18__footer">',
      '  <span aria-hidden="true">✓</span>',
      '  <p data-safety-note>只播放本页为 SWT 口测整理的预合成音轨；个人信息仍以你已确认的事实为准。</p>',
      "</footer>"
    ].join("");

    state.root = root;
    state.audio = root.querySelector("[data-audio]");
    state.progress = root.querySelector("[data-progress]");

    bindPanelEvents();
    applyRate();
    updateLoopButton();
    setupMediaSession();
    setupAudioInterlock();
    loadManifest();
  }

  function bindPanelEvents() {
    state.root.addEventListener("click", function (event) {
      var button = event.target.closest("button[data-action]");
      if (!button || !state.root.contains(button) || button.disabled) return;

      var action = button.getAttribute("data-action");
      if (action === "mode") {
        selectMode(button.getAttribute("data-mode"));
      } else if (action === "play-all") {
        loadSelection({ kind: "all" }, true);
      } else if (action === "play-module") {
        loadSelection(
          { kind: "module", index: Number(button.getAttribute("data-module-index")) },
          true
        );
      } else if (action === "play-from-module") {
        loadSelection(
          { kind: "from", index: Number(button.getAttribute("data-module-index")) },
          true
        );
      } else if (action === "resume") {
        resumeLastProgress();
      } else if (action === "rewind") {
        seekBy(-15);
      } else if (action === "rate") {
        setRate(Number(button.getAttribute("data-rate")));
      } else if (action === "loop") {
        state.loop = !state.loop;
        state.audio.loop = state.loop;
        updateLoopButton();
        savePreferences();
        setStatus(state.loop ? "已开启整条音轨循环。" : "已关闭整条音轨循环。");
      } else if (action === "stop") {
        stopAudio();
      }
    });

    state.progress.addEventListener("input", function () {
      var duration = state.audio.duration;
      var nextTime = Number(state.progress.value);
      if (!Number.isFinite(duration) || duration <= 0 || !Number.isFinite(nextTime)) return;
      state.audio.currentTime = clamp(nextTime, 0, duration);
      updateTimeline();
    });

    state.audio.addEventListener("loadedmetadata", function () {
      applyPendingSeek();
      applyRate();
      updateTimeline();
      updateMediaPosition(true);
    });
    state.audio.addEventListener("durationchange", updateTimeline);
    state.audio.addEventListener("timeupdate", function () {
      updateTimeline();
      updateMediaPosition(false);
      saveCurrentProgress(false);
    });
    state.audio.addEventListener("play", function () {
      stopCompetingAudio();
      state.root.setAttribute("data-playing", "true");
      setMediaPlaybackState("playing");
      setStatus("正在播放 · " + selectionTitle());
    });
    state.audio.addEventListener("pause", function () {
      state.root.setAttribute("data-playing", "false");
      setMediaPlaybackState("paused");
      if (state.audio.currentSrc && !state.audio.ended) {
        saveCurrentProgress(true);
        setStatus("已暂停 · " + selectionTitle());
      }
    });
    state.audio.addEventListener("ended", function () {
      state.root.setAttribute("data-playing", "false");
      setMediaPlaybackState("none");
      clearSavedProgressForCurrentSelection();
      setStatus("本条长音轨已播放完；今天的脱稿口测也别忘了完成。", true);
    });
    state.audio.addEventListener("error", function () {
      if (!state.audio.currentSrc) return;
      setStatus("音频暂时无法载入。请检查网络，或稍后重新点选这条音轨。", true);
    });

    window.addEventListener("pagehide", function () {
      saveCurrentProgress(true);
    });
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "hidden") saveCurrentProgress(true);
    });
  }

  function loadManifest() {
    fetchFirstAvailable(manifestUrls, 0)
      .then(function (manifest) {
        state.manifest = manifest;
        state.modes = normalizeModes(manifest);
        state.modules = normalizeModules(manifest);

        if (!findMode(state.modeId)) state.modeId = "teaching";
        if (!findMode(state.modeId) && state.modes[0]) state.modeId = state.modes[0].id;

        renderManifest();
        state.root.setAttribute("data-state", "ready");
        setStatus("听练清单已就绪。先选模式，再播放全集或一节单课。", true);
      })
      .catch(function (error) {
        state.root.setAttribute("data-state", "error");
        state.root.querySelector("[data-version]").textContent = "清单未载入";
        state.root.querySelector("[data-modes]").innerHTML =
          '<span class="sv18__loading">暂时无法读取听练清单</span>';
        state.root.querySelector("[data-modules]").innerHTML =
          '<p class="sv18__loading">刷新页面后会自动重试。</p>';
        setStatus("听练清单载入失败：" + friendlyError(error), true);
      });
  }

  function fetchFirstAvailable(urls, index) {
    if (index >= urls.length) {
      return Promise.reject(new Error("未找到 listening-v18.json"));
    }

    return fetch(urls[index], {
      credentials: "same-origin",
      cache: "no-cache"
    })
      .then(function (response) {
        if (!response.ok) throw new Error("HTTP " + response.status);
        return response.json();
      })
      .catch(function () {
        return fetchFirstAvailable(urls, index + 1);
      });
  }

  function normalizeModes(manifest) {
    var source = Array.isArray(manifest.modes) ? manifest.modes : [];
    var byId = {};
    source.forEach(function (mode) {
      if (mode && mode.id) byId[String(mode.id)] = mode;
    });

    return MODE_ORDER.map(function (id) {
      var incoming = byId[id] || {};
      var fallback = MODE_COPY[id];
      return {
        id: id,
        title: incoming.title || fallback.title,
        description: incoming.description || fallback.description,
        estimatedMinutes: numberOrZero(incoming.estimatedMinutes),
        all: normalizeTrack(
          incoming.all ||
            (manifest.collections && manifest.collections[id]) ||
            (manifest.all && manifest.all[id])
        )
      };
    });
  }

  function normalizeModules(manifest) {
    var source = Array.isArray(manifest.modules)
      ? manifest.modules
      : Array.isArray(manifest.lessons)
        ? manifest.lessons
        : [];

    return source.map(function (module, index) {
      var id = module.id == null ? String(index + 1).padStart(2, "0") : String(module.id);
      return {
        id: id,
        slug: module.slug || "",
        title: module.title || "第 " + (index + 1) + " 课",
        question: module.question || "",
        questionZh: module.questionZh || "",
        connections: Array.isArray(module.connections) ? module.connections : [],
        lines: normalizeLines(module.lines),
        offsets: module.offsets || {},
        estimatedMinutes: numberOrZero(module.estimatedMinutes),
        tracks: module.tracks || {}
      };
    });
  }

  function normalizeTrack(track) {
    if (!track) return null;
    if (typeof track === "string") return { src: track };
    if (typeof track !== "object") return null;
    var src = track.src || track.url || track.path;
    if (!src) return null;
    return {
      src: src,
      durationSeconds: numberOrZero(track.durationSeconds || track.duration),
      built: track.built
    };
  }

  function normalizeLines(lines) {
    if (!Array.isArray(lines)) return [];
    return lines
      .map(function (line) {
        if (typeof line === "string") return { en: line, zh: "" };
        if (!line || typeof line !== "object") return null;
        return {
          en: line.en || line.english || line.text || "",
          zh: line.zh || line.chinese || line.translation || ""
        };
      })
      .filter(function (line) {
        return line && (line.en || line.zh);
      });
  }

  function renderManifest() {
    var version = state.manifest.version ? String(state.manifest.version).toUpperCase() : "V18";
    state.root.querySelector("[data-version]").textContent = version + " · " + state.modules.length + " 课";

    state.root.querySelector("[data-modes]").innerHTML = state.modes
      .map(function (mode) {
        return [
          '<button type="button" data-action="mode" data-mode="',
          escapeAttribute(mode.id),
          '" aria-pressed="false"><strong>',
          escapeHtml(mode.title),
          "</strong><span>",
          escapeHtml(shortModeHint(mode.id)),
          "</span></button>"
        ].join("");
      })
      .join("");

    state.root.querySelector("[data-module-count]").textContent =
      state.modules.length + " 个预合成长音轨";
    state.root.querySelector("[data-modules]").innerHTML = state.modules
      .map(renderModuleButton)
      .join("");

    var safety = state.manifest.safetyNote ||
      (state.manifest.safety && (state.manifest.safety.notice || state.manifest.safety.note));
    if (safety) state.root.querySelector("[data-safety-note]").textContent = safety;

    renderModeState();
    updateSelectionUI();
    renderResumeButton();
    state.root.querySelector('[data-action="play-all"]').disabled =
      !isTrackReady(trackFor({ kind: "all" }));
    state.root.querySelector('[data-action="rewind"]').disabled = true;
    state.root.querySelector('[data-action="stop"]').disabled = true;
  }

  function renderModuleButton(module, index) {
    var question = module.questionZh || module.question;
    var connections = module.connections.slice(0, 2).join(" · ");
    var minutes = module.estimatedMinutes
      ? '<small>约 ' + escapeHtml(String(module.estimatedMinutes)) + " 分钟</small>"
      : "";

    return [
      '<article class="sv18__module" data-module-card="',
      String(index),
      '">',
      '  <div class="sv18__module-copy">',
      '    <span class="sv18__module-number">',
      escapeHtml(padLessonId(module.id, index)),
      "</span>",
      "    <span><strong>",
      escapeHtml(module.title),
      "</strong>",
      question ? "<em>" + escapeHtml(question) + "</em>" : "",
      connections ? "<i>" + escapeHtml(connections) + "</i>" : "",
      "</span>",
      minutes,
      "  </div>",
      '  <div class="sv18__module-actions">',
      '    <button type="button" data-action="play-from-module" data-module-index="',
      String(index),
      '"><span>从本课听到最后</span><b aria-hidden="true">▶</b></button>',
      '    <button type="button" data-action="play-module" data-module-index="',
      String(index),
      '">只听本课</button>',
      "  </div>",
      "</article>"
    ].join("");
  }

  function renderModeState() {
    var mode = currentMode();
    if (!mode) return;

    state.root.querySelectorAll('[data-action="mode"]').forEach(function (button) {
      var active = button.getAttribute("data-mode") === state.modeId;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });
    state.root.querySelector("[data-mode-description]").textContent = mode.description;

    var allButton = state.root.querySelector('[data-action="play-all"]');
    var allTrack = trackFor({ kind: "all" });
    var allReady = isTrackReady(allTrack);
    allButton.disabled = !allReady;
    allButton.title = allReady ? "" : "这一模式的全集音频尚未生成";
    var allTitle = allButton.querySelector("strong");
    var allDetail = allButton.querySelector("small");
    allTitle.textContent = "一键连续播放 · 全 " + state.modules.length + " 课";
    allDetail.textContent = allReady
      ? mode.title + durationHint(allTrack, mode.estimatedMinutes) + " · 一条长音轨"
      : mode.title + " · 全集音频尚未生成";

    state.root.querySelectorAll('[data-action="play-module"]').forEach(function (button) {
      var index = Number(button.getAttribute("data-module-index"));
      var ready = isTrackReady(trackFor({ kind: "module", index: index }));
      button.disabled = !ready;
      button.textContent = ready ? "只听本课" : "单课音频未生成";
      button.title = ready ? "" : "这一模式的单课音频尚未生成";
    });
    state.root.querySelectorAll('[data-action="play-from-module"]').forEach(function (button) {
      var index = Number(button.getAttribute("data-module-index"));
      var ready = isTrackReady(trackFor({ kind: "from", index: index }));
      var hasOffset = offsetFor(state.modules[index], state.modeId) != null;
      button.disabled = !ready || !hasOffset;
      button.querySelector("span").textContent = !ready
        ? "合集音频未生成"
        : hasOffset
          ? "从本课听到最后"
          : "本课定位尚未生成";
      button.title = button.disabled ? button.textContent.trim() : "";
    });
  }

  function selectMode(modeId) {
    if (!findMode(modeId) || modeId === state.modeId) return;
    saveCurrentProgress(true);
    state.modeId = modeId;
    savePreferences();
    renderModeState();

    if (state.selection) {
      if (isTrackReady(trackFor(state.selection))) {
        loadSelection(state.selection, false);
        setStatus("已切换到“" + currentMode().title + "”。点播放键继续。", true);
      } else {
        clearLoadedTrack();
        setStatus("已切换模式，但对应音频尚未生成，相关按钮已禁用。", true);
      }
    } else {
      setStatus("已选择“" + currentMode().title + "”。请选择全集或单课。", true);
    }
  }

  function loadSelection(selection, autoplay, startAtOverride) {
    var track = trackFor(selection);
    if (!track || !track.src) {
      setStatus("这一模式的音轨尚未提供。", true);
      return;
    }
    if (!isTrackReady(track)) {
      setStatus("这条音频尚未生成，构建完成后按钮会自动启用。", true);
      return;
    }

    saveCurrentProgress(true);

    state.selection = selection.kind === "all"
      ? { kind: "all" }
      : { kind: selection.kind, index: selection.index };
    state.expectedDuration = numberOrZero(track.durationSeconds);
    state.pendingSeek = Number.isFinite(startAtOverride)
      ? startAtOverride
      : selection.kind === "from"
        ? offsetFor(state.modules[selection.index], state.modeId)
        : 0;
    state.lastProgressSaveSecond = -1;
    updateSelectionUI();
    updateNowPlaying();

    var nextUrl = resolveAudioUrl(track.src);
    if (state.audio.src !== nextUrl) {
      state.audio.pause();
      state.audio.src = nextUrl;
      state.audio.load();
    }
    state.loadedUrl = nextUrl;

    applyPendingSeek();

    state.audio.loop = state.loop;
    applyRate();
    state.root.querySelector('[data-action="rewind"]').disabled = false;
    state.root.querySelector('[data-action="stop"]').disabled = false;
    updateTimeline();
    updateMediaMetadata();
    updateDownloadLink(nextUrl);

    if (autoplay) {
      playAudio();
    } else {
      setStatus("已载入 · " + selectionTitle());
    }
  }

  function trackFor(selection, modeId) {
    var activeModeId = modeId || state.modeId;
    var mode = findMode(activeModeId);
    if (!mode || !selection) return null;
    if (selection.kind === "all" || selection.kind === "from") return mode.all;

    var module = state.modules[selection.index];
    if (!module || !module.tracks) return null;
    return normalizeTrack(module.tracks[activeModeId]);
  }

  function isTrackReady(track) {
    return Boolean(track && track.src && track.built !== false);
  }

  function currentMode() {
    return findMode(state.modeId);
  }

  function findMode(id) {
    return state.modes.find(function (mode) {
      return mode.id === id;
    });
  }

  function updateSelectionUI() {
    if (!state.root) return;
    var allButton = state.root.querySelector('[data-action="play-all"]');
    var allActive = state.selection && state.selection.kind === "all";
    allButton.classList.toggle("is-active", Boolean(allActive));
    allButton.setAttribute("aria-pressed", allActive ? "true" : "false");

    state.root.querySelectorAll('[data-action="play-module"], [data-action="play-from-module"]').forEach(function (button) {
      var index = Number(button.getAttribute("data-module-index"));
      var active = state.selection &&
        state.selection.kind === (button.getAttribute("data-action") === "play-module" ? "module" : "from") &&
        state.selection.index === index;
      button.classList.toggle("is-active", Boolean(active));
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });

    state.root.querySelectorAll("[data-module-card]").forEach(function (card) {
      var index = Number(card.getAttribute("data-module-card"));
      var active = state.selection && state.selection.kind !== "all" && state.selection.index === index;
      card.classList.toggle("is-active", Boolean(active));
    });
  }

  function updateNowPlaying() {
    var title = selectionTitle();
    var mode = currentMode();
    var subtitle = mode ? mode.title : "";
    if (state.selection && state.selection.kind !== "all") {
      var module = state.modules[state.selection.index];
      if (module && module.question) subtitle += " · " + module.question;
    } else if (state.selection) {
      subtitle += " · 14 课连续长音轨";
    }

    state.root.querySelector("[data-now-title]").textContent = title;
    state.root.querySelector("[data-now-subtitle]").textContent = subtitle || "尚未载入音频";
    renderTranscript();
  }

  function selectionTitle() {
    if (!state.selection) return "尚未选择音轨";
    if (state.selection.kind === "all") return "SWT 全 14 课连续听练";
    var module = state.modules[state.selection.index];
    if (!module) return "单课听练";
    return state.selection.kind === "from"
      ? padLessonId(module.id, state.selection.index) + "起 · 连续听到最后"
      : padLessonId(module.id, state.selection.index) + " · " + module.title;
  }

  function playAudio() {
    stopCompetingAudio();
    var result;
    try {
      result = state.audio.play();
    } catch (error) {
      setStatus("Safari 需要你再点一次原生播放键。", true);
      return;
    }

    if (result && typeof result.catch === "function") {
      result.catch(function () {
        setStatus("Safari 暂停了自动播放；请点下方原生播放键继续。", true);
      });
    }
  }

  function applyPendingSeek() {
    if (state.pendingSeek == null || !state.audio.currentSrc) return;
    // Safari can briefly expose the previous currentSrc immediately after load().
    // Keep the target until metadata for the newly selected file is available.
    if (state.audio.readyState < HTMLMediaElement.HAVE_METADATA ||
        state.audio.currentSrc !== state.loadedUrl) return;
    var target = Number(state.pendingSeek);
    if (!Number.isFinite(target) || target < 0) {
      state.pendingSeek = null;
      return;
    }

    try {
      var duration = state.audio.duration;
      state.audio.currentTime = Number.isFinite(duration) && duration > 0
        ? clamp(target, 0, Math.max(0, duration - 0.001))
        : target;
      state.pendingSeek = null;
      updateTimeline();
    } catch (error) {
      // Safari may require loadedmetadata before accepting a non-zero seek.
    }
  }

  function offsetFor(module, modeId) {
    if (!module) return null;
    var offsets = module.offsets;
    var raw = offsets && typeof offsets === "object" && !Array.isArray(offsets)
      ? offsets[modeId]
      : offsets;
    if (raw == null) {
      return state.modules[0] && module.id === state.modules[0].id ? 0 : null;
    }
    if (raw && typeof raw === "object") {
      raw = raw.startSeconds != null
        ? raw.startSeconds
        : raw.offsetSeconds != null
          ? raw.offsetSeconds
          : raw.seconds != null
            ? raw.seconds
            : raw.start;
    }
    var value = Number(raw);
    return Number.isFinite(value) && value >= 0 ? value : null;
  }

  function renderTranscript() {
    var details = state.root.querySelector("[data-transcript]");
    var target = state.root.querySelector("[data-transcript-lines]");
    var module = state.selection && state.selection.kind !== "all"
      ? state.modules[state.selection.index]
      : null;
    var lines = module ? module.lines : [];

    details.open = false;
    details.hidden = !lines.length;
    if (!lines.length) {
      target.innerHTML = "";
      return;
    }

    target.innerHTML = lines.map(function (line, index) {
      return [
        '<div class="sv18__transcript-line">',
        "  <span>",
        String(index + 1).padStart(2, "0"),
        "</span>",
        "  <p>",
        line.en ? '<strong lang="en">' + escapeHtml(line.en) + "</strong>" : "",
        line.zh ? "<em>" + escapeHtml(line.zh) + "</em>" : "",
        "  </p>",
        "</div>"
      ].join("");
    }).join("");
  }

  function updateDownloadLink(url) {
    var link = state.root.querySelector("[data-download]");
    link.href = url;
    link.hidden = false;
  }

  function saveCurrentProgress(force) {
    if (state.suppressProgressSave || !state.manifest || !state.selection || !state.audio.currentSrc) return;
    if (state.audio.ended) return;

    var track = trackFor(state.selection);
    if (!isTrackReady(track) || resolveAudioUrl(track.src) !== state.loadedUrl) return;

    var currentTime = Number(state.audio.currentTime);
    if (!Number.isFinite(currentTime) || currentTime < 1) return;
    var second = Math.floor(currentTime);
    if (!force && Math.abs(second - state.lastProgressSaveSecond) < 5) return;

    var module = state.selection.kind === "all" ? null : state.modules[state.selection.index];
    state.resume = {
      modeId: state.modeId,
      selection: {
        kind: state.selection.kind,
        index: state.selection.index,
        moduleId: module ? module.id : null
      },
      currentTime: currentTime,
      duration: Number.isFinite(state.audio.duration) ? state.audio.duration : state.expectedDuration,
      updatedAt: Date.now()
    };
    state.lastProgressSaveSecond = second;
    savePreferences();
    if (force) renderResumeButton();
  }

  function resolveSavedProgress() {
    var saved = state.resume;
    if (!saved || !findMode(saved.modeId) || !saved.selection) return null;
    var currentTime = Number(saved.currentTime);
    if (!Number.isFinite(currentTime) || currentTime < 1) return null;

    var kind = saved.selection.kind;
    var selection;
    if (kind === "all") {
      selection = { kind: "all" };
    } else if (kind === "module" || kind === "from") {
      var index = state.modules.findIndex(function (module) {
        return module.id === String(saved.selection.moduleId || "");
      });
      if (index < 0 && Number.isInteger(saved.selection.index)) index = saved.selection.index;
      if (!state.modules[index]) return null;
      selection = { kind: kind, index: index };
    } else {
      return null;
    }

    if (!isTrackReady(trackFor(selection, saved.modeId))) return null;
    return {
      modeId: saved.modeId,
      selection: selection,
      currentTime: currentTime
    };
  }

  function renderResumeButton() {
    if (!state.root) return;
    var button = state.root.querySelector('[data-action="resume"]');
    var saved = state.manifest ? resolveSavedProgress() : null;
    button.hidden = !saved;
    if (!saved) return;

    var mode = findMode(saved.modeId);
    var selectionText = saved.selection.kind === "all"
      ? "全 14 课"
      : padLessonId(state.modules[saved.selection.index].id, saved.selection.index);
    button.querySelector("[data-resume-label]").textContent =
      mode.title + " · " + selectionText + " · " + formatTime(saved.currentTime);
  }

  function resumeLastProgress() {
    var saved = resolveSavedProgress();
    if (!saved) {
      renderResumeButton();
      setStatus("没有可恢复的上次进度。", true);
      return;
    }

    state.modeId = saved.modeId;
    savePreferences();
    renderModeState();
    loadSelection(saved.selection, false, saved.currentTime);
    setStatus(
      "已恢复到 " + formatTime(saved.currentTime) + "，没有自动播放；请点原生播放键继续。",
      true
    );
  }

  function clearSavedProgressForCurrentSelection() {
    var saved = resolveSavedProgress();
    if (!saved || !state.selection || saved.modeId !== state.modeId) return;
    var sameKind = saved.selection.kind === state.selection.kind;
    var sameIndex = saved.selection.kind === "all" || saved.selection.index === state.selection.index;
    if (!sameKind || !sameIndex) return;
    state.resume = null;
    state.lastProgressSaveSecond = -1;
    savePreferences();
    renderResumeButton();
  }

  function stopAudio() {
    if (!state.audio.currentSrc) return;
    state.suppressProgressSave = true;
    state.audio.pause();
    var start = state.selection && state.selection.kind === "from"
      ? offsetFor(state.modules[state.selection.index], state.modeId) || 0
      : 0;
    try {
      state.audio.currentTime = start;
    } catch (error) {
      state.pendingSeek = start;
    }
    clearSavedProgressForCurrentSelection();
    updateTimeline();
    updateMediaPosition(true);
    setStatus("已停止并回到这条音轨的起点。", true);
    window.setTimeout(function () {
      state.suppressProgressSave = false;
    }, 0);
  }

  function clearLoadedTrack() {
    state.suppressProgressSave = true;
    state.audio.pause();
    state.audio.removeAttribute("src");
    state.audio.load();
    state.loadedUrl = "";
    state.selection = null;
    state.expectedDuration = 0;
    state.pendingSeek = null;
    updateSelectionUI();
    updateNowPlaying();
    updateTimeline();
    state.root.querySelector('[data-action="rewind"]').disabled = true;
    state.root.querySelector('[data-action="stop"]').disabled = true;
    state.root.querySelector("[data-download]").hidden = true;
    window.setTimeout(function () {
      state.suppressProgressSave = false;
    }, 0);
  }

  function setupAudioInterlock() {
    document.addEventListener("click", function (event) {
      if (state.interlockBusy || !state.audio || state.audio.paused || !(event.target instanceof Element)) return;
      var trigger = event.target.closest(
        "[data-main-record], [data-coach-record], [data-main-audio], #stop-audio"
      );
      if (!trigger || state.root.contains(trigger)) return;
      state.audio.pause();
      setStatus("已暂停连续听练，避免与短音频或录音串音。", true);
    }, true);

    document.addEventListener("play", function (event) {
      if (!state.audio || event.target === state.audio || !(event.target instanceof HTMLMediaElement)) return;
      if (!state.audio.paused) {
        state.audio.pause();
        setStatus("已暂停连续听练，避免两段音频同时播放。", true);
      }
    }, true);
  }

  function stopCompetingAudio() {
    if (state.interlockBusy) return;
    state.interlockBusy = true;
    try {
      var stopButton = document.getElementById("stop-audio");
      if (stopButton && !state.root.contains(stopButton)) stopButton.click();

      var playingButton = document.querySelector("[data-main-audio].playing");
      if (playingButton && !state.root.contains(playingButton)) playingButton.click();

      document.querySelectorAll("audio, video").forEach(function (media) {
        if (media !== state.audio && !media.paused) media.pause();
      });
    } finally {
      state.interlockBusy = false;
    }
  }

  function seekBy(seconds) {
    if (!state.audio.currentSrc) return;
    var duration = Number.isFinite(state.audio.duration) ? state.audio.duration : Infinity;
    state.audio.currentTime = clamp(state.audio.currentTime + seconds, 0, duration);
    updateTimeline();
    updateMediaPosition(true);
    setStatus(seconds < 0 ? "已回退 15 秒。" : "已前进 15 秒。");
  }

  function seekTo(seconds) {
    if (!state.audio.currentSrc || !Number.isFinite(seconds)) return;
    var duration = state.audio.duration;
    if (!Number.isFinite(duration) || duration <= 0) return;
    if (typeof state.audio.fastSeek === "function") {
      state.audio.fastSeek(clamp(seconds, 0, duration));
    } else {
      state.audio.currentTime = clamp(seconds, 0, duration);
    }
    updateTimeline();
    updateMediaPosition(true);
  }

  function setRate(rate) {
    if (![0.85, 1, 1.1].includes(rate)) return;
    state.rate = rate;
    applyRate();
    savePreferences();
    setStatus("播放速度已设为 " + rate + " 倍。", true);
  }

  function applyRate() {
    if (!state.audio) return;
    state.audio.defaultPlaybackRate = state.rate;
    state.audio.playbackRate = state.rate;
    state.root.querySelectorAll('[data-action="rate"]').forEach(function (button) {
      var active = Number(button.getAttribute("data-rate")) === state.rate;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });
  }

  function updateLoopButton() {
    if (!state.root) return;
    var button = state.root.querySelector('[data-action="loop"]');
    button.classList.toggle("is-active", state.loop);
    button.setAttribute("aria-pressed", state.loop ? "true" : "false");
    if (state.audio) state.audio.loop = state.loop;
  }

  function updateTimeline() {
    var current = Number.isFinite(state.audio.currentTime) ? state.audio.currentTime : 0;
    var actualDuration = state.audio.duration;
    var hasActualDuration = Number.isFinite(actualDuration) && actualDuration > 0;
    var shownDuration = hasActualDuration ? actualDuration : state.expectedDuration;

    state.root.querySelector("[data-current-time]").textContent = formatTime(current);
    state.root.querySelector("[data-duration]").textContent = shownDuration
      ? formatTime(shownDuration)
      : "--:--";
    state.progress.disabled = !hasActualDuration;
    state.progress.max = hasActualDuration ? String(actualDuration) : "0";
    state.progress.value = hasActualDuration ? String(Math.min(current, actualDuration)) : "0";
    state.progress.style.setProperty(
      "--sv18-progress",
      hasActualDuration ? Math.min(100, current / actualDuration * 100) + "%" : "0%"
    );
  }

  function setupMediaSession() {
    if (!("mediaSession" in navigator)) return;

    setMediaAction("play", function () {
      playAudio();
    });
    setMediaAction("pause", function () {
      state.audio.pause();
    });
    setMediaAction("seekbackward", function (details) {
      seekBy(-(details && details.seekOffset ? details.seekOffset : 15));
    });
    setMediaAction("seekforward", function (details) {
      seekBy(details && details.seekOffset ? details.seekOffset : 15);
    });
    setMediaAction("seekto", function (details) {
      if (details && Number.isFinite(details.seekTime)) seekTo(details.seekTime);
    });
    setMediaAction("previoustrack", function () {
      stepMediaModule(-1);
    });
    setMediaAction("nexttrack", function () {
      stepMediaModule(1);
    });
  }

  function stepMediaModule(direction) {
    if (!state.selection || !state.modules.length) return;
    var index = state.selection.kind === "all"
      ? moduleIndexAtTime(state.audio.currentTime)
      : state.selection.index;
    var kind = state.selection.kind === "module" ? "module" : "from";

    if (direction < 0 && kind === "from") {
      var currentOffset = offsetFor(state.modules[index], state.modeId) || 0;
      if (state.audio.currentTime > currentOffset + 5) {
        loadSelection({ kind: "from", index: index }, true);
        return;
      }
    }

    var targetIndex = clamp(index + direction, 0, state.modules.length - 1);
    var nextSelection = { kind: kind, index: targetIndex };
    if (!isTrackReady(trackFor(nextSelection))) return;
    if (kind === "from" && offsetFor(state.modules[targetIndex], state.modeId) == null) return;
    loadSelection(nextSelection, true);
  }

  function moduleIndexAtTime(currentTime) {
    var index = 0;
    state.modules.forEach(function (module, moduleIndex) {
      var offset = offsetFor(module, state.modeId);
      if (offset != null && offset <= currentTime) index = moduleIndex;
    });
    return index;
  }

  function setMediaAction(action, handler) {
    try {
      navigator.mediaSession.setActionHandler(action, handler);
    } catch (error) {
      // Safari exposes Media Session actions gradually; unsupported actions are optional.
    }
  }

  function updateMediaMetadata() {
    if (!("mediaSession" in navigator) || typeof MediaMetadata !== "function") return;
    var mode = currentMode();
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: selectionTitle(),
        artist: mode ? mode.title : "SWT 连续听练",
        album: "GoSpeak SWT V18",
        artwork: [
          {
            src: new URL("icon-192.png", siteBase).href,
            sizes: "192x192",
            type: "image/png"
          }
        ]
      });
    } catch (error) {
      // Metadata is an enhancement; native audio controls remain fully usable.
    }
  }

  function updateMediaPosition(force) {
    if (!("mediaSession" in navigator) ||
        typeof navigator.mediaSession.setPositionState !== "function") return;
    var duration = state.audio.duration;
    var current = state.audio.currentTime;
    if (!Number.isFinite(duration) || duration <= 0 || !Number.isFinite(current)) return;

    var second = Math.floor(current);
    if (!force && second === state.mediaPositionSecond) return;
    state.mediaPositionSecond = second;
    try {
      navigator.mediaSession.setPositionState({
        duration: duration,
        playbackRate: state.audio.playbackRate || 1,
        position: clamp(current, 0, Math.max(0, duration - 0.001))
      });
    } catch (error) {
      // Some Safari releases reject position updates while media is still loading.
    }
  }

  function setMediaPlaybackState(value) {
    if (!("mediaSession" in navigator)) return;
    try {
      navigator.mediaSession.playbackState = value;
    } catch (error) {
      // Older Safari versions expose metadata without a writable playback state.
    }
  }

  function setStatus(message, announceAgain) {
    var node = state.root && state.root.querySelector("[data-status]");
    if (!node) return;
    if (announceAgain && node.textContent === message) {
      node.textContent = "";
      window.setTimeout(function () {
        node.textContent = message;
      }, 20);
    } else {
      node.textContent = message;
    }
  }

  function resolveAudioUrl(src) {
    var clean = String(src).replace(/^\.\//, "").replace(/^_site\//, "");
    return new URL(clean, siteBase).href;
  }

  function shortModeHint(id) {
    if (id === "teaching") return "听懂再记";
    if (id === "review") return "只听英文";
    return "留白作答";
  }

  function durationHint(track, estimatedMinutes) {
    var seconds = numberOrZero(track && track.durationSeconds);
    if (seconds) return " · " + formatTime(seconds);
    if (estimatedMinutes) return " · 约 " + estimatedMinutes + " 分钟";
    return "";
  }

  function formatTime(value) {
    if (!Number.isFinite(value) || value < 0) return "--:--";
    var total = Math.floor(value);
    var hours = Math.floor(total / 3600);
    var minutes = Math.floor(total % 3600 / 60);
    var seconds = total % 60;
    if (hours) {
      return hours + ":" + String(minutes).padStart(2, "0") + ":" + String(seconds).padStart(2, "0");
    }
    return minutes + ":" + String(seconds).padStart(2, "0");
  }

  function padLessonId(id, index) {
    var raw = String(id || index + 1).replace(/^0+/, "");
    var number = Number(raw);
    return "第 " + (Number.isFinite(number) ? String(number).padStart(2, "0") : escapeHtml(String(id))) + " 课";
  }

  function numberOrZero(value) {
    var parsed = Number(value);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function escapeAttribute(value) {
    return escapeHtml(value).replace(/`/g, "&#096;");
  }

  function friendlyError(error) {
    if (!error || !error.message) return "未知错误";
    return String(error.message).replace(/[<>]/g, "");
  }

  function restorePreferences() {
    try {
      var stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
      if (MODE_ORDER.includes(stored.modeId)) state.modeId = stored.modeId;
      if ([0.85, 1, 1.1].includes(Number(stored.rate))) state.rate = Number(stored.rate);
      state.loop = stored.loop === true;
      if (stored.resume && typeof stored.resume === "object") state.resume = stored.resume;
    } catch (error) {
      // Private browsing may disable localStorage; defaults still work.
    }
  }

  function savePreferences() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        modeId: state.modeId,
        rate: state.rate,
        loop: state.loop,
        resume: state.resume
      }));
    } catch (error) {
      // Preference persistence is optional.
    }
  }
})();
