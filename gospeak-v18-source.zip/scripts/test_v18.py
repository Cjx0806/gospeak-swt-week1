"""Fast, offline regression tests for the continuous listening release."""

import json
from pathlib import Path
import tempfile
import unittest

import build_v18_listening as build
from v18_curriculum import CHINESE_VOICE, ENGLISH_VOICE, MODULES, validate_curriculum


class ListeningTests(unittest.TestCase):
    def test_curriculum_and_correct_major(self):
        validate_curriculum()
        text = " ".join(s.en for m in MODULES for s in m.sentences)
        self.assertIn("physical fitness training", text)
        self.assertNotIn("My major is business", text)
        self.assertNotIn("I plan to continue my studies", text)

    def test_every_sentence_has_requested_five_pass_pattern(self):
        for module in MODULES:
            speech = [c for c in build.build_track_plan(module, "teaching") if isinstance(c, build.Speech)]
            # Chinese title, English question and Chinese question precede lines.
            for index, line in enumerate(module.sentences):
                chunk = speech[3 + index * 5:8 + index * 5]
                self.assertEqual([s.voice for s in chunk], [ENGLISH_VOICE, CHINESE_VOICE, ENGLISH_VOICE, ENGLISH_VOICE, ENGLISH_VOICE])
                self.assertEqual([s.rate for s in chunk], ["-5%", "+0%", "-25%", "-5%", "+5%"])
                self.assertEqual(chunk[0].text, build._spoken_english(line.en))
                self.assertEqual(chunk[1].text, build._spoken_chinese(line.zh))
                self.assertTrue(all(s.text == chunk[0].text for s in chunk[2:]))

    def test_review_is_english_and_three_whole_answers(self):
        for module in MODULES:
            speech = [c for c in build.build_track_plan(module, "review") if isinstance(c, build.Speech)]
            self.assertEqual(len(speech), 5)  # title, question, three complete answers
            self.assertTrue(all(s.voice == ENGLISH_VOICE for s in speech))
            self.assertEqual([s.rate for s in speech[-3:]], ["-20%", "-5%", "+5%"])
            self.assertEqual(len({s.text for s in speech[-3:]}), 1)

    def test_mock_gives_preparation_and_answer_time(self):
        for module in MODULES:
            plan = build.build_track_plan(module, "mock")
            gaps = [c.seconds for c in plan if isinstance(c, build.Silence)]
            self.assertIn(3.0, gaps)
            self.assertIn(30.0, gaps)

    def test_missing_audio_is_not_playable(self):
        with tempfile.TemporaryDirectory() as directory:
            manifest = build.make_manifest(Path(directory), {}, {}, {})
            self.assertEqual(len(manifest["modules"]), 14)
            self.assertTrue(all(not mode["all"]["built"] for mode in manifest["modes"]))
            self.assertTrue(all(not track["built"] for module in manifest["modules"] for track in module["tracks"].values()))
            build.write_manifests(Path(directory), manifest)
            self.assertEqual((Path(directory) / "listening-v18.json").read_bytes(), (Path(directory) / "audio/v18/manifest.json").read_bytes())

    def test_service_worker_does_not_cache_long_tracks(self):
        with tempfile.TemporaryDirectory() as directory:
            worker = Path(directory) / "sw.js"
            worker.write_text("const VERSION = 'gospeak-independent-v17';\nconst core = [];\nself.addEventListener('install', () => {});\nconst old = keys.filter((key) => key !== VERSION);\nself.addEventListener('fetch', event => {\n  if (event.request.method !== 'GET') return;\n  event.respondWith(fetch(event.request));\n});\n")
            self.assertTrue(build.patch_service_worker(worker))
            self.assertFalse(build.patch_service_worker(worker))
            text = worker.read_text()
            self.assertLess(text.index("V18_RANGE_BYPASS"), text.index("event.respondWith"))
            self.assertIn("startsWith('gospeak-independent-')", text)
            self.assertNotIn("collections/teaching.mp3", text)


if __name__ == "__main__":
    unittest.main()
