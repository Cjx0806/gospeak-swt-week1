"""Render new lesson text locally; previously approved prerecorded clips are reused."""
import subprocess,wave
from pathlib import Path
from piper import PiperVoice, SynthesisConfig
import imageio_ffmpeg
from build_v18_listening import _clip_key
from real_v30 import ROOT
MODELS=ROOT/'tmp/v31-offline'
async def offline(requested):
    result={};loaded={}
    for clip in set(requested):
        key=_clip_key(clip)
        existing=ROOT/'.audio-cache-v18'/(key+'.mp3')
        if existing.is_file() and existing.stat().st_size:
            result[clip]=existing;continue
        output=MODELS/'clips'/(key+'.mp3');output.parent.mkdir(exist_ok=True)
        if not output.exists():
            chinese=clip.voice.startswith('zh-');model='huayan' if chinese else 'lessac'
            if model not in loaded:loaded[model]=PiperVoice.load(MODELS/(model+'.onnx'))
            rate=float(clip.rate.rstrip('%'))/100+1
            with wave.open(str(output.with_suffix('.wav')),'wb') as stream:
                loaded[model].synthesize_wav(clip.text.replace('Felix','菲利克斯') if chinese else clip.text,stream,syn_config=SynthesisConfig(length_scale=1/rate))
            subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-loglevel','error','-y','-i',str(output.with_suffix('.wav')),'-ar','24000','-ac','1','-b:a','64k',str(output)],check=True)
            output.with_suffix('.wav').unlink()
        result[clip]=output
    return result
if __name__=='__main__':
    import real_v30,course_v31,felix_v31
    real_v30.synthesize_missing=offline
    course_v31.compile_course()
    felix_v31.build(offline)
