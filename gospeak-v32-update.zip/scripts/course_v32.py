"""Compile the two-turn location drill. Only generic examiner prompts use online TTS."""
import json
from real_v30 import ROOT,SITE,PROFILES,build,entries,synthesize_missing
from voice_local_v31 import offline
def compile_course():
    rows=entries('real-v32.txt',{'location':'in Delaware.','locationwhy':'by the sea.'})
    rows[1]['secondSeam']='close to work. '+rows[1]['lines'][-1]['en']
    prompts={line['en'].replace(' US',' U.S.') for row in rows for line in row['lines'][:2]}
    prompts.add('Please introduce yourself.')
    async def voices(clips):
        questions={s for s in clips if s.text in prompts}
        return {**await synthesize_missing(questions),**await offline(clips-questions)}
    vocab={k:dict(zh=zh,ipa=ipa) for k,ipa,zh in
           (line.split('|') for line in (ROOT/'assets/real-vocab-v32.txt').read_text().splitlines())}
    build(rows,[(n,style,voice,['location','locationwhy']) for n,style,voice,_ in PROFILES if n in ('Alex','Brian')],
          additional_vocab=vocab,synthesizer=voices,output='location-v32.json')
if __name__=='__main__':compile_course()
