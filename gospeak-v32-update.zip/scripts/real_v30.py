"""Compile the listening route and its content-addressed, locally served audio."""
import asyncio, hashlib, json, shutil
from pathlib import Path
from build_v18_listening import Speech
from build_v21 import synthesize_missing
from language_v29 import tokens, LABELS, gloss, modifiers
ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'_site'
VOICE='en-US-GuyNeural'
PROFILES=[
    ('Alex','项目与返校','en-US-GuyNeural',['purpose','return','grad','plans','place','visit','conflict']),
    ('Eric','经历与旅行','en-US-EricNeural',['sales','strength','trip','alone','hobby','place','return']),
    ('Brian','岗位与体能','en-US-BrianNeural',['job','swim','hobby','sales','pressure','conflict','grad']),
    ('Andrew','工作与合作','en-US-AndrewNeural',['sales','job','conflict','pressure','purpose','grad','plans'])]
INTRO='Please introduce yourself.'
def entries(source="real-v30.txt", extra_tails=None):
    rows=[]
    for raw in (ROOT/'assets'/source).read_text().splitlines():
        if raw.startswith('@'):
            name,title,cue,bridge,related=map(str.strip,raw[1:].split('|'))
            rows.append(dict(id='r30-'+name,title=title,cue=cue,bridge=bridge,related=['r30-'+k for k in related.split(',')],lines=[]))
        elif raw and not raw.startswith('#'):
            en,zh=raw.split(' ~ ')
            parts=[part.split(' ',1) for part in en.split('|')]
            assert all(label in LABELS for label,_ in parts)
            rows[-1]['lines'].append(dict(en=' '.join(s for _,s in parts),zh=zh,parts=parts))
    for row in rows:
        assert len(row['lines'])>=4
        a,b=row['lines'][2:4]
        tail=dict(grad='a first-year student.',return_='to China.',plans='a swimming coach.',
            purpose='American culture.',job='a lifeguard.',swim='every day.',sales='used phones.',
            strength='about cars.',pressure='usually cheerful.',conflict='listen first.',
            place='the East Coast.',visit='New York.',trip='at nineteen.',alone='at seventeen.',
            hobby='cycling and swimming.',state='the East Coast.',malaysia='at sixteen.',vietnam='at eighteen.',outdoors='work outdoors.')
        tail.update(extra_tails or {})
        end=tail['return_' if row['id']=='r30-return' else row['id'][4:]]
        assert a['en'].endswith(end)
        row['seam']=end+' '+b['en']
    return rows
def speech(text,voice):return Speech(text.replace('2029','twenty twenty-nine').replace('…','.').replace(' US',' U.S.'),voice,'-5%')
def build(rows=None,profiles_config=None,*,additional_vocab=None,synthesizer=None,output='real-v30.json'):
    if rows is None: rows=entries()
    base=json.loads((SITE/'interview-v21.json').read_text())
    lex=base['lexicon'].copy()
    lex.update({w:{'ipa':ipa,'zh':zh} for w,ipa,zh in (l.split('|') for l in (ROOT/'assets/real-vocab-v30.txt').read_text().splitlines())})
    if additional_vocab:
        lex.update(additional_vocab)
    requests=set()
    def audio(text,voice=VOICE):
        clip=speech(text,voice);requests.add(clip)
        name=hashlib.sha256((clip.text+'|'+voice+'|'+clip.rate).encode()).hexdigest()[:22]
        src='./audio/real-v30/'+name+'.mp3'
        files[clip]=src
        return dict(normal=src,slow=src,slowRate=.78)
    files={};notes={};newlex={}
    for row in rows:
        for line in row['lines']:
            en=line['en'];line['audio']=audio(en, 'en-US-GuyNeural' if line in row['lines'][:2] else VOICE)
            ws=tokens(en);ls=[w.lower() for w in ws];parts=[[r,s.rstrip('.,?')] for r,s in line.pop('parts')]
            roles=[r for r,s in parts for _ in tokens(s)]
            for w in ls:
                if not lex[w].get('src'):
                    lex[w]['src']=audio(w if w!='us' else 'the U.S.')['normal'];newlex[w]=lex[w]
            word_glosses=[]
            for i,(w,k) in enumerate(zip(ws,ls)):
                glosses={'US':'美国','2029':'2029年（twenty twenty-nine）','might':'可能','used':'二手的','first':'先','taken':'进行过（与 trip 连用）','done':'做过','open':'愿意考虑的','still':'仍然'}
                meaning=glosses.get(w,gloss(k,i,ls,roles[i],lex,' '.join(ls)))
                if w=='first-year':meaning='大一的'
                if k=='to' and i+1<len(ws) and ls[i+1] in ('south','indonesia','china','the'):meaning='到；对（引出地点或对象）'
                if k=='about' and en.startswith('What do you know'):meaning='关于（与 know 连用）'
                if k=='would' and 'love' in ls:meaning='与 love 连用，表示很想'
                if k=='in' and '2029' in ls:meaning='在（某一年）'
                word_glosses.append([w,meaning])
            notes[en]=dict(words=word_glosses,parts=parts,mod=modifiers(ws),inner=[],tips=[])
        joined=' '.join(l['en'] for l in row['lines'][2:])
        row['fullAudio']=audio(joined);row['seamAudio']=audio(row['seam'])
    bank={}
    for row in rows:
        q,v,*answers=row['lines']
        bank[row['id']]=dict(id=row['id'],title=row['title'],question=q['en'],questionZh=q['zh'],questionAudio=q['audio'],
            variants=[v],short=answers,extra=[],branches=[],followups=[],category='实录重点',fullAudio=row['fullAudio'],
            cue=row['cue'],bridge=row['bridge'],seam=row['seam'],seamAudio=row['seamAudio'],related=row['related'])
        if row.get('secondSeam'):
            bank[row['id']]['secondSeam']=row['secondSeam']
            bank[row['id']]['secondSeamAudio']=audio(row['secondSeam'])
    profiles=[]
    for name,style,voice,route in (profiles_config or PROFILES):
        audioMap={INTRO:audio(INTRO,voice)}
        for key in route:
            for line in bank['r30-'+key]['variants']+[{'en':bank['r30-'+key]['question']}]:
                audioMap[line['en']]=audio(line['en'],voice)
        profiles.append(dict(name=name,style=style,route=['r30-'+k for k in route],audio=audioMap))
    clips=asyncio.run((synthesizer or synthesize_missing)(requests))
    for clip,path in clips.items():
        target=SITE/files[clip];target.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(path,target)
    real=dict(topics=list(bank.values()),notes=notes,lexicon=newlex,profiles=profiles)
    (SITE/output).write_text(json.dumps(real,ensure_ascii=False,separators=(',',':')))
    print(len(bank),'topics;',len(files),'audio files')
if __name__=='__main__':build()
