"""Install the paired work-location questions over the verified V31 release."""
import hashlib,json,re
from zipfile import ZipFile
from build_v30 import ROOT,SITE,sub
from build_v31 import pack

LOCATION='r30-location'
WHY='r30-locationwhy'

def update_player(js):
    js=sub(js,"state.selected=typeof location!=='undefined'&&location.hash==='#hire'?", """state.selected=typeof location!=='undefined'&&location.hash==='#location'?'r30-location':typeof location!=='undefined'&&location.hash==='#hire'?""")
    js=js.replace("['#exam','#practice','#hire']","['#exam','#practice','#hire','#location']")
    js=sub(js,"var seed=String(item.id)", """if(item.id==='r30-location')alternatives=['为什么想去那里工作？','你以前做过什么工作？'];
    if(item.id==='r30-locationwhy')alternatives=['你想去哪个州或哪座城市？','你什么时候能开始工作？'];
    var seed=String(item.id)""")
    js=sub(js,"'一句一句学','两句连读'", "'一句一句学',item.short.length>2?'整段连读':'两句连读'")
    js=sub(js,"loopTools(item.seamAudio,item.seam)+'<p", """loopTools(item.seamAudio,item.seam)+(item.secondSeam?'<h4>再接第三句</h4><div class="r30-join" lang="en">'+esc(item.secondSeam.split('. ')[0])+'. / '+esc(item.short[2].en)+'</div>'+loopTools(item.secondSeamAudio,item.secondSeam):'')+'<p""")
    js=sub(js,"const dest=realTopic(!follow&&q().id==='r30-job'?'r30-hire':pick(pool.length?pool:q().related));","""const firstFollow={'r30-job':'r30-hire','r30-location':'r30-locationwhy'};
    const dest=realTopic(!follow&&firstFollow[q().id]||pick(pool.length?pool:q().related));""")
    js=sub(js,"btn('real-follow','练好了，听随机追问 →'","btn('real-follow',item.id==='r30-location'?'听下一问：为什么选那里？':'练好了，听随机追问 →'")
    js=sub(js,"    // Open with a focus question", """    if(remaining.includes('r30-location')&&remaining.includes('r30-locationwhy')){
      for(const id of ['r30-location','r30-locationwhy']){order.push(id);remaining.splice(remaining.indexOf(id),1);}
    }
    const fixedThrough=order.length;
    // Open with a focus question""")
    js=sub(js,"return {profile:profileIndex,start:Date.now(),index:0,turns:", "return {profile:profileIndex,start:Date.now(),index:0,fixedThrough,turns:")
    js=sub(js,"const reserved=session.turns[1].id==='r30-job'&&session.turns[2].id==='r30-hire'&&session.index<2;","""const fixed=session.fixedThrough??(session.turns[1].id==='r30-job'&&session.turns[2].id==='r30-hire'?2:0);
      const reserved=session.index<fixed;""")
    js=sub(js,"    place:[", """    location:[/delaware|rehoboth|new hampshire|portsmouth|new york|east coast|california|florida/,/delaware|new hampshire|new york|california|florida/,/rehoboth|portsmouth|new york city|los angeles|miami/],
    locationwhy:[/\\b(sea|beach|ocean|coast|housing|rent|save|savings|money)\\b|close to work|near work/,/\\b(sea|beach|ocean|coast|lifeguard)\\b/,/housing|rent|save|savings|money|close to work|near work|short commute/],
    place:[""")
    js=sub(js, "const compact=turn.id==='r30-grad'", "const compact=turn.id==='r30-location'&&first&&detail||turn.id==='r30-grad'")
    js=sub(js,"    return {score,why:", """    if(turn.id==='r30-location'&&key<4)advice='州和城市各说一个。地名识别可能有误，回听原录音核对。';
    if(turn.id==='r30-locationwhy'&&key<4)advice='试着说一个工作上的理由，再补一个住宿或存钱的理由。';
    return {score,why:""")
    return js.replace('course=31','course=32.1')

def build():
    extra=json.loads((SITE/'location-v32.json').read_text())
    notes=extra['notes']
    by_sea=notes['I want to be a lifeguard by the sea.']
    by_sea['words'][6][1]='在……旁边（by the sea 表示在海边）'
    assert by_sea['words'][6][0]=='by'
    by_sea['parts']=[['S','I'],['V','want'],['O','to be a lifeguard'],['L','by the sea']]
    close=notes['I hope to live close to work.']
    close['words'][-2:]=[['to','介词，和 close 一起表示“离……近”'],['work','工作地点']]
    close['tips']=['第一个 to 后接动作 live。第二个 to 后接地点 work，close to work 就是“离上班地点近”。']
    close['inner']=[[['V','to live'],['L','close to work']]]
    notes['Which state and city would you like to work in?']['parts'][0][0]='PO'
    with ZipFile(ROOT/'gospeak-v31-update.zip') as baseline:
        original=lambda name:baseline.read('_site/'+name).decode()
        data=json.loads(original('interview-v21.json'));real=data['real']
        real['topics']=extra['topics']+real['topics']
        real['notes'].update(extra['notes']);real['lexicon'].update(extra['lexicon'])
        incoming={p['name']:p for p in extra['profiles']}
        routes={'Alex':[LOCATION,WHY,'r30-purpose','r30-family','r30-grad','r30-plans','r30-return'],
                'Brian':['r30-job','r30-hire',LOCATION,WHY,'r30-swim','r30-outdoors','r30-challenge']}
        for p in real['profiles']:
            if p['name'] in routes:
                p['route']=routes[p['name']]
                p['audio'].update(incoming[p['name']]['audio'])
                p['style']='选岗地点与返校' if p['name']=='Alex' else '救生员与选岗地点'
        js=update_player(original('assets/mainline-v21.js'))
        html=original('index.html').replace('V31 ·','V32 ·').replace('mainline-v21.js?v=22&design=31','mainline-v21.js?v=22&design=32.1')
        sw=original('sw.js').replace("set('course','31')","set('course','32.1')").replace("if(u.pathname.endsWith('/mainline-v21.js'))u.searchParams.set('design','31')","if(u.pathname.endsWith('/mainline-v21.js'))u.searchParams.set('design','32.1')")
    payload=json.dumps(data,ensure_ascii=False,separators=(',',':'))
    (SITE/'interview-v21.json').write_text(payload);(SITE/'index.html').write_text(html);(SITE/'assets/mainline-v21.js').write_text(js)
    digest=hashlib.sha256((payload+js).encode()).hexdigest()[:12]
    (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,sw))
    paths=['_site/'+p for p in ['index.html','sw.js','assets/mainline-v21.js','interview-v21.json']]
    paths+=['scripts/'+p for p in ['build_v32.py','course_v32.py','real_v30.py','voice_local_v31.py','test_location_v32.cjs']]
    paths+=['assets/real-v32.txt','assets/real-vocab-v32.txt']
    clips=json.dumps(extra,ensure_ascii=False)
    paths+=[str(p.relative_to(ROOT)) for p in (SITE/'audio/real-v30').glob('*.mp3') if p.name in clips]
    pack('gospeak-v32-update.zip',paths)
if __name__=='__main__':build()
