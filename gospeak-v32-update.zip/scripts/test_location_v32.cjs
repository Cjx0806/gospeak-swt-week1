/* Exercise the same mounted run loop as the course, with an in-memory mic. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{createRequire}=require('node:module');
let setup=fs.readFileSync(path.join(__dirname,'test_mainline_v25.cjs'),'utf8').split('\nt.render();')[0];
setup=setup.replace('q,recordSaved,stopSound','q,recordSaved,stopSound,markTurn,examGrade,bootReal,realAction,examProgress,getSession:()=>session');
function run(){
  const male={window:{}};vm.runInNewContext(fs.readFileSync(path.join(site,'assets/male-v30.js'),'utf8'),male);
  const manifest=JSON.parse(fs.readFileSync(path.join(site,'lesson-audio-v22.json'),'utf8'));
  const legacySentences=manifest.sentences.map(s=>s.audio);
  const paths=[...legacySentences,...Object.values(manifest.words),...Object.values(data.lexicon),...data.questions.map(q=>q.questionAudio)];
  for(const r of paths){
    const original=r.src||r.normal;if(!original)continue;
    const converted=male.window.samMaleClip(original);assert(/male-v30|felix-v31/.test(converted),original);
    assert(fs.statSync(path.join(site,converted)).size>500);
  }
  sandbox.clearInterval=()=>{};sandbox.setInterval=()=>1;sandbox.window.confirm=()=>true;
  t.bootReal(data);assert.equal(t.state.selected,'r30-hire');t.render();assert(html.includes('实录重点')&&html.includes('模拟考场'));
  for(const row of data.real.topics){
    click('real-retrain',row.id);assert.equal(t.state.listeningFocus,true);
    assert(!html.includes(row.question));click('wording');assert.equal(t.state.variant,1);
    click('question-hint');assert(html.includes(row.variants[0].zh));click('answer-start');
    assert.equal(t.state.recorderTarget.expectedText,row.short[0].en);
    click('sentence-index',1);assert.equal(t.state.recorderTarget.expectedText,row.short[1].en);
    if(row.short.length===3){click('sentence-index',2);assert.equal(t.state.recorderTarget.expectedText,row.short[2].en);}
    click('joined');if(row.secondSeam){assert(html.includes('再接第三句'));assert(Object.values(t.state.clips).some(c=>c.text===row.secondSeam&&c.rate===1));}
    assert.equal(t.state.recorderTarget.expectedText,row.short.map(s=>s.en).join(' '));
    assert(html.includes('先练两句交界处'));
    const seam=Object.values(t.state.clips).filter(c=>c.text===row.seam);assert.equal(seam.map(c=>c.rate).join(','),'0.78,1');
    assert(row.short[1].en===row.seam.slice(row.seam.indexOf('. ')+2));
    click('round',3);assert(!html.includes(row.short[0].en));assert.equal(t.state.recorderTarget.assessmentMode,'free');click('real-follow');assert.equal(t.state.recorderTarget.assessmentMode,'free');
    click('real-model');assert(t.state.recorderTarget.expectedText);if(row.id==='r30-location')assert.equal(t.state.recorderTarget.expectedText,data.real.topics.find(x=>x.id==='r30-locationwhy').short.map(x=>x.en).join(' '));
  }
  const tokens=s=>s.match(/U\.S\.|[A-Za-z0-9]+(?:[-’'][A-Za-z0-9]+)*/gi)||[];
  for(const [en,n] of Object.entries(data.real.notes)){
    assert.deepEqual(n.words.map(w=>w[0]),tokens(en));
    assert.deepEqual(tokens(n.parts.map(p=>p[1]).join(' ')),tokens(en));
    for(const [w,zh] of n.words){assert(zh);assert(data.lexicon[w.toLowerCase()].src);}
  }
  for(const p of data.real.profiles){
    click('exam-lobby');click('exam-profile',data.real.profiles.indexOf(p));click('exam-start');
    let sess=t.getSession();if(p.route.includes('r30-hire'))assert.equal(sess.turns.slice(1,3).map(x=>x.id).join(','),'r30-job,r30-hire');assert.equal(sess.turns.length,8);assert.equal(sess.turns[0].id,'intro');assert.equal(new Set(sess.turns.map(v=>v.id)).size,8);
    assert(!html.includes('Please introduce yourself.'));click('exam-next');assert.equal(sess.index,0);
    click('exam-repeat');assert.equal(sess.turns[0].repeats,1);
    t.state.recorderTarget.onTake({duration:8,hasAudio:true,transcript:'I like swimming.'});
    assert.equal(sess.turns[0].seconds,8);click('exam-next');assert.equal(sess.index,1);if(p.route.includes('r30-hire')){assert.equal(sess.turns[1].id,'r30-job');assert.equal(sess.turns[2].id,'r30-hire');}
    if(['Alex','Brian'].includes(p.name)){
      const placeIndex=p.name==='Alex'?1:3;
      while(sess.index<placeIndex){t.state.recorderTarget.onTake({complete:true,duration:5,transcript:'I like swimming.'});click('exam-next');}
      assert.equal(sess.turns[sess.index].id,'r30-location');
      t.state.recorderTarget.onTake({complete:true,duration:5,transcript:'I want to work in Delaware. I like Rehoboth Beach.'});click('exam-next');
      assert.equal(sess.turns[sess.index].id,'r30-locationwhy');
    }
    while(!sess.end)click('exam-skip');
    assert(html.includes('本场复盘')&&html.includes('/ 8')&&html.includes('I like swimming.'));
    for(const clip of Object.values(p.audio))assert(fs.statSync(path.join(site,clip.normal)).size>500);
  }
  for(const row of data.real.topics){
    for(const v of [row.questionAudio,row.fullAudio,row.seamAudio,...row.short.map(s=>s.audio),...row.variants.map(v=>v.audio)]){
      assert(fs.statSync(path.join(site,v.normal)).size>500);
    }
    for(const k of row.related)assert(data.real.topics.some(q=>q.id===k));
  }
  const mark=(heard,assessable=true)=>t.markTurn({id:'r30-hire',heard,assessable});
  assert.equal(mark('I have a Chinese lifeguard certificate. I swim one kilometer every day.').score,10);
  assert.equal(mark('I want to be a lifeguard.').score,0);
  assert.equal(mark('I can swim.',false),null);
  const grades=(hits,misses)=>({turns:[...Array.from({length:hits},()=>({id:'r30-grad',heard:'2029',assessable:true,seconds:1})),...Array.from({length:misses},()=>({skip:true}))]});
  assert(t.examGrade(grades(3,2)).includes('6 / 10 · 通过'));
  assert(t.examGrade(grades(2,3)).includes('4 / 10 · 未通过'));
  assert(t.examGrade({turns:[{seconds:8}]}).includes('总分待定'));
  for(const id of ['r30-location','r30-locationwhy']){
    const row=data.real.topics.find(x=>x.id===id);
    assert.equal(t.markTurn({id,heard:row.short.map(s=>s.en).join(' '),assessable:true}).score,10);
    assert.equal(t.markTurn({id,heard:'I bought a phone.',assessable:true}).score,0);
  }
  console.log('PASS: original lesson and word voice routes; 25 real topics, listening, sentence scoring, boundary practice, joined scoring, related follow-ups; 4 full mock sessions.');
}
vm.runInNewContext(setup+'\n('+run.toString()+')();',{require:createRequire(__filename),__dirname,console,URL});
