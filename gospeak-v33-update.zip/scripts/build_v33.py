"""Publish the one-tap two-round lesson within the existing listening entry points."""
import json,hashlib,shutil
from zipfile import ZipFile
from build_v30 import ROOT,SITE,sub
from build_v31 import pack
def released(name):
    for v in (32,31,30,29,28,26,24,22,19):
        path=ROOT/f'gospeak-v{v}-update.zip'
        if path.exists():
            with ZipFile(path) as z:
                if '_site/'+name in z.namelist():return z.read('_site/'+name).decode()
    return (SITE/name).read_text()
def build():
    track=json.loads((ROOT/'tmp/location-listening-v33.json').read_text())
    template=(ROOT/'assets/location-listen-v33.js').read_text()
    (SITE/'assets/location-listen-v33.js').write_text(sub(template,'/* COURSE_DATA */',json.dumps(track,ensure_ascii=False,separators=(',',':'))))
    shutil.copyfile(ROOT/'assets/location-listen-v33.css',SITE/'assets/location-listen-v33.css')
    assets='<link rel="stylesheet" href="./assets/location-listen-v33.css?v=33"><script defer src="./assets/location-listen-v33.js?v=33"></script>'
    page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>选岗地点 · 连续听练｜快乐出村计划</title>'+assets+'<style>body{background:#f0f3fa;color:#14213a;font:17px/1.6 system-ui,sans-serif;margin:0}main{max-width:750px;margin:0 auto;padding:30px 16px}h1{font-size:clamp(28px,6vw,43px);margin:.7em 0 .3em}a{color:#20459a}nav{display:flex;gap:20px;flex-wrap:wrap}summary{cursor:pointer;padding:10px 0}li{margin:.65em 0}p{margin:0}.translation{color:#46536a}</style><main><nav><a href="./?v=33#location">逐句练习与评分</a><a href="./cards.html?v=33">8 题连续听练</a></nav><h1>选岗地点与理由</h1><location-listen full></location-listen><details><summary>查看两轮对话</summary><ol>'
    for row in track['rows']:page+='<li><strong>'+row['role']+'</strong><p lang="en">'+row['en']+'</p><p class="translation">'+row['zh']+'</p></li>'
    (SITE/'location-listening.html').write_text(page+'</ol></details></main></html>')
    html=released('index.html').replace('V32 ·','V33 ·').replace('cards.html?v=31','cards.html?v=33').replace('>8题连续听练<','>连续听练<').replace('mainline-v21.js?v=22&design=32.1','mainline-v21.js?v=22&design=33').replace('listening-v18.js?v=22&design=31','listening-v18.js?v=22&design=33')
    (SITE/'index.html').write_text(sub(html,'</head>',assets+'</head>'))
    cards=released('cards.html').replace('cards-v24.js?v=31','cards-v24.js?v=33').replace('./?v=29','./?v=33').replace('</head>',assets+'</head>')
    (SITE/'cards.html').write_text(sub(cards,'</header>','</header><div style="max-width:1100px;padding:0 16px;margin:auto"><location-listen></location-listen></div>'))
    cardjs=released('assets/cards-v24.js')
    start=cardjs.index(" if('mediaSession' in navigator)")
    stop=cardjs.index('\n',start)
    session=cardjs[start:stop]
    cardjs=cardjs[:start]+" audio.addEventListener('play',setCardSession);"+cardjs[stop:]
    (SITE/'assets/cards-v24.js').write_text(sub(cardjs,"function playAt(seconds){","function setCardSession(){"+session+"\n}\nfunction playAt(seconds){"))
    js=released('assets/listening-v18.js')
    js=sub(js,"function () {\n      if (window.__samMainlineV19", "function () {\n      setupMediaSession();\n      if (window.__samMainlineV19") if js.count("function () {\n      if (window.__samMainlineV19")==1 else js.replace('state.audio.addEventListener("play", function () {','state.audio.addEventListener("play", function () {\n      setupMediaSession();')
    (SITE/'assets/listening-v18.js').write_text(sub(js,'      "</header>",','      "</header>",\n      "<location-listen></location-listen>",'))
    mainline=released('assets/mainline-v21.js')
    mainline=sub(mainline,"return realHeader(item)+'<div class=\"sam25-panel\"", """if(stage===1&&!follow&&['r30-location','r30-locationwhy'].includes(item.id))content+='<location-listen></location-listen>';
    return realHeader(item)+'<div class="sam25-panel" """.rstrip())
    (SITE/'assets/mainline-v21.js').write_text(mainline)
    worker=released('sw.js').replace("set('design','32.1')","set('design','33')").replace("if(u.pathname.endsWith('/listening-v18.js'))u.searchParams.set('design','31')","if(u.pathname.endsWith('/listening-v18.js'))u.searchParams.set('design','33')")
    digest=hashlib.sha256((html+template+track['sha256']).encode()).hexdigest()[:12]
    import re
    (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,worker))
    paths=['_site/'+f for f in ['location-listening.html','cards.html','index.html','sw.js','assets/cards-v24.js','assets/mainline-v21.js','assets/listening-v18.js','assets/location-listen-v33.css','assets/location-listen-v33.js',track['src'][2:]]]
    paths+=['scripts/location_audio_v33.py','scripts/build_v33.py','scripts/test_dialogue_v33.py','assets/location-listen-v33.js','assets/location-listen-v33.css']
    pack('gospeak-v33-update.zip',paths)
if __name__=='__main__':build()
