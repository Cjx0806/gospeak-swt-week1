"""Check the shipped MP3, its lesson bindings, cue order, and final dialogue."""
import hashlib,json,re
from pathlib import Path
from mutagen.mp3 import MP3
SITE=Path(__file__).resolve().parents[1]/'_site'
js=(SITE/'assets/location-listen-v33.js').read_text()
track=json.loads(re.search(r'const track = (.*?);\n',js).group(1))
real=json.loads((SITE/'interview-v21.json').read_text())['real']
topics={q['id']:q for q in real['topics']}
expect=[]
for number,k in enumerate(('r30-location','r30-locationwhy'),1):
    q=topics[k]
    expect.append((number,'考官',q['question'],q['questionZh']))
    expect.extend((number,'Felix',s['en'],s['zh']) for s in q['short'])
assert [(r['round'],r['role'],r['en'],r['zh']) for r in track['rows']]==expect
stages=['英文','中文','慢读 1/3','慢读 2/3','慢读 3/3']
sequence=[(i,s) for i in range(len(expect)) for s in stages]
sequence.extend((i,'整段对话 · 正常语速') for i in range(len(expect)))
cues=track['cues'];assert [(c['row'],c['phase']) for c in cues]==sequence
for i,c in enumerate(cues):
    end=cues[i+1]['start'] if i+1<len(cues) else track['duration']
    assert c['start']<c['spokenEnd']<end
for i in range(len(expect)):
    row=cues[i*5:i*5+5];length=lambda c:c['spokenEnd']-c['start']
    assert all(length(c)>length(row[0])*1.18 for c in row[2:])
    assert abs(length(row[0])-length(cues[len(stages)*len(expect)+i]))<.001
file=SITE/track['src'];assert hashlib.sha256(file.read_bytes()).hexdigest()==track['sha256']
assert abs(MP3(file).info.length-track['duration'])<.15
assert '<audio loop playsinline controls' in js
for path in ('cards.html','location-listening.html','assets/mainline-v21.js','assets/listening-v18.js'):
    assert '<location-listen' in (SITE/path).read_text()
print(f'PASS: {len(expect)} aligned sentences, {len(cues)} spoken cues, loop-ready MP3 {track["duration"]:.2f}s.')
