(() => {
  'use strict';
  const track = {"src":"./audio/location-v33/felix-location-dialogue.mp3","duration":165.89733333333334,"sha256":"7a2c9e14f91ffa3e2b9115e6de15b494b8f328b46a97584b6cec0e35bc4dd494","rows":[{"role":"考官","round":1,"en":"Which state and city would you like to work in?","zh":"你想在哪个州、哪座城市工作？","src":"./audio/real-v30/0fc666ad13a627c1cbcecb.mp3"},{"role":"Felix","round":1,"en":"I would like to work in Delaware.","zh":"我想在特拉华州工作。","src":"./audio/real-v30/80b3a42b2a67a106b75116.mp3"},{"role":"Felix","round":1,"en":"I like Rehoboth Beach.","zh":"我喜欢里霍博斯比奇这座城市。","src":"./audio/real-v30/8432eca05e07d0d6513e40.mp3"},{"role":"考官","round":2,"en":"Why would you like to work there?","zh":"为什么想在那里工作？","src":"./audio/real-v30/7581aa35418361db23ae13.mp3"},{"role":"Felix","round":2,"en":"I want to be a lifeguard by the sea.","zh":"我想在海边做救生员。","src":"./audio/real-v30/8fe28e704dd582b38bd1ee.mp3"},{"role":"Felix","round":2,"en":"I hope to live close to work.","zh":"我希望住得离上班的地方近一些。","src":"./audio/real-v30/42f588d15abed013aed23b.mp3"},{"role":"Felix","round":2,"en":"I want to save some money.","zh":"我想攒点钱。","src":"./audio/real-v30/28bf34f6287012a0cf3249.mp3"}],"cues":[{"row":0,"phase":"英文","start":0.0,"spokenEnd":3.024},{"row":0,"phase":"中文","start":3.524,"spokenEnd":6.055},{"row":0,"phase":"慢读 1/3","start":6.705,"spokenEnd":10.64975},{"row":0,"phase":"慢读 2/3","start":14.24975,"spokenEnd":18.1945},{"row":0,"phase":"慢读 3/3","start":21.7945,"spokenEnd":25.73925},{"row":1,"phase":"英文","start":29.33925,"spokenEnd":31.196875},{"row":1,"phase":"中文","start":31.696875,"spokenEnd":33.728625},{"row":1,"phase":"慢读 1/3","start":34.378625,"spokenEnd":36.80916666666667},{"row":1,"phase":"慢读 2/3","start":39.329166666666666,"spokenEnd":41.759708333333336},{"row":1,"phase":"慢读 3/3","start":44.27970833333333,"spokenEnd":46.71025},{"row":2,"phase":"英文","start":49.23025,"spokenEnd":50.72795833333333},{"row":2,"phase":"中文","start":51.22795833333333,"spokenEnd":54.21175},{"row":2,"phase":"慢读 1/3","start":54.86175,"spokenEnd":56.81283333333333},{"row":2,"phase":"慢读 2/3","start":58.612833333333334,"spokenEnd":60.563916666666664},{"row":2,"phase":"慢读 3/3","start":62.36391666666667,"spokenEnd":64.315},{"row":3,"phase":"英文","start":66.115,"spokenEnd":68.131},{"row":3,"phase":"中文","start":68.631,"spokenEnd":70.45379166666666},{"row":3,"phase":"慢读 1/3","start":71.10379166666667,"spokenEnd":73.72308333333334},{"row":3,"phase":"慢读 2/3","start":76.24308333333333,"spokenEnd":78.862375},{"row":3,"phase":"慢读 3/3","start":81.382375,"spokenEnd":84.00166666666667},{"row":4,"phase":"英文","start":86.52166666666666,"spokenEnd":88.75079166666667},{"row":4,"phase":"中文","start":89.25079166666667,"spokenEnd":91.54958333333333},{"row":4,"phase":"慢读 1/3","start":92.19958333333334,"spokenEnd":95.12183333333333},{"row":4,"phase":"慢读 2/3","start":98.36183333333334,"spokenEnd":101.28408333333333},{"row":4,"phase":"慢读 3/3","start":104.52408333333334,"spokenEnd":107.44633333333333},{"row":5,"phase":"英文","start":110.68633333333334,"spokenEnd":112.48591666666667},{"row":5,"phase":"中文","start":112.98591666666667,"spokenEnd":115.87683333333334},{"row":5,"phase":"慢读 1/3","start":116.52683333333333,"spokenEnd":118.87095833333333},{"row":5,"phase":"慢读 2/3","start":121.39095833333333,"spokenEnd":123.73508333333334},{"row":5,"phase":"慢读 3/3","start":126.25508333333333,"spokenEnd":128.59920833333334},{"row":6,"phase":"英文","start":131.11920833333335,"spokenEnd":132.43116666666666},{"row":6,"phase":"中文","start":132.93116666666666,"spokenEnd":134.27795833333334},{"row":6,"phase":"慢读 1/3","start":134.92795833333332,"spokenEnd":136.63908333333333},{"row":6,"phase":"慢读 2/3","start":138.79908333333333,"spokenEnd":140.51020833333334},{"row":6,"phase":"慢读 3/3","start":142.67020833333333,"spokenEnd":144.38133333333334},{"row":0,"phase":"整段对话 · 正常语速","start":147.54133333333334,"spokenEnd":150.56533333333334},{"row":1,"phase":"整段对话 · 正常语速","start":151.26533333333333,"spokenEnd":153.12295833333334},{"row":2,"phase":"整段对话 · 正常语速","start":153.50295833333334,"spokenEnd":155.00066666666666},{"row":3,"phase":"整段对话 · 正常语速","start":155.70066666666668,"spokenEnd":157.71666666666667},{"row":4,"phase":"整段对话 · 正常语速","start":158.41666666666666,"spokenEnd":160.64579166666667},{"row":5,"phase":"整段对话 · 正常语速","start":161.02579166666666,"spokenEnd":162.825375},{"row":6,"phase":"整段对话 · 正常语速","start":163.205375,"spokenEnd":164.51733333333334}]};
  if (customElements.get('location-listen')) return;
  class LocationListen extends HTMLElement {
    connectedCallback() {
      const full = this.hasAttribute('full');
      this.innerHTML = '<section class="loc33" aria-label="选岗地点连续听练">'+
        (full?'':'<h3>选岗地点 · 两轮连续听练</h3>')+
        '<p>考官问，Felix 答。每句英文 → 中文 → 慢读三遍，最后听正常语速的完整对话。</p>'+
        '<div class="loc33-actions"><button type="button" data-loc-toggle>▶ 开始循环听</button><button type="button" data-loc-stop disabled>停止</button>'+
        '<a download="Felix-选岗地点-连续听练.mp3">下载 MP3</a></div>'+
        '<audio loop playsinline controls preload="none" aria-label="选岗对话音频"></audio>'+
        '<div class="loc33-captions"><small data-phase></small><p lang="en" data-en></p><p data-zh></p></div>'+
        '<small data-loc-status role="status"></small></section>';
      const audio = this.querySelector('audio'), toggle = this.querySelector('[data-loc-toggle]'), stop = this.querySelector('[data-loc-stop]');
      const status = this.querySelector('[data-loc-status]');
      this.media=audio;
      const controls=this.querySelector('.loc33-captions');
      if(!full){audio.hidden=true;controls.hidden=true;}
      audio.src=track.src;this.querySelector('a').href=track.src;
      let last=-1;
      const update=()=>{
        const index=track.cues.findLastIndex?track.cues.findLastIndex(c=>c.start<=audio.currentTime):track.cues.reduce((i,c,n)=>c.start<=audio.currentTime?n:i,0);
        if(index===last)return;
        last=index;const cue=track.cues[Math.max(0,index)], row=track.rows[cue.row];
        this.querySelector('[data-phase]').textContent='第 '+row.round+' 轮 · '+row.role+' · '+cue.phase;
        this.querySelector('[data-en]').textContent=row.en;
        this.querySelector('[data-zh]').textContent=row.zh;
      };
      const recording=()=>window.__samMainlineV19?.isRecording?.()||document.querySelector('main.layout .practice.listening');
      toggle.onclick=()=>{
        if(recording()){status.textContent='请先结束录音，再开始连续听练。';return;}
        if(!audio.paused){audio.pause();return;}
        if(audio.error)audio.load();
        audio.hidden=false;controls.hidden=false;
        audio.play().catch(e=>{if(e.name!=='AbortError')status.textContent='暂时无法播放，可点播放重试或下载 MP3。';});
      };
      stop.onclick=()=>{audio.pause();audio.currentTime=0;update();toggle.textContent='▶ 开始循环听';stop.disabled=true;status.textContent='已停止，下次从第一问开始。';};
      this.otherPlayer=e=>{if(e.target!==audio&&!audio.paused)audio.pause();};
      this.release=e=>{if(e.detail?.owner!=='location-v33'&&!audio.paused)audio.pause();};
      this.suspend=()=>audio.pause();
      document.addEventListener('play',this.otherPlayer,true);
      window.addEventListener('gospeak-playback-request',this.release);
      window.addEventListener('sam-recorder-start',this.suspend);
      window.addEventListener('pagehide',this.suspend);
      audio.addEventListener('play',()=>{
        if(recording()){audio.pause();status.textContent='请先结束录音。';return;}
        window.dispatchEvent(new CustomEvent('gospeak-playback-request',{detail:{owner:'location-v33'}}));
        document.querySelectorAll('audio,video').forEach(m=>{if(m!==audio&&!m.paused)m.pause();});
        if(navigator.mediaSession){try{
          navigator.mediaSession.metadata=new MediaMetadata({title:'选岗地点 · 两轮连续听练',artist:'快乐出村计划'});
          for(const action of ['play','pause','nexttrack','previoustrack','seekto','seekforward','seekbackward','stop'])navigator.mediaSession.setActionHandler(action,null);
        }catch(_){}}
        toggle.textContent='暂停';stop.disabled=false;audio.hidden=false;controls.hidden=false;
        status.textContent='整段对话结束后会从第一问重新播放。';update();
      });
      audio.addEventListener('pause',()=>{toggle.textContent=audio.currentTime?'继续循环听':'▶ 开始循环听';});
      audio.addEventListener('error',()=>{status.textContent='音频加载失败，可重试或下载 MP3。';});
      audio.addEventListener('timeupdate',update);audio.addEventListener('seeked',update);update();
    }
    disconnectedCallback(){
      document.removeEventListener('play',this.otherPlayer,true);
      window.removeEventListener('gospeak-playback-request',this.release);
      window.removeEventListener('sam-recorder-start',this.suspend);
      window.removeEventListener('pagehide',this.suspend);
      this.media.pause();this.media.removeAttribute('src');this.media.load();
    }
  }
  customElements.define('location-listen',LocationListen);
})();
