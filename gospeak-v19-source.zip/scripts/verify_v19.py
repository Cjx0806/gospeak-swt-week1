"""Fail-closed checks for a prebuilt public V19 site (no network or TTS)."""
import json
from pathlib import Path
import re
import sys
from mutagen.mp3 import MP3


def verify(root):
    root = Path(root)
    course = json.loads((root / 'interview-v19.json').read_text())
    assert course['audioReady'] is True, 'incomplete TTS build'
    assert len(course['questions']) == 24
    assert course['profile']['englishName'] == 'Sam'
    assert course['profile']['majorZh'] == '体育体能训练'
    q22 = next(q for q in course['questions'] if q['id'] == '22')
    assert any('return to China' in s['en'] for s in q22['short'])
    assert any('not confirmed' in s['en'] for s in q22['short'])
    def walk(item):
        if isinstance(item, dict):
            for k, v in item.items():
                if k in ('src','normal','slow') and isinstance(v, str) and v.endswith('.mp3'):
                    assert v.startswith('./audio/'), v
                    assert (root / v).is_file(), v
                    assert MP3(str(root / v)).info.length > 0, v
                else:
                    walk(v)
        elif isinstance(item, list):
            for v in item: walk(v)
    walk(course)
    missing_words = [k for k,v in course['lexicon'].items() if not v.get('ipa') or not v.get('zh')]
    assert not missing_words, missing_words
    audio = json.loads((root / 'listening-v18.json').read_text())
    assert audio['version'] == 'v19'
    assert (root / 'listening-v18.json').read_bytes() == (root / 'audio/v18/manifest.json').read_bytes()
    for module in audio['modules']:
        for track in module['tracks'].values():
            assert track['built'] and track['cues'], track['src']
            last = 0
            for cue in track['cues']:
                assert cue['start'] >= last - 0.002
                assert cue['end'] > cue['start']
                last = cue['end']
            assert abs(last - track['durationSeconds']) < 0.2, (track['src'],last,track['durationSeconds'])
    walk(audio)
    for path in [root/'index.html',root/'interview-v19.json',root/'listening-v18.json',*list((root/'assets').glob('index*.js'))]:
        text = path.read_text()
        for forbidden in ['Junxi', 'junxi', '俊熙', '30天口测', 'My major is business.', '我的专业是商科。']:
            assert forbidden not in text, (path,forbidden)
    html = (root/'index.html').read_text()
    assert 'mainline-v17-profile.js' not in html
    for asset in ['mainline-v19.js','mainline-v19.css','recorder-v19.js','recorder-v19.css']:
        assert (root/'assets'/asset).is_file()
        assert asset in html
    sw = (root/'sw.js').read_text()
    assert "requestUrl.pathname.includes('/audio/')" in sw
    assert 'gospeak-independent-v19-' in sw
    print(f'V19 verified: 24 topics, {len(course["lexicon"])} annotated words, 45 real long tracks with timed bilingual cues; all linked MP3s valid.')


if __name__ == '__main__':
    verify(sys.argv[1] if len(sys.argv)>1 else '_site')
