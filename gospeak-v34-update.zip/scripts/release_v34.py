import json,re,html
from pathlib import Path
from zipfile import ZipFile
from build_v34 import baseline,ROOT,SITE,pack
def release():
    data=json.loads((SITE/'interview-v21.json').read_text())
    track=json.loads((ROOT/'tmp/location-listening-v34.json').read_text())
    js=baseline('assets/mainline-v21.js').replace('course=32.1','course=34')
    js=js.replace("realTopic(last)?last:'r30-hire'", "typeof location!=='undefined'&&location.hash==='#route'?'r30-intro':realTopic(last)?last:'r30-intro'").replace("'#hire','#location'","'#hire','#location','#route'").replace("else chooseReal('r30-hire')","else chooseReal('r30-intro')")
    start=js.index("    return '<header",js.index('function realHeader(item)'))
    end=js.index("      ['听懂问法'",start)
    js=js[:start]+"""    const groups=realData().sequence;
    const index=realData().topics.findIndex(row=>row.id===item.id);
    const group=groups.find(g=>g.ids.includes(item.id));
    const options=groups.map(g=>'<optgroup label="'+esc(g.title)+'">'+g.ids.map(id=>{
      const row=realTopic(id);return '<option value="'+id+'" '+(id===item.id?'selected':'')+'>'+esc(row.title)+'</option>';
    }).join('')+'</optgroup>').join('');
    return '<header class="r30-header"><div><h1>按口测顺序练</h1><p>'+esc(group.title)+' · '+(index<13?'主线 '+(index+1)+' / 13':'延伸追问')+'</p></div><label>选题<select data-real-topic>'+options+
      '</select></label></header><nav class="sam25-steps r30-steps" aria-label="实录训练步骤">'+
"""+js[end:]
    js=js.replace("item.short.length>2?'整段连读':'两句连读'","item.short.length===1?'脱稿短答':item.short.length>2?'整段连读':'两句连读'")
    js=js.replace("const tail=item.seam.split", """if(item.short.length===1)return '<p class="r30-hint">'+esc(item.bridge)+'</p>';
    const tail=item.seam.split""")
    js=js.replace("index===answer.length-1?'学完了，连起来说 →'", "index===answer.length-1?(answer.length===1?'练好了，脱稿说 →':'学完了，连起来说 →')")
    js=js.replace("const pool=q().related.filter(id=>!follow||id!==follow.id);", "const basis=follow?realTopic(follow.id):q();const pool=basis.related.filter(id=>id!==basis.id);")
    js=js.replace("firstFollow[q().id]||pick(pool.length?pool:q().related)", "firstFollow[basis.id]||pick(pool.length?pool:basis.related)")
    ix=js.index("    return realHeader(item)+'<div")
    js=js[:ix]+"""    const rows=realData().topics, pos=rows.findIndex(r=>r.id===item.id), next=rows[pos+1];
    const nav='<nav class="r30-actions" aria-label="顺序练题">'+(pos?btn('real-retrain','上一题',rows[pos-1].id):'')+
      (pos===12?btn('exam-lobby','主线练完，进入模拟考场',null,'r30-primary'): '')+
      (next?btn('real-retrain',(pos===12?'开始延伸追问 · ':'下一题 · ')+next.title,next.id,pos===12?'':'r30-primary'):btn('exam-lobby','进入模拟考场',null,'r30-primary'))+'</nav>';
"""+js[ix:]
    js=js.replace("'+content+'</div>';\n  }\n\n  function examLobby", "'+content+'</div>'+nav;\n  }\n\n  function examLobby")
    js=js.replace("{'r30-job':'r30-hire'", "{'r30-intro':'r30-major','r30-major':'r30-purpose','r30-job':'r30-hire'")
    # Keep examiner routes coherent. Draw a wording still, and retain older sessions.
    start=js.index('    const p=realData().profiles[profileIndex],remaining=')
    end=js.index('    return {profile:profileIndex',start)
    js=js[:start]+"""    const order=realData().profiles[profileIndex].route.slice(), fixedThrough=order.length;
"""+js[end:]
    # JS word boundaries in the V32 generator had been emitted as backspace bytes.
    js=js.replace(chr(8),r'\b')
    js=js.replace("btn('real-study','实录重点'", "btn('real-study','顺序练题'")
    js=js.replace("    const related=rules[0].test(words), first=rules[1].test(words);","""    const namesLocation=turn.id==='r30-location';
    const namesState=namesLocation&&rules[1].test(words),namesCity=namesLocation&&rules[2].test(words);
    const related=namesLocation?!!(namesState||namesCity):rules[0].test(words), first=rules[1].test(words);""")
    js=js.replace("    const score=(related?4:0)+key+expression;", """    const score=namesLocation&&!(namesState&&namesCity)?Math.min(5,(related?4:0)+key+expression):(related?4:0)+key+expression;""")
    # Display the actual component breakdown when only one of the two requested place names was recognized.
    js=js.replace("    const score=namesLocation&&!(namesState&&namesCity)?Math.min(5,(related?4:0)+key+expression):(related?4:0)+key+expression;", """    const relevance=namesLocation&&related&&!(namesState&&namesCity)?1:related?4:0;
    const score=relevance+key+expression;""").replace("'切题 '+(related?4:0)","'切题 '+relevance")
    (SITE/'assets/mainline-v21.js').write_text(js)
    template=(ROOT/'assets/location-listen-v33.js').read_text()
    (SITE/'assets/location-listen-v33.js').write_text(template.replace('/* COURSE_DATA */',json.dumps(track,ensure_ascii=False,separators=(',',':'))))
    page=baseline('location-listening.html').split('<ol>')[0]+'<ol>'+''.join('<li><strong>'+html.escape(r['role'])+'</strong><p lang="en">'+html.escape(r['en'])+'</p><p class="translation">'+html.escape(r['zh'])+'</p></li>' for r in track['rows'])+'</ol></details></main></html>'
    (SITE/'location-listening.html').write_text(page.replace('?v=33','?v=34'))
    for file in ('index.html','cards.html'):
        body=baseline(file).replace('location-listen-v33.js?v=33','location-listen-v33.js?v=34').replace('V33 ·','V34 ·').replace('mainline-v21.js?v=22&design=33','mainline-v21.js?v=22&design=34')
        (SITE/file).write_text(body)
    sw=baseline('sw.js').replace("set('course','32.1')","set('course','34')").replace("endsWith('/mainline-v21.js'))u.searchParams.set('design','33')","endsWith('/mainline-v21.js'))u.searchParams.set('design','34')")
    (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+track['sha256'][:12],sw))
    paths=['_site/'+p for p in ['index.html','cards.html','sw.js','interview-v21.json','location-listening.html','assets/mainline-v21.js','assets/location-listen-v33.js',track['src'][2:]]]
    previous=baseline('interview-v21.json')
    for p in (SITE/'audio/real-v30').glob('*.mp3'):
        if p.name not in previous and p.name in (SITE/'interview-v21.json').read_text():paths.append(str(p.relative_to(ROOT)))
    paths+=['scripts/'+f for f in ('build_v34.py','release_v34.py','location_audio_v33.py','test_v34.cjs')]+['assets/answers-v34.txt']
    pack('gospeak-v34-update.zip',paths)
if __name__=='__main__':release()
