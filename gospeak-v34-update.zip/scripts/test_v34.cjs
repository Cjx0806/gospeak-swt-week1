/* Exercise the published course through its own question, recording and sequence controls. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{createRequire}=require('node:module');
let setup=fs.readFileSync(path.join(__dirname,'test_mainline_v25.cjs'),'utf8').split('\nt.render();')[0];
setup=setup.replace('q,recordSaved,stopSound','q,recordSaved,stopSound,bootReal,markTurn,makeSession');
function audit(){
  t.bootReal(data);t.render();
  assert.equal(t.q().id,'r30-intro');
  const rows=data.real.topics, ids=rows.map(q=>q.id);
  assert.equal(new Set(ids).size,27);
  assert.deepEqual(data.real.sequence.flatMap(s=>s.ids),ids);
  const byId=id=>rows.find(q=>q.id==='r30-'+id);
  assert.equal(byId('location').short.length,1);
  assert.equal(byId('location').short[0].en,'I would like to work in Rehoboth Beach, Delaware.');
  assert.equal(byId('purpose').short[0].en,'I want to experience American culture.');
  assert.deepEqual(byId('purpose').short.map(s=>s.en),data.questions.find(q=>q.id==='15').short.map(s=>s.en));
  assert.equal(byId('grad').short[0].en,'I will graduate in 2029.');
  assert(byId('plans').short[1].en.includes('might also'));
  for(let i=0;i<rows.length;i++){
    const q=rows[i];
    if(i){assert(html.includes('data-value="'+q.id+'"'));click('real-retrain',q.id);}
    assert.equal(t.q().id,q.id);assert(html.includes('顺序练题'));
    click('wording');assert.equal(t.state.variant,1);
    click('answer-start');
    for(let n=0;n<q.short.length;n++){
      click('sentence-index',n);assert.equal(t.state.recorderTarget.expectedText,q.short[n].en);
      assert(html.includes('慢速循环跟读'));assert(html.includes('正常语速循环'));
      assert(data.languageNotes[q.short[n].en].words.length);
      for(const clip of [q.short[n].audio.normal,q.fullAudio.normal])
        assert(fs.statSync(path.join(site,clip)).size>500);
    }
    click('joined');assert.equal(t.state.recorderTarget.expectedText,q.short.map(s=>s.en).join(' '));
    if(q.short.length===1)assert(!html.includes('先练两句交界处'));
    else assert(q.seam.endsWith(q.short[1].en));
    click('round',3);assert.equal(t.state.recorderTarget.assessmentMode,'free');
  }
  for(const [i,p] of data.real.profiles.entries()){
    const turns=t.makeSession(i).turns;assert.equal(turns[0].id,'intro');
    assert.equal(turns.slice(1).map(x=>x.id).join(),p.route.join());assert.equal(turns.length,8);
    for(const id of p.route)for(const en of [byId(id.slice(4)).question,...byId(id.slice(4)).variants.map(v=>v.en)])assert(p.audio[en]);
  }
  const score=(id,heard)=>t.markTurn({id:'r30-'+id,heard,assessable:true}).score;
  assert.equal(score('location',byId('location').short[0].en),10);
  assert.equal(score('location','I like the beach.'),0);
  assert(score('location','I like Rehoboth Beach.')<6);
  assert.equal(score('locationwhy',byId('locationwhy').short.map(s=>s.en).join(' ')),10);
  assert.equal(score('grad','2029'),10);
  console.log('Verified all 27 ordered topics, per-sentence and full-answer targets, four examiner routes, prompt alignment and place scoring.');
}
vm.runInNewContext(setup+'\n('+audit.toString()+')();',{require:createRequire(__filename),__dirname,console,URL});
