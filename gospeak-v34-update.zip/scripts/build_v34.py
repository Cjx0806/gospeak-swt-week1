"""Align prompts, model answers and their recordings across real and library practice."""
import asyncio, copy, hashlib, json, re, shutil
from zipfile import ZipFile
from real_v30 import ROOT, SITE, speech, VOICE
from voice_local_v31 import offline
from language_v29 import tokens, LABELS, gloss
from build_v31 import pack
import location_audio_v33

def baseline(path):
    for version in (33,32,31):
        with ZipFile(ROOT/f'gospeak-v{version}-update.zip') as z:
            if '_site/'+path in z.namelist():return z.read('_site/'+path).decode()
    raise KeyError(path)
def write_json(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':')))
def read_lessons():
    groups={}
    for raw in (ROOT/'assets/answers-v34.txt').read_text().splitlines():
        if raw.startswith('@'):
            key,tip,tail=map(str.strip,raw[1:].split('|'))
            groups[key]=dict(tip=tip,tail=tail,lines=[])
        elif raw and not raw.startswith('#'):
            expr,zh=raw.split(' ~ ')
            parts=[s.split(' ',1) for s in expr.split('|')]
            assert all(r in LABELS for r,_ in parts)
            groups[key]['lines'].append((' '.join(p for _,p in parts),zh,parts))
    return groups

COURSE=[
 ('开场与学业','intro major'),
 ('项目与岗位','purpose job hire swim'),
 ('选岗地点','location locationwhy'),
 ('适应与支持','challenge family'),
 ('毕业与返校','grad plans return'),
 ('经历与工作追问','outdoors sales strength pressure conflict'),
 ('地点与旅行追问','state place visit hobby trip alone independent malaysia vietnam')]
def build():
    data=json.loads(baseline('interview-v21.json')); real=data['real']
    legacy={q['id']:q for q in data['questions']}; bank={q['id'][4:]:q for q in real['topics']}
    lex={**data['lexicon'],**real['lexicon']}; notes={**data['languageNotes'],**real['notes']}
    groups=read_lessons(); requests={}; by_en={}
    def collect(obj):
        if isinstance(obj,list):
            for v in obj:collect(v)
        if isinstance(obj,dict):
            if obj.get('en') and obj.get('zh') and obj.get('audio'):by_en[obj['en']]=obj
            for v in obj.values():collect(v)
    collect(data)
    def audio(en):
        s=speech(en,VOICE); name=hashlib.sha256((s.text+'|'+s.voice+'|'+s.rate).encode()).hexdigest()[:22]
        src='./audio/real-v30/'+name+'.mp3'
        if not (SITE/src).exists():requests[s]=src
        return dict(normal=src,slow=src,slowRate=.78)
    def line(en,zh,parts):
        words=tokens(en)
        if en not in notes:
            roles=[r for r,p in parts for w in tokens(p)]; ls=[w.lower() for w in words]
            meanings=[gloss(k,i,ls,roles[i],lex,' '.join(ls)) for i,k in enumerate(ls)]
            if 'save money on travel' in en:meanings=['那样（指住得近）','可能','帮助','我','省下','钱','在……方面','交通、出行']
            if 'practice my English' in en:meanings=['我','也','想','引出动作 practice','练习','我的','英语','在','工作']
            for i,k in enumerate(ls):
                if k in ('rehoboth','beach') and 'Rehoboth' in en:meanings[i]='里霍博斯比奇（城市名的一部分）'
                if k=='to' and ls[i-1:i]==['close']: meanings[i]='和 close 连用，表示离……近'
                if k=='also':meanings[i]='也，还'
            notes[en]=dict(words=list(zip(words,meanings)),parts=[[r,p.rstrip('.?,')] for r,p in parts],mod=[],inner=[],tips=[])
        base=copy.deepcopy(by_en.get(en,{}))
        base.update(en=en,zh=zh,audio=audio(en),id='s-'+hashlib.sha256(en.encode()).hexdigest()[:12])
        return base
    for row in ['phu|fuː|富（富国岛名称的一部分）','quoc|kwɔk|国（富国岛名称的一部分）','hanoi|hæˈnɔɪ|河内','so|soʊ|所以','easily|ˈiːzəli|轻松地','because|bɪˈkəz|因为','look|lʊk|看；look for 表示寻找','talk|tɔk|交谈','coworkers|ˈkoʊˌwɝkɚz|同事们']:
        w,ipa,zh=row.split('|')
        if w not in lex:lex[w]=dict(ipa=ipa,zh=zh,src=audio(w)['normal'])
    for g in groups.values():g['answer']=[line(*spec) for spec in g['lines']]
    def model(q,lines):
        q['short']=copy.deepcopy(lines)
        en=' '.join(s['en'] for s in lines);q['fullAudio']=lines[0]['audio'] if len(lines)==1 else audio(en)
        if 'cumulativeAudio' in q:q['cumulativeAudio']=[]
    for k,q in bank.items():
        if k not in groups:continue
        g=groups[k];model(q,g['answer']);q['bridge']=g['tip']
        if len(q['short'])==1:q.update(seam='',seamAudio=None)
        else:
            assert q['short'][0]['en'].endswith(g['tail'])
            q['seam']=g['tail']+' '+q['short'][1]['en'];q['seamAudio']=audio(q['seam'])
        if len(q['short'])==3:
            q['secondSeam']='close to work. '+q['short'][2]['en'];q['secondSeamAudio']=audio(q['secondSeam'])
    for k,v in [('state','countrytype'),('vietnam','triproute')]:
        bank[k]['variants']=[groups[v]['answer'][0]]
        for p in real['profiles']:
            if bank[k]['id'] in p['route']:
                p['audio'][bank[k]['variants'][0]['en']]=bank[k]['variants'][0]['audio']
    bank['location']['cue']='state and city 问州和城市。Rehoboth Beach 是完整的城市名，Delaware 是州名。'
    bank['vietnam']['cue']='trip to Vietnam 问旅行经历；what places 问实际去过的地方。'
    def replace_legacy(k,lines,cues):
        q=legacy[k];q.update(branches=[],extra=[],requiresConfirmation=False,readyForAutoplay=True,answerType='short-beginner',scaffold=cues,keywords=cues,examinerIntent='。'.join(cues)+'。',intent='。'.join(cues)+'。')
        model(q,lines)
    edits={
      '02':(legacy['02']['short'][:1],['先说所学专业']),
      '03':(legacy['03']['short'][:1],['直接说学校名称']),
      '04':(bank['hobby']['short'],['说骑行和游泳','用环岛骑行展开爱好']),
      '05':(bank['hobby']['short'],['说空闲时的爱好','举一个骑行例子']),
      '06':(bank['strength']['short'],['说你熟悉的领域','补充另一项长处']),
      '07':(groups['personal']['answer'],['说自己的性格']),
      '08':(bank['sales']['short'],['买卖过二手手机','还帮驾校招过生']),
      '15':(bank['purpose']['short'],['想亲身体验美国文化','也想在工作中练英语']),
      '16':(groups['culture']['answer'],['对美国文化感兴趣','想了解当地生活']),
      '17':(groups['gain']['answer'],['说想取得的具体进步']),
      '26':(bank['alone']['short'],['说独自去过哪里','补充自己喜欢独自旅行']),
      '29':(bank['visit']['short'],['想去纽约','想坐观光直升机']),
      '30':(bank['visit']['short'],['想游览纽约','在那里想做什么']),
      'i02':(legacy['i02']['short'][:1],['问年级，直接回答大一']),
      's03':(bank['return']['short'],['回中国','在那里完成大学学业']),
      'i04':(bank['swim']['short'],['一公里就是一千米','这是每天的训练距离']),
      'i09':(groups['favorite']['answer']+[by_en['I cycled around Hainan Island.']],['喜欢骑行','在海南骑过环岛路线']),
      'i10':(bank['plans']['short'],['想当游泳教练','也可能去韩国留学'])}
    for k,(lines,cues) in edits.items():replace_legacy(k,lines,cues)
    for k in ('01','02'): # normal study steps and recordings, also used at the start of the ordered route
        name='intro' if k=='01' else 'major'
        q=copy.deepcopy(legacy[k]);q.update(id='r30-'+name,title='自我介绍' if k=='01' else '在校专业',category='实录重点',
            related=['r30-major','r30-purpose'] if k=='01' else ['r30-purpose','r30-job'],
            cue='introduce yourself 和 tell me about yourself 都请你介绍自己。' if k=='01' else 'major 和 what do you study 都问你学什么。',
            bridge='名字后稍停，接自己的学生身份。' if k=='01' else '问专业，直接说体育体能训练。',seam='',seamAudio=None)
        if k=='01':
            model(q,q['short']);q['seam']='Felix. '+q['short'][1]['en'];q['seamAudio']=audio(q['seam'])
        bank[name]=q
    # Refresh linked questions that reuse the reviewed model. Never attach the parent answer to a distinct follow-up.
    question_lookup={q['question']:q for q in data['questions']}
    for q in data['questions']:
        for f in q['followups']:
            target=question_lookup.get(f['en'])
            if target and target['id'] in edits:
                f.update(answer=copy.deepcopy(target['short']),answerAudio=target['fullAudio'],hint=target['intent'],requiresConfirmation=False)
    def update_follow(f, lines, hint):
        f.update(answer=copy.deepcopy(lines),answerAudio=audio(' '.join(s['en'] for s in lines)),hint=hint,requiresConfirmation=False)
    update_follow(legacy['06']['followups'][0],bank['sales']['short'][:1],'问例子：用买卖过二手手机说明自己熟悉手机。')
    update_follow(legacy['21']['followups'][0],groups['refund']['answer'],'考官问会不会承诺退款。先说自己会请示主管。')
    replace_legacy('19',groups['howwork']['answer']+[by_en['I would write down useful words.']],['与同事交谈','记下有用的词'])
    update_follow(legacy['17']['followups'][0],legacy['19']['short'],legacy['19']['intent'])
    q=legacy['30']['followups'][0]
    q['answer']=[by_en['I will return to China after SWT.'],by_en['My travel dates are not confirmed yet.']]
    q['answerAudio']=audio(' '.join(r['en'] for r in q['answer']))
    q=legacy['11']
    # The user confirmed past jobs. Their specific takeaway is still personal.
    q['branches']=[b for b in q['branches'] if '[skill]' in ' '.join(s['en'] for s in b['sentences'])]
    q['scaffold']=['先想一个亲自在销售中学会的技能','填入实际收获'];q['examinerIntent']='这题问从工作学到了什么。先补你自己的收获，再练回答。'
    real['topics']=[bank[k] for _,keys in COURSE for k in keys.split()]
    assert set(bank)=={q['id'][4:] for q in real['topics']} and len(bank)==len(real['topics'])
    real['sequence']=[dict(title=t,ids=['r30-'+k for k in ks.split()]) for t,ks in COURSE]
    real['notes'].update({k:v for k,v in notes.items() if k not in data['languageNotes']})
    data['languageNotes'].update(notes);data['lexicon'].update(lex)
    real['lexicon'].update({k:v for k,v in lex.items() if k in ('phu','quoc','hanoi','so','easily','because','look','talk','coworkers')})
    for p in real['profiles']:
        rank={q['id']:i for i,q in enumerate(real['topics'])}
        # Keep each examiner's own material; close on future plans or return.
        closing={'r30-return':100,'r30-grad':98,'r30-plans':99}
        p['route'].sort(key=lambda k:closing.get(k,rank[k]))
    cache=asyncio.run(offline(requests))
    for s,src in requests.items():
        dest=SITE/src;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(cache[s],dest)
    write_json(SITE/'interview-v21.json',data)
    location_audio_v33.build(real,version=34)
    return data

if __name__=='__main__':build()
