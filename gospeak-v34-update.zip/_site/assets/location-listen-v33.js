(() => {
  'use strict';
  const track = {"src":"./audio/location-v34/felix-location-dialogue.mp3","duration":168.617,"sha256":"6b6b7f330223610e3e5526599eaae2596594bf19222c649b50547d9aede1a397","rows":[{"role":"考官","round":1,"en":"Which state and city would you like to work in?","zh":"你想在哪个州、哪座城市工作？","src":"./audio/real-v30/0fc666ad13a627c1cbcecb.mp3"},{"role":"Felix","round":1,"en":"I would like to work in Rehoboth Beach, Delaware.","zh":"我想在特拉华州的里霍博斯比奇市工作。","src":"./audio/real-v30/6a99fdb0d6894c2d4cb38c.mp3"},{"role":"考官","round":2,"en":"Why would you like to work there?","zh":"为什么想在那里工作？","src":"./audio/real-v30/7581aa35418361db23ae13.mp3"},{"role":"Felix","round":2,"en":"I want to be a lifeguard by the sea.","zh":"我想在海边做救生员。","src":"./audio/real-v30/8fe28e704dd582b38bd1ee.mp3"},{"role":"Felix","round":2,"en":"I also hope to live close to work.","zh":"我也希望住得离上班的地方近。","src":"./audio/real-v30/c68ea56f53d24748b6ef39.mp3"},{"role":"Felix","round":2,"en":"That could help me save money on travel.","zh":"这样可能帮我省下交通费。","src":"./audio/real-v30/401bb6f0fe620aba1ba8aa.mp3"}],"cues":[{"row":0,"phase":"英文","start":0.0,"spokenEnd":3.024},{"row":0,"phase":"中文","start":3.524,"spokenEnd":6.055},{"row":0,"phase":"慢读 1/3","start":6.705,"spokenEnd":10.64975},{"row":0,"phase":"慢读 2/3","start":14.24975,"spokenEnd":18.1945},{"row":0,"phase":"慢读 3/3","start":21.7945,"spokenEnd":25.73925},{"row":1,"phase":"英文","start":29.33925,"spokenEnd":32.265},{"row":1,"phase":"中文","start":32.765,"spokenEnd":36.445375},{"row":1,"phase":"慢读 1/3","start":37.095375,"spokenEnd":40.92666666666667},{"row":1,"phase":"慢读 2/3","start":44.166666666666664,"spokenEnd":47.99795833333334},{"row":1,"phase":"慢读 3/3","start":51.23795833333333,"spokenEnd":55.06925},{"row":2,"phase":"英文","start":58.30925,"spokenEnd":60.32525},{"row":2,"phase":"中文","start":60.82525,"spokenEnd":62.648041666666664},{"row":2,"phase":"慢读 1/3","start":63.29804166666667,"spokenEnd":65.91733333333333},{"row":2,"phase":"慢读 2/3","start":68.43733333333333,"spokenEnd":71.056625},{"row":2,"phase":"慢读 3/3","start":73.576625,"spokenEnd":76.19591666666666},{"row":3,"phase":"英文","start":78.71591666666667,"spokenEnd":80.94504166666667},{"row":3,"phase":"中文","start":81.44504166666667,"spokenEnd":83.74383333333333},{"row":3,"phase":"慢读 1/3","start":84.39383333333333,"spokenEnd":87.31608333333334},{"row":3,"phase":"慢读 2/3","start":90.55608333333333,"spokenEnd":93.47833333333334},{"row":3,"phase":"慢读 3/3","start":96.71833333333333,"spokenEnd":99.64058333333334},{"row":4,"phase":"英文","start":102.88058333333333,"spokenEnd":105.06329166666667},{"row":4,"phase":"中文","start":105.56329166666667,"spokenEnd":108.17554166666666},{"row":4,"phase":"慢读 1/3","start":108.82554166666667,"spokenEnd":111.67791666666666},{"row":4,"phase":"慢读 2/3","start":114.55791666666667,"spokenEnd":117.41029166666667},{"row":4,"phase":"慢读 3/3","start":120.29029166666666,"spokenEnd":123.14266666666667},{"row":5,"phase":"英文","start":126.02266666666667,"spokenEnd":128.136625},{"row":5,"phase":"中文","start":128.636625,"spokenEnd":131.28370833333332},{"row":5,"phase":"慢读 1/3","start":131.93370833333333,"spokenEnd":134.70429166666668},{"row":5,"phase":"慢读 2/3","start":137.58429166666667,"spokenEnd":140.354875},{"row":5,"phase":"慢读 3/3","start":143.234875,"spokenEnd":146.00545833333334},{"row":0,"phase":"整段对话 · 正常语速","start":149.88545833333333,"spokenEnd":152.90945833333333},{"row":1,"phase":"整段对话 · 正常语速","start":153.60945833333332,"spokenEnd":156.53520833333334},{"row":2,"phase":"整段对话 · 正常语速","start":157.23520833333333,"spokenEnd":159.25120833333332},{"row":3,"phase":"整段对话 · 正常语速","start":159.95120833333334,"spokenEnd":162.18033333333332},{"row":4,"phase":"整段对话 · 正常语速","start":162.56033333333335,"spokenEnd":164.74304166666667},{"row":5,"phase":"整段对话 · 正常语速","start":165.12304166666667,"spokenEnd":167.237}]};
  if (customElements.get('location-listen')) return;
  class LocationListen extends HTMLElement {
    connectedCallback() {
      const full = this.hasAttribute('full');
      this.innerHTML = '<section class="loc33" aria-label="选岗地点连续听练">'+
        (full?'':'<h3>选岗地点 · 两轮连续听练</h3>')+
        '<p>考官问，Felix 答。每句英文 → 中文 → 慢读三遍，最后听正常语速的完整对话。</p>'+
        '<div class="loc33-actions"><button type="button" data-loc-toggle>▶ 开始循环听</button><button type="button" data-loc-stop disabled>停止</button>'+
        '<a download="Felix-选岗地点-连续听练.mp3">下载 MP3</a></div>'+
        '<audio loop playsinline controls preload="none" aria-label="选岗对话音频"></audio>'+
        '<div class="loc33-captions"><small data-phase></small><p lang="en" data-en></p><p data-zh></p></div>'+
        '<small data-loc-status role="status"></small></section>';
      const audio = this.querySelector('audio'), toggle = this.querySelector('[data-loc-toggle]'), stop = this.querySelector('[data-loc-stop]');
      const status = this.querySelector('[data-loc-status]');
      this.media=audio;
      const controls=this.querySelector('.loc33-captions');
      if(!full){audio.hidden=true;controls.hidden=true;}
      audio.src=track.src;this.querySelector('a').href=track.src;
      let last=-1;
      const update=()=>{
        const index=track.cues.findLastIndex?track.cues.findLastIndex(c=>c.start<=audio.currentTime):track.cues.reduce((i,c,n)=>c.start<=audio.currentTime?n:i,0);
        if(index===last)return;
        last=index;const cue=track.cues[Math.max(0,index)], row=track.rows[cue.row];
        this.querySelector('[data-phase]').textContent='第 '+row.round+' 轮 · '+row.role+' · '+cue.phase;
        this.querySelector('[data-en]').textContent=row.en;
        this.querySelector('[data-zh]').textContent=row.zh;
      };
      const recording=()=>window.__samMainlineV19?.isRecording?.()||document.querySelector('main.layout .practice.listening');
      toggle.onclick=()=>{
        if(recording()){status.textContent='请先结束录音，再开始连续听练。';return;}
        if(!audio.paused){audio.pause();return;}
        if(audio.error)audio.load();
        audio.hidden=false;controls.hidden=false;
        audio.play().catch(e=>{if(e.name!=='AbortError')status.textContent='暂时无法播放，可点播放重试或下载 MP3。';});
      };
      stop.onclick=()=>{audio.pause();audio.currentTime=0;update();toggle.textContent='▶ 开始循环听';stop.disabled=true;status.textContent='已停止，下次从第一问开始。';};
      this.otherPlayer=e=>{if(e.target!==audio&&!audio.paused)audio.pause();};
      this.release=e=>{if(e.detail?.owner!=='location-v33'&&!audio.paused)audio.pause();};
      this.suspend=()=>audio.pause();
      document.addEventListener('play',this.otherPlayer,true);
      window.addEventListener('gospeak-playback-request',this.release);
      window.addEventListener('sam-recorder-start',this.suspend);
      window.addEventListener('pagehide',this.suspend);
      audio.addEventListener('play',()=>{
        if(recording()){audio.pause();status.textContent='请先结束录音。';return;}
        window.dispatchEvent(new CustomEvent('gospeak-playback-request',{detail:{owner:'location-v33'}}));
        document.querySelectorAll('audio,video').forEach(m=>{if(m!==audio&&!m.paused)m.pause();});
        if(navigator.mediaSession){try{
          navigator.mediaSession.metadata=new MediaMetadata({title:'选岗地点 · 两轮连续听练',artist:'快乐出村计划'});
          for(const action of ['play','pause','nexttrack','previoustrack','seekto','seekforward','seekbackward','stop'])navigator.mediaSession.setActionHandler(action,null);
        }catch(_){}}
        toggle.textContent='暂停';stop.disabled=false;audio.hidden=false;controls.hidden=false;
        status.textContent='整段对话结束后会从第一问重新播放。';update();
      });
      audio.addEventListener('pause',()=>{toggle.textContent=audio.currentTime?'继续循环听':'▶ 开始循环听';});
      audio.addEventListener('error',()=>{status.textContent='音频加载失败，可重试或下载 MP3。';});
      audio.addEventListener('timeupdate',update);audio.addEventListener('seeked',update);update();
    }
    disconnectedCallback(){
      document.removeEventListener('play',this.otherPlayer,true);
      window.removeEventListener('gospeak-playback-request',this.release);
      window.removeEventListener('sam-recorder-start',this.suspend);
      window.removeEventListener('pagehide',this.suspend);
      this.media.pause();this.media.removeAttribute('src');this.media.load();
    }
  }
  customElements.define('location-listen',LocationListen);
})();
