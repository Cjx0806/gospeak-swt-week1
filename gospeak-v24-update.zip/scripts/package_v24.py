from pathlib import Path
import hashlib,json,re,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'_site'
shutil.copy2(ROOT/'assets/cards-v24.html',SITE/'cards.html')
shutil.copy2(ROOT/'assets/cards-v24.js',SITE/'assets/cards-v24.js')
html=(SITE/'index.html').read_text()
if 'cards-listen-link' not in html:
    html=html.replace('</aside>','<a class="cards-listen-link" href="./cards.html?v=24" style="display:inline-flex;align-items:center;min-height:44px;padding:8px 14px;background:#175cff;color:white;border-radius:5px;text-decoration:none;font-weight:650">8题连续听练</a></aside>')
html=html.replace('V23 · 快乐出村计划','V24 · 快乐出村计划');(SITE/'index.html').write_text(html)
sw=(SITE/'sw.js').read_text()
digest=hashlib.sha256((SITE/'cards.html').read_bytes()+(SITE/'assets/cards-v24.js').read_bytes()).hexdigest()[:12]
sw=re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,sw)
(SITE/'sw.js').write_text(sw)
paths=[SITE/p for p in ('index.html','sw.js','cards.html','cards-v24.json','assets/cards-v24.js')]
paths += list((SITE/'audio/cards-v24').glob('*.mp3'))
paths += [ROOT/'assets/cards-source-v24.json',ROOT/'assets/cards-v24.html',ROOT/'assets/cards-v24.js',ROOT/'scripts/build_cards_v24.py',ROOT/'scripts/package_v24.py',ROOT/'scripts/verify_cards_v24.py']
with zipfile.ZipFile(ROOT/'gospeak-v24-update.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(ROOT))
workflow=ROOT/'.github/workflows/pages.yml';text=workflow.read_text().replace('Deploy 快乐出村计划 V23','Deploy 快乐出村计划 V24')
if 'unzip -q -o gospeak-v24-update.zip' not in text:text=text.replace('unzip -q -o gospeak-v23-update.zip -d .','unzip -q -o gospeak-v23-update.zip -d .\n          unzip -q -o gospeak-v24-update.zip -d .')
if 'python scripts/verify_cards_v24.py' not in text:text=text.replace('python scripts/verify_v22.py _site','python scripts/verify_v22.py _site\n          python scripts/verify_cards_v24.py\n          node --check _site/assets/cards-v24.js')
workflow.write_text(text)
print('Packaged V24 with one continuous MP3 and synchronized bilingual card player.')
