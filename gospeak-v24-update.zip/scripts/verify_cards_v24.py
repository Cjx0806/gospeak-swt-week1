from pathlib import Path
import hashlib,json
from mutagen.mp3 import MP3
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'_site'
m=json.loads((SITE/'cards-v24.json').read_text())
assert len(m['topics'])==8
assert [t['id'] for t in m['topics']]==list(range(1,9))
audio=SITE/m['audio'];assert audio.is_file()
assert hashlib.sha256(audio.read_bytes()).hexdigest()==m['sha256']
assert abs(MP3(audio).info.length-m['duration'])<.2
assert 600<m['duration']<1800
rows=[r for t in m['topics'] for r in t['rows']]
assert len(rows)==41 and len(m['cues'])==205
for t in m['topics']:
    assert (SITE/t['image']).is_file()
    assert t['start']<=t['rows'][0]['start']<t['end']
    for r in t['rows']:
        cues=[c for c in m['cues'] if c['row']==r['id']]
        assert [c['mode'] for c in cues]==['normal','chinese','slow','slow','slow']
        assert [c['step'] for c in cues]==list(range(5))
        assert cues[0]['start']==r['start'] and cues[-1]['end']==r['end']
        for c in cues:
            p=m['provenance'][c['source']]
            expected=r['zh'] if c['mode']=='chinese' else r['en']
            assert p['text']==expected.replace('SWT','S W T')
            assert p['rate']=={'normal':'-5%','chinese':'+0%','slow':'-25%'}[c['mode']]
            assert c['start']<c['spokenEnd']<c['end']
        assert all(a['end']==b['start'] for a,b in zip(cues,cues[1:]))
assert all(a['end']<=b['start'] for a,b in zip(m['cues'],m['cues'][1:]))
page=(SITE/'cards.html').read_text();player=(SITE/'assets/cards-v24.js').read_text()
assert page.count('<audio ')==1 and 'playsinline' in page
assert 'speechSynthesis' not in player and 'setInterval' not in player
assert 'cards-v24.json?v=24' in player and 'audio.ended?0' in player
assert 'cards-listen-link' in (SITE/'index.html').read_text()
print(f'PASS V24: 8 topics, 41 exact bilingual rows, 205 correctly ordered passes; slow repeats at -25%; single MP3 {m["duration"]:.2f}s verified, all 8 images present.')
