(()=>{'use strict';
const $=s=>document.querySelector(s), audio=$('#player'), status=$('#status');
let data=null,topic=0,lastCue='',saveAt=0,playToken=0,pendingSeek=null;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const stamp=s=>`${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`;
const names=['英文示范','中文意思','慢速英文 1 / 3','慢速英文 2 / 3','慢速英文 3 / 3'];
function showTopic(id){
 if(topic===id)return;topic=id;
 document.querySelectorAll('[data-panel]').forEach(e=>e.hidden=Number(e.dataset.panel)!==id);
 document.querySelectorAll('[data-topic]').forEach(e=>e.setAttribute('aria-pressed',String(Number(e.dataset.topic)===id)));
 $('#current-topic').textContent=`${id} / 8 · ${data.topics[id-1].title}`;
}
function sync(){
 if(!data)return;
 const t=audio.currentTime;
 let cue=data.cues[0];for(const candidate of data.cues){if(candidate.start>t)break;cue=candidate;}
 if(!cue)return;
 showTopic(cue.topic);
 const key=cue.row+':'+cue.step+':'+(t>=cue.spokenEnd?'gap':'voice');
 if(key!==lastCue){
   lastCue=key;
   const row=data.topics[cue.topic-1].rows.find(r=>r.id===cue.row);
   $('#now-en').textContent=row.en;$('#now-zh').textContent=row.zh;
   $('#phase').textContent=names[cue.step]+(t>=cue.spokenEnd?(cue.step>1?' · 留空，轮到你跟读':' · 稍停'):'');
   document.querySelectorAll('[data-row]').forEach(el=>{const active=el.dataset.row===cue.row;el.classList.toggle('active',active);if(active)el.setAttribute('aria-current','true');else el.removeAttribute('aria-current');});
 }
 if(Math.abs(t-saveAt)>5){saveAt=t;try{localStorage.setItem('sam-cards-audio-v24',String(t));}catch{}}
}
function playAt(seconds){
 if(!data)return;
 const token=++playToken,time=Math.max(0,Math.min(seconds,data.duration-.1));
 try{audio.currentTime=time;pendingSeek=null;}catch{pendingSeek=time;}sync();
 const p=audio.play();if(p)p.catch(error=>{if(token!==playToken||error.name==='AbortError')return;status.textContent='暂时无法播放。请检查网络，再点“继续 / 暂停”；也可下载整套音频。';});
}
$('#all').onclick=()=>playAt(0);
$('#toggle').onclick=()=>audio.paused?playAt(audio.ended?0:audio.currentTime):audio.pause();
$('#restart').onclick=()=>{if(data)playAt(data.topics[topic-1].start);};
$('#previous').onclick=()=>{if(data)playAt(data.topics[Math.max(0,topic-2)].start);};
$('#next').onclick=()=>{if(data)playAt(data.topics[Math.min(7,topic)].start);};
$('#loop').onchange=e=>{audio.loop=e.target.checked;};
audio.addEventListener('timeupdate',sync);audio.addEventListener('seeking',sync);
audio.addEventListener('loadedmetadata',()=>{if(pendingSeek!==null){const time=pendingSeek;pendingSeek=null;audio.currentTime=time;sync();}});
audio.addEventListener('play',()=>{status.textContent='连续播放中；每句都是英文 → 中文 → 慢速英文 3 遍。';$('#toggle').textContent='暂停';});
audio.addEventListener('pause',()=>{playToken++;$('#toggle').textContent='继续';if(!audio.ended)status.textContent='已暂停，点击继续会从这里接着读。';});
audio.addEventListener('waiting',()=>status.textContent='正在缓冲音频，请稍等；无需重复点播放。');
audio.addEventListener('playing',()=>status.textContent='正在连续播放。你可以看上方同步句子，也可以展开原版学习卡。');
audio.addEventListener('error',()=>status.textContent='音频加载失败，请检查网络后重试。也可下载整套 MP3 离线听。');
audio.addEventListener('ended',()=>{status.textContent='8 类基础题已播放完。可以重新听，或选一题练习。';$('#toggle').textContent='重新播放';try{localStorage.removeItem('sam-cards-audio-v24');}catch{}});
fetch('./cards-v24.json?v=24').then(r=>{if(!r.ok)throw Error('manifest');return r.json();}).then(m=>{
 data=m;audio.src=m.audio;audio.preload='metadata';
 $('#download').href=m.audio;$('#download').download='Sam-SWT-8类基础题-英中慢速三遍.mp3';
 $('#length').textContent=`整套 ${stamp(m.duration)} · 共 ${m.topics.reduce((n,t)=>n+t.rows.length,0)} 句问答`;
 $('#topics').innerHTML=m.topics.map(t=>`<button type="button" data-topic="${t.id}" aria-pressed="false">${String(t.id).padStart(2,'0')} ${esc(t.title)}</button>`).join('');
 $('#panels').innerHTML=m.topics.map(t=>`<section data-panel="${t.id}" hidden><h2>${String(t.id).padStart(2,'0')} ${esc(t.title)}</h2><p class="clues">先听这些词：${esc(t.clues)}</p><div class="study"><div class="sentences">${t.rows.map(r=>`<article data-row="${r.id}"><span class="kind">${r.kind==='question'?'考官问法':r.kind==='rescue'?'没听懂时直接说':'我的回答'}</span><p lang="en">${esc(r.en)}</p><p class="zh">${esc(r.zh)}</p><button type="button" data-seek="${r.start}">从这句连续听</button></article>`).join('')}<p class="note">${esc(t.note)}</p></div><details class="card" open><summary>展开原版学习卡 · 可长按保存</summary><a href="${t.image}" target="_blank" rel="noopener"><img src="${t.image}" loading="lazy" alt="${esc(t.title)}中英学习卡"></a></details></div></section>`).join('');
 $('#topics').onclick=e=>{const b=e.target.closest('[data-topic]');if(b)playAt(m.topics[Number(b.dataset.topic)-1].start);};
 $('#panels').onclick=e=>{const b=e.target.closest('[data-seek]');if(b)playAt(Number(b.dataset.seek));};
 document.querySelectorAll('[data-ready]').forEach(b=>b.disabled=false);
 showTopic(1);sync();status.textContent='准备好了。点“一次听完 8 题”就会从头连续播放，不需要逐句点击。';
 let saved=0;try{saved=Number(localStorage.getItem('sam-cards-audio-v24'))||0;}catch{}
 if(saved>5&&saved<m.duration-5){$('#resume').hidden=false;$('#resume').textContent=`接着上次 ${stamp(saved)} 听`;$('#resume').onclick=()=>playAt(saved);}
 if('mediaSession' in navigator){try{navigator.mediaSession.metadata=new MediaMetadata({title:'Sam 的 8 类 SWT 口测题',artist:'快乐出村计划',album:'英文 → 中文 → 慢速英文三遍'});navigator.mediaSession.setActionHandler('play',()=>playAt(audio.currentTime));navigator.mediaSession.setActionHandler('pause',()=>audio.pause());navigator.mediaSession.setActionHandler('nexttrack',()=>$('#next').click());navigator.mediaSession.setActionHandler('previoustrack',()=>$('#previous').click());}catch{}}
}).catch(()=>{status.textContent='课程未能加载，请刷新页面重试。';$('#phase').textContent='加载失败';});
})();
