/* Local-first practice recorder. No recording is uploaded by this code.
 * Optional SpeechRecognition is browser-provided and requires explicit opt-in.
 * Transcription differences are NOT a pronunciation score or phoneme analysis.
 */
(function (root) {
  'use strict';

  var DB_NAME = 'gospeak-sam-recordings-v19';
  var MAX_SECONDS = 120;
  var MAX_PER_TARGET = 3;
  var MAX_TOTAL = 18;
  var active = null;
  var sequence = 0;
  var dbPromise = null;
  var storageQueue = Promise.resolve();

  function escapeHTML(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function tokenize(value) {
    var contractions = { "i'm": 'i am', "i've": 'i have', "i'll": 'i will', "i'd": 'i would',
      "it's": 'it is', "that's": 'that is', "there's": 'there is', "don't": 'do not',
      "doesn't": 'does not', "didn't": 'did not', "can't": 'cannot', "won't": 'will not',
      "isn't": 'is not', "aren't": 'are not', "wasn't": 'was not', "we're": 'we are',
      "you're": 'you are', "they're": 'they are', "let's": 'let us' };
    var text = String(value || '').toLowerCase().replace(/[’‘]/g, "'");
    text = text.replace(/[a-z]+'[a-z]+/g, function (word) { return contractions[word] || word; });
    return (text.match(/[a-z0-9]+(?:'[a-z]+)?/g) || []).slice(0, 240);
  }

  function compareText(expected, actual) {
    var a = tokenize(expected), b = tokenize(actual), rows = [];
    var i, j;
    for (i = 0; i <= a.length; i++) {
      rows[i] = [];
      rows[i][0] = i;
    }
    for (j = 0; j <= b.length; j++) rows[0][j] = j;
    for (i = 1; i <= a.length; i++) {
      for (j = 1; j <= b.length; j++) {
        rows[i][j] = Math.min(rows[i - 1][j] + 1, rows[i][j - 1] + 1,
          rows[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
    }
    i = a.length; j = b.length;
    var differences = [];
    while (i || j) {
      if (i && j && a[i - 1] === b[j - 1]) { i--; j--; }
      else if (i && j && rows[i][j] === rows[i - 1][j - 1] + 1) {
        differences.push({ type: 'replacement', expected: a[--i], actual: b[--j] });
      } else if (i && rows[i][j] === rows[i - 1][j] + 1) {
        differences.push({ type: 'missing', expected: a[--i], actual: '' });
      } else {
        differences.push({ type: 'extra', expected: '', actual: b[--j] });
      }
    }
    return { differences: differences.reverse(), expectedCount: a.length, actualCount: b.length };
  }

  function signalAdvice(duration, samples, peakRMS, kind) {
    var advice = [];
    if (duration < 2) advice.push('这条录音不足 2 秒。请听完示范，再完整说一次，不要过早点停止。');
    else if (kind === 'answer' && duration < 20) advice.push('这条录音不足 20 秒。下次尝试「直接回答＋一个真实理由或例子」，目标 20—40 秒，不用为凑时长说空话。');
    else if (kind === 'answer' && duration > 55) advice.push('这条录音较长。回听后保留直接回答和一个真实细节，尝试更简洁地说一次。');
    if (samples > 10 && peakRMS < 0.012) advice.push('检测到的录音电平很低，可能是距离较远、声音小或麦克风问题。请先回听；若听不清，靠近麦克风后重录。');
    if (!samples) advice.push('此设备未提供可用的音量检测。请回放确认录音是否清楚；这不影响音频保存。');
    if (!advice.length) advice.push('录音已完成。现在回听一次，找出最卡的一小句：听示范 → 模仿 3 次 → 再脱稿录一遍。');
    return advice;
  }

  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve, reject) {
      if (!root.indexedDB) { reject(new Error('storage-unavailable')); return; }
      var request = root.indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = function () {
        if (!request.result.objectStoreNames.contains('recordings')) request.result.createObjectStore('recordings', { keyPath: 'key' });
      };
      request.onsuccess = function () { resolve(request.result); };
      request.onerror = function () { reject(request.error || new Error('storage-error')); };
      request.onblocked = function () { reject(new Error('storage-blocked')); };
    });
    return dbPromise;
  }

  async function allRecords() {
    var db = await openDB();
    return new Promise(function (resolve, reject) {
      var request = db.transaction('recordings', 'readonly').objectStore('recordings').getAll();
      request.onsuccess = function () { resolve(request.result.sort(function (a, b) { return b.createdAt - a.createdAt; })); };
      request.onerror = function () { reject(request.error); };
    });
  }

  async function writeRecord(record) {
    var db = await openDB();
    var records = await allRecords();
    records = [record].concat(records.filter(function (entry) { return entry.key !== record.key; }));
    var counts = {}, keep = [], remove = [];
    records.forEach(function (entry) {
      counts[entry.targetId] = (counts[entry.targetId] || 0) + 1;
      if (keep.length < MAX_TOTAL && counts[entry.targetId] <= MAX_PER_TARGET) keep.push(entry.key);
      else remove.push(entry.key);
    });
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('recordings', 'readwrite');
      var store = tx.objectStore('recordings');
      store.put(record);
      remove.forEach(function (key) { store.delete(key); });
      tx.oncomplete = function () { resolve(); };
      tx.onerror = tx.onabort = function () { reject(tx.error || new Error('storage-full')); };
    });
  }

  function storeRecord(record) {
    // Serialize saves from multiple widgets so retention limits stay bounded.
    var result = storageQueue.catch(function () {}).then(function () { return writeRecord(record); });
    storageQueue = result;
    return result;
  }

  async function deleteRecord(key) {
    var db = await openDB();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('recordings', 'readwrite');
      tx.objectStore('recordings').delete(key);
      tx.oncomplete = resolve;
      tx.onerror = tx.onabort = function () { reject(tx.error); };
    });
  }

  function permissionMessage(error) {
    var name = error && error.name;
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError') return '麦克风未获允许。请在 Safari 的网站设置中允许麦克风，再点开始；如果仍不行，可用 iPad「语音备忘录」录音并回听。';
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return '没有找到麦克风。请检查 iPad 或耳机麦克风，再重新打开 Safari。';
    if (name === 'NotReadableError' || name === 'TrackStartError') return '麦克风暂时被占用或不可读取。请关闭通话或其他录音应用，再重试。';
    if (name === 'SecurityError') return '浏览器阻止了麦克风。请使用 HTTPS 网站并检查 Safari 的网站权限。';
    return '录音没有成功开始。请在 Safari 中打开 HTTPS 网站，检查麦克风权限后重试；也可先用「语音备忘录」。';
  }

  function mimeChoice() {
    var types = ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'];
    if (!root.MediaRecorder || !root.MediaRecorder.isTypeSupported) return '';
    return types.find(function (type) { return root.MediaRecorder.isTypeSupported(type); }) || '';
  }

  function mount(container, options) {
    if (typeof container === 'string') container = root.document.querySelector(container);
    if (!container) throw new Error('SamRecorder: container not found');
    var opts = Object.assign({ id: 'practice', title: '开口练习', expectedText: '', kind: 'answer' }, options || {});
    var uid = 'sam-recorder-' + (++sequence);
    var state = { recording: false, starting: false, destroyed: false, stream: null, recorder: null,
      chunks: [], context: null, analyser: null, source: null, frame: 0, timer: 0, samples: 0, peakRMS: 0,
      startedAt: 0, finalTranscript: '', interimTranscript: '', recognition: null, recognitionNote: '',
      stopPromise: null, resolveStop: null, currentRecord: null, urls: [], entries: [], generation: 0 };
    var Recognition = root.SpeechRecognition || root.webkitSpeechRecognition;
    var supported = !!(root.isSecureContext && root.navigator.mediaDevices && root.navigator.mediaDevices.getUserMedia && root.MediaRecorder);
    var api;

    container.innerHTML = '<section class="sam-recorder" aria-labelledby="' + uid + '-title">' +
      '<div class="sam-recorder__heading"><div><span class="sam-recorder__eyebrow">从会读到能回答</span><h4 id="' + uid + '-title"></h4></div><span class="sam-recorder__local">本地录音</span></div>' +
      '<p class="sam-recorder__guide"></p>' +
      '<details class="sam-recorder__reference"><summary>查看本次参考英文 · 脱稿时收起</summary><p lang="en"></p></details>' +
      '<div class="sam-recorder__controls"><button type="button" class="sam-recorder__start"></button><button type="button" class="sam-recorder__stop" disabled>停止并回听</button><span class="sam-recorder__clock" aria-label="录音时长">0:00</span></div>' +
      '<div class="sam-recorder__meter" role="meter" aria-label="麦克风音量，不是发音分数" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span></span></div>' +
      '<p class="sam-recorder__status" role="status" aria-live="polite"></p>' +
      '<details class="sam-recorder__recognition"><summary>可选：识别我说的英文（需联网）</summary><p>勾选后，录音时浏览器可能将你的语音交给其识别服务处理。本网站不接收、不上传你的录音。大陆网络或 Safari 上可能无法识别，不影响本地录音。</p>' +
      '<label><input type="checkbox" class="sam-recorder__consent">我已了解并同意本次使用浏览器联网转写</label><p class="sam-recorder__recognition-note"></p></details>' +
      '<div class="sam-recorder__result" hidden><h5>这一次练习</h5><audio controls playsinline preload="metadata"></audio><a class="sam-recorder__download">下载这条录音</a><div class="sam-recorder__feedback"></div></div>' +
      '<details class="sam-recorder__history"><summary>本题最近的录音</summary><div class="sam-recorder__history-list"></div></details>' +
      '<p class="sam-recorder__privacy">每题最多留 3 条、全站最多 18 条；较旧录音会自动替换。仅存这台设备的浏览器，清理网站数据会丢失，重要录音请下载。不用自评分；文字对照不是发音评分，不能判定哪个音素读错。</p></section>';

    var el = {};
    ['title', 'guide', 'reference', 'start', 'stop', 'clock', 'meter', 'status', 'consent', 'recognition-note', 'result', 'download', 'feedback', 'history-list'].forEach(function (name) {
      el[name] = name === 'title' ? container.querySelector('h4') : container.querySelector('.sam-recorder__' + name);
    });
    el.audio = container.querySelector('audio');

    function status(message) { if (!state.destroyed) el.status.textContent = message; }
    function updateTarget() {
      el.title.textContent = opts.title;
      el.guide.textContent = opts.kind === 'sentence' ? '先听这一句示范，再点开始模仿。录完回听，下一遍只改一个卡点。' : '先听完整示范，再收起答案，独立回答。先说清楚，目标 20—40 秒；不要求一字不差背稿。';
      el.start.textContent = opts.kind === 'sentence' ? '开始录这句' : '开始脱稿录音';
      el.reference.querySelector('p').textContent = opts.expectedText;
      el.reference.hidden = !opts.expectedText;
      el.reference.open = opts.kind === 'sentence';
      el.start.disabled = !supported;
      el.consent.disabled = !Recognition;
      el['recognition-note'].textContent = Recognition ? '默认关闭；每次打开控件需要重新选择。识别结果可能有误，不代表真实发音好坏。' : '当前浏览器没有可用的语音识别接口。请使用下方录音回听；不会假装已经给你评分。';
      status(supported ? '准备好后点开始，允许麦克风。录音时请保持 Safari 在前台。' : '此环境无法网页录音。请用 iPad Safari 打开 HTTPS 网址；若仍不支持，可使用「语音备忘录」。');
    }

    function revokeURLs() {
      state.urls.forEach(function (url) { root.URL.revokeObjectURL(url); });
      state.urls = [];
    }
    function objectURL(blob) { var url = root.URL.createObjectURL(blob); state.urls.push(url); return url; }
    function filename(record) {
      var ext = /mp4|m4a/i.test(record.blob.type) ? 'm4a' : /ogg/i.test(record.blob.type) ? 'ogg' : 'webm';
      return 'Sam-' + String(record.targetId).replace(/[^a-z0-9_-]/gi, '-').slice(0, 45) + '-' + record.createdAt + '.' + ext;
    }

    function renderFeedback(record) {
      var lines = signalAdvice(record.duration, record.samples, record.peakRMS, record.kind);
      var html = '<p><strong>录音时长：' + record.duration.toFixed(1) + ' 秒</strong> · 时长含停顿，不等于连续说话时长</p><ul>' +
        lines.map(function (line) { return '<li>' + escapeHTML(line) + '</li>'; }).join('') + '</ul>';
      if (record.transcript && tokenize(record.transcript).length) {
        html += '<p><strong>浏览器转写（请先核对）</strong></p><p class="sam-recorder__transcript" lang="en">' + escapeHTML(record.transcript) + '</p>';
        if (record.expectedText) {
          var result = compareText(record.expectedText, record.transcript);
          if (!result.differences.length) html += '<p>转写文字与参考句一致。这不代表所有发音都标准；请再听自己的停顿、重音和整句是否自然。</p>';
          else {
            html += '<p><strong>优先复核这些差异（最多 5 项）</strong>：可能来自转写错误、改写或口误，不能直接判定发音错。</p><ul>';
            html += result.differences.slice(0, 5).map(function (difference) {
              if (difference.type === 'missing') return '<li>参考句的 <b lang="en">' + escapeHTML(difference.expected) + '</b> 未出现在转写中。</li>';
              if (difference.type === 'extra') return '<li>转写多出 <b lang="en">' + escapeHTML(difference.actual) + '</b>；若是你主动补充的真实内容，不必删除。</li>';
              return '<li>参考 <b lang="en">' + escapeHTML(difference.expected) + '</b> → 识别为 <b lang="en">' + escapeHTML(difference.actual) + '</b>。</li>';
            }).join('') + '</ul><p>下一步：先回听确认是否真有差异，再听对应句示范，慢说 3 次后重录。整段回答允许用自己的话，不追求逐字一致。</p>';
          }
        }
      } else html += '<p>本次没有可用转写。先回听这一条，再听标准句作对照；不能据此给出词级发音结论。若需专业发音判断，可下载后交给口语老师审听。</p>';
      if (record.recognitionNote) html += '<p class="sam-recorder__muted">' + escapeHTML(record.recognitionNote) + '</p>';
      el.feedback.innerHTML = html;
    }

    function showRecord(record) {
      el.audio.pause();
      revokeURLs();
      el.audio.src = objectURL(record.blob);
      el.download.href = el.audio.src;
      el.download.download = filename(record);
      el.result.hidden = false;
      state.currentRecord = record;
      renderFeedback(record);
    }

    async function refreshHistory() {
      var generation = state.generation;
      try {
        var records = await allRecords();
        if (state.destroyed || generation !== state.generation) return;
        state.entries = records.filter(function (record) { return record.targetId === opts.id; }).slice(0, MAX_PER_TARGET);
        el['history-list'].innerHTML = state.entries.length ? state.entries.map(function (record, i) {
          return '<div class="sam-recorder__history-row"><span>' + escapeHTML(new Date(record.createdAt).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })) + ' · ' + record.duration.toFixed(1) + ' 秒</span><button type="button" data-replay="' + i + '">查看 / 回听</button><button type="button" data-delete="' + i + '">删除此条</button></div>';
        }).join('') : '<p>还没有本题录音。录完后会保存在这里。</p>';
      } catch (_) {
        if (!state.destroyed) el['history-list'].textContent = '浏览器暂时无法持久保存录音。当前页面仍可回听和下载，请及时下载后再离开。';
      }
    }

    function cleanupCapture() {
      if (state.frame) root.cancelAnimationFrame(state.frame);
      root.clearInterval(state.timer);
      if (state.stream) state.stream.getTracks().forEach(function (track) { track.stop(); });
      if (state.source) { try { state.source.disconnect(); } catch (_) {} }
      if (state.context) { state.context.close().catch(function () {}); }
      state.stream = state.context = state.source = state.analyser = null;
      state.frame = state.timer = 0;
      if (active === api) active = null;
    }

    function clockTick() {
      var seconds = Math.floor((root.performance.now() - state.startedAt) / 1000);
      el.clock.textContent = Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
      if (seconds >= MAX_SECONDS) stop('已到 2 分钟上限，正在保存。建议分成短回答反复练。');
    }

    function monitorLevel() {
      if (!state.analyser || !state.recording) return;
      if (state.context && state.context.state !== 'running') {
        state.frame = root.requestAnimationFrame(monitorLevel);
        return;
      }
      var data = new Uint8Array(state.analyser.fftSize);
      state.analyser.getByteTimeDomainData(data);
      var sum = 0;
      for (var i = 0; i < data.length; i++) { var value = (data[i] - 128) / 128; sum += value * value; }
      var rms = Math.sqrt(sum / data.length);
      state.samples++;
      state.peakRMS = Math.max(state.peakRMS, rms);
      var level = Math.min(100, Math.round(rms * 450));
      el.meter.setAttribute('aria-valuenow', String(level));
      el.meter.firstElementChild.style.width = level + '%';
      state.frame = root.requestAnimationFrame(monitorLevel);
    }

    function startRecognition() {
      if (!el.consent.checked || !Recognition) return;
      try {
        var recognizer = new Recognition();
        state.recognition = recognizer;
        recognizer.lang = 'en-US';
        recognizer.continuous = true;
        recognizer.interimResults = true;
        recognizer.onresult = function (event) {
          if (state.recognition !== recognizer) return;
          var complete = [], interim = [];
          for (var i = 0; i < event.results.length; i++) {
            (event.results[i].isFinal ? complete : interim).push(event.results[i][0].transcript);
          }
          state.finalTranscript = complete.join(' ').trim();
          state.interimTranscript = interim.join(' ').trim();
        };
        recognizer.onerror = function (event) {
          if (state.recognition !== recognizer) return;
          state.recognitionNote = event.error === 'network' ? '联网转写不可用（网络或识别服务未响应）；录音仍保留。' :
            event.error === 'not-allowed' || event.error === 'service-not-allowed' ? '浏览器未允许语音识别；已保留本地录音。' :
            event.error === 'no-speech' ? '浏览器未识别出语音；请先检查录音是否清楚。' : '浏览器语音识别未完成；请以实际录音为准。';
        };
        recognizer.onend = function () { if (state.recognition === recognizer && state.recording) state.recognitionNote = '识别服务提前结束，转写可能不完整；本地录音仍继续。'; };
        recognizer.start();
      } catch (_) { state.recognitionNote = '此设备未能启动联网识别，已保留纯本地录音。'; }
    }

    async function finishRecording(snapshot, duration, reason) {
      cleanupCapture();
      // Give browser recognition a bounded chance to deliver its final result.
      if (state.recognition) {
        await new Promise(function (resolve) { root.setTimeout(resolve, 650); });
        try { state.recognition.abort(); } catch (_) {}
        state.recognition = null;
      }
      var type = (state.recorder && state.recorder.mimeType) || (state.chunks[0] && state.chunks[0].type) || 'audio/mp4';
      var blob = new Blob(state.chunks, { type: type });
      state.recorder = null;
      state.chunks = [];
      if (blob.size) {
        var record = { key: String(Date.now()) + '-' + Math.random().toString(36).slice(2, 9), targetId: snapshot.id,
          title: snapshot.title, expectedText: snapshot.expectedText, kind: snapshot.kind, createdAt: Date.now(),
          blob: blob, duration: duration, samples: state.samples, peakRMS: state.peakRMS,
          transcript: [state.finalTranscript, state.interimTranscript].filter(Boolean).join(' '), recognitionNote: state.recognitionNote };
        var saved = true;
        try { await storeRecord(record); } catch (_) { saved = false; }
        if (saved) {
          // Only a newly captured, nonempty, persisted blob emits this event.
          // Restoring/listening to a historical recording never increments practice.
          var detail = { id: record.targetId, kind: record.kind, duration: record.duration,
            savedAt: record.createdAt, bytes: record.blob.size };
          root.dispatchEvent(new CustomEvent('sam-recorder-saved', { detail: detail }));
          if (typeof snapshot.onSaved === 'function') { try { snapshot.onSaved(detail); } catch (_) {} }
        }
        if (!state.destroyed) {
          showRecord(record);
          status(saved ? (reason ? reason + ' ' : '') + '录音已在本机保存，请点播放器回听。' : '录音完成，但浏览器无法保存。请立即下载，离开页面后可能丢失。');
          await refreshHistory();
        }
      } else status('没有生成有效音频。请检查权限，并保持 Safari 在前台重新录制。');
      state.starting = false;
      if (!state.destroyed) {
        el.start.disabled = !supported;
        el.stop.disabled = true;
        el.consent.disabled = !Recognition;
        container.classList.remove('is-recording');
      }
      if (state.resolveStop) state.resolveStop();
      state.resolveStop = null;
      state.stopPromise = null;
    }

    async function start() {
      if (state.recording || state.starting || state.destroyed || !supported) return;
      if (active && active !== api) { status('另一个练习正在录音。请先停止并保存那一条，再开始这里。'); return; }
      active = api;
      state.starting = true;
      state.stopRequested = false;
      el.start.disabled = true;
      el.consent.disabled = true;
      el.audio.pause();
      status('正在请求麦克风权限，请在弹窗中选择允许。');
      try {
        root.dispatchEvent(new CustomEvent('sam-recorder-start', { detail: { id: opts.id } }));
        if (typeof opts.onStart === 'function') { try { opts.onStart(); } catch (_) {} }
        if (opts.kind === 'answer') el.reference.open = false;
        state.stream = await root.navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        if (state.destroyed || state.stopRequested) { cleanupCapture(); state.starting = false; return; }
        var type = mimeChoice();
        try { state.recorder = type ? new root.MediaRecorder(state.stream, { mimeType: type }) : new root.MediaRecorder(state.stream); }
        catch (_) { state.recorder = new root.MediaRecorder(state.stream); }
        var snapshot = Object.assign({}, opts);
        var endReason = '';
        state.chunks = []; state.samples = 0; state.peakRMS = 0;
        state.finalTranscript = ''; state.interimTranscript = ''; state.recognitionNote = '';
        state.recorder.ondataavailable = function (event) { if (event.data && event.data.size) state.chunks.push(event.data); };
        state.recorder.onstop = function () {
          var duration = (root.performance.now() - state.startedAt) / 1000;
          state.recording = false;
          finishRecording(snapshot, duration, state.endReason || endReason).catch(function () {
            cleanupCapture(); state.starting = false; status('音频处理失败，请重试或改用「语音备忘录」。');
            if (state.resolveStop) state.resolveStop();
          });
        };
        state.recorder.onerror = function () { endReason = '录音过程中浏览器报告异常，请回听确认是否完整。'; stop(endReason); };
        state.recorder.start();
        state.endReason = '';
        state.startedAt = root.performance.now();
        state.recording = true;
        state.starting = false;
        state.stopPromise = new Promise(function (resolve) { state.resolveStop = resolve; });
        el.stop.disabled = false;
        container.classList.add('is-recording');
        try {
          var Context = root.AudioContext || root.webkitAudioContext;
          if (Context) {
            state.context = new Context();
            if (state.context.state === 'suspended') state.context.resume().catch(function () {});
            state.source = state.context.createMediaStreamSource(state.stream);
            state.analyser = state.context.createAnalyser();
            state.analyser.fftSize = 1024;
            state.source.connect(state.analyser);
            monitorLevel();
          }
        } catch (_) { /* Recording still works without an audio-level meter. */ }
        startRecognition();
        state.timer = root.setInterval(clockTick, 250);
        status('正在录音。说完点「停止并回听」；离开页面或锁屏会结束本次录音。');
      } catch (error) {
        cleanupCapture();
        state.starting = false;
        el.start.disabled = !supported;
        el.consent.disabled = !Recognition;
        status(permissionMessage(error));
      }
    }

    function stop(reason) {
      if (state.starting && !state.recorder) { state.stopRequested = true; return Promise.resolve(); }
      if (!state.recording) return state.stopPromise || Promise.resolve();
      state.endReason = typeof reason === 'string' ? reason : '';
      state.starting = true;
      el.stop.disabled = true;
      status('正在停止并保存，请稍等，不要关闭页面。');
      if (state.recognition) { try { state.recognition.stop(); } catch (_) {} }
      if (state.recorder && state.recorder.state !== 'inactive') state.recorder.stop();
      return state.stopPromise || Promise.resolve();
    }

    function visibilityChanged() {
      if (root.document.hidden && state.recording) stop('页面进入后台，本次录音已停止。');
    }
    function beforeLeave(event) {
      if (state.recording || state.starting) { event.preventDefault(); event.returnValue = ''; }
    }
    function pageHide() {
      if (state.starting && !state.recorder) state.stopRequested = true;
      if (state.recording) stop();
      cleanupCapture();
    }
    function historyAction(event) {
      var replay = event.target.closest('[data-replay]');
      var remove = event.target.closest('[data-delete]');
      if (state.recording || state.starting) { status('请先停止并保存录音，再查看或删除历史记录。'); return; }
      if (replay) { var record = state.entries[Number(replay.dataset.replay)]; if (record) { showRecord(record); el.result.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } }
      if (remove) {
        var target = state.entries[Number(remove.dataset.delete)];
        if (target) deleteRecord(target.key).then(function () {
          if (state.currentRecord && state.currentRecord.key === target.key) { el.audio.pause(); el.audio.removeAttribute('src'); revokeURLs(); el.result.hidden = true; state.currentRecord = null; }
          status('已删除这条本地录音，不能从本页面恢复。'); refreshHistory();
        }).catch(function () { status('删除没有成功，请稍后重试。'); });
      }
    }

    el.start.addEventListener('click', start);
    el.stop.addEventListener('click', function () { stop(); });
    el['history-list'].addEventListener('click', historyAction);
    root.document.addEventListener('visibilitychange', visibilityChanged);
    root.addEventListener('beforeunload', beforeLeave);
    root.addEventListener('pagehide', pageHide);

    api = {
      start: start,
      stop: stop,
      isRecording: function () { return state.recording || state.starting; },
      setTarget: async function (next) {
        // Do not abandon a pending permission prompt or silently switch its target.
        if (state.starting && !state.recorder) { status('请先处理麦克风权限提示，再切换练习。'); return false; }
        await stop('已切换练习，前一条录音已停止并保存。');
        state.generation++;
        opts = Object.assign({}, opts, next || {});
        el.audio.pause(); el.audio.removeAttribute('src'); el.audio.load();
        revokeURLs(); el.result.hidden = true; el.consent.checked = false;
        updateTarget(); await refreshHistory(); return true;
      },
      destroy: async function () {
        await stop();
        state.destroyed = true;
        state.generation++;
        cleanupCapture();
        if (state.recognition) { try { state.recognition.abort(); } catch (_) {} }
        el.audio.pause(); el.audio.removeAttribute('src'); el.audio.load(); revokeURLs();
        root.document.removeEventListener('visibilitychange', visibilityChanged);
        root.removeEventListener('beforeunload', beforeLeave);
        root.removeEventListener('pagehide', pageHide);
        container.innerHTML = '';
      }
    };
    updateTarget(); refreshHistory();
    return api;
  }

  root.SamRecorder = { mount: mount, compareText: compareText, signalAdvice: signalAdvice };
  if (typeof module !== 'undefined' && module.exports) module.exports = { tokenize: tokenize, compareText: compareText, signalAdvice: signalAdvice, permissionMessage: permissionMessage };
})(typeof window !== 'undefined' ? window : globalThis);
