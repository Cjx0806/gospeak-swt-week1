"""Publish Felix's opening questions as shared study, mock-exam and listening material."""
import asyncio, hashlib, html, json, re, shutil
from zipfile import ZipFile
from build_v31 import pack
from real_v30 import ROOT, SITE, speech, VOICE
from language_v29 import tokens
from voice_local_v31 import offline
from location_audio_v33 import compose

with ZipFile(ROOT/'gospeak-v34-update.zip') as base:
    def previous(name): return base.read('_site/'+name).decode()
    course=json.loads(previous('interview-v21.json'))
    player=previous('assets/mainline-v21.js')
    index=previous('index.html')
    cards=previous('cards.html')
    listening_page=previous('location-listening.html')
    worker=previous('sw.js')
real=course['real']
topics={r['id']:r for r in real['topics']}
requests={}
def clip(en):
    s=speech(en,VOICE)
    key=hashlib.sha256((s.text+'|'+s.voice+'|'+s.rate).encode()).hexdigest()[:22]
    src='./audio/real-v30/'+key+'.mp3'
    requests[s]=src
    return dict(normal=src,slow=src,slowRate=.78)

vocabulary={
    "i'm":("aɪm","我是；I am 的缩写"), "what's":("wʌts","what is 的缩写"),
    "yulin":("yù lín","玉林（这里标普通话拼音）"),"hometown":("ˈhoʊmtaʊn","家乡"),
    "easygoing":("ˌiːziˈɡoʊɪŋ","随和的"),"outgoing":("ˈaʊtˌɡoʊɪŋ","外向的"),
    "personality":("ˌpɝsəˈnæləti","性格"),"describe":("dɪˈskraɪb","描述")}
for word,(ipa,zh) in vocabulary.items():
    real['lexicon'][word]=dict(ipa=ipa if word!='yulin' else '',zh=zh,src=clip(word if word!='yulin' else 'Yulin')['normal'])
def line(en,zh,parts,meanings):
    words=tokens(en); values=meanings.split('|')
    assert len(words)==len(values) and tokens(' '.join(p for _,p in parts))==words,en
    real['notes'][en]=dict(words=list(zip(words,values)),parts=parts,mod=[],inner=[],tips=[])
    return dict(en=en,zh=zh,audio=clip(en))
def topic(key,title,cue,questions,reply,next_key):
    q,*variants=questions
    return dict(id=key,title=title,cue=cue,question=q['en'],questionZh=q['zh'],questionAudio=q['audio'],
        variants=variants,short=[reply],fullAudio=reply['audio'],related=[next_key],category='开场三问',
        seam='',seamAudio=None,bridge='这一句就能回答考官。',extra=[],branches=[],followups=[])
home='r35-home'; personality='r35-personality'; sales='r30-sales'; opening=[home,personality,sales]
topics[home]=topic(home,'来自哪里','from 是“来自”，hometown 是“家乡”。听到这两个词，先报城市。',
    [line('Where are you from?','你来自哪里？',[('PO','Where'),('K','are'),('S','you'),('PRE','from')],'哪里|是（和 from 连用）|你|来自'),
     line('Which city are you from?','你来自哪座城市？',[('PO','Which city'),('K','are'),('S','you'),('PRE','from')],'哪一个|城市|是|你|来自'),
     line("What's your hometown?",'你的家乡是哪里？',[('P',"What's"),('S','your hometown')],'是什么|你的|家乡')],
    line("I'm from Yulin, Guangxi.",'我来自广西玉林。',[('S',"I'm"),('G','from Yulin, Guangxi')],'我是（I am 的缩写）|来自|玉林|广西'),personality)
topics[personality]=topic(personality,'性格怎么样','personality 和 What are you like 都问性格。What do you like to do 才问爱好。',
    [line("What's your personality like?",'你的性格怎么样？',[('W',"What's"),('S','your personality'),('PRE','like')],'是什么（和 like 合起来问“怎么样”）|你的|性格|像……；这里问特点'),
     line('What are you like?','你是个怎样的人？',[('PO','What'),('K','are'),('S','you'),('PRE','like')],'什么|是|你|像……；这里问特点'),
     line('How would you describe your personality?','你会怎样形容自己的性格？',[('W','How'),('U','would'),('S','you'),('V','describe'),('O','your personality')],'怎样|会|你|描述|你的|性格')],
    line("I'm easygoing and outgoing.",'我很随和，也很外向。',[('S',"I'm"),('P','easygoing and outgoing')],'我是|随和的|和，也|外向的'),sales)
def split_contraction(en,first,role):
    n=real['notes'][en];n['parts']=[[role,first],['K','am' if first=='I' else 'is']]+n['parts'][1:]
    n['tips']=[("I'm 是 I am 的缩写。" if first=='I' else "What's 是 What is 的缩写。")]
split_contraction(topics[home]['short'][0]['en'],'I','S')
split_contraction(topics[personality]['short'][0]['en'],'I','S')
split_contraction("What's your hometown?",'What','P')
split_contraction("What's your personality like?",'What','PO')
topics[sales]['variants'].append(line('What kind of work have you done before?','你以前做过哪类工作？',[('O','What kind of work'),('U','have'),('S','you'),('V','done'),('T','before')],'什么|种类|……的|工作|助动词，问经历|你|做过|以前'))
topics[sales]['cue']='听 work experience（工作经历），或 jobs / work 和 done（做过）。先说买卖过二手手机；also 带出驾校招生。'
real['sequence'][0]['ids']=['r30-intro',*opening,'r30-major']
real['sequence'][0]['title']='开场与个人背景'
for g in real['sequence'][1:]:g['ids']=[v for v in g['ids'] if v!=sales]
real['topics']=[topics[k] for g in real['sequence'] for k in g['ids']]
real['mainCount']=sum(len(g['ids']) for g in real['sequence'][:5])
topics['r30-intro']['related']=[home]
routes={'Alex':['purpose','location','locationwhy','return'],'Brian':['job','hire','location','locationwhy'],
        'Eric':['strength','trip','alone','return'],'Andrew':['job','hire','conflict','pressure']}
for p in real['profiles']:
    p['route']=opening+['r30-'+k for k in routes[p['name']]]
    for id in opening:
        q=topics[id]
        for en,a in [(q['question'],q['questionAudio'])]+[(v['en'],v['audio']) for v in q['variants']]:
            p['audio'].setdefault(en,a)
# Keep previous exam audio bindings for stored in-progress sessions.
extra_audio=[]
missing={s for s,src in requests.items() if not (SITE/src).exists()}
for s,src in asyncio.run(offline(missing)).items():shutil.copyfile(src,SITE/requests[s])
for src in requests.values():extra_audio.append('_site/'+src[2:])
rows=[]
for num,k in enumerate(opening,1):
    q=topics[k]
    rows.append(dict(round=num,role='考官',en=q['question'],zh=q['questionZh'],src=q['questionAudio']['normal']))
    for v in q['variants']:rows.append(dict(round=num,role='考官 · 换个问法',alternate=True,en=v['en'],zh=v['zh'],src=v['audio']['normal']))
    for a in q['short']:rows.append(dict(round=num,role='Felix',en=a['en'],zh=a['zh'],src=a['audio']['normal']))
track=compose(rows,'opening-v35','felix-opening','家乡、性格和工作经历',ROOT/'tmp/opening-v35.json')
def dump(o):return json.dumps(o,ensure_ascii=False,separators=(',',':'))
def patch(text,old,new):
    assert old in text,old
    return text.replace(old,new)
player=patch(player,'course=34','course=35')
player=patch(player,"location.hash==='#location'?", "location.hash==='#opening'?'r35-home':typeof location!=='undefined'&&location.hash==='#location'?")
player=patch(player,"'#location','#route'","'#location','#route','#opening'")
player=patch(player,"index<13?'主线 '+(index+1)+' / 13'","index<realData().mainCount?'主线 '+(index+1)+' / '+realData().mainCount")
player=patch(player,'pos===12','pos===realData().mainCount-1')
player=patch(player,"'r30-intro':'r30-major'","'r30-intro':'r35-home','r35-home':'r35-personality','r35-personality':'r30-sales'")
player=patch(player,"!follow&&firstFollow[basis.id]", "((!follow||['r35-home','r35-personality'].includes(basis.id))&&firstFollow[basis.id])")
player=patch(player,"if(stage===1&&!follow&&['r30-location'", "if(stage===1&&!follow&&['r35-home','r35-personality','r30-sales'].includes(item.id))content+='<opening-listen></opening-listen>';\n    if(stage===1&&!follow&&['r30-location'")
player=patch(player,"const examRules={",r"""const examRules={
    'r35-home':[/\b(yu ?lin|guang ?xi)\b/,/\byu ?lin\b/,null],
    'r35-personality':[/easy[ -]?going|out[ -]?going|cheerful|optimistic|friendly|positive/,/easy[ -]?going|out[ -]?going|cheerful|optimistic|friendly|positive/,null],""")
player=patch(player,"const compact=turn.id==='r30-location'","const compact=turn.id==='r35-home'&&first||turn.id==='r35-personality'&&first||turn.id==='r30-location'")
player=patch(player,"    return {score,why:", """    if(turn.id==='r35-home'&&!first)advice='先报家乡城市。玉林的英文转写可能有误，可以回听核对。';
    return {score,why:""")
template=(ROOT/'assets/location-listen-v33.js').read_text()
new_player=template.replace('/* COURSE_DATA */',dump(track)).replace('location-listen','opening-listen').replace('location-v33','opening-v35').replace('选岗地点 · 两轮连续听练','家乡、性格、工作经历 · 三轮连续听练').replace('选岗地点','开场三问').replace('选岗对话音频','开场三问音频')
insert='<script defer src="./assets/opening-listen-v35.js?v=35"></script>'
index=index.replace('</head>',insert+'</head>').replace('V34 ·','V35 ·').replace('design=34','design=35').replace('cards.html?v=33','cards.html?v=35')
cards=cards.replace('</head>',insert+'</head>').replace('<location-listen>','<opening-listen></opening-listen><location-listen>')
opening_page=listening_page.split('<ol>')[0].replace('assets/location-listen-v33.js?v=34','assets/opening-listen-v35.js?v=35').replace('选岗地点 ·','开场三问 ·').replace('选岗地点与理由','家乡、性格和工作经历').replace('?v=34#location','?v=35#opening').replace('查看两轮对话','查看三轮问答与换问法').replace('location-listen full','opening-listen full').replace('</location-listen>','</opening-listen>')
opening_page+='<ol>'+''.join('<li><strong>'+r['role']+'</strong><p lang="en">'+html.escape(r['en'])+'</p><p class="translation">'+r['zh']+'</p></li>' for r in rows)+'</ol></details></main></html>'
worker=worker.replace("set('course','34')","set('course','35')").replace("endsWith('/mainline-v21.js'))u.searchParams.set('design','34')","endsWith('/mainline-v21.js'))u.searchParams.set('design','35')")
worker=re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+hashlib.sha256((player+dump(course)+new_player).encode()).hexdigest()[:12],worker)
outputs={'interview-v21.json':dump(course),'assets/mainline-v21.js':player,'index.html':index,'sw.js':worker,'assets/opening-listen-v35.js':new_player,'cards.html':cards,'opening-listening.html':opening_page}
for name,contents in outputs.items():(SITE/name).write_text(contents)
pack('gospeak-v35-update.zip',['_site/'+p for p in outputs]+extra_audio+['_site/'+track['src'][2:],'scripts/build_v35.py','scripts/location_audio_v33.py','scripts/test_v35.cjs'])
