const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{createRequire}=require('node:module');
let setup=fs.readFileSync(path.join(__dirname,'test_mainline_v25.cjs'),'utf8').split('\nt.render();')[0];
setup=setup.replace('q,recordSaved,stopSound','q,recordSaved,stopSound,bootReal,markTurn,makeSession');
function check(){
  t.bootReal(data);t.render();
  const ids=['r35-home','r35-personality','r30-sales'];
  const byId=id=>data.real.topics.find(q=>q.id===id);
  assert.equal(data.real.topics.slice(0,4).map(q=>q.id).join(),['r30-intro',...ids].join());
  assert.equal(data.real.mainCount,16);
  const all=data.real.sequence.flatMap(g=>g.ids);assert.equal(new Set(all).size,all.length);
  assert.equal(all.join(),data.real.topics.map(q=>q.id).join());
  for(const [i,p] of data.real.profiles.entries()){
    const turns=t.makeSession(i).turns;
    assert.equal(turns.length,8);assert.equal(new Set(turns.map(s=>s.id)).size,8);
    assert.equal(turns.slice(0,4).map(s=>s.id).join(),['intro',...ids].join());
    for(const id of p.route){
      const q=byId(id);
      for(const en of [q.question,...q.variants.map(s=>s.en)]){
        assert(p.audio[en]);assert(fs.statSync(path.join(site,p.audio[en].normal)).size>500);
      }
    }
  }
  const src=fs.readFileSync(path.join(site,'assets/opening-listen-v35.js'),'utf8');
  const track=JSON.parse(src.match(/const track = (.*);\n/)[1]);
  assert(src.includes('<audio loop playsinline controls'));
  const expected=[];
  for(const [index,id] of ids.entries()){
    const q=byId(id);click('real-retrain',id);assert(html.includes('<opening-listen>'));
    for(let i=0;i<q.variants.length;i++){
      click('wording');assert.equal(t.state.variant,i+1);
    }
    click('answer-start');
    for(const [i,s] of q.short.entries()){click('sentence-index',i);assert.equal(t.state.recorderTarget.expectedText,s.en);assert.equal(t.state.recorderTarget.assessmentMode,'scripted');}
    click('joined');assert.equal(t.state.recorderTarget.expectedText,q.short.map(s=>s.en).join(' '));
    click('round',3);assert.equal(t.state.recorderTarget.assessmentMode,'free');
    assert.equal(t.markTurn({id,heard:q.short.map(s=>s.en).join(' '),assessable:true}).score,10);
    const items=[q.question,...q.variants.map(v=>v.en),...q.short.map(s=>s.en)];
    expected.push(...items);for(const en of items){
      assert(data.languageNotes[en]);for(const [w,zh] of data.languageNotes[en].words){assert(zh);assert(data.lexicon[w.toLowerCase()].src,w);}
    }
    assert.equal(track.rows.filter(r=>r.round===index+1).map(r=>r.en).join(),items.join());
  }
  assert.equal(track.rows.map(r=>r.en).join(),expected.join());
  const cues=track.cues;for(const [i,row] of track.rows.entries()){
    assert.equal(cues.filter(c=>c.row===i).map(c=>c.phase).join(),['英文','中文','慢读 1/3','慢读 2/3','慢读 3/3',...(row.alternate?[]:['整段对话 · 正常语速'])].join());
  }
  assert.equal(require('node:crypto').createHash('sha256').update(fs.readFileSync(path.join(site,track.src))).digest('hex'),track.sha256);
  console.log('Verified three opening topics, three wordings each, four mock exams, per-sentence and joined scoring, and bilingual continuous audio.');
}
vm.runInNewContext(setup+'\n('+check.toString()+')();',{require:createRequire(__filename),__dirname,console,URL});
