"""Assemble one seamless loop from the V32 interview prompts and answers."""
import asyncio, hashlib, io, json, subprocess, wave
from pathlib import Path
from zipfile import ZipFile
import imageio_ffmpeg
from build_v30 import ROOT, SITE
from real_v30 import Speech
from voice_local_v31 import offline

def build(course=None, version=33):
    if course is None:
        with ZipFile(ROOT/'gospeak-v32-update.zip') as archive:
            course=json.loads(archive.read('_site/interview-v21.json'))['real']
    questions={q['id']:q for q in course['topics']}
    examiner=next(p for p in course['profiles'] if p['name']=='Brian')
    rows=[]
    for number,key in enumerate(('r30-location','r30-locationwhy'),1):
        q=questions[key]
        rows.append(dict(role='考官',round=number,en=q['question'],zh=q['questionZh'],src=examiner['audio'][q['question']]['normal']))
        rows.extend(dict(role='Felix',round=number,en=line['en'],zh=line['zh'],src=line['audio']['normal']) for line in q['short'])
    return compose(rows, f'location-v{version}', 'felix-location-dialogue', '选岗地点与理由',
                   ROOT/f'tmp/location-listening-v{version}.json')

def compose(rows, folder, filename, title, manifest_path):
    translations=[Speech(row['zh'],'zh-CN-XiaoxiaoNeural','+0%') for row in rows]
    cn=asyncio.run(offline(translations))
    ff=imageio_ffmpeg.get_ffmpeg_exe()
    def pcm(path,slow=False):
        command=[ff,'-v','error','-i',str(path)]
        if slow:command+=['-af','atempo=0.76']
        return subprocess.check_output(command+['-ar','24000','-ac','1','-f','s16le','pipe:1'])
    track=bytearray();cues=[];normals=[]
    def append(index,phase,clip,rest):
        start=len(track)/48000;track.extend(clip);end=len(track)/48000
        cues.append(dict(row=index,phase=phase,start=start,spokenEnd=end))
        track.extend(bytes(2*round(24000*rest)))
    for i,(row,zh) in enumerate(zip(rows,translations)):
        source=SITE/row['src'];normal=pcm(source);slow=pcm(source,True);normals.append(normal)
        append(i,'英文',normal,.5);append(i,'中文',pcm(cn[zh]),.65)
        for repeat in range(1,4):append(i,'慢读 '+str(repeat)+'/3',slow,min(4.8,max(1.8,len(row['en'].split())*.36)))
    track.extend(bytes(48000))
    for i,row in enumerate(rows):
        if not row.get('alternate'):
            append(i,'整段对话 · 正常语速',normals[i],.7)
    track.extend(bytes(48000))
    output=SITE/'audio'/folder;output.mkdir(parents=True,exist_ok=True)
    wav=io.BytesIO()
    with wave.open(wav,'wb') as w:
        w.setparams((1,2,24000,0,'NONE','not compressed'));w.writeframes(track)
    path=output/(filename+'.mp3')
    subprocess.run([ff,'-v','error','-y','-i','pipe:0','-c:a','libmp3lame','-b:a','80k','-metadata','title='+title,'-metadata','artist=快乐出村计划',str(path)],input=wav.getvalue(),check=True)
    manifest=dict(src=f'./audio/{folder}/'+path.name,duration=len(track)/48000,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),rows=rows,cues=cues)
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,separators=(',',':')))
    print(len(rows),'lines,',len(cues),'spoken turns,',round(manifest['duration']),'seconds')
    return manifest
if __name__=='__main__':build()
