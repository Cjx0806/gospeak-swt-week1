(() => {
  'use strict';
  const track = {"src":"./audio/opening-v35/felix-opening.mp3","duration":262.95125,"sha256":"e6755e410f387dea0df769f87a3d5fba76766e05923c605176192b51525cf8cb","rows":[{"round":1,"role":"考官","en":"Where are you from?","zh":"你来自哪里？","src":"./audio/real-v30/907d3db76bc55df057d32f.mp3"},{"round":1,"role":"考官 · 换个问法","alternate":true,"en":"Which city are you from?","zh":"你来自哪座城市？","src":"./audio/real-v30/47b9ee632078c14bc2397b.mp3"},{"round":1,"role":"考官 · 换个问法","alternate":true,"en":"What's your hometown?","zh":"你的家乡是哪里？","src":"./audio/real-v30/5cecdef75a860150d96b4f.mp3"},{"round":1,"role":"Felix","en":"I'm from Yulin, Guangxi.","zh":"我来自广西玉林。","src":"./audio/real-v30/5230c130ea419fcfd14288.mp3"},{"round":2,"role":"考官","en":"What's your personality like?","zh":"你的性格怎么样？","src":"./audio/real-v30/84e718cc1b8083b68a0bb0.mp3"},{"round":2,"role":"考官 · 换个问法","alternate":true,"en":"What are you like?","zh":"你是个怎样的人？","src":"./audio/real-v30/4e70af490b8a6bfbd0239b.mp3"},{"round":2,"role":"考官 · 换个问法","alternate":true,"en":"How would you describe your personality?","zh":"你会怎样形容自己的性格？","src":"./audio/real-v30/d5f3ad9567c0acfbfd7d66.mp3"},{"round":2,"role":"Felix","en":"I'm easygoing and outgoing.","zh":"我很随和，也很外向。","src":"./audio/real-v30/a51de9ce5c4294d27efd1f.mp3"},{"round":3,"role":"考官","en":"Do you have any work experience?","zh":"你有工作经验吗？","src":"./audio/real-v30/6ed5c3e280ee47ab8e4b06.mp3"},{"round":3,"role":"考官 · 换个问法","alternate":true,"en":"What jobs have you done?","zh":"你做过哪些工作？","src":"./audio/real-v30/23bae824f08a4218e2d5ab.mp3"},{"round":3,"role":"考官 · 换个问法","alternate":true,"en":"What kind of work have you done before?","zh":"你以前做过哪类工作？","src":"./audio/real-v30/5c23ff1e8cb892b7537663.mp3"},{"round":3,"role":"Felix","en":"I bought and sold used phones.","zh":"我买卖过二手手机。","src":"./audio/real-v30/4ba0e9bd1e20c95b5b2f34.mp3"},{"round":3,"role":"Felix","en":"I also helped a driving school find students.","zh":"我还帮一家驾校招过生。","src":"./audio/real-v30/fcf571b9bea3a82210784e.mp3"}],"cues":[{"row":0,"phase":"英文","start":0.0,"spokenEnd":1.172625},{"row":0,"phase":"中文","start":1.672625,"spokenEnd":2.9149166666666666},{"row":0,"phase":"慢读 1/3","start":3.5649166666666665,"spokenEnd":5.0849166666666665},{"row":0,"phase":"慢读 2/3","start":6.884916666666666,"spokenEnd":8.404916666666667},{"row":0,"phase":"慢读 3/3","start":10.204916666666668,"spokenEnd":11.724916666666667},{"row":1,"phase":"英文","start":13.524916666666666,"spokenEnd":15.069083333333333},{"row":1,"phase":"中文","start":15.569083333333333,"spokenEnd":17.577625},{"row":1,"phase":"慢读 1/3","start":18.227625,"spokenEnd":20.2465},{"row":1,"phase":"慢读 2/3","start":22.0465,"spokenEnd":24.065375},{"row":1,"phase":"慢读 3/3","start":25.865375,"spokenEnd":27.88425},{"row":2,"phase":"英文","start":29.68425,"spokenEnd":30.94975},{"row":2,"phase":"中文","start":31.44975,"spokenEnd":32.935833333333335},{"row":2,"phase":"慢读 1/3","start":33.58583333333333,"spokenEnd":35.22983333333333},{"row":2,"phase":"慢读 2/3","start":37.029833333333336,"spokenEnd":38.673833333333334},{"row":2,"phase":"慢读 3/3","start":40.47383333333333,"spokenEnd":42.11783333333333},{"row":3,"phase":"英文","start":43.917833333333334,"spokenEnd":45.671791666666664},{"row":3,"phase":"中文","start":46.171791666666664,"spokenEnd":47.971375},{"row":3,"phase":"慢读 1/3","start":48.621375,"spokenEnd":50.912125},{"row":3,"phase":"慢读 2/3","start":52.712125,"spokenEnd":55.002875},{"row":3,"phase":"慢读 3/3","start":56.802875,"spokenEnd":59.093625},{"row":4,"phase":"英文","start":60.893625,"spokenEnd":62.623583333333336},{"row":4,"phase":"中文","start":63.123583333333336,"spokenEnd":64.749},{"row":4,"phase":"慢读 1/3","start":65.399,"spokenEnd":67.65145833333334},{"row":4,"phase":"慢读 2/3","start":69.45145833333333,"spokenEnd":71.70391666666667},{"row":4,"phase":"慢读 3/3","start":73.50391666666667,"spokenEnd":75.756375},{"row":5,"phase":"英文","start":77.556375,"spokenEnd":78.38070833333333},{"row":5,"phase":"中文","start":78.88070833333333,"spokenEnd":80.33195833333333},{"row":5,"phase":"慢读 1/3","start":80.98195833333334,"spokenEnd":82.0405},{"row":5,"phase":"慢读 2/3","start":83.8405,"spokenEnd":84.89904166666666},{"row":5,"phase":"慢读 3/3","start":86.69904166666667,"spokenEnd":87.75758333333333},{"row":6,"phase":"英文","start":89.55758333333333,"spokenEnd":91.484875},{"row":6,"phase":"中文","start":91.984875,"spokenEnd":94.57391666666666},{"row":6,"phase":"慢读 1/3","start":95.22391666666667,"spokenEnd":97.73633333333333},{"row":6,"phase":"慢读 2/3","start":99.89633333333333,"spokenEnd":102.40875},{"row":6,"phase":"慢读 3/3","start":104.56875,"spokenEnd":107.08116666666666},{"row":7,"phase":"英文","start":109.24116666666667,"spokenEnd":111.110375},{"row":7,"phase":"中文","start":111.610375,"spokenEnd":113.32866666666666},{"row":7,"phase":"慢读 1/3","start":113.97866666666667,"spokenEnd":116.42254166666666},{"row":7,"phase":"慢读 2/3","start":118.22254166666667,"spokenEnd":120.66641666666666},{"row":7,"phase":"慢读 3/3","start":122.46641666666666,"spokenEnd":124.91029166666667},{"row":8,"phase":"英文","start":126.71029166666666,"spokenEnd":129.59029166666667},{"row":8,"phase":"中文","start":130.09029166666667,"spokenEnd":131.73891666666665},{"row":8,"phase":"慢读 1/3","start":132.38891666666666,"spokenEnd":136.14358333333334},{"row":8,"phase":"慢读 2/3","start":138.30358333333334,"spokenEnd":142.05825},{"row":8,"phase":"慢读 3/3","start":144.21825,"spokenEnd":147.97291666666666},{"row":9,"phase":"英文","start":150.13291666666666,"spokenEnd":152.58091666666667},{"row":9,"phase":"中文","start":153.08091666666667,"spokenEnd":154.69470833333332},{"row":9,"phase":"慢读 1/3","start":155.34470833333333,"spokenEnd":158.53425},{"row":9,"phase":"慢读 2/3","start":160.33425,"spokenEnd":163.52379166666665},{"row":9,"phase":"慢读 3/3","start":165.32379166666666,"spokenEnd":168.51333333333332},{"row":10,"phase":"英文","start":170.31333333333333,"spokenEnd":172.28704166666665},{"row":10,"phase":"中文","start":172.78704166666665,"spokenEnd":174.79558333333333},{"row":10,"phase":"慢读 1/3","start":175.44558333333333,"spokenEnd":178.03570833333333},{"row":10,"phase":"慢读 2/3","start":180.91570833333333,"spokenEnd":183.50583333333333},{"row":10,"phase":"慢读 3/3","start":186.38583333333332,"spokenEnd":188.97595833333332},{"row":11,"phase":"英文","start":191.85595833333332,"spokenEnd":194.73595833333334},{"row":11,"phase":"中文","start":195.23595833333334,"spokenEnd":197.03554166666666},{"row":11,"phase":"慢读 1/3","start":197.68554166666667,"spokenEnd":201.44020833333335},{"row":11,"phase":"慢读 2/3","start":203.60020833333334,"spokenEnd":207.354875},{"row":11,"phase":"慢读 3/3","start":209.514875,"spokenEnd":213.26954166666667},{"row":12,"phase":"英文","start":215.42954166666667,"spokenEnd":218.15791666666667},{"row":12,"phase":"中文","start":218.65791666666667,"spokenEnd":221.038},{"row":12,"phase":"慢读 1/3","start":221.688,"spokenEnd":225.25770833333334},{"row":12,"phase":"慢读 2/3","start":228.13770833333334,"spokenEnd":231.70741666666666},{"row":12,"phase":"慢读 3/3","start":234.58741666666666,"spokenEnd":238.157125},{"row":0,"phase":"整段对话 · 正常语速","start":242.037125,"spokenEnd":243.20975},{"row":3,"phase":"整段对话 · 正常语速","start":243.90975,"spokenEnd":245.66370833333335},{"row":4,"phase":"整段对话 · 正常语速","start":246.36370833333334,"spokenEnd":248.09366666666668},{"row":7,"phase":"整段对话 · 正常语速","start":248.79366666666667,"spokenEnd":250.662875},{"row":8,"phase":"整段对话 · 正常语速","start":251.362875,"spokenEnd":254.242875},{"row":11,"phase":"整段对话 · 正常语速","start":254.942875,"spokenEnd":257.822875},{"row":12,"phase":"整段对话 · 正常语速","start":258.522875,"spokenEnd":261.25125}]};
  if (customElements.get('opening-listen')) return;
  class LocationListen extends HTMLElement {
    connectedCallback() {
      const full = this.hasAttribute('full');
      this.innerHTML = '<section class="loc33" aria-label="开场三问连续听练">'+
        (full?'':'<h3>家乡、性格、工作经历 · 三轮连续听练</h3>')+
        '<p>考官问，Felix 答。每句英文 → 中文 → 慢读三遍，最后听正常语速的完整对话。</p>'+
        '<div class="loc33-actions"><button type="button" data-loc-toggle>▶ 开始循环听</button><button type="button" data-loc-stop disabled>停止</button>'+
        '<a download="Felix-开场三问-连续听练.mp3">下载 MP3</a></div>'+
        '<audio loop playsinline controls preload="none" aria-label="开场三问音频"></audio>'+
        '<div class="loc33-captions"><small data-phase></small><p lang="en" data-en></p><p data-zh></p></div>'+
        '<small data-loc-status role="status"></small></section>';
      const audio = this.querySelector('audio'), toggle = this.querySelector('[data-loc-toggle]'), stop = this.querySelector('[data-loc-stop]');
      const status = this.querySelector('[data-loc-status]');
      this.media=audio;
      const controls=this.querySelector('.loc33-captions');
      if(!full){audio.hidden=true;controls.hidden=true;}
      audio.src=track.src;this.querySelector('a').href=track.src;
      let last=-1;
      const update=()=>{
        const index=track.cues.findLastIndex?track.cues.findLastIndex(c=>c.start<=audio.currentTime):track.cues.reduce((i,c,n)=>c.start<=audio.currentTime?n:i,0);
        if(index===last)return;
        last=index;const cue=track.cues[Math.max(0,index)], row=track.rows[cue.row];
        this.querySelector('[data-phase]').textContent='第 '+row.round+' 轮 · '+row.role+' · '+cue.phase;
        this.querySelector('[data-en]').textContent=row.en;
        this.querySelector('[data-zh]').textContent=row.zh;
      };
      const recording=()=>window.__samMainlineV19?.isRecording?.()||document.querySelector('main.layout .practice.listening');
      toggle.onclick=()=>{
        if(recording()){status.textContent='请先结束录音，再开始连续听练。';return;}
        if(!audio.paused){audio.pause();return;}
        if(audio.error)audio.load();
        audio.hidden=false;controls.hidden=false;
        audio.play().catch(e=>{if(e.name!=='AbortError')status.textContent='暂时无法播放，可点播放重试或下载 MP3。';});
      };
      stop.onclick=()=>{audio.pause();audio.currentTime=0;update();toggle.textContent='▶ 开始循环听';stop.disabled=true;status.textContent='已停止，下次从第一问开始。';};
      this.otherPlayer=e=>{if(e.target!==audio&&!audio.paused)audio.pause();};
      this.release=e=>{if(e.detail?.owner!=='opening-v35'&&!audio.paused)audio.pause();};
      this.suspend=()=>audio.pause();
      document.addEventListener('play',this.otherPlayer,true);
      window.addEventListener('gospeak-playback-request',this.release);
      window.addEventListener('sam-recorder-start',this.suspend);
      window.addEventListener('pagehide',this.suspend);
      audio.addEventListener('play',()=>{
        if(recording()){audio.pause();status.textContent='请先结束录音。';return;}
        window.dispatchEvent(new CustomEvent('gospeak-playback-request',{detail:{owner:'opening-v35'}}));
        document.querySelectorAll('audio,video').forEach(m=>{if(m!==audio&&!m.paused)m.pause();});
        if(navigator.mediaSession){try{
          navigator.mediaSession.metadata=new MediaMetadata({title:'家乡、性格、工作经历 · 三轮连续听练',artist:'快乐出村计划'});
          for(const action of ['play','pause','nexttrack','previoustrack','seekto','seekforward','seekbackward','stop'])navigator.mediaSession.setActionHandler(action,null);
        }catch(_){}}
        toggle.textContent='暂停';stop.disabled=false;audio.hidden=false;controls.hidden=false;
        status.textContent='整段对话结束后会从第一问重新播放。';update();
      });
      audio.addEventListener('pause',()=>{toggle.textContent=audio.currentTime?'继续循环听':'▶ 开始循环听';});
      audio.addEventListener('error',()=>{status.textContent='音频加载失败，可重试或下载 MP3。';});
      audio.addEventListener('timeupdate',update);audio.addEventListener('seeked',update);update();
    }
    disconnectedCallback(){
      document.removeEventListener('play',this.otherPlayer,true);
      window.removeEventListener('gospeak-playback-request',this.release);
      window.removeEventListener('sam-recorder-start',this.suspend);
      window.removeEventListener('pagehide',this.suspend);
      this.media.pause();this.media.removeAttribute('src');this.media.load();
    }
  }
  customElements.define('opening-listen',LocationListen);
})();
