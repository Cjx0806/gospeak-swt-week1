  // Local, topic-specific practice rubric. Only an unedited, complete final transcript is scoreable.
  const examRules={
    intro:[/name|call me|felix|student|study|college|major/,/felix/,/college|student|fitness|training|swim|guangxi/],
    hire:[/certif|qualified|trained|train(ing)?|i swim|i can swim|good swimmer|strong swimmer|practice|experience|reliable|responsib/,/certif|qualified|trained|experience|reliable|responsib/,/kilomet|kilometre|meters|metres|daily|every day|practice|example|trained in/],
    job:[/lifeguard|life guard|pool|rescue|swim/,/lifeguard|life guard/,/certif|swim|train|safe|because/],
    swim:[/kilomet|meters|metres|yards|laps/,/one kilom|1 kilom|thousand met|1000 met|1 000 met|1km/,/daily|every day|school|usually|practice/],
    grad:[/graduate|graduation|finish|twenty twenty|20\d\d|two thousand/,/2029|twenty twenty nine|two thousand (and )?twenty nine/,null],
    plans:[/study|coach|teach|college|work|korea|job/,/swim|korea|coach/,/might|want|plan|hope|after|because/],
    return:[/china|home|college|school|stud/,/china|home/,/college|school|stud|finish/],
    purpose:[/culture|english|experience|learn|exchange|meet/,/culture|english|exchange|meet/,/work|america|people|practice|life/],
    sales:[/sold|bought|sell|sales|driving school|worked|recruit/,/phone|driving school|student/,/used|second hand|bought|recruit|help|another|also/],
    strength:[/know|good at|skill|familiar|understand/,/car|phone|tech|electronic|device/,/because|also|sell|sold|example|and/],
    pressure:[/stress|pressure|calm|positive|cheerful|ask|help|breathe|focus/,/calm|positive|cheerful|ask|help|breathe|focus/,/work|problem|when|task|first|usually/],
    conflict:[/listen|speak|talk|discuss|explain|supervisor|understand/,/listen|discuss|understand|talk/,/then|idea|solve|supervisor|together|calm/],
    place:[/coast|state|delaware|hampshire|beach|east|west|new york|near the sea/,/coast|delaware|hampshire|beach|new york|near the sea/,/open|also|ocean|sea|because|water|tax/],
    visit:[/visit|ride|travel|new york|helicopter|beach|explore/,/new york|helicopter|beach|museum|city/,/ride|see|love|because|tour/],
    state:[/state|coast|sea|ocean|beach|delaware|hampshire/,/tax|coast|beach|delaware|hampshire/,/also|because|water|tax|close/],
    trip:[/visited|went|been|traveled|travelled|korea|vietnam|singapore|malaysia|indonesia/,/korea|vietnam|singapore|malaysia|indonesia/,/seoul|busan|hanoi|nineteen|alone|with|when/],
    alone:[/alone|my own|by myself|solo|indonesia|korea/,/alone|my own|by myself|solo/,/indonesia|korea|seventeen|nineteen/],
    independent:[/i (can|think|could)|on my own|by myself|independent|alone/,/can|could|ready|manage|confident/,/korea|indonesia|travel|trip|before|example/],
    malaysia:[/friend|malaysia|sixteen/,/friend/,/sixteen|kuala|kota|together/],
    vietnam:[/vietnam|hanoi|north|south/,/vietnam|hanoi|nha trang|phu quoc|ho chi minh/,/eighteen|north|south|city|cities/],
    outdoors:[/outdoor|sun|outside|heat|i can|comfortable/,/outdoor|sun|outside|heat/,/comfortable|worry|fine|okay|happy|can work|used to/],
    hobby:[/swim|cycl|bik|rid(e|ing)/,/swim|cycl|bik/,/hainan|kilomet|every day|and|school/],
    challenge:[/english|speak|language|understand|listen|communicat/,/english|language|speak|understand|listen/,/practic|ask|repeat|slow|learn|improv/],
    family:[/parents|family|support|encourage/,/support|encourage|agree|happy/,/always|very|really|plan|new things/]
  };
  function markTurn(turn){
    if(!turn.assessable||!turn.heard)return null;
    const words=turn.heard.toLowerCase().replace(/[’']/g,"'").replace(/[^a-z0-9' ]/g,' ').replace(/\s+/g,' ').trim();
    const rules=examRules[turn.id.replace(/^r30-/,'')];
    if(!rules||!words)return null;
    const related=rules[0].test(words), first=rules[1].test(words);
    const detail=first&&!rules[2]||rules[2]&&rules[2].test(words);
    const key=related?(first?2:0)+(detail?2:0):0;
    const full=/\b(i|we|they|it|he|she|my|the|speaking)\b.*\b(am|was|is|have|had|has|will|would|feel|like|think|can|want|swim|went|got|know|worked|visited|sold|bought|studied|traveled|travelled|support|helped|enjoy|plan|prefer|should|need|holds?|returned|try|might|hope)\b/.test(words)||/\bi'(m|ll|d|ve)\b/.test(words);
    const compact=turn.id==='r30-grad'&&first||turn.id==='r30-job'&&first;
    const expression=related?(full||compact?2:1):0;
    const score=(related?4:0)+key+expression;
    let advice=!related?'先听清问什么，再直接回答。':key<4?'补一个能回答这道题的具体事实或理由。':expression<2?'试着把关键词说成一句完整短句。':'换个问法，再脱稿答一遍。';
    if(turn.id==='r30-hire'&&key<4)advice='可以用中国救生员证和每天游一公里说明你适合这个岗位。';
    return {score,why:'切题 '+(related?4:0)+'/4 · 要点 '+key+'/4 · 表达 '+expression+'/2',advice};
  }
  function examGrade(s){
    let points=0,missing=0;
    for(const turn of s.turns){
      const mark=markTurn(turn);
      if(mark)points+=mark.score;
      else if(turn.seconds)missing++;
    }
    if(missing)return '总分待定 · '+missing+' 题有回答但缺少完整识别，请重测。';
    const grade=points/s.turns.length;
    return '模拟总分 '+Number(grade.toFixed(2))+' / 10 · '+(grade>=6?'通过':'未通过');
  }
