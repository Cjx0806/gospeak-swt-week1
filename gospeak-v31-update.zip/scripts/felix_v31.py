"""Rebuild the name-bearing text, picture and audio bindings without touching learner histories."""
import asyncio,dataclasses,hashlib,json,re,shutil,tempfile
from pathlib import Path
from zipfile import ZipFile
import imageio_ffmpeg
from mutagen.mp3 import MP3
import build_v18_listening as b
from build_v21 import synthesize_missing
from real_v30 import ROOT,SITE,speech,VOICE
AUDIO=SITE/'audio/felix-v31'
def renamed(text):
    return re.sub(r'(?<![A-Za-z])Sam(?![A-Za-z])','Felix',text).replace('sæm','ˈfiːlɪks').replace('My NAME is SAM.','My NAME is FELIX.').replace('嘴张开，最后双唇闭合发 /m/，不要读成 same。','重音在第一音节，结尾读 /ks/。')
def strings(obj):
    if isinstance(obj,list):return [strings(x) for x in obj]
    if isinstance(obj,dict):return {('felix' if k=='sam' else renamed(k)):strings(v) for k,v in obj.items()}
    if isinstance(obj,str):return renamed(obj)
    return obj
def write(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')))
def local(path):return './'+str(path.relative_to(SITE))
def build(synthesize=synthesize_missing):
    AUDIO.mkdir(exist_ok=True,parents=True)
    with ZipFile(ROOT/'gospeak-v30-update.zip') as z:
        def old(k):return z.read('_site/'+k).decode()
        data=strings(json.loads(old('interview-v21.json')))
        legacy=renamed(old('assets/index-C6MAz4Oq.js')).replace('sam:`','felix:`').replace('"sam":','"felix":')
        male=old('assets/male-v30.js')
    data['real']=json.loads((SITE/'real-v30.json').read_text())
    bindings=json.loads((ROOT/'tmp/male-bindings-v30.json').read_text())
    nameclips={path:speech('Felix' if en.lower()=='sam' else renamed(en),VOICE) for path,en in bindings.items() if re.search(r'\bsam\b',en,re.I)}
    shots=set(nameclips.values()); module=b.MODULES[1]
    module=dataclasses.replace(module,sentences=tuple(dataclasses.replace(s,en=renamed(s.en),zh=renamed(s.zh)) for s in module.sentences))
    plans={m['id']:b.build_track_plan(module,m['id']) for m in b.MODES}
    for plan in plans.values():
        for clip in plan:
            if isinstance(clip,b.Speech):shots.add(clip)
    clips=asyncio.run(synthesize(shots))
    lookup={}
    for path,clip in nameclips.items():
        dest=AUDIO/(b._clip_key(clip)+'.mp3');shutil.copyfile(clips[clip],dest);lookup['./'+path]=local(dest)
    start=male.index('const clips=')+len('const clips=');end=male.index(';window.',start)
    table=json.loads(male[start:end]);table.update({k[2:]:v for k,v in lookup.items()});table['audio/words/felix.mp3']=lookup['./audio/words/sam.mp3']
    (SITE/'assets/male-v30.js').write_text(male[:start]+json.dumps(table,separators=(',',':'))+male[end:])
    # Rebind the content itself as well as legacy playback aliases.
    def links(obj):
        if isinstance(obj,dict):return {k:links(v) for k,v in obj.items()}
        if isinstance(obj,list):return [links(v) for v in obj]
        return lookup.get(obj,obj) if isinstance(obj,str) else obj
    write(SITE/'interview-v21.json',links(data))
    with ZipFile(ROOT/'gospeak-v22-update.zip') as z:lesson=strings(json.loads(z.read('_site/lesson-audio-v22.json')))
    for entry in [lesson['sentences'][0]['audio'],lesson['words']['felix']]:
        oldsrc=entry['src'];src=lookup[oldsrc];entry.update(src=src,voice=VOICE,spokenText='Felix' if entry['spokenText'].lower()=='sam' else entry['spokenText'])
        entry.update(sha256=hashlib.sha256((SITE/src).read_bytes()).hexdigest(),textSha256=hashlib.sha256(entry['spokenText'].encode()).hexdigest(),provenance='V31 Felix pronunciation')
        legacy=legacy.replace(oldsrc,src)
    write(SITE/'lesson-audio-v22.json',lesson);(SITE/'assets/index-C6MAz4Oq.js').write_text(legacy)
    for file in (ROOT/'tmp/cards-v31').glob('Felix*'):
        if '-pair-' not in file.name:shutil.copyfile(file,SITE/'study-cards'/file.name)
    cards=json.loads((SITE/'cards-v24.json').read_text())
    for t in cards['topics']:t['image']=f'./study-cards/Felix-SWT-{t["id"]:02}.png'
    write(SITE/'cards-v24.json',cards)
    p=SITE/'cards.html';p.write_text(renamed(p.read_text()).replace('Felix-SWT-8张学习卡-v29.zip','Felix-SWT-8张学习卡.zip').replace('cards-v24.js?v=29','cards-v24.js?v=31'))
    p=SITE/'assets/cards-v24.js';p.write_text(renamed(p.read_text()).replace('course=29','course=31'))
    p=SITE/'assets/listening-v18.js';p.write_text(p.read_text().replace('listening-v18.json?v=19.1','listening-v18.json?v=31'))
    listen=strings(json.loads((SITE/'listening-v18.json').read_text()));current=listen['modules'][1];ff=imageio_ffmpeg.get_ffmpeg_exe()
    with tempfile.TemporaryDirectory(dir=ROOT/'tmp') as tmp:
        work=Path(tmp)
        for mode in listen['modes']:
            k=mode['id'];inputs=[];cursor=0;cues=[]
            for clip in plans[k]:
                if isinstance(clip,b.Speech):src=clips[clip]
                else:
                    src=work/f'sil-{clip.seconds}.mp3'
                    if not src.exists():b._make_silence(ff,clip.seconds,src)
                inputs.append(src)
                duration=b._decoded_pcm(ff,src,work).stat().st_size/48000
                cues.append(b._cue(module,clip,cursor,cursor+duration,cues[-1] if cues else None));cursor+=duration
            out=AUDIO/f'intro-{k}.mp3';b._concat_mp3(ff,inputs,out,work)
            current['tracks'][k].update(src=local(out),durationSeconds=MP3(out).info.length,cues=cues)
            cursor=0;pieces=[]
            for m in listen['modules']:
                m['offsets'][k]=round(cursor,3);track=m['tracks'][k];pieces.append(SITE/track['src']);cursor+=track['cues'][-1]['end']
            out=AUDIO/'collections'/(k+'.mp3');b._concat_mp3(ff,pieces,out,work)
            mode['all'].update(src=local(out),durationSeconds=MP3(out).info.length)
    write(SITE/'listening-v18.json',listen);write(SITE/'audio/v18/manifest.json',listen)
if __name__=='__main__':build()
