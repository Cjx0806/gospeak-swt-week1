import json
from real_v30 import SITE, PROFILES, build, entries
TAILS={'hire':'lifeguard certificate.','challenge':'hard for me.','family':'my plan.','independent':'do it.'}
ROUTES=[
 ['purpose','family','grad','plans','place','visit','return'],
 ['sales','strength','trip','alone','independent','hobby','return'],
 ['job','hire','swim','outdoors','challenge','pressure','grad'],
 ['sales','job','hire','conflict','pressure','challenge','plans']]
def compile_course():
    previous=json.loads((SITE/'interview-v21.json').read_text())['real']['profiles']
    rows=entries('real-v31.txt',TAILS)+entries()
    next(q for q in rows if q['id']=='r30-job')['related']=['r30-hire','r30-swim']
    build(rows,[(name,style,voice,route) for (name,style,voice,_),route in zip(PROFILES,ROUTES)])
    path=SITE/'real-v30.json'
    data=json.loads(path.read_text())
    for old,new in zip(previous,data['profiles']):
        new['audio']={**old['audio'],**new['audio']}
    path.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
if __name__=='__main__':compile_course()
