"""Create a small overlay over V30, keeping previous release tests reproducible."""
import json,hashlib,re,shutil
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from build_v30 import ROOT,SITE,sub
def render(js):
    js=sub(js,"realTopic(last)?last:'r30-grad'","typeof location!=='undefined'&&location.hash==='#hire'?'r30-hire':realTopic(last)?last:'r30-hire'")
    js=js.replace("else chooseReal('r30-grad')","else chooseReal('r30-hire')").replace("['#exam','#practice']","['#exam','#practice','#hire']")
    js=sub(js,"const dest=realTopic(pick(pool.length?pool:q().related));","const dest=realTopic(!follow&&q().id==='r30-job'?'r30-hire':pick(pool.length?pool:q().related));")
    js=sub(js,"    // Open with a focus question", """    if(p.route.includes('r30-hire')&&p.route.includes('r30-job')){
      for(const id of ['r30-job','r30-hire']){order.push(id);remaining.splice(remaining.indexOf(id),1);}
    }
    // Open with a focus question""")
    js=sub(js,"if(match){const next=", "const reserved=session.turns[1].id==='r30-job'&&session.turns[2].id==='r30-hire'&&session.index<2;\n      if(match&&!reserved){const next=")
    js=sub(js,"  function examReport(){",(ROOT/'assets/exam-score-v31.js').read_text()+"\n  function examReport(){")
    js=sub(js,"turn.heard=String(take.transcript||'').slice(0,1200);","turn.heard=String(take.transcript||'').slice(0,1200);turn.assessable=!!take.complete&&!!turn.heard;")
    js=sub(js,"const v=examQuestion(turn),row=realTopic(turn.id);","const v=examQuestion(turn),row=realTopic(turn.id),mark=markTurn(turn);")
    js=sub(js,"'</span>'+(turn.heard?", """'</span><small>'+esc(mark?mark.score+' / 10 · '+mark.why+'。'+mark.advice:turn.seconds?'未评分：缺少完整英文识别。':'0 / 10 · 未作答。')+'</small>'+(turn.heard?""")
    js=sub(js,"<h1>本场复盘</h1><p>","<h1>本场复盘</h1><h2>'+esc(examGrade(session))+'</h2><p>8 题等权 · 6 分通过 · 跳过或未答计 0 分。分数按英文转写估算，换词可能漏判。</p><p>")
    js=sub(js,"约 10–15 分钟 · 自我介绍 + 7 轮问答","约 10–15 分钟 · 自我介绍 + 7 轮问答 · 满分 10 分，6 分通过")
    return js.replace('course=30','course=31')
def pack(name,paths):
    with ZipFile(ROOT/name,'w',ZIP_DEFLATED) as z:
        for p in sorted(set(paths)):z.write(ROOT/p,p)
def build():
    with ZipFile(ROOT/'gospeak-v30-update.zip') as z:
        old=lambda name:z.read('_site/'+name).decode()
        recorder=old('assets/recorder-v19.js')
        recorder=sub(recorder,"snapshot.onTake({transcript:","snapshot.onTake({complete:record.transcriptSource==='browser-final'&&!record.recognitionIncomplete,transcript:")
        (SITE/'assets/recorder-v19.js').write_text(recorder)
        js=render(old('assets/mainline-v21.js'))
        (SITE/'assets/mainline-v21.js').write_text(js)
        html=old('index.html').replace('V30 ·','V31 ·').replace('mainline-v21.js?v=22&design=30','mainline-v21.js?v=22&design=31').replace('index-C6MAz4Oq.js?v=22&voice=30','index-C6MAz4Oq.js?v=22&voice=31').replace('male-v30.js?v=22','male-v30.js?v=22&voice=31').replace('recorder-v19.js?v=22&design=30','recorder-v19.js?v=22&design=31').replace('cards.html?v=29','cards.html?v=31').replace('listening-v18.js?v=22&design=26','listening-v18.js?v=22&design=31')
        (SITE/'index.html').write_text(html)
        sw=old('sw.js').replace("if(u.pathname.endsWith('/recorder-v19.js'))u.searchParams.set('design','30')","if(u.pathname.endsWith('/recorder-v19.js'))u.searchParams.set('design','31')").replace("set('course','30')","set('course','31')").replace("if(u.pathname.endsWith('/mainline-v21.js'))u.searchParams.set('design','30')","if(u.pathname.endsWith('/mainline-v21.js'))u.searchParams.set('design','31')").replace("return u.href;", """if(u.pathname.endsWith('/male-v30.js'))u.searchParams.set('voice','31'); if(u.pathname.endsWith('/listening-v18.js'))u.searchParams.set('design','31'); return u.href;""")
        digest=hashlib.sha256((SITE/'interview-v21.json').read_bytes()+js.encode()).hexdigest()[:12]
        (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,sw))
        previous=set(z.namelist())
    paths=['_site/'+p for p in ['index.html','sw.js','assets/mainline-v21.js','assets/index-C6MAz4Oq.js','assets/male-v30.js','assets/listening-v18.js','assets/cards-v24.js','assets/recorder-v19.js','cards.html','cards-v24.json','listening-v18.json','lesson-audio-v22.json','interview-v21.json','audio/v18/manifest.json']]
    paths+=['scripts/'+p for p in ['build_v31.py','course_v31.py','real_v30.py','felix_v31.py','card_images_v31.py','test_real_v31.cjs']]
    paths+=['assets/real-v31.txt','assets/real-vocab-v30.txt','assets/exam-score-v31.js']
    data=(SITE/'interview-v21.json').read_text()
    paths+=[str(p.relative_to(ROOT)) for p in (SITE/'audio/real-v30').glob('*.mp3') if p.name in data and str(p.relative_to(ROOT)) not in previous]
    paths+=[str(p.relative_to(ROOT)) for p in (SITE/'study-cards').glob('Felix*')]
    paths+=[str(p.relative_to(ROOT)) for p in (SITE/'audio/felix-v31').rglob('*') if p.is_file() and 'collections' not in p.parts]
    pack('gospeak-v31-update.zip',paths)
    for mode in ['teaching','mock','review']:
        pack(f'gospeak-v31-{mode}.zip',[f'_site/audio/felix-v31/collections/{mode}.mp3'])
if __name__=='__main__':build()
