from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import zipfile
OUT=Path(__file__).parent
FONT='/System/Library/Fonts/STHeiti Medium.ttc'
EN='/System/Library/Fonts/Supplemental/Arial.ttf'
import json
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'tmp/cards-v31';OUT.mkdir(exist_ok=True,parents=True)
cards=json.loads((ROOT/'assets/cards-source-v29.json').read_text())
def font(size,en=False):return ImageFont.truetype(EN if en else FONT,size)
def lines(text,f,width):
    # Word wrap English; character wrap Chinese without splitting English words.
    import re
    tokens=re.findall(r'[A-Za-z0-9]+(?:[\-\x27][A-Za-z]+)*|\s+|.',text)
    out=[];line=''
    for token in tokens:
        if line and f.getlength(line+token)>width:out.append(line.rstrip());line=token.lstrip()
        else:line+=token
    if line:out.append(line.rstrip())
    return out
for i,(title,cues,qs,ans,note,extra) in enumerate(cards,1):
    im=Image.new('RGB',(1200,1800),'#f3f4f6');d=ImageDraw.Draw(im)
    d.rectangle((0,0,1200,170),fill='#141821')
    d.text((64,38),'快乐出村计划  /  Felix 的口测随身卡',font=font(32),fill='white')
    d.text((64,96),'先听懂，再回答。',font=font(38),fill='white')
    d.text((1050,50),f'{i:02}',font=font(62,True),fill='#719eff')
    y=214
    def text(s,size=34,color='#141821',english=False,gap=12):
        global y
        f=font(size,english)
        for line in lines(s,f,1072):d.text((64,y),line,font=f,fill=color);y+=size*1.35
        y+=gap
    def label(s):
        global y
        y+=14;text(s,29,'#175cff',gap=16)
    text(title,58,gap=24)
    label('01  先听：抓住这些词')
    text(cues,32,'#485469',gap=16)
    for en,zh in qs:text(en,39,english=True,gap=2);text(zh,31,'#596273',gap=20)
    d.line((64,y,1136,y),fill='#ccd2dd',width=2);y+=12
    label('02  再答：两三句就能表达清楚')
    for en,zh in ans:text(en,40,english=True,gap=3);text(zh,32,'#596273',gap=22)
    text(note,29,'#485469',gap=12)
    if extra:
        label('03  相关追问 / 按题意选用')
        for en,zh in extra:text(en,33,english=True,gap=2);text(zh,28,'#596273',gap=12)
    assert y<1690,(i,y)
    d.line((64,1710,1136,1710),fill='#ccd2dd',width=2)
    d.text((64,1734),'练法：认出题意 → 看短答说 → 遮住答案再说。',font=font(27),fill='#596273')
    im.save(OUT/f'Felix-SWT-{i:02}.png',optimize=True)
for n in range(4):
    pair=Image.new('RGB',(2440,1800),'#dce0e7')
    for col in range(2):pair.paste(Image.open(OUT/f'Felix-SWT-{2*n+col+1:02}.png'),(col*1240,0))
    pair.save(OUT/f'Felix-SWT-pair-{n+1}.jpg',quality=94)
with zipfile.ZipFile(OUT/'Felix-SWT-8张学习卡.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.glob('Felix-SWT-??.png')):z.write(p,p.name)
print('Created 8 portrait cards and 4 paired previews, with English/Chinese sentence pairs.')
