/* Local-first practice recorder. No recording is uploaded by this code.
 * Optional SpeechRecognition is browser-provided and requires explicit opt-in.
 * The scripted-reading score measures transcript matching, NOT phoneme accuracy.
 */
(function (root) {
  'use strict';

  var DB_NAME = 'gospeak-sam-recordings-v19';
  var MAX_SECONDS = 120;
  var MAX_PER_TARGET = 3;
  var MAX_TOTAL = 18;
  var active = null;
  var sequence = 0;
  var dbPromise = null;
  var recordsPromise = null;
  var storageQueue = Promise.resolve();
  // Memory only: an explicit choice may follow the learner between sentences
  // in this open page. Reloading or opening another page resets it to false.
  var pageRecognitionConsent = false;
  var scoreMicReady = false;

  function recognitionFailure(code) {
    var reasons = {
      network: '浏览器未连通语音识别服务（network）。稍后可点重新识别。',
      'not-allowed': '语音或麦克风权限未获允许（not-allowed）。请检查 Safari 的网站权限。',
      'service-not-allowed': '浏览器未获准使用语音识别服务（service-not-allowed）。请检查系统语音识别设置。',
      'no-speech': '识别服务没有听到英文（no-speech）。看到“请开口”后再读一次。',
      'audio-capture': '浏览器无法获取麦克风音频（audio-capture）。请关闭占用麦克风的应用后重试。',
      'language-not-supported': '此设备的识别服务未提供英语（language-not-supported）。',
      aborted: '浏览器中止了这次识别（aborted）。可以重新开始。'
    };
    return reasons[code] || '浏览器的语音识别未完成（'+String(code || 'unknown')+'）。可以重新开始。';
  }

  function escapeHTML(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function tokenize(value) {
    var contractions = { "i'm": 'i am', "i've": 'i have', "i'll": 'i will', "i'd": 'i would',
      "it's": 'it is', "that's": 'that is', "there's": 'there is', "don't": 'do not',
      "doesn't": 'does not', "didn't": 'did not', "can't": 'can not', "cannot": 'can not', "won't": 'will not',
      "isn't": 'is not', "aren't": 'are not', "wasn't": 'was not', "we're": 'we are',
      "you're": 'you are', "they're": 'they are', "let's": 'let us' };
    var text = String(value || '').replace(/\bU\.?S\.?\b/g, 'u s').toLowerCase().replace(/[’‘]/g, "'");
    text = text.replace(/\b(?:[a-z]+'[a-z]+|cannot)\b/g, function (word) { return contractions[word] || word; });
    text = text.replace(/\bu\.s\.?\b/g, 'u s').replace(/\bswt\b/g, 's w t');
    return (text.match(/[a-z0-9]+(?:'[a-z]+)?/g) || []).slice(0, 240);
  }

  function compareText(expected, actual) {
    var a = tokenize(expected), b = tokenize(actual), rows = [];
    var i, j;
    for (i = 0; i <= a.length; i++) {
      rows[i] = [];
      rows[i][0] = i;
    }
    for (j = 0; j <= b.length; j++) rows[0][j] = j;
    for (i = 1; i <= a.length; i++) {
      for (j = 1; j <= b.length; j++) {
        rows[i][j] = Math.min(rows[i - 1][j] + 1, rows[i][j - 1] + 1,
          rows[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
    }
    i = a.length; j = b.length;
    var differences = [], alignment = [];
    while (i || j) {
      if (i && j && a[i - 1] === b[j - 1]) {
        alignment.push({ type: 'matched', expected: a[--i], actual: b[--j] });
      }
      else if (i && j && rows[i][j] === rows[i - 1][j - 1] + 1) {
        var replacement = { type: 'replacement', expected: a[--i], actual: b[--j] };
        differences.push(replacement); alignment.push(replacement);
      } else if (i && rows[i][j] === rows[i - 1][j] + 1) {
        var missing = { type: 'missing', expected: a[--i], actual: '' };
        differences.push(missing); alignment.push(missing);
      } else {
        var extra = { type: 'extra', expected: '', actual: b[--j] };
        differences.push(extra); alignment.push(extra);
      }
    }
    return { differences: differences.reverse(), alignment: alignment.reverse(),
      expectedCount: a.length, actualCount: b.length, distance: rows[a.length][b.length] };
  }

  function assessmentMode(options) {
    return options.assessmentMode || (options.kind === 'sentence' ? 'scripted' : 'free');
  }

  function evaluateReading(record) {
    // A typed correction, interim hypothesis, or historical transcript with no
    // provenance is never presented as an automatically detected reading score.
    if (assessmentMode(record) !== 'scripted' || record.transcriptSource !== 'browser-final' || record.transcriptEdited || record.recognitionIncomplete ||
        !tokenize(record.expectedText).length || !tokenize(record.transcript).length) return null;
    var result = compareText(record.expectedText, record.transcript);
    var denominator = Math.max(result.expectedCount, result.actualCount);
    result.score = Math.max(0, Math.min(100, Math.round(100 * (1 - result.distance / denominator))));
    result.matchedCount = result.alignment.filter(function (item) { return item.type === 'matched'; }).length;
    var seen = {};
    result.review = result.alignment.filter(function (item) {
      if (item.type === 'matched' || !item.expected || seen[item.expected]) return false;
      seen[item.expected] = true; return true;
    }).slice(0, 5);
    return result;
  }

  function signalAdvice(duration, samples, peakRMS, kind) {
    var advice = [];
    if (duration < 2) advice.push('这条录音不足 2 秒。请听完示范，再完整说一次，不要过早点停止。');
    else if (kind === 'answer' && duration > 55) advice.push('这条录音较长。回听后保留直接回答和一个真实细节，尝试更简洁地说一次。');
    if (samples > 10 && peakRMS < 0.012) advice.push('检测到的录音电平很低，可能是距离较远、声音小或麦克风问题。请先回听；若听不清，靠近麦克风后重录。');
    if (!samples) advice.push('此设备未提供可用的音量检测。请回放确认录音是否清楚；这不影响音频保存。');
    if (!advice.length) advice.push('录音已完成。现在回听一次，找出最卡的一小句：听示范 → 模仿 3 次 → 再脱稿录一遍。');
    return advice;
  }

  function feedbackHTML(record, lexicon) {
    var result = evaluateReading(record), scripted = assessmentMode(record) === 'scripted';
    var html = '<p><strong>录音：' + Number(record.duration || 0).toFixed(1) + ' 秒</strong> · 含停顿，不按时长打分</p>';
    if (result) {
      html += '<div class="sam-recorder__score"><strong>' + result.score + '<small> / 100</small></strong><span>跟读文字匹配分<br><small>不是专业发音分</small></span></div>' +
        '<p>参考词中有 ' + result.matchedCount + ' / ' + result.expectedCount + ' 个被一致识别。分数也考虑遗漏、替换和多出的词；缩写、连字符、大小写不扣分。</p>' +
        '<p class="sam-recorder__legend">✓ 一致识别　? 未识别 / 识别不同，需回听确认</p><div class="sam-recorder__word-check" lang="en" aria-label="参考句逐词识别对照">';
      html += result.alignment.filter(function (item) { return item.expected; }).map(function (item) {
        var matched = item.type === 'matched';
        var detail = matched ? '一致识别' : item.type === 'missing' ? '未识别到，请复核' : '识别成 ' + item.actual + '，请复核';
        return '<span class="sam-recorder__word sam-recorder__word--' + (matched ? 'matched' : 'review') + '" title="' + escapeHTML(detail) + '">' +
          '<span aria-hidden="true">' + (matched ? '✓ ' : '? ') + '</span>' + escapeHTML(item.expected) + '<span class="sam-recorder__sr-only">：' + escapeHTML(detail) + '</span></span>';
      }).join('') + '</div>';
      if (result.review.length) {
        html += '<p><strong>这一遍只复核这些词（最多 5 个）</strong></p><ul class="sam-recorder__review-list">' + result.review.map(function (item) {
          var word = (lexicon || {})[item.expected] || {};
          var src = word.src || (typeof word.audio === 'string' ? word.audio : word.audio && word.audio.normal) || '';
          return '<li><b lang="en">' + escapeHTML(item.expected) + '</b>' + (word.ipa ? ' <span lang="en">' + escapeHTML(word.ipa) + '</span>' : '') +
            (word.zh ? ' · ' + escapeHTML(word.zh) : '') + '<br>' +
            (item.type === 'missing' ? '本次未识别到。' : '本次识别成 “' + escapeHTML(item.actual) + '”。') +
            (src ? ' <button type="button" data-review-word="' + escapeHTML(item.expected) + '">听标准词</button>' : '') + '</li>';
        }).join('') + '</ul>';
      } else html += '<p>这些词都被一致识别了。下一步收起文字，把这句和下一句连起来说。</p>';
      var additions = result.alignment.filter(function (item) { return item.type === 'extra'; });
      if (additions.length) html += '<p>转写中还出现：<span lang="en">' + escapeHTML(additions.map(function (item) { return item.actual; }).join(' ')) + '</span>。若你在自主回答时主动补充内容，请切到「脱稿回答」，不要追求逐字匹配。</p>';
      html += '<p class="sam-recorder__score-caution">识别一致不等于发音完全标准；未识别也不等于你读错。先回听确认，再听示范 → 慢读 3 次 → 重录。这里不能判断音素、重音或连读是否准确。</p>';
    } else if (!scripted) {
      html += '<p><strong>脱稿回答：不按参考稿逐字打分</strong></p><p>用自己的简单句回答也可以。回听检查：有没有直接回答问题？有没有一个真实细节？卡住时能否重新说一句？</p>';
    } else {
      var noScore = record.transcriptSource === 'manual' || record.transcriptEdited ? '手动输入的文字不代表实际录音，因此不生成录音识别分。' :
        record.recognitionIncomplete ? '识别中断或出错，转写可能不完整；不据此给你扣分。' :
        record.interimTranscript && !record.transcript ? '这次只有未确认的临时转写，不能评分。' :
        record.transcript && record.transcriptSource !== 'browser-final' ? '这条旧记录没有可验证的最终识别结果，因此不补算分数。' :
        !record.recognitionRequested ? '本次是仅录音，没有开启识别，因此不评分。' : '本次没有得到有效的最终识别结果，因此不评分。';
      html += '<p class="sam-recorder__no-score"><strong>本次未评分</strong> · ' + noScore + '</p><p>要显示逐词对照，请先勾选上方「识别我说的英文」，再重新录音。若 Safari 或大陆网络无法识别，先回听本地录音、对照示范；也可下载交给老师听，不用反复等待。</p>';
    }
    if (record.transcript && tokenize(record.transcript).length) html += '<details class="sam-recorder__transcript-detail" open><summary>浏览器听到的英文 · 请核对</summary><p class="sam-recorder__transcript" lang="en">' + escapeHTML(record.transcript) + '</p></details>';
    else if (record.interimTranscript) html += '<p>临时转写（不用于评分）：<span lang="en">' + escapeHTML(record.interimTranscript) + '</span></p>';
    if (record.recognitionNote) html += '<p class="sam-recorder__muted">' + escapeHTML(record.recognitionNote) + '</p>';
    html += '<details><summary>录音检查与下一步</summary><ul>' + signalAdvice(record.duration, record.samples, record.peakRMS, record.kind).map(function (line) { return '<li>' + escapeHTML(line) + '</li>'; }).join('') + '</ul></details>';
    return html;
  }

  function scorePanel(value, label) {
    return '<div class="swt-score"><strong>'+escapeHTML(value)+'<small> / 100</small></strong><span>跟读评分<br><small>'+escapeHTML(label)+'</small></span></div>';
  }
  function unscored(reason, retry) {
    return scorePanel('—','本次未评分')+'<p>'+escapeHTML(reason)+'</p>'+
      (retry ? '<button type="button" data-score-only>重新识别评分（不保存音频）</button>' : '');
  }
  function practiceFeedback(record, lexicon) {
    var result = evaluateReading(record);
    var transcript = escapeHTML(record.transcript || '');
    var heard = transcript ? '<p class="swt-heard">听到的英文</p><p lang="en" class="swt-transcript">' + transcript + '</p>' : '';
    if (!result) {
      if (!record.recognitionRequested) return scriptedRecord(record) ? unscored('本次选择了仅录音回听。',true) : '<p>录好了，可以回听。</p>';
      if (assessmentMode(record) === 'free' && transcript) return heard + (record.recognitionNote ? '<p>'+escapeHTML(record.recognitionNote)+'</p>' : '') + '<p>回听一次，检查有没有答到考官的问题。</p>';
      var reason = record.recognitionNote || '浏览器没有返回完整英文。请再读一次。';
      return heard + (scriptedRecord(record) ? unscored(reason,true) : '<p>'+escapeHTML(reason)+'</p>');
    }
    var words = result.alignment.map(function (part) {
      var word = part.expected || part.actual;
      var ok = part.type === 'matched';
      var label = ok ? '✓ ' : part.type === 'extra' ? '+ ' : '? ';
      var detail = ok ? '一致' : part.type === 'missing' ? '没听到' : part.type === 'extra' ? '多听到的词' : '听成 ' + part.actual;
      var entry = (lexicon || {})[word];
      var attributes = ' class="swt-word ' + (ok ? 'swt-match' : 'swt-review') + '" title="' + escapeHTML(detail) + '"';
      var content = label + escapeHTML(word);
      return !ok && entry && entry.src ? '<button type="button" data-review-word="' + escapeHTML(word) + '"' + attributes + ' aria-label="听 '+escapeHTML(word)+'，'+escapeHTML(detail)+'">' + content + '</button>' : '<span' + attributes + '>' + content + '</span>';
    }).join(' ');
    var hint = result.review[0];
    var advice = hint ? ('先练 ' + hint.expected + (hint.type === 'missing' ? '，这次没听到这个词。' : '，这次听成了 ' + hint.actual + '。')) :
      (result.distance ? '留意多听到的词，再跟读一次。' : '这一遍的词都听清了。');
    var differences = result.differences.map(function (part) {
      var word = part.expected;
      var entry = word && (lexicon || {})[word];
      var note = part.type === 'missing' ? '这次没有听到' : part.type === 'extra' ? '额外听到 “'+part.actual+'”' : '这次听成 “'+part.actual+'”';
      return '<li><span><b lang="en">'+escapeHTML(word || part.actual)+'</b> · '+escapeHTML(note)+'</span>'+
        (entry && entry.src ? '<button type="button" data-review-word="'+escapeHTML(word)+'">听这个词</button>' : '')+'</li>';
    }).join('');
    return scorePanel(result.score,'按识别文字与参考句对照') + heard +
      '<div class="swt-word-row" aria-label="逐词对照">' + words + '</div><p class="swt-tip">' + escapeHTML(advice) + '</p>' +
      (differences ? '<ul class="swt-differences" aria-label="需要复听的词">'+differences+'</ul>' : '');
  }
  function scriptedRecord(record) { return assessmentMode(record) === 'scripted'; }

  function practiceControls(uid, scripted, recognitionAvailable, recordingAvailable) {
    var primary = scripted ? '开始跟读评分' : '开始回答';
    var privacy = recognitionAvailable ? '点「' + primary + '」会通过浏览器联网识别英文。' : '当前浏览器无法识别英文。';
    if (recordingAvailable && recognitionAvailable) privacy += '需要回听时，可在“更多录音选项”保存声音。';
    return '<section class="sam-recorder swt-practice"><h4>' + (scripted ? '轮到你跟读了' : '轮到你回答了') + '</h4>' +
      '<p class="sam-recorder__guide"></p><div class="sam-recorder__controls">' +
      '<button type="button" class="sam-recorder__start"></button><button type="button" class="sam-recorder__stop" disabled></button>' +
      '<span class="sam-recorder__clock">0:00</span></div><p class="swt-disclosure">'+privacy+'</p>' +
      '<p class="sam-recorder__status" role="status" aria-live="polite"></p>' +
      '<div class="sam-recorder__feedback" aria-live="polite"></div><div class="sam-recorder__result" hidden>' +
      '<audio controls playsinline preload="metadata" aria-label="回听这次录音"></audio><a class="sam-recorder__download">下载录音</a></div>' +
      '<details class="swt-options"><summary>更多录音选项</summary>' +
      (recordingAvailable && recognitionAvailable ? '<button type="button" class="swt-with-audio">'+(scripted?'录音并评分（可回听）':'录音并转写（可回听）')+'</button>' : '') +
      '<button type="button" class="swt-local-only">仅录音回听</button>' +
      '<details class="sam-recorder__history"><summary>以前的录音</summary><div class="sam-recorder__history-list"></div></details>' +
      '<p>每题保留最近 3 条，全站最多 18 条。跟读分数按识别文字计算。</p></details>' +
      '<div hidden><label><input type="checkbox" class="sam-recorder__consent">识别英文</label><span class="sam-recorder__recognition-purpose"></span><span class="sam-recorder__recognition-note"></span>' +
      '<div class="sam-recorder__reference"><p></p></div><div class="sam-recorder__meter"><span></span></div></div></section>';
  }

  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve, reject) {
      if (!root.indexedDB) { reject(new Error('storage-unavailable')); return; }
      var request = root.indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = function () {
        if (!request.result.objectStoreNames.contains('recordings')) request.result.createObjectStore('recordings', { keyPath: 'key' });
      };
      request.onsuccess = function () {
        request.result.onversionchange = function () { request.result.close(); dbPromise = null; };
        resolve(request.result);
      };
      request.onerror = function () { reject(request.error || new Error('storage-error')); };
      request.onblocked = function () { reject(new Error('storage-blocked')); };
    });
    dbPromise = dbPromise.catch(function (error) { dbPromise = null; throw error; });
    return dbPromise;
  }

  function allRecords() {
    // Share only an in-flight read, not a permanent cache of every recording Blob.
    // A page can mount many practice widgets; simultaneous history requests must
    // not clone the entire recording collection once per widget on an iPad.
    if (recordsPromise) return recordsPromise;
    recordsPromise = openDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var request = db.transaction('recordings', 'readonly').objectStore('recordings').getAll();
        request.onsuccess = function () { resolve(request.result.sort(function (a, b) { return b.createdAt - a.createdAt; })); };
        request.onerror = function () { reject(request.error); };
      });
    });
    var pending = recordsPromise;
    pending.then(function () { if (recordsPromise === pending) recordsPromise = null; },
      function () { if (recordsPromise === pending) recordsPromise = null; });
    return pending;
  }

  async function writeRecord(record) {
    var db = await openDB();
    var records = await allRecords();
    records = [record].concat(records.filter(function (entry) { return entry.key !== record.key; }));
    var counts = {}, keep = [], remove = [];
    records.forEach(function (entry) {
      counts[entry.targetId] = (counts[entry.targetId] || 0) + 1;
      if (keep.length < MAX_TOTAL && counts[entry.targetId] <= MAX_PER_TARGET) keep.push(entry.key);
      else remove.push(entry.key);
    });
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('recordings', 'readwrite');
      var store = tx.objectStore('recordings');
      store.put(record);
      remove.forEach(function (key) { store.delete(key); });
      tx.oncomplete = function () { resolve(); };
      tx.onerror = tx.onabort = function () { reject(tx.error || new Error('storage-full')); };
    });
  }

  function storeRecord(record) {
    // Serialize saves from multiple widgets so retention limits stay bounded.
    var result = storageQueue.catch(function () {}).then(function () { return writeRecord(record); });
    storageQueue = result;
    return result;
  }

  async function deleteRecord(key) {
    var db = await openDB();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('recordings', 'readwrite');
      tx.objectStore('recordings').delete(key);
      tx.oncomplete = resolve;
      tx.onerror = tx.onabort = function () { reject(tx.error); };
    });
  }

  function permissionMessage(error) {
    var name = error && error.name;
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError') return '麦克风未获允许。请在 Safari 的网站设置中允许麦克风，再点开始；如果仍不行，可用 iPad「语音备忘录」录音并回听。';
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return '没有找到麦克风。请检查 iPad 或耳机麦克风，再重新打开 Safari。';
    if (name === 'NotReadableError' || name === 'TrackStartError') return '麦克风暂时被占用或不可读取。请关闭通话或其他录音应用，再重试。';
    if (name === 'SecurityError') return '浏览器阻止了麦克风。请使用 HTTPS 网站并检查 Safari 的网站权限。';
    return '录音没有成功开始。请在 Safari 中打开 HTTPS 网站，检查麦克风权限后重试；也可先用「语音备忘录」。';
  }

  function mimeChoice() {
    var types = ['audio/mp4', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'];
    if (!root.MediaRecorder || !root.MediaRecorder.isTypeSupported) return '';
    return types.find(function (type) { return root.MediaRecorder.isTypeSupported(type); }) || '';
  }

  function mount(container, options) {
    if (typeof container === 'string') container = root.document.querySelector(container);
    if (!container) throw new Error('SamRecorder: container not found');
    var opts = Object.assign({ id: 'practice', title: '开口练习', expectedText: '', kind: 'answer' }, options || {});
    var uid = 'sam-recorder-' + (++sequence);
    var state = { recording: false, starting: false, destroyed: false, stream: null, recorder: null,
      chunks: [], context: null, analyser: null, source: null, frame: 0, timer: 0, samples: 0, peakRMS: 0,
      startedAt: 0, finalTranscript: '', interimTranscript: '', recognition: null, recognitionNote: '', recognitionStopRequested: false, recognitionIncomplete: false,
      stopPromise: null, resolveStop: null, currentRecord: null, urls: [], entries: [], generation: 0,
      captureGeneration: 0, permissionPending: false, historyPromise: null, meterData: null, meterAt: -Infinity };
    var Recognition = root.SpeechRecognition || root.webkitSpeechRecognition;
    var quick = /^sam-(?:v21|v25):/.test(opts.id);
    var canRecord = !!(root.isSecureContext && root.navigator.mediaDevices && root.navigator.mediaDevices.getUserMedia && root.MediaRecorder);
    var supported = canRecord || !!(quick && root.isSecureContext && Recognition);
    var api;

    container.innerHTML = quick ? practiceControls(uid, assessmentMode(opts) === 'scripted', !!Recognition, canRecord) : '<section class="sam-recorder" aria-labelledby="' + uid + '-title">' +
      '<div class="sam-recorder__heading"><div><span class="sam-recorder__eyebrow">从会读到能回答</span><h4 id="' + uid + '-title"></h4></div><span class="sam-recorder__local">本地录音</span></div>' +
      '<p class="sam-recorder__guide"></p>' +
      '<details class="sam-recorder__reference"><summary>查看本次参考英文 · 脱稿时收起</summary><p lang="en"></p></details>' +
      '<div class="sam-recorder__recognition"><label><input type="checkbox" class="sam-recorder__consent"><span><strong>识别我说的英文（可选，需联网）</strong><br><span class="sam-recorder__recognition-purpose"></span></span></label><p>勾选后，浏览器可能把你的语音交给其识别服务处理。本网站不接收、不上传你的录音。首次默认关闭；本次打开页面记住此选择，可随时取消，刷新后重新选择。大陆网络或 Safari 可能无法识别，不影响本地录音。</p><p class="sam-recorder__recognition-note" role="status"></p></div>' +
      '<div class="sam-recorder__controls"><button type="button" class="sam-recorder__start"></button><button type="button" class="sam-recorder__stop" disabled>停止并回听</button><span class="sam-recorder__clock" aria-label="录音时长">0:00</span></div>' +
      '<div class="sam-recorder__meter" role="meter" aria-label="麦克风音量，不是发音分数" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span></span></div>' +
      '<p class="sam-recorder__status" role="status" aria-live="polite"></p>' +
      '<div class="sam-recorder__result" hidden><h5>这一次练习</h5><audio controls playsinline preload="metadata"></audio><a class="sam-recorder__download">下载这条录音</a><div class="sam-recorder__feedback"></div></div>' +
      '<details class="sam-recorder__history"><summary>本题最近的录音</summary><div class="sam-recorder__history-list"></div></details>' +
      '<p class="sam-recorder__privacy">每题最多留 3 条、全站最多 18 条；较旧录音会自动替换。仅存这台设备的浏览器，清理网站数据会丢失，重要录音请下载。文字匹配分不是专业发音分，不能判定哪个音素读错。</p></section>';

    var el = {};
    ['title', 'guide', 'reference', 'start', 'stop', 'clock', 'meter', 'status', 'consent', 'recognition-purpose', 'recognition-note', 'result', 'download', 'feedback', 'history', 'history-list'].forEach(function (name) {
      el[name] = name === 'title' ? container.querySelector('h4') : container.querySelector('.sam-recorder__' + name);
    });
    el.audio = container.querySelector('audio');

    function status(message) { if (!state.destroyed) el.status.textContent = message; }
    function updateRecognitionChoice() {
      var scripted = assessmentMode(opts) === 'scripted';
      if (quick) {
        var label = scripted ? '开始跟读评分' : '开始回答';
        if (!Recognition) label = '开始录音';
        if (state.attempted) label = scripted && Recognition ? '再读一次并评分' : '再练一次';
        el.start.textContent = label;
        el.start.setAttribute('aria-label', label);
        return;
      }
      el.start.textContent = scripted ? '开始跟读录音' : '开始脱稿录音';
      el.start.setAttribute('aria-label', el.start.textContent + (el.consent.checked && Recognition ? '，已开启英文识别' : '，仅本地录音，未开启识别'));
      el['recognition-purpose'].textContent = scripted ? '跟读时显示文字匹配分和逐词对照' : '显示识别文字，换一种说法也可以；不按范文打分';
      el['recognition-note'].textContent = !Recognition ? (scripted ? '当前浏览器不支持语音识别：只能录音回听，不能生成文字匹配分。' : '当前浏览器不支持语音识别：只能录音回听，不能显示转写。') + '可尝试更新 iPad 系统后用 Safari；仍不可用时请下载给老师听。' :
        el.consent.checked ? scripted ? '已开启：说完后显示文字匹配分 /100。分数依据转写文字，不是专业发音评分。' : '已开启：说完显示英文转写。脱稿回答允许换词，不按参考稿逐字打分。' :
        scripted ? '当前仅录音，不识别、不评分。想看识别对照，请先勾选上方选项。' : '当前仅录音，不识别。可勾选上方选项查看英文转写；允许换一种说法，不按范文打分。';
    }
    function updateTarget() {
      if (quick) {
        var scripted = assessmentMode(opts) === 'scripted';
        el.title.textContent = scripted ? '轮到你跟读了' : '轮到你回答了';
        el.guide.textContent = !Recognition ? '说完点「完成录音」，再回听。' : opts.kind === 'sentence' ? '读完这一句，稍停一下就能看分数。' :
          scripted ? '句间可以停顿。全部说完，点「完成跟读」。' : '用自己的话回答，说完点「完成回答」看转写。';
        el.start.disabled = !supported;
        container.querySelector('.swt-local-only').disabled = !canRecord;
        el.feedback.innerHTML = scripted ? (Recognition ? scorePanel('—','等待你跟读') : unscored('此浏览器未提供英文识别，请用 iPad 的 Safari 打开。',false)) : '';
        updateRecognitionChoice();
        status(supported ? '' : '请在 iPad Safari 中打开网站，并允许麦克风。');
        return;
      }
      el.title.textContent = opts.title;
      el.guide.textContent = assessmentMode(opts) === 'scripted' ? '先听示范，再照着这次的参考句说。开启识别后可看匹配分：先复核一个词，再重录，不追求复杂长句。' : '听问题后，用自己的简单句回答。可以换词，不要求一字不差；先回答问题，再加一个真实理由。';
      el.reference.querySelector('p').textContent = opts.expectedText;
      el.reference.hidden = !opts.expectedText;
      el.reference.open = opts.kind === 'sentence';
      el.start.disabled = !supported;
      el.consent.disabled = !Recognition;
      el.consent.checked = !!(Recognition && pageRecognitionConsent);
      updateRecognitionChoice();
      status(supported ? '准备好后点开始，允许麦克风。录音时请保持 Safari 在前台。' : '此环境无法网页录音。请用 iPad Safari 打开 HTTPS 网址；若仍不支持，可使用「语音备忘录」。');
    }

    function revokeURLs() {
      state.urls.forEach(function (url) { root.URL.revokeObjectURL(url); });
      state.urls = [];
    }
    function objectURL(blob) { var url = root.URL.createObjectURL(blob); state.urls.push(url); return url; }
    function filename(record) {
      var ext = /mp4|m4a/i.test(record.blob.type) ? 'm4a' : /ogg/i.test(record.blob.type) ? 'ogg' : 'webm';
      return 'Sam-' + String(record.targetId).replace(/[^a-z0-9_-]/gi, '-').slice(0, 45) + '-' + record.createdAt + '.' + ext;
    }

    function renderFeedback(record) {
      el.feedback.innerHTML = quick ? practiceFeedback(record, opts.lexicon) : feedbackHTML(record, opts.lexicon);
    }

    function showRecord(record) {
      renderFeedback(record);
      el.audio.pause();
      revokeURLs();
      var hasAudio = !!(record.blob && record.blob.size);
      el.audio.hidden = el.download.hidden = !hasAudio;
      if (hasAudio) {
        el.audio.src = objectURL(record.blob);
        el.download.href = el.audio.src;
        el.download.download = filename(record);
      } else el.audio.removeAttribute('src');
      el.result.hidden = false;
      state.currentRecord = record;
    }

    async function refreshHistory() {
      if (state.destroyed || !el.history.open) return;
      if (state.historyPromise) return state.historyPromise;
      var generation = state.generation;
      state.historyPromise = allRecords();
      try {
        var records = await state.historyPromise;
        if (state.destroyed || !el.history.open || generation !== state.generation) return;
        state.entries = records.filter(function (record) { return record.targetId === opts.id; }).slice(0, MAX_PER_TARGET);
        el['history-list'].innerHTML = state.entries.length ? state.entries.map(function (record, i) {
          return '<div class="sam-recorder__history-row"><span>' + escapeHTML(new Date(record.createdAt).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })) + ' · ' + record.duration.toFixed(1) + ' 秒</span><button type="button" data-replay="' + i + '">查看 / 回听</button><button type="button" data-delete="' + i + '">删除此条</button></div>';
        }).join('') : '<p>还没有本题录音。录完后会保存在这里。</p>';
      } catch (_) {
        if (!state.destroyed) el['history-list'].textContent = '浏览器暂时无法持久保存录音。当前页面仍可回听和下载，请及时下载后再离开。';
      } finally { state.historyPromise = null; }
    }

    function cleanupCapture() {
      if (state.frame) root.cancelAnimationFrame(state.frame);
      root.clearInterval(state.timer);
      if (state.stream) state.stream.getTracks().forEach(function (track) { track.stop(); });
      if (state.source) { try { state.source.disconnect(); } catch (_) {} }
      if (state.context) { state.context.close().catch(function () {}); }
      state.stream = state.context = state.source = state.analyser = null;
      state.meterData = null;
      state.frame = state.timer = 0;
      if (active === api) active = null;
    }

    function clockTick() {
      var seconds = Math.floor((root.performance.now() - state.startedAt) / 1000);
      el.clock.textContent = Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
      if (seconds >= MAX_SECONDS) stop('已到 2 分钟上限，正在保存。建议分成短回答反复练。');
    }

    function monitorLevel() {
      if (!state.analyser || !state.recording) return;
      if (state.context && state.context.state !== 'running') {
        state.frame = root.requestAnimationFrame(monitorLevel);
        return;
      }
      // Ten visual updates per second are enough for a meter. Reusing the buffer
      // also avoids a new allocation and DOM mutation on every animation frame.
      var now = root.performance.now();
      if (now - state.meterAt < 100) { state.frame = root.requestAnimationFrame(monitorLevel); return; }
      state.meterAt = now;
      var data = state.meterData || (state.meterData = new Uint8Array(state.analyser.fftSize));
      state.analyser.getByteTimeDomainData(data);
      var sum = 0;
      for (var i = 0; i < data.length; i++) { var value = (data[i] - 128) / 128; sum += value * value; }
      var rms = Math.sqrt(sum / data.length);
      state.samples++;
      state.peakRMS = Math.max(state.peakRMS, rms);
      var level = Math.min(100, Math.round(rms * 450));
      el.meter.setAttribute('aria-valuenow', String(level));
      el.meter.firstElementChild.style.width = level + '%';
      state.frame = root.requestAnimationFrame(monitorLevel);
    }

    function recognitionPhase(recognizer, label, milliseconds, timeoutReason) {
      if (!quick || state.recognition !== recognizer || state.recognitionStopRequested) return;
      root.clearTimeout(state.scoreDeadline);
      if (scriptedRecord(opts)) el.feedback.innerHTML = scorePanel('—',label);
      status(label);
      state.scoreDeadline = root.setTimeout(function () {
        if (state.recognition !== recognizer || state.recognitionStopRequested) return;
        state.recognitionIncomplete = true;
        state.recognitionNote = timeoutReason;
        stop();
      },milliseconds);
    }

    function startRecognition(prefix) {
      if (!el.consent.checked || !Recognition) return;
      prefix = prefix || '';
      try {
        var recognizer = new Recognition();
        state.recognition = recognizer;
        recognizer.lang = 'en-US';
        recognizer.continuous = !quick || opts.kind !== 'sentence';
        recognizer.interimResults = !(quick && opts.kind === 'sentence');
        recognitionPhase(recognizer,'正在启动英文识别，请稍等…',10000,'浏览器在 10 秒内没有启动英文识别。可以重试。');
        var started = false;
        function markListening() {
          if (started || state.recognition !== recognizer) return;
          started = true;
          recognitionPhase(recognizer,'麦克风已就绪，请开口。',opts.kind === 'sentence' ? 18000 : 75000,
            '识别已启动，但未在练习时限内返回完整结果。请再试一次。');
        }
        recognizer.onstart = markListening;
        recognizer.onresult = function (event) {
          if (state.recognition !== recognizer) return;
          markListening();
          var complete = [], interim = [];
          for (var i = 0; i < event.results.length; i++) {
            var part = event.results[i];
            if (!part || !part[0] || !part[0].transcript) continue;
            var confirmed = part.isFinal === true || (!recognizer.interimResults && part.isFinal !== false);
            (confirmed ? complete : interim).push(part[0].transcript);
          }
          state.finalTranscript = [prefix, complete.join(' ')].filter(Boolean).join(' ').trim();
          state.interimTranscript = interim.join(' ').trim();
          if (quick && scriptedRecord(opts) && state.finalTranscript && !state.interimTranscript &&
              !state.recognitionIncomplete && (opts.kind==='sentence' || state.recognitionStopRequested)) {
            renderFeedback(Object.assign({},opts,{recognitionRequested:true,transcript:state.finalTranscript,transcriptSource:'browser-final'}));
          }
          if (quick && !state.recognitionStopRequested) {
            status([state.finalTranscript, state.interimTranscript].filter(Boolean).join(' ') || '正在听你说…');
            if (opts.kind === 'sentence' && state.finalTranscript && !state.interimTranscript) stop();
          }
        };
        recognizer.onerror = function (event) {
          if (state.recognition !== recognizer) return;
          if (state.recognitionStopRequested && (event.error === 'aborted' ||
              (quick && opts.kind === 'sentence' && state.finalTranscript && !state.interimTranscript && !state.recognitionIncomplete))) return;
          state.recognitionIncomplete = true;
          state.recognitionNote = recognitionFailure(event.error);
          if (['audio-capture','not-allowed','service-not-allowed'].indexOf(event.error)>=0) scoreMicReady = false;
          if (!state.destroyed) el['recognition-note'].textContent = state.recognitionNote;
          if (quick && !state.recognitionStopRequested) stop();
        };
        recognizer.onend = function () {
          if (quick) {
            if (state.recognition !== recognizer) return;
            state.recognition = null;
            if (state.finishRecognitionWait) state.finishRecognitionWait();
            if (state.recognitionStopRequested || !state.recording || state.destroyed) return;
            if (opts.kind === 'answer' && opts.expectedText && !state.interimTranscript &&
                compareText(opts.expectedText,state.finalTranscript).distance === 0) {
              stop();
              return;
            }
            // Some Safari sessions end on a pause even in continuous mode.
            // Keep confirmed segments when a learner pauses between sentences.
            if (opts.kind === 'answer' && !state.recognitionIncomplete && !state.interimTranscript &&
                state.finalTranscript && state.finalTranscript !== prefix) {
              startRecognition(state.finalTranscript);
              return;
            }
            if (!state.finalTranscript || state.interimTranscript || opts.kind === 'answer') {
              state.recognitionIncomplete = true;
              state.recognitionNote = '识别已结束，但未收到完整英文。请重新开始。';
            }
            stop();
            return;
          }
          if (state.recognition === recognizer && state.recording && !state.recognitionStopRequested) {
            state.recognitionIncomplete = true;
            state.recognitionNote = '识别服务提前结束，转写可能不完整；本地录音仍继续。本次不据此评分。';
            if (!state.destroyed) el['recognition-note'].textContent = state.recognitionNote;
          }
        };
        recognizer.start();
      } catch (_) {
        state.recognitionIncomplete = true;
        state.recognitionNote = '浏览器未能启动英文识别。请重试，或选「仅录音回听」。';
        if (quick) { state.recognition = null; stop(); }
      }
    }

    async function finishRecording(snapshot, duration, reason) {
      if (!quick) cleanupCapture();
      // Give browser recognition a bounded chance to deliver its final result.
      if (state.recognition) {
        if (quick && (opts.kind === 'answer' || !state.finalTranscript) && !state.recognitionIncomplete) {
          await new Promise(function (resolve) {
            var deadline = root.setTimeout(function () {
              if (state.interimTranscript) state.recognitionIncomplete = true;
              resolve();
            }, 2200);
            state.finishRecognitionWait = function () { root.clearTimeout(deadline); resolve(); };
          });
          state.finishRecognitionWait = null;
        } else if (!quick) await new Promise(function (resolve) { root.setTimeout(resolve, 650); });
        var finishedRecognizer = state.recognition;
        state.recognition = null;
        if (finishedRecognizer) try { finishedRecognizer.abort(); } catch (_) {}
      }
      if (quick) cleanupCapture();
      var type = (state.recorder && state.recorder.mimeType) || (state.chunks[0] && state.chunks[0].type) || 'audio/mp4';
      var blob = snapshot.captureAudio ? new Blob(state.chunks, { type: type }) : null;
      var hasAudio = !!(blob && blob.size);
      state.recorder = null;
      state.chunks = [];
      if (hasAudio || (quick && snapshot.recognitionRequested)) {
        var record = { key: String(Date.now()) + '-' + Math.random().toString(36).slice(2, 9), targetId: snapshot.id,
          title: snapshot.title, expectedText: snapshot.expectedText, kind: snapshot.kind, assessmentMode: snapshot.assessmentMode,
          recognitionRequested: snapshot.recognitionRequested, createdAt: Date.now(),
          blob: blob, duration: duration, samples: state.samples, peakRMS: state.peakRMS,
          transcript: state.finalTranscript, interimTranscript: state.interimTranscript,
          transcriptSource: state.finalTranscript && snapshot.recognitionRequested ? 'browser-final' : 'none',
          recognitionIncomplete: state.recognitionIncomplete,
          recognitionNote: state.recognitionNote };
        if (typeof snapshot.onTake === 'function') {
          snapshot.onTake({complete:record.transcriptSource==='browser-final'&&!record.recognitionIncomplete,transcript:record.transcriptSource==='browser-final'?record.transcript:'', duration:duration, hasAudio:hasAudio});
        }
        // Show the current take before waiting on IndexedDB.
        if (quick && !state.destroyed) showRecord(record);
        var saved = false;
        if (hasAudio) {
          var storageDeadline;
          try {
            await Promise.race([storeRecord(record), new Promise(function (_, reject) {
              storageDeadline = root.setTimeout(function () { reject(new Error('storage-timeout')); },3500);
            })]);
            saved = true;
          } catch (_) {}
          finally { root.clearTimeout(storageDeadline); }
        }
        if (saved) {
          // Only a newly captured, nonempty, persisted blob emits this event.
          // Restoring/listening to a historical recording never increments practice.
          var detail = { id: record.targetId, kind: record.kind, duration: record.duration,
            savedAt: record.createdAt, bytes: record.blob.size };
          root.dispatchEvent(new CustomEvent('sam-recorder-saved', { detail: detail }));
          if (typeof snapshot.onSaved === 'function') { try { snapshot.onSaved(detail); } catch (_) {} }
        }
        if (!state.destroyed) {
          if (!quick) showRecord(record);
          if (quick) status(saved ? '录音已保存，可回听。' : hasAudio ? '录音可回听，请在离开前下载。' : record.recognitionIncomplete || !record.transcript ? '本次未收到可评分的完整转写。' : '识别完成。');
          else status(saved ? (reason ? reason + ' ' : '') + '录音已在本机保存，请点播放器回听。' : '录音完成，但浏览器无法保存。请立即下载，离开页面后可能丢失。');
          if (hasAudio) refreshHistory().catch(function () {});
          if (!snapshot.captureAudio && record.transcriptSource==='browser-final' && !record.recognitionIncomplete &&
              tokenize(record.transcript).length) {
            root.dispatchEvent(new CustomEvent('sam-recognition-complete',{detail:{id:snapshot.id,duration:duration,savedAt:record.createdAt}}));
          }
        }
      } else status('没有生成有效音频。请检查权限，并保持 Safari 在前台重新录制。');
      state.starting = false;
      if (!state.destroyed) {
        el.start.disabled = !supported;
        el.stop.disabled = true;
        el.consent.disabled = !Recognition;
        container.classList.remove('is-recording');
        if (quick) updateRecognitionChoice();
      }
      if (state.resolveStop) state.resolveStop();
      state.resolveStop = null;
      state.stopPromise = null;
    }

    async function start(localOnly) {
      if (state.recording || state.starting || state.destroyed || !supported) return;
      if (active && active !== api) { status('另一个练习正在录音。请先停止并保存那一条，再开始这里。'); return; }
      active = api;
      var captureGeneration = ++state.captureGeneration;
      var captureAudio = canRecord && (!quick || !Recognition || localOnly === true || localOnly === 'with-audio');
      state.starting = true;
      state.permissionPending = true;
      state.stopRequested = false;
      if (quick) {
        state.attempted = true;
        el.consent.checked = localOnly !== true && !!Recognition;
        el.result.hidden = true;
        if (scriptedRecord(opts)) el.feedback.innerHTML = scorePanel('—',el.consent.checked ? '准备识别英文' : '仅录音回听');
        state.permissionTimer = root.setTimeout(function () {
          if (!state.permissionPending) return;
          stop();
          status('麦克风准备超时，请检查 Safari 的麦克风权限后重试。');
        }, 18000);
      }
      el.start.disabled = true;
      el.stop.disabled = false;
      el.stop.textContent = '取消麦克风等待';
      el.consent.disabled = true;
      el.audio.pause();
      status('正在请求麦克风权限，请在弹窗中选择允许。');
      try {
        root.dispatchEvent(new CustomEvent('sam-recorder-start', { detail: { id: opts.id } }));
        if (typeof opts.onStart === 'function') { try { opts.onStart(); } catch (_) {} }
        if (opts.kind === 'answer') el.reference.open = false;
        var media = root.navigator.mediaDevices;
        var checkPermission = !captureAudio && !scoreMicReady && localOnly !== 'score-only' && media && media.getUserMedia;
        var grantedStream = captureAudio || checkPermission ? await media.getUserMedia({audio:true,video:false}) : null;
        if (state.destroyed || state.stopRequested || captureGeneration !== state.captureGeneration) {
          if (grantedStream) grantedStream.getTracks().forEach(function (track) { track.stop(); });
          return;
        }
        if (checkPermission) {
          grantedStream.getTracks().forEach(function (track) { track.stop(); });
          grantedStream = null;
          scoreMicReady = true;
        }
        state.stream = grantedStream;
        state.permissionPending = false;
        root.clearTimeout(state.permissionTimer);
        var type = captureAudio ? mimeChoice() : '';
        if (captureAudio) {
          try { state.recorder = type ? new root.MediaRecorder(state.stream, { mimeType: type }) : new root.MediaRecorder(state.stream); }
          catch (_) {
            try { state.recorder = new root.MediaRecorder(state.stream); }
            catch (error) {
              if (!quick || !el.consent.checked) throw error;
              state.recorder = null;
              state.stream.getTracks().forEach(function (track) { track.stop(); });
              state.stream = null;
            }
          }
        }
        var snapshot = Object.assign({}, opts, { captureAudio:captureAudio, assessmentMode: assessmentMode(opts), recognitionRequested: !!(el.consent.checked && Recognition) });
        var endReason = '';
        state.chunks = []; state.samples = 0; state.peakRMS = 0; state.meterAt = -Infinity;
        state.finalTranscript = ''; state.interimTranscript = ''; state.recognitionNote = '';
        state.recognitionStopRequested = false; state.recognitionIncomplete = false;
        if (state.recorder) state.recorder.ondataavailable = function (event) { if (event.data && event.data.size) state.chunks.push(event.data); };
        var captureFinished = false;
        function completeCapture() {
          if (captureFinished) return;
          captureFinished = true;
          root.clearTimeout(state.captureStopDeadline);
          var duration = (root.performance.now() - state.startedAt) / 1000;
          state.recording = false;
          finishRecording(snapshot, duration, state.endReason || endReason).catch(function () {
            cleanupCapture(); state.starting = false; state.recorder = null;
            if (!state.destroyed) {
              el.start.disabled = !supported; el.stop.disabled = true; el.consent.disabled = !Recognition;
              container.classList.remove('is-recording');
            }
            status('音频处理失败，请重试或改用「语音备忘录」。');
            if (state.resolveStop) state.resolveStop();
            state.resolveStop = null; state.stopPromise = null;
          });
        };
        if (state.recorder) {
          state.recorder.onstop = completeCapture;
          state.finishCapture = completeCapture;
          state.recorder.onerror = function () { endReason = '录音过程中浏览器报告异常，请回听确认是否完整。'; stop(endReason); };
          try { state.recorder.start(); }
          catch (error) {
            if (!quick || !el.consent.checked) throw error;
            state.recorder.onstop = state.recorder.onerror = state.recorder.ondataavailable = null;
            state.recorder = null;
            state.stream.getTracks().forEach(function (track) { track.stop(); });
            state.stream = null;
            state.finishWithoutAudio = completeCapture;
          }
        } else state.finishWithoutAudio = completeCapture;
        state.endReason = '';
        state.startedAt = root.performance.now();
        state.recording = true;
        state.starting = false;
        state.stopPromise = new Promise(function (resolve) { state.resolveStop = resolve; });
        el.stop.disabled = false;
        el.stop.textContent = quick ? (snapshot.recognitionRequested ? assessmentMode(opts) === 'scripted' ? '完成跟读' : '完成回答' : '完成录音') : '停止并回听';
        container.classList.add('is-recording');
        try {
          var Context = root.AudioContext || root.webkitAudioContext;
          if (Context && state.stream) {
            state.context = new Context();
            if (state.context.state === 'suspended') state.context.resume().catch(function () {});
            state.source = state.context.createMediaStreamSource(state.stream);
            state.analyser = state.context.createAnalyser();
            state.analyser.fftSize = 1024;
            state.source.connect(state.analyser);
            monitorLevel();
          }
        } catch (_) { /* Recording still works without an audio-level meter. */ }
        state.timer = root.setInterval(clockTick, 250);
        status(quick ? (snapshot.recognitionRequested ? '正在听你说…' : '正在录音…') : snapshot.recognitionRequested ? '正在录音并尝试识别英文。说完点「停止并回听」；请保持 Safari 在前台。' : '正在本地录音（未开启识别，不评分）。说完点「停止并回听」；请保持 Safari 在前台。');
        startRecognition();
      } catch (error) {
        if (captureGeneration !== state.captureGeneration || state.destroyed) return;
        root.clearTimeout(state.permissionTimer);
        cleanupCapture();
        state.starting = false;
        state.permissionPending = false;
        el.start.disabled = !supported;
        el.stop.disabled = true;
        el.stop.textContent = '停止并回听';
        el.consent.disabled = !Recognition;
        status(permissionMessage(error));
        if (quick && scriptedRecord(opts)) el.feedback.innerHTML = unscored(permissionMessage(error),!!Recognition);
      }
    }

    function stop(reason) {
      root.clearTimeout(state.permissionTimer);
      root.clearTimeout(state.scoreDeadline);
      if (state.permissionPending) {
        state.stopRequested = true;
        state.captureGeneration++;
        state.starting = false;
        state.permissionPending = false;
        cleanupCapture();
        if (!state.destroyed) {
          el.start.disabled = !supported;
          el.stop.disabled = true;
          el.stop.textContent = '停止并回听';
          el.consent.disabled = !Recognition;
          status('已取消麦克风等待，可以继续点读。若权限弹窗稍后出现，可选择取消；重新录音请再点开始。');
          if (quick && scriptedRecord(opts)) el.feedback.innerHTML = unscored('麦克风准备已取消，请重试。',!!Recognition);
        }
        return Promise.resolve();
      }
      if (!state.recording || state.recognitionStopRequested) return state.stopPromise || Promise.resolve();
      state.endReason = typeof reason === 'string' ? reason : '';
      state.starting = true;
      el.stop.disabled = true;
      status(quick && !state.recorder ? '正在接收最后的识别结果…' : '正在完成本次录音…');
      state.recognitionStopRequested = true;
      if (state.recognition) { try { state.recognition.stop(); } catch (_) {} }
      if (state.recorder && state.finishCapture) {
        state.captureStopDeadline = root.setTimeout(state.finishCapture,3000);
        if (state.recorder.state !== 'inactive') {
          try { state.recorder.stop(); } catch (_) { state.finishCapture(); }
        }
      }
      else if (state.finishWithoutAudio) {
        var finish = state.finishWithoutAudio;
        state.finishWithoutAudio = null;
        finish();
      }
      return state.stopPromise || Promise.resolve();
    }

    function visibilityChanged() {
      if (root.document.hidden && (state.recording || state.permissionPending)) stop('页面进入后台，本次录音已停止。');
    }
    function beforeLeave(event) {
      if (state.recording || state.starting) { event.preventDefault(); event.returnValue = ''; }
    }
    function pageHide() {
      if (state.starting || state.recording) stop();
      cleanupCapture();
    }
    function historyAction(event) {
      var replay = event.target.closest('[data-replay]');
      var remove = event.target.closest('[data-delete]');
      if (state.recording || state.starting) { status('请先停止并保存录音，再查看或删除历史记录。'); return; }
      if (replay) { var record = state.entries[Number(replay.dataset.replay)]; if (record) { showRecord(record); el.result.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } }
      if (remove) {
        var target = state.entries[Number(remove.dataset.delete)];
        if (target) deleteRecord(target.key).then(function () {
          if (state.currentRecord && state.currentRecord.key === target.key) { el.audio.pause(); el.audio.removeAttribute('src'); revokeURLs(); el.result.hidden = true; state.currentRecord = null; }
          status('已删除这条本地录音，不能从本页面恢复。'); refreshHistory();
        }).catch(function () { status('删除没有成功，请稍后重试。'); });
      }
    }

    el.start.addEventListener('click', start);
    if (quick) {
      el.audio.loop = true;
      container.querySelector('.swt-local-only').addEventListener('click', function () { return start(true); });
      var withAudio = container.querySelector('.swt-with-audio');
      if (withAudio) withAudio.addEventListener('click', function () { return start('with-audio'); });
    }
    el.stop.addEventListener('click', function () { stop(); });
    el.consent.addEventListener('change', function () {
      pageRecognitionConsent = !!(el.consent.checked && Recognition);
      updateRecognitionChoice();
    });
    el.feedback.addEventListener('click', function (event) {
      if (quick && event.target.closest('[data-score-only]')) {
        if (Recognition) start('score-only');
        else status('当前浏览器未提供英文识别，请用 iPad Safari 打开评分。');
        return;
      }
      var button = event.target.closest('[data-review-word]');
      if (!button) return;
      if (state.recording || state.starting) { status('请先停止并保存录音，再听标准词。'); return; }
      var key = button.dataset.reviewWord, word = (opts.lexicon || {})[key] || {};
      var src = word.src || (typeof word.audio === 'string' ? word.audio : word.audio && word.audio.normal) || '';
      el.audio.pause();
      root.dispatchEvent(new CustomEvent('sam-review-word', { detail: { word: key, ipa: word.ipa || '', zh: word.zh || '', src: src, targetId: opts.id } }));
    });
    el['history-list'].addEventListener('click', historyAction);
    el.history.addEventListener('toggle', function () {
      if (el.history.open) refreshHistory();
      else { state.entries = []; el['history-list'].innerHTML = ''; }
    });
    root.document.addEventListener('visibilitychange', visibilityChanged);
    root.addEventListener('beforeunload', beforeLeave);
    root.addEventListener('pagehide', pageHide);

    api = {
      start: start,
      stop: stop,
      isRecording: function () { return state.recording || state.starting; },
      setTarget: async function (next) {
        // Do not abandon a pending permission prompt or silently switch its target.
        if (state.permissionPending) { status('请先处理麦克风权限提示，或点「取消麦克风等待」，再切换练习。'); return false; }
        await stop('已切换练习，前一条录音已停止并保存。');
        state.generation++;
        opts = Object.assign({}, opts, next || {});
        state.entries = []; state.currentRecord = null;
        el.audio.pause(); el.audio.removeAttribute('src'); el.audio.load();
        revokeURLs(); el.result.hidden = true; el.consent.checked = false;
        updateTarget(); await refreshHistory(); return true;
      },
      destroy: async function () {
        await stop();
        state.destroyed = true;
        state.generation++;
        state.captureGeneration++;
        state.entries = []; state.currentRecord = null;
        cleanupCapture();
        if (state.recognition) { try { state.recognition.abort(); } catch (_) {} }
        el.audio.pause(); el.audio.removeAttribute('src'); el.audio.load(); revokeURLs();
        root.document.removeEventListener('visibilitychange', visibilityChanged);
        root.removeEventListener('beforeunload', beforeLeave);
        root.removeEventListener('pagehide', pageHide);
        container.innerHTML = '';
      }
    };
    // Histories start collapsed. Do not open IndexedDB or load recording Blobs
    // until the learner actually asks to see history.
    updateTarget();
    return api;
  }

  root.SamRecorder = { latestAudio: async function(id){ var rows=await allRecords(); var row=rows.find(function(r){return r.targetId===id && r.blob;}); return row?row.blob:null; }, mount: mount, compareText: compareText, evaluateReading: evaluateReading, signalAdvice: signalAdvice };
  if (typeof module !== 'undefined' && module.exports) module.exports = { tokenize: tokenize, compareText: compareText, evaluateReading: evaluateReading, feedbackHTML: feedbackHTML, signalAdvice: signalAdvice, permissionMessage: permissionMessage };
})(typeof window !== 'undefined' ? window : globalThis);
