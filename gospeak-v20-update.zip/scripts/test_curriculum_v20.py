"""Offline checks for short answers, shared sentence identity, and real facts."""
import json
import re
import unittest

import v19_curriculum as old
import v20_curriculum as course


class CurriculumTests(unittest.TestCase):
    def test_all_24_topics(self):
        self.assertTrue(course.validate_curriculum())
        self.assertEqual([q["id"] for q in course.QUESTIONS], [f"{i:02d}" for i in range(1, 25)])

    def test_short_default_answers(self):
        for q in course.QUESTIONS:
            for sentence in q["short"]:
                words = re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", sentence["en"])
                if "Guangxi College" not in sentence["en"]:
                    self.assertLessEqual(len(words), 8, sentence["en"])
                self.assertNotIn("[", sentence["en"])

    def test_short_followups(self):
        for q in course.QUESTIONS:
            for f in q["followups"]:
                self.assertLessEqual(len(f["answer"]), 3)
                for s in f["answer"]:
                    self.assertLessEqual(len(s["en"].split()), 8, s["en"])

    def test_shared_identity_and_metadata(self):
        seen = {}
        for s in course.all_sentences():
            prior = seen.setdefault(s["en"], s)
            self.assertEqual(s, prior, s["en"])
            self.assertEqual(s["id"], course.sentence_id(s["en"]))
            for field in ("en", "zh", "chunks", "grammar", "pronunciation"):
                self.assertTrue(s[field], (s["en"], field))
            if "[" not in s["en"]:
                self.assertTrue(s["ipa"], s["en"])
        # Mainline and sentence study can identify this reused line exactly.
        self.assertEqual(course.QUESTIONS[0]["short"][3], course.QUESTIONS[19]["short"][1])

    def test_correct_profile(self):
        p = course.PROFILE
        self.assertEqual(p["englishName"], "Sam")
        self.assertEqual(p["schoolZh"], "广西幼儿师范高等专科学校")
        self.assertEqual(p["majorZh"], "体育体能训练")
        self.assertEqual(p["majorEn"], "physical fitness training")
        default = " ".join(s["en"] for q in course.QUESTIONS for s in q["short"] + q["extra"])
        self.assertIn("I have a Chinese lifeguard certificate.", default)
        self.assertIn("I will return to China after SWT.", default)
        self.assertIn("I will continue my studies.", default)
        for text in ("Junxi", "business major", "sports art", "I have a passport", "my parents support", "I worked", "U.S. certified"):
            self.assertNotIn(text, default)
        self.assertIsNone(re.search(r"I can swim \d", default))

    def test_unknown_facts_remain_unconfirmed(self):
        for q in course.QUESTIONS:
            if q["id"] in {"14", "15", "16", "17", "18", "19", "21", "24"}:
                self.assertFalse(q["short"])
                self.assertFalse(q["readyForAutoplay"])
                self.assertTrue(q["requiresConfirmation"])
            for b in q["branches"]:
                self.assertFalse(b["confirmed"])
                for s in b["sentences"]:
                    if "[" in s["en"]:
                        self.assertTrue(s["needsPersonalization"])
                        self.assertFalse(s["ipa"])

    def test_preserve_different_question_intents(self):
        replaced_followups = {("02", 0): 2, ("08", 0): 2}
        for before, after in zip(old.QUESTIONS, course.QUESTIONS):
            self.assertEqual(before["question"], after["question"])
            self.assertEqual(before["questionZh"], after["questionZh"])
            for index, (v1, v2) in enumerate(zip(before["variants"], after["variants"])):
                # Keep every original prompt and Chinese meaning. Existing
                # safety hints must survive exactly; new related-intent hints
                # are allowed, and every explicit override must be applied.
                self.assertEqual(v1["en"], v2["en"])
                self.assertEqual(v1["zh"], v2["zh"])
                if v1.get("hint"):
                    self.assertEqual(v1["hint"], v2["hint"])
                override = course.VARIANT_INTENT_OVERRIDES.get((after["id"], index))
                if override:
                    self.assertEqual(override, v2["hint"])
            for index, (f1, f2) in enumerate(zip(before["followups"], after["followups"])):
                key = (after["id"], index)
                if key in replaced_followups:
                    source = after["variants"][replaced_followups[key]]
                    self.assertEqual(source["en"], f2["en"])
                    self.assertEqual(source["zh"], f2["zh"])
                    self.assertTrue(source["hint"])
                    self.assertTrue(f2["hint"])
                    self.assertTrue(f2["answer"])
                else:
                    self.assertEqual(f1["en"], f2["en"])
                    self.assertEqual(f1["zh"], f2["zh"])
                    self.assertEqual(f1["hint"], f2["hint"])
        self.assertEqual(course.QUESTIONS[1]["followups"][0]["answer"], course.take("life", "understand_people"))
        self.assertEqual(course.QUESTIONS[7]["followups"][0]["answer"], course.take("repeat_slow", "slow_request"))
        america = " ".join(s["en"] for s in course.QUESTIONS[1]["short"])
        swt = " ".join(s["en"] for s in course.QUESTIONS[2]["short"])
        self.assertNotEqual(america, swt)
        self.assertIn("at work", swt)

    def test_json_ready(self):
        exported = json.loads(json.dumps(course.export_payload()))
        self.assertEqual(exported["version"], "v20")
        self.assertIn("不是发音标准分", exported["plan"]["assessmentLimit"])


if __name__ == "__main__":
    unittest.main()
