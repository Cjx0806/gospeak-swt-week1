'use strict';
// Browser API mocks only: this test cannot access a microphone or any network.
const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const { join } = require('node:path');
const vm = require('node:vm');
class Element {
  constructor() { this.children = new Map(); this.listeners = new Map(); this.textContent = ''; this.innerHTML = ''; this.hidden = false; this.disabled = false; this.checked = false; this.style = {}; this.attributes = {}; this.classList = { add() {}, remove() {} }; }
  querySelector(selector) { if (!this.children.has(selector)) this.children.set(selector, new Element()); return this.children.get(selector); }
  addEventListener(name, fn) { this.listeners.set(name, fn); }
  removeEventListener(name) { this.listeners.delete(name); }
  setAttribute(key, value) { this.attributes[key] = value; }
  removeAttribute(key) { delete this.attributes[key]; }
  pause() {}
  load() {}
  scrollIntoView() {}
}
const recordedEvents = [], records = new Map(), tracks = [], revoked = [];
let now = 0, storageFailure = false, recognitionStarts = 0, permissionError = null, customGetMedia = null;
function makeStream() { const track = { stopped: false, stop() { this.stopped = true; } }; tracks.push(track); return { getTracks: () => [track] }; }
class FakeMediaRecorder {
  static isTypeSupported(type) { return type === 'audio/mp4'; }
  constructor(stream, options) { this.stream = stream; this.mimeType = options?.mimeType || 'audio/mp4'; this.state = 'inactive'; }
  start() { this.state = 'recording'; }
  stop() { this.state = 'inactive'; queueMicrotask(() => { this.ondataavailable({ data: new Blob(['simulated-recording'], { type: this.mimeType }) }); this.onstop(); }); }
}
class FakeRecognition {
  constructor() { FakeRecognition.last = this; }
  start() { recognitionStarts++; }
  stop() { this.onend?.(); }
  abort() {}
}
const db = {
  objectStoreNames: { contains: () => true },
  transaction(name, mode) {
    const tx = {};
    const complete = () => setTimeout(() => storageFailure ? tx.onerror?.() : tx.oncomplete?.(), 0);
    tx.objectStore = () => ({
      getAll() { const request = {}; queueMicrotask(() => { request.result = [...records.values()]; request.onsuccess(); }); return request; },
      put(record) { if (!storageFailure) records.set(record.key, record); complete(); },
      delete(key) { records.delete(key); complete(); }
    });
    return tx;
  }
};
const document = new Element();
const root = {
  isSecureContext: true, document,
  navigator: { mediaDevices: { getUserMedia: async () => { if (permissionError) throw permissionError; return customGetMedia ? customGetMedia() : makeStream(); } } },
  MediaRecorder: FakeMediaRecorder, SpeechRecognition: FakeRecognition,
  indexedDB: { open() { const request = {}; queueMicrotask(() => { request.result = db; request.onsuccess(); }); return request; } },
  performance: { now: () => now }, URL: { createObjectURL: () => 'blob:mock-' + Math.random(), revokeObjectURL: url => revoked.push(url) },
  setTimeout, clearTimeout, setInterval, clearInterval, cancelAnimationFrame() {},
  addEventListener() {}, removeEventListener() {}, dispatchEvent: event => recordedEvents.push(event)
};
const context = vm.createContext({ window: root, Blob, Uint8Array, Promise, Date, Math, CustomEvent: class { constructor(type, init) { this.type = type; this.detail = init.detail; } } });
vm.runInContext(readFileSync(join(__dirname, '../assets/recorder-v19.js'), 'utf8'), context);
const flush = () => new Promise(resolve => setTimeout(resolve, 5));
const make = (id, extra = {}) => { const container = new Element(); const api = root.SamRecorder.mount(container, { id, title: 'Test', kind: 'answer', expectedText: 'I am Sam.', ...extra }); return { container, api, el: suffix => container.querySelector('.sam-recorder__' + suffix) }; };

(async () => {
  const first = make('q1');
  await first.api.start(); now += 35000; await first.api.stop();
  assert.equal(recognitionStarts, 0, 'no speech service without explicit consent');
  assert(tracks.every(track => track.stopped), 'tracks released after stopping');
  assert.equal(records.size, 1);
  assert.equal(recordedEvents.filter(event => event.type === 'sam-recorder-saved').length, 1);
  assert.equal(recordedEvents.find(event => event.type === 'sam-recorder-saved').detail.duration, 35);
  assert.match(first.el('status').textContent, /本机保存/);
  assert.match(first.container.querySelector('audio').src, /^blob:/);
  await first.api.setTarget({ id: 'q2', kind: 'sentence' });
  assert.equal(first.el('start').textContent, '开始跟读录音');
  await first.api.start(); now += 2500; await first.api.setTarget({ id: 'q3' });
  assert([...records.values()].some(record => record.targetId === 'q2' && record.blob.size));
  assert.equal(first.api.isRecording(), false);
  await first.api.start(); now += 4000; await first.api.destroy();
  assert([...records.values()].some(record => record.targetId === 'q3'), 'destroy waits for recorded blob to persist');
  assert.equal(first.container.innerHTML, '');
  assert(tracks.every(track => track.stopped));
  assert(revoked.length >= 2, 'old object URLs revoked');

  const blocked = make('denied');
  permissionError = { name: 'NotAllowedError' };
  await blocked.api.start();
  assert.match(blocked.el('status').textContent, /麦克风未获允许/);
  assert.equal(blocked.el('start').disabled, false);
  permissionError = null;
  await blocked.api.destroy();

  const pending = make('pending');
  let grant;
  customGetMedia = () => new Promise(resolve => { grant = resolve; });
  const pendingStart = pending.api.start();
  assert.equal(await pending.api.setTarget({ id: 'should-not-switch' }), false);
  await pending.api.destroy();
  grant(makeStream()); await pendingStart;
  assert(tracks.every(track => track.stopped), 'late permission grant is immediately released after destroy');
  assert(![...records.values()].some(record => record.targetId === 'pending'));
  customGetMedia = null;

  const recognition = make('transcript');
  recognition.el('consent').checked = true;
  await recognition.api.start();
  assert.equal(recognitionStarts, 1);
  FakeRecognition.last.onresult({ results: [Object.assign([{ transcript: 'I am <img src=x> Sam' }], { isFinal: true })] });
  now += 3000; await recognition.api.stop();
  assert.match(recognition.el('feedback').innerHTML, /&lt;img src=x&gt;/);
  assert(!recognition.el('feedback').innerHTML.includes('<img src=x>'));
  await recognition.api.destroy();

  const unsaved = make('storage-error'); storageFailure = true;
  const eventsBefore = recordedEvents.filter(event => event.type === 'sam-recorder-saved').length;
  await unsaved.api.start(); now += 3000; await unsaved.api.stop();
  assert.match(unsaved.el('status').textContent, /立即下载/);
  assert.equal(recordedEvents.filter(event => event.type === 'sam-recorder-saved').length, eventsBefore);
  assert.match(unsaved.container.querySelector('audio').src, /^blob:/, 'failed storage still leaves playable blob');
  storageFailure = false; await unsaved.api.destroy();

  const bounded = make('bounded');
  for (let i = 0; i < 5; i++) { await bounded.api.start(); now += 3000; await bounded.api.stop(); await flush(); }
  assert.equal([...records.values()].filter(record => record.targetId === 'bounded').length, 3);
  for (let i = 0; i < 20; i++) { await bounded.api.setTarget({ id: 'cap-' + i }); await bounded.api.start(); now += 3000; await bounded.api.stop(); await flush(); }
  assert.equal(records.size, 18);
  await bounded.api.destroy();
  assert(tracks.every(track => track.stopped));
  console.log('Recorder lifecycle mocks passed: consent off, capture, save, events, switching, destroy, permission rejection, late grant, XSS escaping, storage fallback, retention caps.');
})().catch(error => { console.error(error); process.exitCode = 1; });
