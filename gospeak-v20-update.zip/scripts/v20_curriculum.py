"""V20: one small sentence bank shared by sentence study and oral answers.

Original teaching examples, not official questions or a promise of passing.
Same normalized English -> same stable ID in every topic. Unknown biography
stays in unconfirmed branches and is never part of the default spoken answer.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import re

import v19_curriculum as previous

VERSION = "v20"
PROFILE = deepcopy(previous.PROFILE)
SOURCE_NOTES = deepcopy(previous.SOURCE_NOTES)
TRAINING_PLAN = deepcopy(previous.TRAINING_PLAN)
QUESTIONS = deepcopy(previous.QUESTIONS)


def normalized(text):
    return " ".join(re.findall(r"[a-z]+(?:['’-][a-z]+)*", text.lower()))


def sentence_id(text):
    return "s-" + hashlib.sha256(normalized(text).encode()).hexdigest()[:12]


def S(en, zh, ipa, grammar, chunks=None, pronunciation=""):
    return {
        "id": sentence_id(en), "en": en, "zh": zh, "ipa": ipa,
        "chunks": chunks or [en], "grammar": grammar,
        "pronunciation": pronunciation or "先听一句，再自然说完；句末轻停。音标是读音提示，不是录音诊断结果。",
    }


# Small reusable units. Prefer familiar I am / I have / I want / I would.
# Grammar labels deliberately distinguish linking verbs from objects.
LINES = {
    "name": S("Hello, my name is Sam.", "你好，我叫 Sam。", "həˈloʊ maɪ neɪm ɪz sæm", "Hello 打招呼；my name 主语＋is 系动词＋Sam 表语。", ["Hello,", "my name is Sam."], "Sam /sæm/：嘴张开，最后双唇闭合发 /m/，不要读成 same。"),
    "year": S("I am a first-year student.", "我是大一学生。", "aɪ æm ə ˈfɝst jɪr ˈstudənt", "I 主语＋am 系动词＋a first-year student 表语；first-year 修饰 student。", ["I am", "a first-year student."]),
    "school": S("My college is Guangxi College for Preschool Education.", "我的学校是广西幼儿师范高等专科学校。", "maɪ ˈkɑlɪdʒ ɪz ɡwɑŋˈʃi ˈkɑlɪdʒ fər ˈpriskul ˌɛdʒəˈkeɪʃən", "My college 主语＋is 系动词＋学校名称作表语。", ["My college is", "Guangxi College", "for Preschool Education."], "校名是必要长句，分三块练；Guangxi 是中文地名，音标仅为近似提示。正式名称以学校材料为准。"),
    "major": S("My major is physical fitness training.", "我的专业是体育体能训练。", "maɪ ˈmeɪdʒər ɪz ˈfɪzɪkəl ˈfɪtnəs ˈtreɪnɪŋ", "My major 主语＋is 系动词＋physical fitness training 表语。", ["My major is", "physical fitness training."], "physical 的 ph 发 /f/；fitness 和 training 都重读前面。"),
    "culture_interest": S("I am interested in American culture.", "我对美国文化感兴趣。", "aɪ æm ˈɪntrəstɪd ɪn əˈmɛrɪkən ˈkʌltʃər", "I 主语＋am 系动词＋interested in... 表语；be interested in 表示对……感兴趣。", ["I am interested in", "American culture."]),
    "life": S("I want to learn about daily life there.", "我想了解那里的日常生活。", "aɪ wɑnt tə lɝn əˈbaʊt ˈdeɪli laɪf ðɛr", "I 主语＋want 谓语＋to learn... 表示想做的事；there 指美国。", ["I want to learn about", "daily life there."]),
    "english": S("I want to improve my English.", "我想提高英语。", "aɪ wɑnt tə ɪmˈpruv maɪ ˈɪŋɡlɪʃ", "I 主语＋want 谓语＋to improve... 表示想做的事；my English 是 improve 的宾语。", ["I want to", "improve my English."]),
    "work_english": S("I can practice English at work.", "我可以在工作时练习英语。", "aɪ kən ˈpræktɪs ˈɪŋɡlɪʃ ət wɝk", "I 主语＋can practice 谓语＋English 宾语；at work 说明场景。", ["I can practice English", "at work."]),
    "learn_culture": S("I can also learn about American culture.", "我也可以了解美国文化。", "aɪ kən ˈɔlsoʊ lɝn əˈbaʊt əˈmɛrɪkən ˈkʌltʃər", "I 主语＋can learn about 谓语短语＋American culture 宾语；also 表示也。", ["I can also learn about", "American culture."]),
    "daily_practice": S("I would practice English every day.", "我会每天练习英语。", "aɪ wʊd ˈpræktɪs ˈɪŋɡlɪʃ ˈɛvri deɪ", "I 主语＋would practice 谓语＋English 宾语；every day 时间状语。"),
    "ask_questions": S("I would ask questions and follow the rules.", "我会提问，并遵守规则。", "aɪ wʊd æsk ˈkwɛstʃənz ænd ˈfɑloʊ ðə rulz", "I 主语；would 后接 ask 和 follow 两个并列动作；questions 和 the rules 分别作宾语。", ["I would ask questions", "and follow the rules."]),
    "lifeguard": S("I would like to be a lifeguard.", "我想做救生员。", "aɪ wʊd laɪk tə bi ə ˈlaɪfɡɑrd", "I 主语；would like to 表示想做；be a lifeguard 表示成为救生员。", ["I would like to be", "a lifeguard."]),
    "certificate": S("I have a Chinese lifeguard certificate.", "我有中国游泳救生员证。", "aɪ hæv ə tʃaɪˈniz ˈlaɪfɡɑrd sərˈtɪfɪkət", "I 主语＋have 谓语＋a Chinese lifeguard certificate 宾语；Chinese 修饰证书。", ["I have", "a Chinese lifeguard certificate."], "certificate 重读 /tɪ/，名词末尾读 /kət/；这句话只说明中国证书，不代表美国认可。"),
    "other_jobs": S("I can consider other suitable jobs.", "我可以考虑其他合适的岗位。", "aɪ kən kənˈsɪdər ˈʌðər ˈsutəbəl dʒɑbz", "I 主语＋can consider 谓语＋other suitable jobs 宾语；suitable 表示合适的。"),
    "requirements": S("I need to check the job requirements.", "我需要核实岗位要求。", "aɪ nid tə tʃɛk ðə dʒɑb rɪˈkwaɪrmənts", "I 主语＋need 谓语＋to check... 表示需要做的事；the job requirements 是 check 的宾语。"),
    "training": S("I would complete the required training.", "我会完成所需培训。", "aɪ wʊd kəmˈplit ðə rɪˈkwaɪrd ˈtreɪnɪŋ", "I 主语＋would complete 谓语＋the required training 宾语；required 修饰 training。"),
    "responsible": S("I am responsible and patient.", "我有责任心，也有耐心。", "aɪ æm rɪˈspɑnsəbəl ænd ˈpeɪʃənt", "I 主语＋am 系动词＋responsible 和 patient 两个并列表语。"),
    "learn": S("I am willing to learn.", "我愿意学习。", "aɪ æm ˈwɪlɪŋ tə lɝn", "I 主语＋am 系动词＋willing to learn 表语；be willing to 表示愿意。"),
    "safety": S("I would follow safety rules.", "我会遵守安全规则。", "aɪ wʊd ˈfɑloʊ ˈseɪfti rulz", "I 主语＋would follow 谓语＋safety rules 宾语。"),
    "speaking_hard": S("Speaking English is still hard for me.", "说英语对我仍然有难度。", "ˈspikɪŋ ˈɪŋɡlɪʃ ɪz stɪl hɑrd fər mi", "Speaking English 整体作主语；is 系动词＋hard 表语；for me 表示对我来说。", ["Speaking English", "is still hard for me."]),
    "practice_answers": S("I am practicing short answers.", "我正在练习简短回答。", "aɪ æm ˈpræktɪsɪŋ ʃɔrt ˈænsərz", "I 主语＋am practicing 现在进行时谓语＋short answers 宾语。"),
    "intro_progress": S("I can introduce myself without reading.", "我可以不看稿介绍自己。", "aɪ kən ˌɪntrəˈdus maɪˈsɛlf wɪˈðaʊt ˈridɪŋ", "I 主语＋can introduce 谓语＋myself 宾语；without reading 表示不看稿。"),
    "calm": S("I would stay calm.", "我会保持冷静。", "aɪ wʊd steɪ kɑm", "I 主语＋would stay 系动词结构＋calm 表语。"),
    "simple_words": S("I would use simple words.", "我会使用简单的词。", "aɪ wʊd juz ˈsɪmpəl wɝdz", "I 主语＋would use 谓语＋simple words 宾语。", pronunciation="动词 use 的 s 发 /z/；words 的结尾轻轻带出，不加一个额外音节。"),
    "help": S("I would ask for help.", "我会求助。", "aɪ wʊd æsk fər hɛlp", "I 主语＋would ask for 谓语短语＋help 宾语。"),
    "check_first": S("I would check before starting the task.", "我会先确认，再开始任务。", "aɪ wʊd tʃɛk bɪˈfɔr ˈstɑrtɪŋ ðə tæsk", "I 主语＋would check 谓语；before starting the task 说明什么时候。"),
    "sorry": S("I would say sorry to my coworker.", "我会向同事道歉。", "aɪ wʊd seɪ ˈsɑri tə maɪ ˈkoʊwɝkər", "I 主语＋would say 谓语＋sorry 道歉内容；to my coworker 说明向谁。"),
    "tell_supervisor": S("I would tell my supervisor.", "我会告诉主管。", "aɪ wʊd tɛl maɪ ˈsupərvaɪzər", "I 主语＋would tell 谓语＋my supervisor 宾语；主管负责指导工作。"),
    "fix_safe": S("I would help fix the problem safely.", "我会安全地协助解决问题。", "aɪ wʊd hɛlp fɪks ðə ˈprɑbləm ˈseɪfli", "I 主语＋would help 谓语＋fix... 补充帮助做什么；safely 表示安全地。"),
    "learn_mistake": S("I would learn from my mistake.", "我会从错误中学习。", "aɪ wʊd lɝn frəm maɪ mɪˈsteɪk", "I 主语＋would learn 谓语；from my mistake 说明从哪里学习。"),
    "listen_first": S("I would listen to my coworker first.", "我会先听同事怎么说。", "aɪ wʊd ˈlɪsən tə maɪ ˈkoʊwɝkər fɝst", "I 主语＋would listen to 谓语短语＋my coworker 宾语；first 表示先。"),
    "explain": S("Then I would explain my idea politely.", "然后我会礼貌地说明自己的想法。", "ðɛn aɪ wʊd ɪkˈspleɪn maɪ aɪˈdiə pəˈlaɪtli", "Then 表示然后；I 主语＋would explain 谓语＋my idea 宾语；politely 表示礼貌地。"),
    "solve_together": S("We could solve the problem together.", "我们可以一起解决问题。", "wi kʊd sɑlv ðə ˈprɑbləm təˈɡɛðər", "We 主语＋could solve 谓语＋the problem 宾语；together 表示一起。"),
    "fast_hard": S("Fast English may be difficult for me.", "语速快的英语对我可能有难度。", "fæst ˈɪŋɡlɪʃ meɪ bi ˈdɪfɪkəlt fər mi", "Fast English 主语＋may be 系动词结构＋difficult 表语；may 表示可能。"),
    "repeat_slow": S("I would ask people to repeat it slowly.", "我会请对方慢一点重复。", "aɪ wʊd æsk ˈpipəl tə rɪˈpit ɪt ˈsloʊli", "I 主语＋would ask 谓语＋people 宾语＋to repeat... 宾语补足语。", ["I would ask people", "to repeat it slowly."]),
    "step": S("I would take things step by step.", "我会一步一步处理事情。", "aɪ wʊd teɪk θɪŋz stɛp baɪ stɛp", "I 主语＋would take 谓语＋things 宾语；step by step 表示一步一步。"),
    "food_diff": S("Food and daily habits may be different.", "饮食和日常习惯可能不同。", "fud ænd ˈdeɪli ˈhæbɪts meɪ bi ˈdɪfərənt", "Food and daily habits 并列主语＋may be 系动词结构＋different 表语。"),
    "different_people": S("People are different, too.", "人与人之间也有差异。", "ˈpipəl ɑr ˈdɪfərənt tu", "People 主语＋are 系动词＋different 表语；too 表示也。"),
    "ask_polite": S("I would ask politely and respect local rules.", "我会礼貌提问，并尊重当地规则。", "aɪ wʊd æsk pəˈlaɪtli ænd rɪˈspɛkt ˈloʊkəl rulz", "I 主语；would 后接 ask 和 respect 两个动作；local rules 是 respect 的宾语。", ["I would ask politely", "and respect local rules."]),
    "swimming": S("I like swimming.", "我喜欢游泳。", "aɪ laɪk ˈswɪmɪŋ", "I 主语＋like 谓语＋swimming 动名词宾语。"),
    "fitness_study": S("I study physical fitness training.", "我学习体育体能训练。", "aɪ ˈstʌdi ˈfɪzɪkəl ˈfɪtnəs ˈtreɪnɪŋ", "I 主语＋study 谓语＋physical fitness training 宾语。"),
    "return": S("I will return to China after SWT.", "SWT 项目结束后，我会回中国。", "aɪ wɪl rɪˈtɝn tə ˈtʃaɪnə ˈæftər ˌɛs ˌdʌbəlju ˈti", "I 主语＋will return 谓语；to China 表示目的地；after SWT 表示项目之后。", ["I will return to China", "after SWT."], "SWT 按 S、W、T 三个字母读；return 重读后半部分。"),
    "studies": S("I will continue my studies.", "我会继续读书。", "aɪ wɪl kənˈtɪnju maɪ ˈstʌdiz", "I 主语＋will continue 谓语＋my studies 宾语。"),
    "dates_pending": S("My travel dates are not confirmed yet.", "我的出行日期还没有确定。", "maɪ ˈtrævəl deɪts ɑr nɑt kənˈfɝmd jɛt", "My travel dates 主语＋are not confirmed 被动语态否定；yet 表示尚未。"),
    "using_english": S("Using English interests me.", "使用英语让我感兴趣。", "ˈjuzɪŋ ˈɪŋɡlɪʃ ˈɪntrəsts mi", "Using English 整体作主语＋interests 谓语＋me 宾语。"),
    "understand_people": S("I want to understand people better.", "我想更好地听懂别人。", "aɪ wɑnt tə ˌʌndərˈstænd ˈpipəl ˈbɛtər", "I 主语＋want 谓语＋to understand... 表示想做的事；better 表示更好地。"),
    "speak_clearly": S("I want to speak more clearly.", "我想表达得更清楚。", "aɪ wɑnt tə spik mɔr ˈklɪrli", "I 主语＋want 谓语＋to speak... 表示想做的事；more clearly 表示更清楚地。"),
    "repeat_request": S("Could you please repeat the question?", "请您重复一下问题好吗？", "kʊd ju pliz rɪˈpit ðə ˈkwɛstʃən", "Could you please＋动词原形，是礼貌请求；the question 是 repeat 的宾语。", ["Could you please", "repeat the question?"]),
    "slow_request": S("Could you please speak more slowly?", "请您说慢一点好吗？", "kʊd ju pliz spik mɔr ˈsloʊli", "Could you please＋动词原形，是礼貌请求；more slowly 修饰 speak。"),
    "word_meaning": S("What does that word mean?", "那个词是什么意思？", "wʌt dʌz ðæt wɝd min", "What 问含义；does 助动词；that word 主语；mean 谓语。"),
    "think": S("Let me think for a moment.", "请让我想一下。", "lɛt mi θɪŋk fər ə ˈmoʊmənt", "Let＋me 宾语＋think 宾语补足语；for a moment 表示一会儿。"),
    "work_culture": S("It includes work and cultural exchange.", "它包括工作和文化交流。", "ɪt ɪnˈkludz wɝk ænd ˈkʌltʃərəl ɪksˈtʃeɪndʒ", "It 主语，指 SWT；includes 谓语＋work and cultural exchange 并列宾语。"),
    "listen_questions": S("I am listening to different questions.", "我正在听不同的问题。", "aɪ æm ˈlɪsənɪŋ tə ˈdɪfərənt ˈkwɛstʃənz", "I 主语＋am listening to 现在进行时谓语短语＋different questions 宾语。"),
    "employer": S("I need to check with the employer.", "我需要向雇主核实。", "aɪ nid tə tʃɛk wɪð ði ɪmˈplɔɪər", "I 主语＋need 谓语＋to check... 表示需要做的事；with the employer 表示向雇主。"),
    "chinese_cert": S("My certificate is from China.", "我的证书来自中国。", "maɪ sərˈtɪfɪkət ɪz frəm ˈtʃaɪnə", "My certificate 主语＋is 系动词＋from China 表语。"),
    "listen": S("I would listen carefully.", "我会认真听。", "aɪ wʊd ˈlɪsən ˈkɛrfəli", "I 主语＋would listen 谓语；carefully 表示认真地。"),
    "try_improve": S("Then I would try to improve.", "然后我会努力改进。", "ðɛn aɪ wʊd traɪ tə ɪmˈpruv", "Then 表示然后；I 主语＋would try 谓语＋to improve 表示努力做的事。"),
    "other_practice": S("I still need practice with other questions.", "其他问题我仍然需要练习。", "aɪ stɪl nid ˈpræktɪs wɪð ˈʌðər ˈkwɛstʃənz", "I 主语＋need 谓语＋practice 名词宾语；with other questions 说明练习范围。"),
    "example_request": S("Could you give me an example?", "您能给我一个例子吗？", "kʊd ju ɡɪv mi ən ɪɡˈzæmpəl", "Could you 表示礼貌请求；give 谓语＋me 间接宾语＋an example 直接宾语。"),
    "no_guess": S("I would not guess.", "我不会猜着做。", "aɪ wʊd nɑt ɡɛs", "I 主语＋would not guess 否定谓语。"),
    "unsafe": S("I would stop any unsafe action first.", "我会先停止不安全的操作。", "aɪ wʊd stɑp ˈɛni ʌnˈseɪf ˈækʃən fɝst", "I 主语＋would stop 谓语＋any unsafe action 宾语；first 表示首先。"),
    "instructions": S("I would check the instructions again.", "我会再次核对操作指示。", "aɪ wʊd tʃɛk ði ɪnˈstrʌkʃənz əˈɡɛn", "I 主语＋would check 谓语＋the instructions 宾语；again 表示再次。"),
    "not_argue": S("I would not argue.", "我不会争吵。", "aɪ wʊd nɑt ˈɑrɡju", "I 主语＋would not argue 否定谓语。"),
    "not_solve": S("If we cannot agree, I would ask for help.", "如果无法达成一致，我会求助。", "ɪf wi ˈkænɑt əˈɡri aɪ wʊd æsk fər hɛlp", "If we cannot agree 条件从句；主句 I 主语＋would ask for help 谓语部分。", ["If we cannot agree,", "I would ask for help."]),
    "work_help": S("For work tasks, I would ask my supervisor.", "工作任务方面，我会询问主管。", "fər wɝk tæsks aɪ wʊd æsk maɪ ˈsupərvaɪzər", "For work tasks 说明范围；I 主语＋would ask 谓语＋my supervisor 宾语。", ["For work tasks,", "I would ask my supervisor."]),
    "program_help": S("For program issues, I would contact my sponsor.", "项目事务方面，我会联系赞助机构。", "fər ˈproʊɡræm ˈɪʃuz aɪ wʊd ˈkɑntækt maɪ ˈspɑnsər", "For program issues 说明范围；I 主语＋would contact 谓语＋my sponsor 宾语。", ["For program issues,", "I would contact my sponsor."]),
    "meal_times": S("Meal times may be different.", "用餐时间可能不同。", "mil taɪmz meɪ bi ˈdɪfərənt", "Meal times 主语＋may be 系动词结构＋different 表语。"),
    "ask_schedule": S("I would ask about the schedule.", "我会询问时间安排。", "aɪ wʊd æsk əˈbaʊt ðə ˈskɛdʒul", "I 主语＋would ask about 谓语短语＋the schedule 宾语。"),
    "follow_guidance": S("Then I would follow the guidance.", "然后我会按照指导去做。", "ðɛn aɪ wʊd ˈfɑloʊ ðə ˈɡaɪdəns", "Then 表示然后；I 主语＋would follow 谓语＋the guidance 宾语。"),
    "safe_exercise": S("We learn about safe exercise and teamwork.", "我们学习安全运动和团队合作。", "wi lɝn əˈbaʊt seɪf ˈɛksərsaɪz ænd ˈtimwɝk", "We 主语＋learn about 谓语短语＋safe exercise and teamwork 并列宾语。"),
    "understand_instructions": S("I want to understand instructions at work.", "我想听懂工作指示。", "aɪ wɑnt tə ˌʌndərˈstænd ɪnˈstrʌkʃənz ət wɝk", "I 主语＋want 谓语＋to understand... 表示想做的事；at work 说明场景。"),
    "explain_ideas": S("I want to explain my ideas clearly.", "我想清楚地表达自己的想法。", "aɪ wɑnt tə ɪkˈspleɪn maɪ aɪˈdiəz ˈklɪrli", "I 主语＋want 谓语＋to explain... 表示想做的事；my ideas 是 explain 的宾语。"),
    "no_job": S("I have not worked part-time yet.", "我还没有做过兼职。", "aɪ hæv nɑt wɝkt ˈpɑrt taɪm jɛt", "I 主语＋have not worked 现在完成时否定；part-time 表示兼职；yet 表示尚未。"),
    "no_overseas": S("I have not been overseas yet.", "我还没有出过国。", "aɪ hæv nɑt bɪn ˌoʊvərˈsiz jɛt", "I 主语＋have not been 现在完成时否定；overseas 表示海外。"),
    "preparing": S("I am preparing for SWT.", "我正在为 SWT 做准备。", "aɪ æm prɪˈpɛrɪŋ fər ˌɛs ˌdʌbəlju ˈti", "I 主语＋am preparing for 现在进行时谓语短语＋SWT 宾语。"),
    "relax": S("It helps me relax.", "它能帮助我放松。", "ɪt hɛlps mi rɪˈlæks", "It 主语，指游泳；helps 谓语＋me 宾语＋relax 宾语补足语。"),
    "dish": S("I would recommend stir-fried tomatoes and eggs.", "我会推荐番茄炒蛋。", "aɪ wʊd ˌrɛkəˈmɛnd ˈstɝ fraɪd təˈmeɪtoʊz ænd ɛɡz", "I 主语＋would recommend 谓语＋菜名作宾语。", ["I would recommend", "stir-fried tomatoes and eggs."]),
    "simple_dish": S("It is a simple Chinese dish.", "这是一道简单的中国菜。", "ɪt ɪz ə ˈsɪmpəl tʃaɪˈniz dɪʃ", "It 主语＋is 系动词＋a simple Chinese dish 表语。"),
    "ingredients": S("It has tomatoes and eggs.", "里面有番茄和鸡蛋。", "ɪt hæz təˈmeɪtoʊz ænd ɛɡz", "It 主语＋has 谓语＋tomatoes and eggs 并列宾语。"),
    "parents": S("Yes, my parents support me.", "是的，我的父母支持我。", "jɛs maɪ ˈpɛrənts səˈpɔrt mi", "Yes 先回答；my parents 主语＋support 谓语＋me 宾语。"),
    "discussing": S("We are still discussing the details.", "我们还在讨论具体细节。", "wi ɑr stɪl dɪˈskʌsɪŋ ðə ˈditeɪlz", "We 主语＋are discussing 现在进行时谓语＋the details 宾语；still 表示仍然。"),
    "explain_program": S("I want to explain the program clearly.", "我想把项目解释清楚。", "aɪ wɑnt tə ɪkˈspleɪn ðə ˈproʊɡræm ˈklɪrli", "I 主语＋want 谓语＋to explain... 表示想做的事；clearly 表示清楚地。"),
    "passport": S("Yes, I have a passport.", "是的，我有护照。", "jɛs aɪ hæv ə ˈpæspɔrt", "Yes 先回答；I 主语＋have 谓语＋a passport 宾语。"),
    "applied": S("I have applied for a passport.", "我已经申请了护照。", "aɪ hæv əˈplaɪd fər ə ˈpæspɔrt", "I 主语＋have applied for 现在完成时谓语短语＋a passport 宾语。"),
    "waiting": S("I am still waiting for it.", "我还在等它办好。", "aɪ æm stɪl ˈweɪtɪŋ fər ɪt", "I 主语＋am waiting for 现在进行时谓语短语＋it 宾语；it 指护照。"),
    "apply_needed": S("I need to apply for a passport.", "我需要申请护照。", "aɪ nid tə əˈplaɪ fər ə ˈpæspɔrt", "I 主语＋need 谓语＋to apply... 表示需要做的事。"),
    "not_tested": S("I have not tested my distance recently.", "我最近没有测试连续游泳距离。", "aɪ hæv nɑt ˈtɛstɪd maɪ ˈdɪstəns ˈrisəntli", "I 主语＋have not tested 现在完成时否定谓语＋my distance 宾语；recently 表示最近。"),
    "career_pending": S("I have not decided on a job yet.", "我还没有决定未来做什么工作。", "aɪ hæv nɑt dɪˈsaɪdɪd ɑn ə dʒɑb jɛt", "I 主语＋have not decided on 现在完成时否定谓语短语＋a job 宾语。"),
    "skills": S("I want to improve my skills.", "我想提高自己的技能。", "aɪ wɑnt tə ɪmˈpruv maɪ skɪlz", "I 主语＋want 谓语＋to improve... 表示想做的事；my skills 是 improve 的宾语。"),
    "confirm_dates": S("I still need to confirm the dates.", "我还需要确认日期。", "aɪ stɪl nid tə kənˈfɝm ðə deɪts", "I 主语＋need 谓语＋to confirm... 表示需要做的事；still 表示仍然。"),
    "calendar": S("I will check my college calendar.", "我会核对学校校历。", "aɪ wɪl tʃɛk maɪ ˈkɑlɪdʒ ˈkæləndər", "I 主语＋will check 谓语＋my college calendar 宾语。"),
    "sponsor": S("I will also ask my sponsor.", "我也会询问赞助机构。", "aɪ wɪl ˈɔlsoʊ æsk maɪ ˈspɑnsər", "I 主语＋will ask 谓语＋my sponsor 宾语；also 表示也。"),
    "checked_dates": S("I have checked the dates with my college.", "我已和学校核实这些日期。", "aɪ hæv tʃɛkt ðə deɪts wɪð maɪ ˈkɑlɪdʒ", "I 主语＋have checked 现在完成时谓语＋the dates 宾语；with my college 说明与谁核实。"),
}


def take(*keys):
    return [deepcopy(LINES[key]) for key in keys]


DEFAULTS = {
    "01": ("name", "year", "school", "major"),
    "02": ("culture_interest", "life", "english"),
    "03": ("english", "work_english", "learn_culture"),
    "04": ("english", "daily_practice", "ask_questions"),
    "05": ("lifeguard", "certificate", "other_jobs", "requirements"),
    "06": ("responsible", "learn", "safety"),
    "07": ("speaking_hard", "practice_answers", "intro_progress"),
    "08": ("calm", "simple_words", "help", "check_first"),
    "09": ("sorry", "tell_supervisor", "fix_safe", "learn_mistake"),
    "10": ("listen_first", "explain", "solve_together"),
    "11": ("fast_hard", "repeat_slow", "step"),
    "12": ("food_diff", "different_people", "ask_polite"),
    "13": ("swimming", "certificate"),
    "20": ("year", "major", "school"),
    "22": ("return", "studies", "dates_pending"),
    "23": ("using_english", "understand_people", "speak_clearly"),
}
EXTRAS = {"01": ("certificate",), "05": ("training",), "08": ("slow_request",), "13": ("fitness_study",), "20": ("safe_exercise",), "22": ("calendar",)}
KEYWORDS = {
    "01": ["Sam", "first-year student", "college", "physical fitness training"],
    "02": ["American culture", "daily life", "improve my English"],
    "03": ["improve my English", "at work", "American culture"],
    "04": ["improve my English", "every day", "ask questions", "follow the rules"],
    "05": ["lifeguard", "Chinese certificate", "other suitable jobs", "check requirements"],
    "06": ["responsible", "patient", "willing to learn", "safety rules"],
    "07": ["still hard", "short answers", "without reading"],
    "08": ["stay calm", "simple words", "ask for help", "check before starting"],
    "09": ["say sorry", "supervisor", "fix safely", "learn from my mistake"],
    "10": ["listen first", "explain politely", "solve together"],
    "11": ["fast English", "repeat slowly", "step by step"],
    "12": ["food and daily habits", "people are different", "ask politely", "local rules"],
    "13": ["swimming", "Chinese lifeguard certificate"],
    "20": ["first-year student", "physical fitness training", "college"],
    "22": ["after SWT", "return to China", "continue my studies", "dates not confirmed"],
    "23": ["using English", "understand people", "speak clearly"],
}
for q in QUESTIONS:
    q["short"] = take(*DEFAULTS.get(q["id"], ()))
    q["extra"] = take(*EXTRAS.get(q["id"], ()))
    q["readyForAutoplay"] = bool(q["short"])
    q["learningGoal"] = "先逐句说清楚，再把同样的句子连起来。随机问答可用自己的简单说法，不必逐字背标准答案。"
    q["connectionTip"] = "句尾停半秒，再接下一句。先说清意思，不必强行连音或加复杂连接词。"
    q["answerType"] = "short-beginner" if q["short"] else "confirm-facts-first"
    if q["id"] in KEYWORDS:
        q["keywords"] = KEYWORDS[q["id"]]

QUESTIONS[0]["title"] = "自我介绍：保留你已经会的短句"
QUESTIONS[2]["note"] = "为什么美国：说你对美国文化的兴趣。为什么 SWT：说项目内可以工作、练英语和交流。不要背成长期在美国找工作的计划。"
QUESTIONS[6]["note"] = "说一个真实困难，再说你正在练什么和已经会什么。不假装流利，也不必反复贬低自己。你已能脱稿自我介绍，这是实在的进步。"
QUESTIONS[21]["note"] = "Sam 已确认：项目结束回中国，在原学校继续读书；具体日期未定。这里不编造开学日期、机票、工作或家庭承诺，也不保证任何面试结果。"

# A related question is not automatically an interchangeable prompt. The UI
# only randomizes unhinted variants against the main answer. Retain all related
# prompts in study, but teach the different first move instead of matching them
# to a recording of the wrong answer.
VARIANT_INTENT_OVERRIDES = {
    ("02", 2): "问为什么对美国文化感兴趣，不是只重复‘我感兴趣’。可说想了解日常生活、理解别人；下方追问有短答。",
    ("03", 2): "问 SWT 和普通度假的区别，先说 It includes work and cultural exchange.；下方追问练这句。",
    ("04", 0): "只问希望得到什么，先说英语和文化方面的目标；不用先把全部执行计划背出来。",
    ("04", 1): "问怎样用好项目机会，重点说具体行动：每天练英语、遇到不懂就问。",
    ("04", 2): "问项目期间会做什么，先说练英语、按要求工作等具体行动，不只说想提高英语。",
    ("07", 1): "问项目期间怎样改善，先用 I would... 说准备采取的行动，不把现在的进步当成未来计划。",
    ("07", 2): "问说英语时具体难在哪里。请按真实情况说找词、组织短句等困难，不只重复‘英语难’。",
    ("08", 0): "问听不懂主管，不是自己表达不清。先请对方重复、举例，确认后再开始任务。",
    ("08", 2): "问对方说得太快，先请对方慢一点重复。下方追问练 repeat it slowly 和实际自救句。",
    ("12", 0): "问如何适应，重点说礼貌询问、遵守当地规则；不是先列出中美差异。",
    ("12", 2): "问能否应对异地生活，按真实情况说明准备和求助方法；不要只背饮食差异，也不保证自己完全没困难。",
    ("14", 0): "问所有工作经历，范围比兼职更广。没有兼职不一定等于没有工作经历；先核实自己的真实情况。",
    ("14", 1): "问是否工作过，不只问兼职。按真实经历回答，不能用没有兼职代替核实全部工作经历。",
    ("14", 2): "请你讲一份做过的工作，需要真实岗位和职责；没有做过就如实说明，不能把持证说成任职经历。",
    ("16", 2): "问菜品有什么特点，不是只报菜名。按自己选的真实菜品说食材、味道或做法，不能照搬别的菜。",
    ("21", 2): "问项目怎样帮助未来计划，不是问想做什么工作。先确认真实职业方向，再说英语或沟通能力的用途。",
}
for q in QUESTIONS:
    for index, variant in enumerate(q["variants"]):
        if (q["id"], index) in VARIANT_INTENT_OVERRIDES:
            variant["hint"] = VARIANT_INTENT_OVERRIDES[(q["id"], index)]

# A follow-up is its own question, often needing a different first sentence.
FOLLOWUP_KEYS = {
    "01": [("major",), ("english", "work_english")],
    "02": [("life",), ("return", "studies")],
    "03": [("work_culture",), ("english", "learn_culture")],
    "04": [("daily_practice", "work_english"), ()],
    "05": [("employer", "chinese_cert"), ()],
    "06": [(), ("listen", "try_improve")],
    "07": [("intro_progress", "other_practice"), ("example_request", "no_guess")],
    "08": [("slow_request", "word_meaning"), ("no_guess", "check_first")],
    "09": [("unsafe", "tell_supervisor"), ("instructions",)],
    "10": [("calm", "not_argue", "help"), ()],
    "11": [("practice_answers", "listen_questions"), ("work_help", "program_help")],
    "12": [("meal_times", "ask_schedule"), ("ask_polite", "follow_guidance")],
    "20": [(), ("safe_exercise",)],
    "22": [(), ("studies",)],
    "23": [("understand_people", "speak_clearly"), ("understand_instructions", "explain_ideas")],
}
for q in QUESTIONS:
    for f, keys in zip(q["followups"], FOLLOWUP_KEYS.get(q["id"], [(), ()])):
        f["answer"] = take(*keys)

# Keep the two important related prompts available for actual oral practice,
# with their own answer, instead of simply filtering them out of random modes.
QUESTIONS[1]["followups"][0].update({
    "en": QUESTIONS[1]["variants"][2]["en"],
    "zh": QUESTIONS[1]["variants"][2]["zh"],
    "hint": "问感兴趣的原因。先说想了解日常生活、理解别人，不再只重复 I am interested in American culture.。",
    "answer": take("life", "understand_people"),
})
QUESTIONS[7]["followups"][0].update({
    "en": QUESTIONS[7]["variants"][2]["en"],
    "zh": QUESTIONS[7]["variants"][2]["zh"],
    "hint": "问别人说得太快怎么办。先说会请对方慢一点重复，然后直接说出请求慢速的句子。",
    "answer": take("repeat_slow", "slow_request"),
})

# Provide short, safe answers to two previously long scenario follow-ups.
QUESTIONS[3]["followups"][1]["answer"] = [
    S("I would try answering without reading.", "我会尝试不看稿回答。", "aɪ wʊd traɪ ˈænsərɪŋ wɪˈðaʊt ˈridɪŋ", "I 主语＋would try 谓语＋answering... 动名词宾语；without reading 表示不看稿。"),
    S("I would check if people understand me.", "我会确认别人能否听懂我。", "aɪ wʊd tʃɛk ɪf ˈpipəl ˌʌndərˈstænd mi", "I 主语＋would check 谓语；if people understand me 是宾语从句，if 表示是否。"),
]
QUESTIONS[9]["followups"][1]["answer"] = [
    S("When we cannot solve the problem together.", "当我们无法一起解决问题时。", "wɛn wi ˈkænɑt sɑlv ðə ˈprɑbləm təˈɡɛðər", "When 问什么情况下；这是口语简答，省略 I would ask for help。", ["When we cannot", "solve the problem together."]),
    S("Also, when there is a safety risk.", "还有，当存在安全风险时。", "ˈɔlsoʊ wɛn ðɛr ɪz ə ˈseɪfti rɪsk", "Also 表示还有；when 引出情况；there is 表示存在。"),
]


def template(en, zh):
    """Unfilled slots must not receive made-up IPA, synthesized audio or scores."""
    result = S(en, zh, "", "方括号需要先填写真实信息；填完后再确认语法、读音和录音目标。", pronunciation="未填写的模板不能直接朗读或评分。")
    result["needsPersonalization"] = True
    return result


BRANCH_LINES = {
    ("13", "swimming"): take("swimming", "relax"),
    ("13", "custom"): [template("I like [activity].", "我喜欢[活动]。"), template("It helps me [reason].", "它帮助我[真实原因]。")],
    ("14", "no"): take("no_job", "learn"),
    ("14", "yes"): [template("I worked as a [job].", "我做过[岗位]。"), template("I helped with [task].", "我协助做[任务]。")],
    ("15", "domestic"): [template("I visited [city] in China.", "我去过中国的[城市]。"), template("I liked the [reason].", "我喜欢那里的[真实事物]。")],
    ("15", "no-overseas"): take("no_overseas", "preparing"),
    ("15", "overseas"): [template("I have been to [country].", "我去过[国家]。"), template("I went there for [purpose].", "我去那里是为了[目的]。")],
    ("16", "tomato-egg"): take("dish", "simple_dish", "ingredients"),
    ("16", "custom"): [template("I would recommend [dish].", "我会推荐[菜名]。"), template("It has [ingredients].", "里面有[食材]。")],
    ("17", "yes"): take("parents"),
    ("17", "discussing"): take("discussing", "explain_program"),
    ("18", "ready"): take("passport"),
    ("18", "applied"): take("applied", "waiting"),
    ("18", "not-yet"): [S("Not yet.", "还没有。", "nɑt jɛt", "Not yet 是简短否定回答，表示尚未。"), *take("apply_needed")],
    ("19", "measured"): [template("I can swim [number] meters without stopping.", "我能连续不停地游[数字]米。"), template("I can swim [strokes].", "我会[泳姿]。")],
    ("19", "not-measured"): take("not_tested", "requirements"),
    ("21", "exploring"): take("career_pending", "skills"),
    ("21", "direction"): [template("I want to work in [field].", "我想在[领域]工作。"), template("I like it because [reason].", "我喜欢它，因为[原因]。")],
    ("22", "return-study"): take("return", "studies"),
    ("22", "dates-pending"): take("return", "studies", "dates_pending"),
    ("24", "confirmed"): [template("I am available from [start] to [end].", "我从[开始日期]到[结束日期]可以参加。"), *take("checked_dates")],
    ("24", "pending"): take("confirm_dates", "calendar", "sponsor"),
}
for q in QUESTIONS:
    for branch in q["branches"]:
        branch["sentences"] = BRANCH_LINES[(q["id"], branch["id"])]
        assert branch["confirmed"] is False

RESCUE_PHRASES = take("repeat_request", "slow_request", "word_meaning", "think")
KNOWN_INTRO = {
    "title": "已会的自介：不推倒重背",
    "note": "可以继续用你已经熟悉的简单说法。这里把姓名、大一、学校、专业拆开；熟悉后再连成一段。证书一句按被问内容再加，不必一次全背。",
    "sentences": take("name", "year", "school", "major"),
    "optional": take("swimming", "certificate"),
}

TRAINING_PLAN.update({
    "title": "SWT 口测：短句 → 连答 → 随机提问",
    "method": "每天选 1—2 个主题：先一句一句练，再把原句连答 3 遍，最后换问法脱稿回答。优先清楚、切题，不追求长句。",
    "daily60": [
        {"minutes": 10, "task": "复测昨天 1—2 题，不看答案；卡住就用请求重复的自救句。"},
        {"minutes": 15, "task": "在句子课选今天的口测主题，只精学同题的 2—4 个短句；逐句听、看中文、录音。"},
        {"minutes": 15, "task": "回到口测主线，把刚学的原句连起来：看句子一次、看关键词一次、脱稿一次。"},
        {"minutes": 10, "task": "回听录音，最多挑 5 个需要复核的词；识别差异不一定是发音错，只改最影响理解的 1—2 处。"},
        {"minutes": 10, "task": "随机听题再回答，并练 1 个追问；允许简单改说，不机械复述整段。"},
    ],
    "successCriteria": ["听懂当前问题", "约 3 秒内开始回答或请求重复", "先用 2—4 个短句把意思说清楚", "个人信息真实，不编经历或日期", "能接一个追问；不会时主动求助"],
    "assessmentLimit": "跟读匹配分只比较浏览器识别出的文字与练习句。它不是发音标准分：漏识别、噪声和网络都会影响；没有转写时不评分。随机回答不应按背稿相似度评分。",
})
for day in TRAINING_PLAN["days"]:
    day["focus"] += " 同题句子课和连答共用短句。"


def all_sentences():
    for q in QUESTIONS:
        yield from q["short"]
        yield from q["extra"]
        for followup in q["followups"]:
            yield from followup["answer"]
        for branch in q["branches"]:
            yield from branch["sentences"]
    yield from RESCUE_PHRASES
    yield from KNOWN_INTRO["sentences"]
    yield from KNOWN_INTRO["optional"]


def validate_curriculum():
    assert [q["id"] for q in QUESTIONS] == [f"{i:02d}" for i in range(1, 25)]
    seen = {}
    for sentence in all_sentences():
        assert sentence["id"] == sentence_id(sentence["en"])
        assert sentence["en"] and sentence["zh"] and sentence["grammar"] and sentence["chunks"]
        if "[" not in sentence["en"]:
            assert sentence["ipa"] and sentence["pronunciation"]
        else:
            assert sentence["needsPersonalization"] and not sentence["ipa"]
        original = seen.setdefault(sentence["id"], sentence["en"])
        assert original == sentence["en"], (original, sentence["en"])
    for q in QUESTIONS:
        assert len(q["variants"]) == 3 and len(q["followups"]) == 2
        assert all(f["hint"] and isinstance(f["answer"], list) for f in q["followups"])
        assert 2 <= len(q["short"]) <= 4 or (not q["short"] and q["branches"])
        assert q["readyForAutoplay"] == bool(q["short"])
        for s in q["short"]:
            assert "[" not in s["en"]
            words = re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", s["en"])
            assert len(words) <= 8 or "Guangxi College for Preschool Education" in s["en"], s["en"]
        for branch in q["branches"]:
            assert branch["confirmed"] is False and branch["condition"]
    return True


def export_payload():
    validate_curriculum()
    return {
        "version": VERSION, "profile": PROFILE, "questions": QUESTIONS,
        "rescuePhrases": RESCUE_PHRASES, "plan": TRAINING_PLAN,
        "sources": SOURCE_NOTES, "knownIntro": KNOWN_INTRO,
        "audioPolicy": "只默认播放已确认事实或明确假设的简短答案。未知经历由本人核实并选择分支；含方括号的模板不得合成或评分。句子课与连答按相同 sentence id 共用内容。",
        "ipaNote": "宽式美式音标为辅助；自然语流会弱读连读。专名仅作近似提示，不用音标替代听音。",
    }


validate_curriculum()
if __name__ == "__main__":
    import sys
    if "--json" in sys.argv:
        print(json.dumps(export_payload(), ensure_ascii=False, indent=2))
    else:
        unique = {s["id"] for s in all_sentences()}
        print(f"{VERSION}: {len(QUESTIONS)} topics, {sum(len(q['short']) for q in QUESTIONS)} default short sentences, {len(unique)} reusable units")
