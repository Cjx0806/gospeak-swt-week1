'use strict';
// Pure scoring + browser-API mocks: never opens a microphone or network service.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { tokenize, compareText, evaluateReading, feedbackHTML } = require('../assets/recorder-v19.js');
const base = { expectedText: 'I am Sam.', transcript: 'I am Sam', kind: 'sentence', transcriptSource: 'browser-final', duration: 3, samples: 50, peakRMS: .1 };
const assess = (expectedText, transcript, extra = {}) => evaluateReading({ ...base, expectedText, transcript, ...extra });
assert.equal(assess("I'm Sam.", 'I am Sam').score, 100);
assert.equal(assess('I am a first-year student.', 'I am a first year student').score, 100);
assert.equal(assess("I can't swim.", 'I cannot swim').score, 100);
assert.equal(assess('I can not swim.', "I can't swim.").score, 100);
assert.equal(assess('I want to join SWT.', 'I want to join S W T').score, 100);
assert.equal(assess('I want to visit the U.S.', 'I want to visit the US').score, 100);
assert.deepEqual(tokenize('Work with us.'), ['work', 'with', 'us']);
assert.equal(assess('I am Sam.', 'I am Tom.').score, 67);
assert.equal(assess('I am Sam.', 'I Sam.').score, 67);
assert.equal(assess('I am Sam.', 'Hello I am Sam.').score, 75);
assert.equal(assess('I am Sam.', 'Hello there friend.').score, 0);
assert.equal(assess('I am Sam.', ''), null);
assert.equal(assess('', 'I am Sam.'), null);
assert.equal(assess('I am Sam.', 'I am Sam.', { kind: 'answer' }), null, 'free answer never exact-match scored');
assert.equal(assess('I am Sam.', 'I am Sam.', { kind: 'answer', assessmentMode: 'scripted' }).score, 100);
assert.equal(assess('I am Sam.', 'I am Sam.', { transcriptSource: 'manual' }), null);
assert.equal(assess('I am Sam.', 'I am Sam.', { transcriptEdited: true }), null);
assert.equal(assess('I am Sam.', 'I am Sam.', { recognitionIncomplete: true }), null, 'network/early-end partial final transcript must not be scored');
assert.equal(assess('I am Sam.', 'I am Sam.', { transcriptSource: undefined }), null, 'historical unverified transcript is not retroactively scored');
assert.equal(assess('I am Sam.', '', { interimTranscript: 'I am Sam.' }), null);
const deleted = assess('I am Sam and I am a student', 'I am Sam I am student');
assert.deepEqual(deleted.review.map(x => x.expected), ['and', 'a']);
assert.equal(deleted.alignment.filter(x => x.expected).length, deleted.expectedCount);
assert.equal(assess('one two three four five six seven eight', 'other').review.length, 5);
for (let count = 0; count < 10; count++) {
  const out = assess('I am Sam', 'hello '.repeat(count) + 'I am Sam');
  assert(out.score >= 0 && out.score <= 100);
}
assert.deepEqual(compareText('I study fitness training', 'I study training').differences, [{ type: 'missing', expected: 'fitness', actual: '' }]);
assert.match(feedbackHTML(base), /100<small> \/ 100/);
assert.match(feedbackHTML(base), /不是专业发音分/);
assert.match(feedbackHTML({ ...base, transcript: 'I am Tom' }, { sam: { ipa: '/sæm/', zh: 'Sam', src: 'audio/sam.mp3' } }), /data-review-word="sam"/);
assert.match(feedbackHTML({ ...base, transcript: '', recognitionRequested: false }), /本次是仅录音/);
assert.match(feedbackHTML({ ...base, transcript: '', interimTranscript: 'I am Sam', recognitionRequested: true }), /只有未确认的临时转写/);
assert(!feedbackHTML({ ...base, kind: 'answer' }).includes('sam-recorder__score"'));
assert(!feedbackHTML({ ...base, transcriptSource: 'manual' }).includes('sam-recorder__score"'));
assert(!feedbackHTML({ ...base, transcript: '<img src=x>' }).includes('<img src=x>'));

class Element {
  constructor() { this.children = new Map(); this.listeners = new Map(); this.textContent = ''; this.innerHTML = ''; this.checked = false; this.disabled = false; this.hidden = false; this.style = {}; this.classList = { add() {}, remove() {} }; }
  querySelector(key) { if (!this.children.has(key)) this.children.set(key, new Element()); return this.children.get(key); }
  addEventListener(name, fn) { this.listeners.set(name, fn); }
  removeEventListener(name) { this.listeners.delete(name); }
  removeAttribute() {} setAttribute() {} pause() {} load() {} scrollIntoView() {}
}
let now = 0, recognitionStarts = 0;
const events = [], saved = [], tracks = [];
class Recorder {
  static isTypeSupported() { return true; }
  constructor() { this.mimeType = 'audio/mp4'; this.state = 'inactive'; }
  start() { this.state = 'recording'; }
  stop() { this.state = 'inactive'; queueMicrotask(() => { this.ondataavailable({ data: new Blob(['test'], { type: this.mimeType }) }); this.onstop(); }); }
}
class Recognition {
  constructor() { Recognition.last = this; }
  start() { recognitionStarts++; }
  stop() { this.onend?.(); } abort() {}
}
const db = { objectStoreNames: { contains: () => true }, transaction() {
  const tx = {};
  tx.objectStore = () => ({
    getAll() { const request = {}; queueMicrotask(() => { request.result = [...saved]; request.onsuccess(); }); return request; },
    put(record) { saved.push(record); setTimeout(() => tx.oncomplete?.(), 0); },
    delete() { setTimeout(() => tx.oncomplete?.(), 0); }
  });
  return tx;
} };
const root = {
  isSecureContext: true, document: new Element(), MediaRecorder: Recorder, SpeechRecognition: Recognition,
  navigator: { mediaDevices: { getUserMedia: async () => { const track = { stopped: false, stop() { this.stopped = true; } }; tracks.push(track); return { getTracks: () => [track] }; } } },
  indexedDB: { open() { const request = {}; queueMicrotask(() => { request.result = db; request.onsuccess(); }); return request; } },
  performance: { now: () => now }, URL: { createObjectURL: () => 'blob:test', revokeObjectURL() {} },
  setTimeout: fn => setTimeout(fn, 0), clearTimeout, setInterval, clearInterval, cancelAnimationFrame() {},
  addEventListener() {}, removeEventListener() {}, dispatchEvent: event => events.push(event)
};
vm.runInNewContext(fs.readFileSync(require.resolve('../assets/recorder-v19.js'), 'utf8'), {
  window: root, Blob, Uint8Array, Promise, Date, Math,
  CustomEvent: class { constructor(type, init) { this.type = type; this.detail = init.detail; } }
});
const make = extra => {
  const container = new Element();
  const api = root.SamRecorder.mount(container, { id: 'score-test', kind: 'sentence', expectedText: 'I am Sam.', lexicon: { sam: { ipa: '/sæm/', zh: 'Sam', src: 'audio/sam.mp3' } }, ...extra });
  return { api, container, el: name => container.querySelector('.sam-recorder__' + name) };
};
const emit = (text, final) => Recognition.last.onresult({ results: [Object.assign([{ transcript: text }], { isFinal: final })] });
const finish = async item => { now += 3000; await item.api.stop(); };

(async () => {
  const plain = make();
  assert(plain.container.innerHTML.indexOf('sam-recorder__recognition') < plain.container.innerHTML.indexOf('sam-recorder__controls'), 'consent must be upfront before recording');
  assert(!plain.container.innerHTML.includes('<details class="sam-recorder__recognition"'), 'consent not buried in details');
  assert.equal(plain.el('consent').checked, false);
  assert.equal(plain.el('start').textContent, '开始跟读录音');
  assert.match(plain.el('recognition-purpose').textContent, /文字匹配分和逐词对照/);
  await plain.api.start(); await finish(plain);
  assert.equal(recognitionStarts, 0);
  assert.match(plain.el('feedback').innerHTML, /本次未评分/);
  assert.equal(saved.at(-1).transcriptSource, 'none');
  await plain.api.destroy();

  const script = make(); script.el('consent').checked = true;
  script.el('consent').listeners.get('change')();
  assert.equal(script.el('start').textContent, '开始跟读录音');
  assert.match(script.el('recognition-note').textContent, /已开启.*文字匹配分/);
  await script.api.start(); emit('I am Tom', true); await finish(script);
  assert.match(script.el('feedback').innerHTML, /67<small> \/ 100/);
  assert.match(script.el('feedback').innerHTML, /识别成 “tom”/);
  assert.equal(saved.at(-1).transcriptSource, 'browser-final');
  assert.equal(saved.at(-1).assessmentMode, 'scripted');
  script.el('feedback').listeners.get('click')({ target: { closest: () => ({ dataset: { reviewWord: 'sam' } }) } });
  assert.equal(events.find(event => event.type === 'sam-review-word').detail.src, 'audio/sam.mp3');
  await script.api.destroy();

  const beforeRemembered = recognitionStarts, tracksBeforeRemembered = tracks.length;
  const remembered = make({ id: 'next-sentence' });
  assert.equal(remembered.el('consent').checked, true, 'explicit choice remembered only within this open page');
  assert.equal(recognitionStarts, beforeRemembered, 'remembering a checkbox never starts capture or recognition');
  assert.equal(tracks.length, tracksBeforeRemembered, 'remembered consent never opens microphone without a new user click');
  await remembered.api.setTarget({ id: 'another-sentence' });
  assert.equal(remembered.el('consent').checked, true, 'same session choice follows setTarget');
  remembered.el('consent').checked = false;
  remembered.el('consent').listeners.get('change')();
  await remembered.api.destroy();
  const cancelledChoice = make();
  assert.equal(cancelledChoice.el('consent').checked, false, 'cancelling consent follows subsequent mounts');
  await cancelledChoice.api.destroy();

  const joinedScript = make({ kind: 'answer', assessmentMode: 'scripted' });
  assert.equal(joinedScript.el('start').textContent, '开始跟读录音', 'whole-answer scripted mode is still follow-reading, not off-script');
  await joinedScript.api.destroy();

  const interim = make(); interim.el('consent').checked = true;
  await interim.api.start(); emit('I am Sam', false); await finish(interim);
  assert.match(interim.el('feedback').innerHTML, /只有未确认的临时转写/);
  assert(!interim.el('feedback').innerHTML.includes('sam-recorder__score"'));
  assert.equal(saved.at(-1).transcript, '');
  await interim.api.destroy();

  const failed = make(); failed.el('consent').checked = true;
  await failed.api.start(); emit('I am Sam', true); Recognition.last.onerror({ error: 'network' }); await finish(failed);
  assert.match(failed.el('feedback').innerHTML, /联网转写不可用/);
  assert.match(failed.el('feedback').innerHTML, /本次未评分/);
  assert(!failed.el('feedback').innerHTML.includes('sam-recorder__score"'));
  await failed.api.destroy();

  const earlyEnd = make(); earlyEnd.el('consent').checked = true;
  await earlyEnd.api.start(); emit('I am', true); Recognition.last.onend(); await finish(earlyEnd);
  assert.match(earlyEnd.el('feedback').innerHTML, /识别中断或出错/);
  assert(!earlyEnd.el('feedback').innerHTML.includes('sam-recorder__score"'));
  await earlyEnd.api.destroy();

  const free = make({ kind: 'answer', assessmentMode: 'free' }); free.el('consent').checked = true;
  assert.equal(free.el('start').textContent, '开始脱稿录音');
  assert.equal(free.el('recognition-purpose').textContent, '显示识别文字，换一种说法也可以；不按范文打分');
  assert.match(free.el('recognition-note').textContent, /可勾选上方选项查看英文转写/);
  assert(!free.el('recognition-note').textContent.includes('识别对照'));
  await free.api.start(); emit('My name is Sam and I am a student.', true); await finish(free);
  assert.match(free.el('feedback').innerHTML, /不按参考稿逐字打分/);
  assert(!free.el('feedback').innerHTML.includes('sam-recorder__score"'));
  await free.api.destroy();

  delete root.SpeechRecognition;
  const unsupported = make();
  assert.equal(unsupported.el('consent').disabled, true);
  assert.match(unsupported.el('recognition-note').textContent, /不支持语音识别/);
  await unsupported.api.destroy();
  assert(tracks.every(track => track.stopped));
  console.log('Recorder V20 scoring: normalization/alignment, numeric bounds, provenance, free-answer guard, consent, word playback event, final-only ASR, network failure and unavailable browser mocks passed.');
})().catch(error => { console.error(error); process.exitCode = 1; });
