"""Shared beginner sentence/answer release; synthesize approved course text only."""
import argparse
import asyncio
import copy
import hashlib
import json
from pathlib import Path
import re
import shutil

from build_v18_listening import Speech, _clip_key, _synthesize_all, ENGLISH_VOICE
from build_v19 import word_maps, all_sentence_groups
from v20_curriculum import QUESTIONS, PROFILE, TRAINING_PLAN, SOURCE_NOTES, RESCUE_PHRASES, KNOWN_INTRO

ROOT = Path(__file__).resolve().parents[1]
TOKENS = r"U\.S\.|[A-Za-z]+(?:['’-][A-Za-z]+)*"

def build(site, skip_audio=False):
    questions, rescue, intro = copy.deepcopy((QUESTIONS, RESCUE_PHRASES, KNOWN_INTRO))
    requested, words = {}, set()
    lexicon = word_maps()
    extra = ROOT / 'assets/word-extra-v20.json'
    if extra.exists(): lexicon.update(json.loads(extra.read_text()))

    def remember(text):
        words.update(w.lower().replace('’', "'") for w in re.findall(TOKENS, re.sub(r'\[[^]]*\]', '', text)))

    def audio(text):
        remember(text)
        if not text.strip() or re.search(r'\[|\]|____', text): return None
        speech = Speech(text.replace('SWT', 'S W T'), ENGLISH_VOICE, '-5%')
        old = f'./audio/v19/{_clip_key(speech)}.mp3'
        path = old if (site / old).is_file() else f'./audio/v20/{_clip_key(speech)}.mp3'
        if not (site / path).is_file(): requested[speech] = site / path
        return {'normal': path, 'slow': path, 'slowRate': 0.78}

    for line in rescue + intro['sentences'] + intro.get('optional', []):
        line['audio'] = audio(line['en'])
    intro['fullAudio'] = audio(' '.join(s['en'] for s in intro['sentences']))
    for q in questions:
        q['questionAudio'] = audio(q['question'])
        for item in q.get('variants', []) + q.get('followups', []):
            item['audio'] = audio(item['en'])
            for line in item.get('answer', []): line['audio'] = audio(line['en'])
        for group in all_sentence_groups(q):
            for line in group: line['audio'] = audio(line['en'])
        for item, lines in [(q, q.get('short', []))] + [(b, b['sentences']) for b in q.get('branches', [])]:
            item['fullAudio'] = audio(' '.join(s['en'] for s in lines))
            item['cumulativeAudio'] = [audio(' '.join(s['en'] for s in lines[:i])) for i in range(1,len(lines)+1)]
        q['expandedAudio'] = audio(' '.join(s['en'] for s in q.get('short', []) + q.get('extra', []))) if q.get('short') else None

    used, unknown = {}, []
    for word in sorted(words):
        data = dict(lexicon.get(word, {}))
        if not data.get('ipa') or not data.get('zh'): unknown.append(word)
        existing = f'./audio/words/{word}.mp3'
        data['src'] = existing if (site/existing).is_file() else audio(word.replace('swt','S W T').replace('u.s.','U S'))['normal']
        used[word] = data
    print('Missing vocabulary annotations:', ', '.join(unknown), flush=True)
    print(f'New audio clips: {len(requested)}; annotated vocabulary: {len(used)}', flush=True)
    if not skip_audio:
        if unknown: raise ValueError('Annotate missing words before final build')
        paths = asyncio.run(_synthesize_all(requested, ROOT/'.audio-cache-v18', 8))
        for speech, target in requested.items():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(paths[speech], target)
    payload = {'version':'v20','profile':PROFILE,'questions':questions,'plan':TRAINING_PLAN,
        'rescuePhrases':rescue,'knownIntro':intro,'sources':SOURCE_NOTES,'lexicon':used,
        'audioReady':all(p.is_file() for p in requested.values())}
    (site/'interview-v20.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    patch_site(site)
    return payload

def patch_site(site):
    for name in ['mainline-v20.js','mainline-v20.css','recorder-v19.js','recorder-v19.css','listening-v18.js','listening-v18.css','audio-recovery.js']:
        shutil.copy2(ROOT/'assets'/name, site/'assets'/name)
    legacy = site/'assets/index-C6MAz4Oq.js'
    source = legacy.read_text()
    start = source.index('/* V19.2 replacement')
    end = source.index('function Fe()',start)
    source = source[:start] + (ROOT/'assets/legacy-audio-stability.js').read_text() + '\n' + source[end:]
    source = re.sub(r'\./sw\.js\?v=[\d.]+','./sw.js?v=20',source)
    source = source.replace('${t.score} 分</strong>','文字匹配 ${t.score}/100</strong>')
    source = source.replace('很好，整句话已经能被清楚识别。再说一次，让反应更快。','识别文字与练习稿较一致。它不是发音标准度评分；请回听确认。')
    source = source.replace('重点重读：<b>','需要回听复核（识别差异不一定是发音错误）：<b>')
    source = source.replace('课程、录音和练习进度只保存在这台设备上，不上传，也不依赖GPT。','课程和练习记录不依赖GPT。本机录音不上传到本站；若启用语音识别，浏览器可能使用在线语音服务。')
    legacy.write_text(source)
    html = (site/'index.html').read_text().replace('mainline-v19.css','mainline-v20.css').replace('mainline-v19.js','mainline-v20.js')
    html = re.sub(r'GoSpeak SWT V[\d.]+', 'GoSpeak SWT V20', html)
    html = html.replace('V19.2 · 播放稳定修复','V20 · 逐句学 → 连句说 → 随机答')
    html = re.sub(r'(src|href)="(\./assets/[^"?]+\.(?:js|css))(?:\?v=[^" ]+)?"',r'\1="\2?v=20"',html)
    (site/'index.html').write_text(html)
    manifest = json.loads((site/'manifest.webmanifest').read_text())
    manifest.update(name='GoSpeak SWT V20 · Sam 口测短句训练',description='同一套简单短句：逐句学、连句说、随机回答；录音识别和文字匹配反馈。')
    (site/'manifest.webmanifest').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    worker = (site/'sw.js').read_text()
    worker = worker.replace('interview-v19.json','interview-v20.json').replace('mainline-v19.','mainline-v20.')
    worker = re.sub(r"u.searchParams.set\('v', '[\d.]+'\)", "u.searchParams.set('v', '20')", worker)
    digest = hashlib.sha256()
    for p in sorted([site/'index.html',site/'interview-v20.json',*list((site/'assets').glob('*.js')),*list((site/'assets').glob('*.css'))]): digest.update(p.read_bytes())
    worker = re.sub(r"const VERSION = '[^']+';",f"const VERSION = 'gospeak-independent-v20-{digest.hexdigest()[:12]}';",worker)
    (site/'sw.js').write_text(worker)
    print('V20 shared course and cache-safe interface built.',flush=True)

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('site',type=Path,nargs='?',default=ROOT/'_site')
    parser.add_argument('--skip-audio',action='store_true')
    args=parser.parse_args()
    build(args.site,args.skip_audio)
