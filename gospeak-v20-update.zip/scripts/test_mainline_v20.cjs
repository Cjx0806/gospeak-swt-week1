/* Shared-course, scoring-mode and resource lifecycle checks. No microphone. */
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const cp=require('node:child_process');
const file=path.join(__dirname,'../assets/mainline-v20.js');
const original=fs.readFileSync(file,'utf8');
const boundary=original.indexOf("  window.addEventListener('sam-recorder-start'");
assert(boundary>0);
const source=original.slice(0,boundary)+'window.test={state,answerLines,lineId,lessonHtml,joinedHtml,freeHtml,factGateHtml,questionHtml,wordsHtml,playButton,variants,render,playClip,stopSound,registerAudio,staticAudioUrl,handleClick};})();';
let created=0,behavior=()=>Promise.resolve(),statusText='';
let timerId=0;const timers=new Map(), mounts=[];
class FakeAudio{
  constructor(){created++;this.paused=true;this.currentTime=0;this.readyState=0;this.duration=2;this.removes=0;this.playCalls=0;}
  play(){this.paused=false;this.playCalls++;return behavior();}
  pause(){this.paused=true;}
  removeAttribute(){this.removes++;this.src='';}
  load(){this.currentTime=0;}
}
const sandbox={window:{dispatchEvent(){},SamRecorder:{mount(node,options){mounts.push(options);return{destroy(){},isRecording(){return false;}};}}},document:{baseURI:'https://example.test/',querySelectorAll(){return[];}},localStorage:{getItem(){return null;},setItem(){}},URL,Audio:FakeAudio,Promise,CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},setTimeout(fn){const id=++timerId;timers.set(id,fn);return id;},clearTimeout(id){timers.delete(id);}};
vm.runInNewContext(source,sandbox,{filename:file});
const t=sandbox.window.test;
const line1={id:'s-one',en:'I like swimming.',zh:'我喜欢游泳。',ipa:'aɪ laɪk ˈswɪmɪŋ',chunks:['I like','swimming.'],grammar:'I 主语；like 谓语；swimming 宾语。',audio:{normal:'one.mp3',slow:'one.mp3',slowRate:.78}};
const line2={id:'s-two',en:'I want to learn.',zh:'我想学习。',ipa:'aɪ wɑnt tə lɜrn',audio:{normal:'two.mp3'}};
const known={id:'03',title:'为什么参加 SWT',question:'Why do you want to join SWT?',questionZh:'为什么参加 SWT？',questionAudio:{normal:'q.mp3'},short:[line1,line2],variants:[{en:'Why SWT?',zh:'为什么 SWT？',audio:{normal:'q2.mp3'}},{en:'When will you leave?',zh:'什么时候走？',hint:'这是不同内容，不能沿用主答'}],followups:[{en:'What do you like?',zh:'你喜欢什么？',answer:[line1]}],fullAudio:{normal:'full.mp3'},cumulativeAudio:[line1.audio,{normal:'full.mp3'}]};
const unknown={id:'18',title:'护照',question:'Do you have a passport?',questionZh:'你有护照吗？',short:[],requiresConfirmation:['是否持有有效护照'],branches:[{id:'yes',label:'有有效护照',condition:'只有你真的有护照时使用',sentences:[{id:'s-passport',en:'I have a passport.',zh:'我有护照。'}]},{id:'date',label:'办理日期',condition:'确认日期后使用',sentences:[{id:'s-date',en:'I applied on [date].',zh:'待填写'}]}]};
t.state.data={questions:[known,unknown],lexicon:{'u.s.':{ipa:'ˌjuː ˈes',zh:'美国',src:'us.mp3'},swimming:{ipa:'ˈswɪmɪŋ',zh:'游泳',src:'swim.mp3'}}};t.state.questions=t.state.data.questions;t.state.selected='03';
const content={innerHTML:''};t.state.root={isConnected:true,contains(){return true;},querySelector(selector){if(selector==='[data-sam-content]')return content;if(selector==='[data-sam-status]')return{set textContent(value){statusText=value;}};return{};},querySelectorAll(){return[];}};
t.state.view='lesson';t.render();
assert.equal(mounts.length,1,'only one active recorder is mounted');
assert.equal(mounts.at(-1).id,'sam-v20:line:s-one');
assert.equal(mounts.at(-1).assessmentMode,'scripted');
assert.equal(mounts.at(-1).expectedText,line1.en);
assert(content.innerHTML.includes(line1.zh)&&content.innerHTML.includes(line1.ipa));
assert(content.innerHTML.includes('下一句'));
t.state.view='coach';t.state.step=2;t.state.chain=2;t.render();
assert.equal(mounts.length,2,'switching view replaces, not accumulates recorders');
assert.equal(mounts.at(-1).assessmentMode,'scripted');
assert.equal(mounts.at(-1).expectedText,line1.en+' '+line2.en);
assert(content.innerHTML.includes('data-line-id="s-one"'));
assert(content.innerHTML.includes('data-line-id="s-two"'));
assert(content.innerHTML.includes('去句子课精学这题'));
t.state.chain=1;t.render();assert.equal(mounts.at(-1).expectedText,line1.en,'cumulative first step uses identical sentence');
t.state.step=3;t.state.revealed=false;t.render();
assert.equal(mounts.at(-1).assessmentMode,'free');assert.equal(mounts.at(-1).expectedText,'');
assert(!content.innerHTML.includes(line1.en),'random answer is not leaked while hidden');
assert(content.innerHTML.includes('data-sam-action="random" disabled'),'next random question requires actual saved recording');
t.state.followup=0;t.render();assert.equal(mounts.at(-1).assessmentMode,'free');assert.equal(mounts.at(-1).expectedText,'');assert(content.innerHTML.includes('What do you like?'));
assert.equal(t.variants(known).length,2,'different-intent variants are excluded from same-answer random practice');
t.state.selected='18';t.state.followup=-1;t.state.step=2;t.state.recorderTarget=null;
const fact=t.joinedHtml(unknown);assert(fact.includes('先选你的真实情况'));assert(!fact.includes('I have a passport.'),'unconfirmed branch not provided as a default answer');assert(!fact.includes('data-sam-play'),'unconfirmed branches cannot be played');assert.equal(t.state.recorderTarget,null,'no fabricated scripted score for unknown facts');
t.state.branchChoices['18']='yes';assert.equal(t.answerLines(unknown)[0].en,'I have a passport.');
assert(t.playButton({normal:'bad.mp3'},'My date is [date].',false).includes('disabled'));
const words=t.wordsHtml('U.S. swimming');assert(words.includes('▶ U.S.'));assert(Object.values(t.state.clips).some(c=>c.text==='U.S.'&&c.src==='us.mp3'));
assert.equal(t.staticAudioUrl('a.mp3'),'https://example.test/a.mp3?v=20');assert.equal(t.staticAudioUrl('blob:https://example.test/id'),'blob:https://example.test/id');
assert(original.includes('observe(app,{childList:true})'),'observe SPA replacement only, not live meters or subtitle subtree');
assert(!original.includes('subtree:true'),'no subtree mutation-remount loop');
const css=fs.readFileSync(path.join(__dirname,'../assets/mainline-v20.css'),'utf8');assert(css.includes('sam20-show-continuous:not(.sam20-lesson-mode)'));
const python=process.env.PYTHON||process.env.PYTHON3||'python3';
const actual=JSON.parse(cp.execFileSync(python,['-c','import json,sys;sys.path.insert(0,sys.argv[1]);import v20_curriculum as c;print(json.dumps(c.export_payload()))',__dirname],{encoding:'utf8',maxBuffer:4*1024*1024}));
assert.equal(actual.questions.length,24);
t.state.data=actual;t.state.questions=actual.questions;t.state.branchChoices={};
for(const question of actual.questions){
  t.state.selected=question.id;t.state.line=0;t.state.chain=99;t.state.followup=-1;t.state.variant=0;t.state.revealed=false;
  t.state.view='lesson';t.state.recorderTarget=null;t.render();
  assert(!content.innerHTML.includes('undefined'),question.id+' must not leak missing field');
  if(question.short.length){
    assert.equal(t.state.recorderTarget.id,'sam-v20:line:'+question.short[0].id);
    assert.equal(t.state.recorderTarget.expectedText,question.short[0].en);
  }else assert.equal(t.state.recorderTarget,null,question.id+' facts stay gated');
  t.state.view='coach';t.state.step=2;t.render();
  if(question.short.length)assert.equal(t.state.recorderTarget.expectedText,question.short.map(line=>line.en).join(' '));
  t.state.step=3;t.render();assert.equal(t.state.recorderTarget.assessmentMode,'free');assert.equal(t.state.recorderTarget.expectedText,'');
  for(const line of question.short)assert(!content.innerHTML.includes(line.en),question.id+' random answer hidden');
}
function clickAction(action,value){const button={disabled:false,hasAttribute(){return false;},getAttribute(key){return key==='data-sam-action'?action:key==='data-value'?value:null;}};t.handleClick({target:{closest(){return button;}}});}
const passport=actual.questions.find(q=>q.id==='18');t.state.selected='18';t.state.step=2;t.state.chain=1;
t.state.branchChoices['18']='ready';const readyHtml=t.joinedHtml(passport),readyId=t.state.recorderTarget.id;
t.state.branchChoices['18']='not-yet';const pendingHtml=t.joinedHtml(passport),pendingId=t.state.recorderTarget.id;
assert.notEqual(readyId,pendingId,'different fact branches cannot share one recording-history target');
assert(readyHtml.includes('reset-branch')&&pendingHtml.includes('reset-branch'),'mistaken fact selection can be corrected without reload');
clickAction('reset-branch');assert.equal(t.answerLines(passport).length,0);assert.equal(t.state.recorderTarget,null,'resetting branch removes the old script and score target');
t.state.selected='03';t.state.line=2;t.state.step=3;t.state.freeRecorded=true;clickAction('random');assert.notEqual(t.state.selected,'03');assert.equal(t.state.line,0,'new random question starts its linked sentence course from sentence one');
function play(key){t.playClip({src:'test.mp3',text:'I like swimming.',rate:1},key,null,false);}
function tick(id){const fn=timers.get(id);assert(fn,'timer exists');timers.delete(id);fn();}
async function settle(){await Promise.resolve();await Promise.resolve();await Promise.resolve();}
(async()=>{
  for(let i=0;i<80;i++)play('word-'+i);await settle();assert.equal(created,1,'repeated word taps reuse a single media element');
  t.stopSound();assert.equal(timers.size,0,'stop cancels repeat/load watchdog');assert.equal(t.state.audioElement.src,'');assert(statusText.includes('已停止'),'active playback stop clears both local and shared status');
  statusText='保留当前错误信息';t.stopSound();assert.equal(statusText,'保留当前错误信息','idle cleanup does not overwrite a meaningful error');
  behavior=()=>Promise.reject(new Error('NotAllowedError'));play('retry');await settle();assert.equal(t.state.audioKey,'');
  behavior=()=>Promise.resolve();play('retry');await settle();assert.equal(t.state.audioKey,'retry','retry not trapped by active-key state');t.stopSound();
  let fulfill;behavior=()=>new Promise(resolve=>{fulfill=resolve;});play('timeout');tick(t.state.watchdog);assert.equal(t.state.audio,null);assert(statusText.includes('超时'));fulfill();await settle();assert.equal(t.state.audio,null,'late completion cannot resurrect timed out player');
  behavior=()=>Promise.resolve();t.state.loop=3;play('repeat');await settle();const audio=t.state.audioElement,before=audio.playCalls;audio.onended();tick(t.state.audioTimer);await settle();audio.onended();tick(t.state.audioTimer);await settle();audio.onended();assert.equal(audio.playCalls-before,2);assert.equal(t.state.audio,null);assert(statusText.includes('播放结束'),'natural completion cannot leave a stale playing label');
  console.log('PASS V20 shared sentence IDs, one recorder, scripted/free separation, hidden answer, fact gate, navigation links, random intent, placeholders, audio reuse/timeout/retry/finite loop.');
})().catch(error=>{console.error(error);process.exitCode=1;});
