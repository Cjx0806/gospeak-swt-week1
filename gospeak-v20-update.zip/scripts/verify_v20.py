"""Fail-closed publication checks for the built V20 site; no network or TTS.

Retains V19's static-MP3 and long-track subtitle verification, but validates the
new shared short-sentence bank, transparent recorder and V20 cache entry points.
"""
from __future__ import annotations

import hashlib
from html.parser import HTMLParser
import json
import math
from pathlib import Path
import re
import sys
from urllib.parse import parse_qs, urlsplit

from mutagen.mp3 import MP3


UNKNOWN_TOPICS = {"14", "15", "16", "17", "18", "19", "21", "24"}
SLOTS = re.compile(r"\[|\]|_{2,}")
WORDS = re.compile(r"U\.S\.|[A-Za-z]+(?:['’-][A-Za-z]+)*")


def normalized(text):
    return " ".join(re.findall(r"[a-z]+(?:['’-][a-z]+)*", text.lower()))


def sentence_id(text):
    return "s-" + hashlib.sha256(normalized(text).encode()).hexdigest()[:12]


class References(HTMLParser):
    def __init__(self):
        super().__init__()
        self.assets = []
        self.ids = set()

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if attrs.get("id"):
            self.ids.add(attrs["id"])
        if tag == "script" and attrs.get("src"):
            self.assets.append(attrs["src"])
        if tag == "link" and attrs.get("rel") == "stylesheet" and attrs.get("href"):
            self.assets.append(attrs["href"])


def verify(root):
    root = Path(root).resolve()
    course = json.loads((root / "interview-v20.json").read_text())
    assert course["version"] == "v20", "wrong curriculum version"
    assert course["audioReady"] is True, "incomplete static speech build"
    assert [q["id"] for q in course["questions"]] == [f"{i:02d}" for i in range(1, 25)]
    profile = course["profile"]
    for key, value in {
        "englishName": "Sam", "schoolZh": "广西幼儿师范高等专科学校",
        "majorZh": "体育体能训练", "majorEn": "physical fitness training",
        "yearZh": "大一", "certificateEn": "a Chinese lifeguard certificate",
    }.items():
        assert profile[key] == value, (key, profile.get(key))
    assert "日期" in profile["returnPlan"] and "未" in profile["returnPlan"], "invented confirmed return dates"

    durations = {}

    def mp3(src):
        assert isinstance(src, str) and src.startswith("./audio/"), ("nonlocal audio reference", src)
        parts = urlsplit(src)
        assert not parts.scheme and not parts.netloc and not parts.query and not parts.fragment, src
        path = (root / parts.path).resolve()
        assert path.is_relative_to(root / "audio"), ("audio escapes site", src)
        assert path.is_file() and path.stat().st_size > 0, ("missing audio", src)
        if path not in durations:
            length = MP3(str(path)).info.length
            assert math.isfinite(length) and length > 0, ("invalid MP3", src)
            durations[path] = length
        return durations[path]

    def pair(value, context, required=True):
        if not required:
            assert value is None, ("unexpected audio for unresolved/empty text", context, value)
            return
        assert isinstance(value, dict), ("missing audio pair", context)
        mp3(value.get("normal"))
        mp3(value.get("slow"))
        assert isinstance(value.get("slowRate"), (int, float)) and 0.5 <= value["slowRate"] <= 1, context

    canonical = {}
    sentence_words = set()
    question_words = set()
    sentence_count = 0

    def sentence(line, context):
        nonlocal sentence_count
        sentence_count += 1
        en = line["en"]
        assert line["id"] == sentence_id(en), ("unstable sentence identity", context, en)
        for field in ("zh", "grammar", "pronunciation"):
            assert isinstance(line.get(field), str) and line[field].strip(), (context, field)
        assert isinstance(line.get("chunks"), list) and line["chunks"] and all(isinstance(s, str) and s.strip() for s in line["chunks"]), context
        assert normalized(" ".join(line["chunks"])) == normalized(en), ("chunks do not form sentence", context)
        placeholder = bool(SLOTS.search(en))
        if placeholder:
            assert line.get("needsPersonalization") is True and not line["ipa"], ("unresolved personal sentence", context)
        else:
            assert isinstance(line.get("ipa"), str) and line["ipa"].strip(), ("missing IPA", context)
            count = len(WORDS.findall(en))
            assert count <= 8 or ("Guangxi College for Preschool Education" in en and count <= 9), ("answer too long", context, en)
        pair(line.get("audio"), context, not placeholder)
        identity = {key: line.get(key) for key in ("en", "zh", "ipa", "chunks", "grammar", "pronunciation", "audio", "needsPersonalization")}
        previous = canonical.setdefault(line["id"], identity)
        assert identity == previous, ("shared sentence differs between lessons/topics", context, line["id"])
        sentence_words.update(word.lower() for word in WORDS.findall(re.sub(r"\[[^]]*\]", "", en)))

    def combined(group, full, cumulative, context):
        eligible = bool(group) and not any(SLOTS.search(s["en"]) for s in group)
        pair(full, context + ":full", eligible)
        assert isinstance(cumulative, list) and len(cumulative) == len(group), ("cumulative answer length", context)
        for index, entry in enumerate(cumulative):
            ok = not any(SLOTS.search(s["en"]) for s in group[:index + 1])
            pair(entry, f"{context}:chain-{index + 1}", ok)
        if eligible:
            assert cumulative[0] == group[0]["audio"], ("first joined unit differs from sentence", context)
            assert cumulative[-1] == full, ("final joined answer differs from full answer", context)

    for q in course["questions"]:
        qid = q["id"]
        assert q["question"] and q["questionZh"] and q["title"], qid
        assert q["learningGoal"] and q["connectionTip"] and q["keywords"], ("missing beginner answer guidance", qid)
        assert q["answerType"] == ("confirm-facts-first" if qid in UNKNOWN_TOPICS else "short-beginner"), ("wrong answer intent/confirmation mode", qid)
        pair(q.get("questionAudio"), qid + ":question")
        question_words.update(word.lower() for word in WORDS.findall(q["question"]))
        assert len(q["variants"]) == 3 and len(q["followups"]) == 2, qid
        for kind in ("variants", "followups"):
            for index, item in enumerate(q[kind]):
                assert item["en"] and item["zh"], (qid, kind, index)
                pair(item.get("audio"), f"{qid}:{kind}:{index}")
                question_words.update(word.lower() for word in WORDS.findall(item["en"]))
                if kind == "followups":
                    assert item.get("hint"), ("follow-up needs distinct intent guidance", qid, index)
                    assert isinstance(item.get("answer"), list) and len(item["answer"]) <= 3
                    for line in item["answer"]:
                        sentence(line, f"{qid}:followup:{index}")
        short = q["short"]
        if qid in UNKNOWN_TOPICS:
            assert not short and q["readyForAutoplay"] is False and q["requiresConfirmation"], ("unknown fact made default", qid)
        else:
            assert 2 <= len(short) <= 4 and q["readyForAutoplay"] is True, ("beginner answer size", qid)
        for line in short + q["extra"]:
            assert not SLOTS.search(line["en"]), ("placeholder in default answer", qid)
            sentence(line, qid + ":default")
        combined(short, q.get("fullAudio"), q.get("cumulativeAudio"), qid)
        pair(q.get("expandedAudio"), qid + ":expanded", bool(short))
        for branch in q["branches"]:
            assert branch["confirmed"] is False and branch["condition"], ("unverified branch silently selected", qid, branch["id"])
            for line in branch["sentences"]:
                sentence(line, f"{qid}:branch:{branch['id']}")
            combined(branch["sentences"], branch.get("fullAudio"), branch.get("cumulativeAudio"), f"{qid}:branch:{branch['id']}")

    for line in course["rescuePhrases"] + course["knownIntro"]["sentences"] + course["knownIntro"].get("optional", []):
        sentence(line, "rescue/known-intro")
    pair(course["knownIntro"].get("fullAudio"), "known-intro:full")
    default_text = " ".join(s["en"] for q in course["questions"] for s in q["short"] + q["extra"])
    for fact in ("I have a Chinese lifeguard certificate.", "I will return to China after SWT.", "I will continue my studies.", "My travel dates are not confirmed yet."):
        assert fact in default_text, ("confirmed fact lost", fact)
    for invented in ("My major is business", "sports art", "I have a passport", "my parents support", "I worked", "U.S. certified"):
        assert invented not in default_text, ("unconfirmed biography in defaults", invented)
    assert not re.search(r"I can swim \d", default_text)

    lexicon = course["lexicon"]
    missing_words = []
    for word, data in lexicon.items():
        if not data.get("ipa") or not data.get("zh"):
            missing_words.append(word)
        mp3(data.get("src"))
    assert not missing_words, ("word annotation missing", missing_words)
    assert sentence_words <= set(lexicon), ("answer words not teachable", sorted(sentence_words - set(lexicon)))
    # Question vocabulary is useful, but old long-listening modules are not
    # retroactively made part of this new sentence dictionary.
    assert question_words <= set(lexicon), ("question vocabulary missing", sorted(question_words - set(lexicon)))

    # All 14 * 3 legacy module tracks remain valid, synchronized and available.
    audio_path = root / "listening-v18.json"
    audio = json.loads(audio_path.read_text())
    assert audio["version"] in ("v19", "v20"), audio["version"]
    assert audio_path.read_bytes() == (root / "audio/v18/manifest.json").read_bytes(), "long-track manifest split-brain"
    assert len(audio["modules"]) == 14
    track_count = 0
    for module in audio["modules"]:
        assert len(module["tracks"]) == 3, module["id"]
        for track in module["tracks"].values():
            track_count += 1
            assert track["built"] is True and track["cues"], track["src"]
            duration = mp3(track["src"])
            assert abs(duration - track["durationSeconds"]) < 0.3, ("MP3 duration drift", track["src"])
            last = 0
            for cue in track["cues"]:
                assert cue["start"] >= last - 0.002, ("overlapping cues", track["src"])
                assert cue["end"] > cue["start"], ("empty cue", track["src"])
                assert isinstance(cue["en"], str) and isinstance(cue["zh"], str)
                assert cue["en"] or cue["zh"], ("empty bilingual cue", track["src"])
                last = cue["end"]
            assert abs(last - track["durationSeconds"]) < 0.2, ("subtitle end mismatch", track["src"], last)

    def walk_audio(item):
        if isinstance(item, dict):
            for key, value in item.items():
                if key in ("src", "normal", "slow") and isinstance(value, str) and value.endswith(".mp3"):
                    mp3(value)
                else:
                    walk_audio(value)
        elif isinstance(item, list):
            for value in item:
                walk_audio(value)

    # Covers the additional three all-module collections kept in modes.
    walk_audio(audio)
    walk_audio(course)

    html = (root / "index.html").read_text()
    refs = References()
    refs.feed(html)
    active_names = {Path(urlsplit(ref).path).name for ref in refs.assets}
    required = {"mainline-v20.js", "mainline-v20.css", "recorder-v19.js", "recorder-v19.css", "audio-recovery.js"}
    assert required <= active_names, ("missing active V20 entry", required - active_names)
    assert not active_names.intersection({"mainline-v19.js", "mainline-v19.css", "mainline-v17-profile.js", "mainline-v17-profile.css"}), "old mainline still running"
    assert "sam-audio-recovery" in refs.ids, "lost sound recovery bar"
    for ref in refs.assets:
        parts = urlsplit(ref)
        path = (root / parts.path).resolve()
        assert not parts.scheme and not parts.netloc and path.is_relative_to(root) and path.is_file(), ("missing/remote active resource", ref)
        assert parse_qs(parts.query).get("v") == ["20"], ("mixed asset cache versions", ref)

    mainline = (root / "assets/mainline-v20.js").read_text()
    recorder = (root / "assets/recorder-v19.js").read_text()
    assert "interview-v20.json" in mainline, "new UI loads old bank"
    assert "sam-review-word" in mainline, "review-word audio missing integration"
    for marker in ("evaluateReading", "browser-final", "recognitionIncomplete", "sam-recorder__score", "不是专业发音分"):
        assert marker in recorder, ("scoring safety contract missing", marker)
    sw = (root / "sw.js").read_text()
    assert re.search(r"gospeak-independent-v20-[0-9a-f]{12}", sw), "wrong SW release hash"
    assert "requestUrl.pathname.includes('/audio/')" in sw and "headers.has('range')" in sw
    assert "interview-v20.json" in sw and "mainline-v20.js" in sw, "new cache core missing"
    assert "mainline-v19.js" not in sw and "interview-v19.json" not in sw, "old course is precached"
    assert not re.search(r"\.\.\.(?:phraseAudio|coachAudio|shadowAudio)", sw), "bulk audio precache reintroduced"
    assert not re.search(r"core\.push\([^\n]*\.mp3", sw), "MP3 added to precache"
    assert re.search(r"searchParams\.set\(['\"]v['\"],\s*['\"]20['\"]\)", sw), "old versioned cache"
    index_scripts = [root / urlsplit(ref).path for ref in refs.assets if re.search(r"/index[^/]*\.js", ref)]
    assert index_scripts and all("./sw.js?v=20" in p.read_text() for p in index_scripts), "legacy shell registers old service worker"
    for path in [root / "index.html", root / "interview-v20.json", audio_path, *index_scripts]:
        text = path.read_text()
        for forbidden in ("Junxi", "junxi", "俊熙", "30天口测", "My major is business.", "我的专业是商科。"):
            assert forbidden not in text, (path.name, forbidden)
    print(f"V20 verified: 24 topics, {len(canonical)} stable shared sentences ({sentence_count} placements), "
          f"{len(lexicon)} complete word entries, {track_count} timed legacy module tracks + collection audio, "
          f"{len(durations)} valid unique MP3s; transparent scoring and V20 cache entries present.")


if __name__ == "__main__":
    verify(sys.argv[1] if len(sys.argv) > 1 else "_site")
