/* V19.2 replacement for the legacy sentence/word player inside its module.
 * A/D/E/$/Me retain the compiled app's audio/key/message/render/asset bindings.
 * Stop means release the resource, not only silence a pending download.
 */
var samLegacyTimer = 0;
function samAudioNotice(message) {
  window.dispatchEvent(new CustomEvent('gospeak-audio-status', {detail:{message:message}}));
}
function q(shouldRender = true) {
  clearTimeout(samLegacyTimer); samLegacyTimer = 0;
  var previous = A; A = null; D = '';
  if (previous) {
    previous.onerror = previous.onplaying = previous.onwaiting = previous.onstalled = previous.onpause = null;
    previous.pause(); previous.removeAttribute('src'); previous.load();
  }
  if (shouldRender) $();
}
function J(path, rate = 1, key = path) {
  if (window.__samMainlineV19 && window.__samMainlineV19.isRecording()) {
    samAudioNotice('请先停止并保存录音，再播放示范。'); return;
  }
  if (D === key) { q(); samAudioNotice('已停止点读。'); return; }
  q(false);
  window.dispatchEvent(new CustomEvent('gospeak-playback-request', {detail:{owner:'legacy-lesson'}}));
  var next = new Audio(Me(path)); A = next; D = key;
  next.preload = 'none'; next.loop = true; next.playbackRate = rate; next.preservesPitch = true;
  function fail(message) { if (A !== next) return; q(false); E = message; samAudioNotice(message); $(); }
  function waiting() {
    if (A !== next || samLegacyTimer) return;
    samAudioNotice('正在加载音频，请稍等；15秒未载入会停止等待，可直接重试。');
    var from = next.currentTime || 0;
    samLegacyTimer = setTimeout(function () {
      samLegacyTimer = 0;
      if (A !== next || (!next.paused && next.currentTime > from + 0.2)) return;
      fail('音频加载较慢，已停止等待。请再点刚才的播放按钮；仍无声可点「恢复声音」。');
    }, 15000);
  }
  next.onplaying = function () { if (A === next) { clearTimeout(samLegacyTimer); samLegacyTimer = 0; samAudioNotice('正在循环点读，再点同一个按钮可停止。'); } };
  next.onwaiting = waiting;
  next.onstalled = function () { if (next.readyState < 3) waiting(); };
  next.onpause = function () { if (A === next && !next.ended) { q(false); samAudioNotice('播放已暂停，再点句子可重新播放。'); $(); } };
  next.onerror = function () { fail('音频未载入，请检查网络后再次点读。'); };
  waiting();
  try {
    var pending = next.play();
    if (pending && pending.catch) pending.catch(function () { fail('播放未开始，请再点一次播放按钮。'); });
  } catch (_) { fail('播放未开始，请再点一次播放按钮。'); }
  $();
}
// The former warmer requested every word in the day at once, competing with
// the audio Sam actually tapped on slow connections. Native HTTP caching stays.
function Pe() {}
window.addEventListener('gospeak-playback-request', function (event) {
  if ((!event.detail || event.detail.owner !== 'legacy-lesson') && A) q(!!(event.detail && event.detail.owner === 'recovery'));
});
window.addEventListener('sam-recorder-start', function () { if (A) q(false); });
window.addEventListener('pagehide', function () { q(false); });
/* END_V19_2_LEGACY_AUDIO */
