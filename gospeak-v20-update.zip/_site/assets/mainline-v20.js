/* Shared short-sentence course: learn one, connect them, answer a new question. */
(function () {
  'use strict';
  if (window.__samMainlineV20) return;
  var VERSION = '20', STORE = 'gospeak-sam-v20-linked', OLD_STORE = 'gospeak-sam-v19-practice';
  var state = {root:null, data:null, questions:[], selected:'03', view:'coach', step:2,
    line:0, chain:99, variant:0, followup:-1, revealed:false, branchChoices:{}, loop:1,
    clips:{}, clipCounter:0, audio:null, audioElement:null, audioToken:0, audioTimer:null,
    watchdog:null, audioKey:'', recorder:null, recorderTarget:null, loading:false,
    loadingToken:0, scheduled:false, lessonLegacy:false, continuous:false,
    practice:{}, counts:{}, seen:{}, freeRecorded:false, lastTarget:'', needsRender:true};
  try {
    var saved=JSON.parse(localStorage.getItem(STORE)||'{}');
    state.selected=saved.selected||'03';state.practice=saved.practice||{};state.counts=saved.counts||{};
    var old=JSON.parse(localStorage.getItem(OLD_STORE)||'{}');
    Object.keys(old.counts||{}).forEach(function(id){state.counts[id]=Math.max(state.counts[id]||0,old.counts[id]||0);});
  } catch (_) {}
  var api={remount:mount,isRecording:isRecording,stopPlayback:stopSound};
  window.__samMainlineV20=api;
  // Legacy audio controls depend on this public interlock; retain the alias.
  window.__samMainlineV19=api;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function list(v){return Array.isArray(v)?v:[];}
  function q(){return state.questions.find(function(x){return x.id===state.selected;})||state.questions[0];}
  function text(lines){return lines.map(function(line){return line.en;}).join(' ');}
  function hasSlots(value){return /\[[^\]]+\]/.test(value||'');}
  function lineId(line){return line.id||'legacy-'+String(line.en).toLowerCase().replace(/[^a-z0-9]+/g,'-');}
  function selectedBranch(item){var id=state.branchChoices[item.id];return list(item.branches).find(function(b){return b.id===id;});}
  function answerLines(item){var direct=list(item.short);if(direct.length)return direct;var branch=selectedBranch(item);return branch?list(branch.sentences).filter(function(l){return !hasSlots(l.en);}):[];}
  function answerTargetId(item,count){var branch=!list(item.short).length&&selectedBranch(item);return 'sam-v20:answer:'+item.id+':'+count+(branch?':branch:'+branch.id:'');}
  function branchChoiceHtml(item){var branch=!list(item.short).length&&selectedBranch(item);return branch?'<div class="sam20-branch-choice"><span>已选真实情况：'+esc(branch.label||branch.id)+'</span><button data-sam-action="reset-branch">选错了？重新选择</button></div>':'';}
  function persist(){try{localStorage.setItem(STORE,JSON.stringify({selected:state.selected,practice:state.practice,counts:state.counts}));}catch(_){}}
  function status(message){var node=state.root&&state.root.querySelector('[data-sam-status]');if(node)node.textContent=message;window.dispatchEvent(new CustomEvent('gospeak-audio-status',{detail:{message:message}}));}
  function isRecording(){return !!(state.recorder&&state.recorder.isRecording&&state.recorder.isRecording());}
  function safeToChange(){if(isRecording()){status('请先停止并保存录音，再换句子或切换板块。');return false;}return true;}
  function disposeRecorder(){if(state.recorder){try{var result=state.recorder.destroy();if(result&&result.catch)result.catch(function(){});}catch(_){}state.recorder=null;}state.recorderTarget=null;}
  function variants(item){return [{en:item.question,zh:item.questionZh,audio:item.questionAudio}].concat(list(item.variants).filter(function(v){return !v.hint&&v.en!==item.question;}));}
  function activeQuestion(item){return state.followup>=0?list(item.followups)[state.followup]||variants(item)[0]:variants(item)[state.variant]||variants(item)[0];}
  function activeAnswer(item){return state.followup>=0?list(activeQuestion(item).answer):answerLines(item);}
  function note(message,kind){return '<p class="sam20-note '+(kind||'')+'">'+esc(message)+'</p>';}

  function mount(){
    var active=document.querySelector('.app-nav [data-view].active');
    var view=active&&active.getAttribute('data-view');
    var host=view==='lesson'?document.querySelector('main.layout'):view==='coach'?document.querySelector('.coach-layout'):null;
    if(!host){if(state.root&&state.root.isConnected===false){stopSound();disposeRecorder();state.needsRender=true;}return;}
    var changed=state.view!==view;state.view=view;
    if(changed&&view==='lesson'){state.followup=-1;state.variant=0;}
    var nav=document.querySelector('.app-nav [data-view="coach"]');if(nav&&nav.textContent!=='SWT口测主线')nav.textContent='SWT口测主线';
    if(!state.root){
      state.root=document.createElement('section');state.root.id='oral-mainline';state.root.className='sam20';
      state.root.innerHTML='<div class="sam20-app"><div data-sam-content>正在载入短句口测课…</div><p data-sam-status class="sam20-status" role="status" aria-live="polite"></p></div>';
      state.root.addEventListener('click',handleClick);state.root.addEventListener('change',handleChange);
    }
    host.classList.add(view==='lesson'?'sam20-lesson-host':'sam20-coach-host');
    if(state.root.parentNode!==host){host.insertBefore(state.root,host.firstChild);state.needsRender=true;}
    document.body.classList.toggle('sam20-lesson-route',view==='lesson');
    document.body.classList.toggle('sam20-legacy-route',view==='lesson'&&state.lessonLegacy);
    state.root.classList.toggle('sam20-lesson-mode',view==='lesson');
    state.root.classList.toggle('sam20-show-continuous',state.continuous&&view==='coach');
    host.classList.toggle('sam20-show-legacy',state.lessonLegacy&&view==='lesson');
    if(changed)state.needsRender=true;
    if(!state.data&&!state.loading)load();else if(state.data&&state.needsRender)render();
  }
  function scheduleMount(){if(state.scheduled)return;state.scheduled=true;(window.requestAnimationFrame||function(cb){setTimeout(cb,0);})(function(){state.scheduled=false;mount();});}
  function load(){
    if(state.loading)return;state.loading=true;var token=++state.loadingToken;
    var controller=typeof AbortController==='function'?new AbortController():null;
    var timer=setTimeout(function(){if(controller)controller.abort();if(token===state.loadingToken){state.loading=false;state.loadingToken++;loadError('网络等待较久，请点“重试载入”。');}},15000);
    fetch(new URL('interview-v20.json?v='+VERSION,document.baseURI).href,{cache:'no-cache',signal:controller?controller.signal:undefined}).then(function(r){if(!r.ok)throw new Error('课程暂时无法下载');return r.json();}).then(function(data){
      if(token!==state.loadingToken)return;clearTimeout(timer);state.loading=false;
      if(!Array.isArray(data.questions)||!data.questions.length)throw new Error('课程数据为空');
      state.data=data;state.questions=data.questions;if(!state.questions.some(function(x){return x.id===state.selected;}))state.selected='03';
      state.needsRender=true;render();status('一句一句学，再把相同的句子连起来。不需要背长篇答案。');
    }).catch(function(error){if(token!==state.loadingToken)return;clearTimeout(timer);state.loading=false;loadError(error.name==='AbortError'?'课程载入超时，请重试。':error.message);});
  }
  function loadError(message){if(state.root)state.root.querySelector('[data-sam-content]').innerHTML='<h2>课程还没有载入</h2>'+note(message)+'<button data-sam-action="retry">重试载入</button>';}
  function registerAudio(audio,content,slow){
    var src=typeof audio==='string'?audio:audio&&(slow?audio.slow||audio.normal||audio.src:audio.normal||audio.src);
    var key='clip-'+(++state.clipCounter);state.clips[key]={src:src||'',text:content||'',rate:slow&&audio&&audio.slowRate?Number(audio.slowRate):1};return key;
  }
  function playButton(audio,content,slow,label,single){
    var key=registerAudio(audio,content,slow),disabled=hasSlots(content);
    return '<button type="button" data-sam-play="'+key+'" '+(single?'data-single="true" ':'')+(disabled?'disabled title="待填真实信息不会朗读" ':'')+'>'+esc(disabled?'先补真实信息':label||(slow?'▶ 慢速听 / 跟读':'▶ 正常语速'))+'</button>';
  }
  function audioRow(audio,content){return '<div class="sam20-audio">'+playButton(audio,content,true)+playButton(audio,content,false)+'</div>';}
  function wordsHtml(content){
    var lex=state.data.lexicon||{}, words=String(content).match(/U\.S\.|[A-Za-z]+(?:['’-][A-Za-z]+)*/g)||[];
    return '<div class="sam20-words">'+words.map(function(word){var info=lex[word.toLowerCase()]||{};return '<button data-sam-play="'+registerAudio(info.src||info.audio,word,false)+'" data-single="true"><b>▶ '+esc(word)+'</b><em>'+esc(info.ipa?'/'+info.ipa+'/':'')+'</em><span>'+esc(info.zh||'结合句意理解')+'</span></button>';}).join('')+'</div>';
  }
  function grammarHtml(line){
    var g=line.grammar;if(typeof g==='string')return note(g);
    var parts=g&&g.parts||line.parts||[];
    return '<div class="sam20-grammar">'+parts.map(function(p){return '<p><b>'+esc(p.role||p.label||'')+'</b> '+esc(p.text||p.en||'')+'<small>'+esc(p.zh||p.meaning||'')+'</small></p>';}).join('')+'</div>'+note(g&&g.note||'');
  }
  function recorderHtml(target){state.recorderTarget=target;return '<div data-sam-recorder></div>';}
  function target(id,expected,kind,mode,title){return {id:id,expectedText:expected,kind:kind,assessmentMode:mode,title:title,lexicon:state.data.lexicon||{},onStart:stopSound};}
  function headerHtml(item){
    var current=state.view==='lesson'?1:state.step;
    return '<header class="sam20-header"><div><p class="sam20-eyebrow">SAM · SWT 口测短句课</p><h1>'+(state.view==='lesson'?'先会一句，再会一段。':'把会读的句子，变成会说的回答。')+'</h1><p>一句一句学 → 用原句连答 → 随机听题开口</p></div><span class="sam20-version">V20</span></header><nav class="sam20-steps" aria-label="口测训练三步">'+['1 逐句精学','2 连成回答','3 随机口测'].map(function(label,i){return '<button data-sam-action="step" data-value="'+(i+1)+'" aria-pressed="'+(current===i+1)+'">'+label+'</button>';}).join('')+'</nav><label class="sam20-selector">今天练哪一题<select data-sam-question aria-label="选择口测题">'+state.questions.map(function(x){return '<option value="'+esc(x.id)+'" '+(x.id===item.id?'selected':'')+'>'+esc(x.title)+'</option>';}).join('')+'</select></label>';
  }
  function questionHtml(item){var question=activeQuestion(item),blind=state.view==='coach'&&state.step===3;
    return '<section class="sam20-question"><small>'+(state.followup>=0?'面试官追问':'面试官可能这样问')+'</small><h2 lang="en">'+esc(question.en)+'</h2>'+(blind?'<details><summary>听不懂？看问题中文</summary><p>'+esc(question.zh)+'</p></details>':'<p>'+esc(question.zh)+'</p>')+'<div class="sam20-audio">'+playButton(question.audio,question.en,false,'▶ 听问题',true)+(state.followup<0?'<button data-sam-action="wording">换一种问法</button>':'<button data-sam-action="base">回主问题</button>')+'</div></section>';
  }
  function controlsHtml(){return '<div class="sam20-controls"><label>示范播放 <select data-sam-loop aria-label="示范播放次数">'+[[1,'1次'],[3,'3次，留空跟读'],[0,'循环直到停止']].map(function(x){return '<option value="'+x[0]+'" '+(state.loop===x[0]?'selected':'')+'>'+x[1]+'</option>';}).join('')+'</select></label><button data-sam-action="stop">■ 停止示范音</button></div>';}
  function factGateHtml(item){
    var branches=list(item.branches);
    return '<section class="sam20-fact"><h3>这题先选你的真实情况</h3>'+note((item.requiresConfirmation||[]).join('、')+'：未确认的信息不会替你编写，也不会默认播放。','sam20-caution')+branches.map(function(branch,index){var content=text(list(branch.sentences)),slots=hasSlots(content);return '<article><h4>'+esc(branch.label||'条件答法')+'</h4>'+note(branch.condition||'请确认这一情况真实')+(slots?note('这组有待填内容。请先把真实信息发给我，再生成专属句子。'): '<button data-sam-action="confirm-branch" data-value="'+index+'">符合我的真实情况，使用这组句子</button>')+'</article>';}).join('')+'</section>';
  }
  function lessonHtml(item){
    var answer=answerLines(item);if(!answer.length)return factGateHtml(item);
    state.line=Math.max(0,Math.min(state.line,answer.length-1));var line=answer[state.line],id=lineId(line),count=state.practice[id]||0;
    return '<section class="sam20-lesson">'+branchChoiceHtml(item)+'<div class="sam20-subhead"><span>这道口测题的第 '+(state.line+1)+' / '+answer.length+' 句</span><small data-line-progress>已录 '+count+' 次 · 不等于已掌握</small></div><h2 class="sam20-english" lang="en">'+esc(line.en)+'</h2><p class="sam20-translation">'+esc(line.zh)+'</p><p class="sam20-ipa">美式音标 /'+esc(line.ipa||'')+'/</p>'+audioRow(line.audio,line.en)+(list(line.chunks).length>1?'<p class="sam20-chunks">按意思分组：'+list(line.chunks).map(esc).join(' <b>/</b> ')+'</p>':'')+'<details class="sam20-explain"><summary>单词点读、中文意思与主谓宾</summary>'+wordsHtml(line.en)+grammarHtml(line)+(line.pronunciation?note('跟读提示：'+line.pronunciation):'')+'</details>'+recorderHtml(target('sam-v20:line:'+id,line.en,'sentence','scripted','跟读这一句 · 录音识别与文字匹配分'))+'<div class="sam20-pager"><button data-sam-action="previous" '+(state.line===0?'disabled':'')+'>上一句</button><button data-sam-action="next">'+(state.line<answer.length-1?'下一句 →':'把这些句子连起来 →')+'</button></div></section>';
  }
  function answerAudio(item,answer,count){var branch=selectedBranch(item),source=branch||item;return list(source.cumulativeAudio)[count-1]||(count===answer.length?source.fullAudio:null);}
  function joinedHtml(item){
    var answer=answerLines(item);if(!answer.length)return factGateHtml(item);
    state.chain=Math.max(1,Math.min(state.chain,answer.length));var selected=answer.slice(0,state.chain),content=text(selected);
    return '<section class="sam20-join">'+branchChoiceHtml(item)+'<div class="sam20-subhead"><h3>就是句子课里的原句，不换一套答案。</h3></div><button class="sam20-link" data-sam-action="to-lesson">不熟？去句子课精学这题 →</button><div class="sam20-chain" aria-label="逐句连接">'+answer.map(function(_,i){return '<button data-sam-action="chain" data-value="'+(i+1)+'" aria-pressed="'+(state.chain===i+1)+'">'+(i===0?'先说第1句':i===answer.length-1?'连说全部'+answer.length+'句':'连说前'+(i+1)+'句')+'</button>';}).join('')+'</div><ol class="sam20-answer-lines">'+selected.map(function(line,i){return '<li data-line-id="'+esc(lineId(line))+'"><div><p lang="en">'+esc(line.en)+'</p><small>'+esc(line.zh)+'</small></div><button data-sam-action="learn-line" data-value="'+i+'">精学这句</button></li>';}).join('')+'</ol>'+audioRow(answerAudio(item,answer,state.chain),content)+note('句子间短停一下就行，不必一口气说完。先说清楚，不追求复杂句或很快的语速。')+recorderHtml(target(answerTargetId(item,state.chain),content,'answer','scripted','把上面的句子连起来录 · 查看哪些词需复核'))+'<button class="sam20-primary" data-sam-action="step" data-value="3">练熟后：隐藏答案，自己回答 →</button></section>';
  }
  function freeHtml(item){
    var answer=activeAnswer(item), question=activeQuestion(item),conditionMissing=!answerLines(item).length&&state.followup<0;
    return '<section class="sam20-free"><h3>不看答案，用会说的短句回答。</h3>'+note('先直接回答，再补一句真实原因。说法和示范不同也可以；这里不按逐字一致扣分。')+recorderHtml(target('sam-v20:free:'+item.id+':'+(state.followup>=0?'followup-'+state.followup:'main'),'', 'answer','free','脱稿回答 · 录音与识别（不按范文逐字打分）'))+'<div class="sam20-random-actions"><button data-sam-action="reveal" aria-expanded="'+state.revealed+'">'+(state.revealed?'收起提示':'卡住了？看中文思路与短答')+'</button><button data-sam-action="followup" '+(!list(item.followups).length?'disabled':'')+'>听一道追问</button></div>'+(state.revealed?'<div class="sam20-help">'+note(question.hint||item.note||'先说明你的真实情况，再补一个简单理由。')+(conditionMissing?factGateHtml(item):answer.map(function(line){return '<p lang="en">'+esc(line.en)+'</p><p>'+esc(line.zh)+'</p>'+audioRow(line.audio,line.en);}).join(''))+'<button data-sam-action="step" data-value="2">还不熟：返回连句练习</button></div>':'')+'<div class="sam20-next-random"><span data-free-status>'+(state.freeRecorded?'这一题已录音，先回听再抽下一题。':'这题先实际录一遍，再换题。')+'</span><button class="sam20-primary" data-sam-action="random" '+(!state.freeRecorded?'disabled':'')+'>抽下一题 →</button></div></section>';
  }
  function footerHtml(){return '<details class="sam20-help-details"><summary>不会用？每天这样练 60 分钟</summary><ol><li>10分钟：脱稿复测昨天1题。</li><li>20分钟：今天1～2题，逐句听、跟读、查看需复核词。</li><li>20分钟：把原句连起来说3遍，最后一遍不看稿。</li><li>10分钟：随机换问法、练追问；最多记5个表达缺口。</li></ol><p>“文字匹配分”只反映识别文字与练习稿的一致程度，不是发音标准度，也不是机构口测成绩。绿色是识别匹配；标记词需你回听核对，不能据此断言发音错误。没有识别文字时不显示假分数。</p></details><div class="sam20-secondary">'+(state.view==='lesson'?'<button data-sam-action="legacy">'+(state.lessonLegacy?'收起原14天句子课':'打开原14天句子课（保留旧记录）')+'</button>':'<button data-sam-action="continuous">'+(state.continuous?'收起拓展连续听练':'展开拓展连续听练（非本页短句）')+'</button>')+'</div>';}
  function render(){
    if(!state.data||!q()||!state.root)return;if(state.root.isConnected===false){state.needsRender=true;return;}
    stopSound();disposeRecorder();state.clips={};state.clipCounter=0;state.needsRender=false;
    var item=q();state.root.querySelector('[data-sam-content]').innerHTML=headerHtml(item)+questionHtml(item)+controlsHtml()+(state.view==='lesson'?lessonHtml(item):state.step===3?freeHtml(item):joinedHtml(item))+footerHtml();
    if(state.recorderTarget&&window.SamRecorder){state.recorder=window.SamRecorder.mount(state.root.querySelector('[data-sam-recorder]'),state.recorderTarget);state.lastTarget=state.recorderTarget.id;}
    else if(state.recorderTarget){state.root.querySelector('[data-sam-recorder]').innerHTML=note('录音组件还没有载入，请刷新重试。');}
  }
  function stopSound(message){
    var wasActive=!!(state.audio||state.audioKey||state.audioTimer||state.watchdog);
    state.audioToken++;clearTimeout(state.audioTimer);clearTimeout(state.watchdog);state.audioTimer=state.watchdog=null;
    if(state.audio){var audio=state.audio;audio.onended=audio.onerror=audio.onplaying=audio.onwaiting=audio.onstalled=audio.onpause=null;audio.pause();audio.removeAttribute('src');audio.load();state.audio=null;}
    state.audioKey='';if(state.root)state.root.querySelectorAll('[data-sam-play]').forEach(function(b){b.classList.remove('playing');b.setAttribute('aria-pressed','false');});
    // Also clear the shared recovery-banner state. An idle render must not
    // replace a useful load/recognition error with an unrelated stop message.
    if(wasActive)status(typeof message==='string'?message:'示范音已停止。');
  }
  function staticAudioUrl(src){var url=new URL(src,document.baseURI);if(url.protocol==='https:'||url.protocol==='http:')url.searchParams.set('v',VERSION);return url.href;}
  function playClip(clip,key,button,single){
    if(clip&&hasSlots(clip.text)){status('先补真实信息，不播放占位内容。');return;}
    if(!clip||!clip.src){status('这段示范音暂不可用，请先看文字练习。');return;}
    if(isRecording()){status('请先停止录音，再听示范音。');return;}
    if(state.audio&&state.audioKey===key){stopSound();return;}stopSound();
    window.dispatchEvent(new CustomEvent('gospeak-playback-request',{detail:{owner:'mainline-v20'}}));
    document.querySelectorAll('audio,video').forEach(function(a){if(!a.paused)a.pause();});
    var token=state.audioToken,played=0,limit=single?1:state.loop,audio=state.audioElement||(state.audioElement=new Audio());
    audio.src=staticAudioUrl(clip.src);audio.preload='auto';audio.playbackRate=clip.rate||1;audio.preservesPitch=true;state.audio=audio;state.audioKey=key;
    if(button){button.classList.add('playing');button.setAttribute('aria-pressed','true');}
    function fail(message){if(token!==state.audioToken)return;stopSound();status(message);}
    function watch(){if(token!==state.audioToken)return;clearTimeout(state.watchdog);var from=audio.currentTime||0;state.watchdog=setTimeout(function(){if(token!==state.audioToken)return;if(!audio.paused&&audio.currentTime>from+0.2){state.watchdog=null;return;}fail('播放等待超时，已解除等待。请再点一次，或用顶部“恢复声音”。');},15000);}
    function attempt(){if(token!==state.audioToken)return;watch();try{Promise.resolve(audio.play()).then(function(){if(token!==state.audioToken)return;clearTimeout(state.watchdog);state.watchdog=null;status('正在播放。再次点同一按钮或“停止示范音”可结束。');}).catch(function(){fail('播放未启动，请检查网络和音量后再点一次。');});}catch(_){fail('暂时无法播放，请再试一次。');}}
    audio.onplaying=function(){if(token===state.audioToken){clearTimeout(state.watchdog);state.watchdog=null;}};audio.onwaiting=watch;audio.onstalled=function(){if(audio.readyState<3)watch();};
    audio.onpause=function(){if(token===state.audioToken&&!audio.ended){stopSound();status('示范音已暂停，可重新点读。');}};
    audio.onended=function(){if(token!==state.audioToken)return;played++;clearTimeout(state.watchdog);if(limit===0||played<limit)state.audioTimer=setTimeout(function(){if(token===state.audioToken){audio.currentTime=0;attempt();}},Math.max(1200,(audio.duration||1)*700));else stopSound('这段示范音已播放结束。');};
    audio.onerror=function(){fail('音频加载失败，已停止等待。检查网络后再点一次。');};status('正在加载示范音…再点同一按钮可取消。');attempt();
  }
  function playQuestion(){var item=activeQuestion(q()),key=registerAudio(item.audio,item.en,false);playClip(state.clips[key],key,null,true);}
  function goView(view){if(!safeToChange())return;stopSound();disposeRecorder();state.needsRender=true;var nav=document.querySelector('.app-nav [data-view="'+view+'"]');if(nav){if(nav.classList.contains('active')){state.view=view;render();}else{nav.click();mount();}}else status('请点击顶部“'+(view==='lesson'?'句子课':'SWT口测主线')+'”。');}
  function choose(id){if(!safeToChange())return;state.selected=id;state.line=0;state.chain=99;state.variant=0;state.followup=-1;state.revealed=false;state.freeRecorded=false;persist();render();}
  function handleChange(event){var target=event.target;if(target.matches('[data-sam-question]')){if(safeToChange())choose(target.value);else target.value=state.selected;}if(target.matches('[data-sam-loop]'))state.loop=Number(target.value);}
  function handleClick(event){
    var button=event.target.closest('button');if(!button||!state.root.contains(button)||button.disabled)return;
    if(button.hasAttribute('data-sam-play')){var key=button.getAttribute('data-sam-play');playClip(state.clips[key],key,button,button.hasAttribute('data-single'));return;}
    var action=button.getAttribute('data-sam-action'),value=button.getAttribute('data-value');if(!action)return;
    if(action==='stop'){stopSound();status('示范音已停止。');return;}if(action==='retry'){load();return;}if(!safeToChange())return;
    if(action==='step'){var step=Number(value);state.followup=-1;state.revealed=false;state.freeRecorded=false;if(step===1){goView('lesson');return;}state.step=step;state.chain=99;goView('coach');if(step===3)playQuestion();}
    else if(action==='to-lesson'||action==='learn-line'){state.line=action==='learn-line'?Number(value):state.line;state.followup=-1;goView('lesson');}
    else if(action==='previous'){state.line=Math.max(0,state.line-1);render();}
    else if(action==='next'){if(state.line<answerLines(q()).length-1){state.line++;render();}else{state.step=2;state.chain=99;goView('coach');}}
    else if(action==='chain'){state.chain=Number(value);render();}
    else if(action==='wording'){state.variant=(state.variant+1)%variants(q()).length;state.freeRecorded=false;render();playQuestion();}
    else if(action==='reveal'){state.revealed=!state.revealed;render();}
    else if(action==='base'){state.followup=-1;state.revealed=false;state.freeRecorded=false;render();playQuestion();}
    else if(action==='followup'){var qs=list(q().followups);state.followup=qs.length?(state.followup+1)%qs.length:-1;state.revealed=false;state.freeRecorded=false;render();playQuestion();}
    else if(action==='random'){if(!state.freeRecorded)return;var pool=state.questions.filter(function(item){return answerLines(item).length&&item.id!==state.selected;});if(!pool.length)return;var picked=pool[Math.floor(Math.random()*pool.length)];state.selected=picked.id;state.line=0;state.chain=99;state.variant=Math.floor(Math.random()*variants(picked).length);state.followup=-1;state.revealed=false;state.freeRecorded=false;state.step=3;persist();render();playQuestion();}
    else if(action==='confirm-branch'){var branch=list(q().branches)[Number(value)];if(!branch||hasSlots(text(list(branch.sentences))))return;state.branchChoices[q().id]=branch.id;state.line=0;state.chain=99;render();status('已按你确认的真实情况选句。情况改变时请重新核实。');}
    else if(action==='reset-branch'){delete state.branchChoices[q().id];state.line=0;state.chain=99;state.freeRecorded=false;render();status('已撤回这个选择。请按真实情况重新选择，旧录音仍保留。');}
    else if(action==='legacy'){state.lessonLegacy=!state.lessonLegacy;mount();render();}
    else if(action==='continuous'){state.continuous=!state.continuous;state.root.classList.toggle('sam20-show-continuous',state.continuous);button.textContent=state.continuous?'收起拓展连续听练':'展开拓展连续听练（非本页短句）';if(state.continuous){var player=state.root.querySelector('#swt-listening-v18');if(player)player.scrollIntoView({behavior:'smooth',block:'start'});}else{var media=state.root.querySelector('#swt-listening-v18 audio');if(media)media.pause();}}
  }
  window.addEventListener('sam-recorder-start',stopSound);
  window.addEventListener('gospeak-playback-request',function(event){if(!event.detail||event.detail.owner!=='mainline-v20')stopSound();});
  window.addEventListener('sam-review-word',function(event){var d=event.detail||{};if(!state.recorderTarget||d.targetId!==state.recorderTarget.id)return;var key=registerAudio(d.src,d.word,false);playClip(state.clips[key],key,null,true);});
  window.addEventListener('sam-recorder-saved',function(event){
    var d=event.detail||{},id=String(d.id||d.targetId||''),stamp=d.savedAt||d.createdAt||Date.now();
    if(!id.startsWith('sam-v20:')||Number(d.duration)<=0)return;var unique=id+':'+stamp;if(state.seen[unique])return;state.seen[unique]=true;
    var parts=id.split(':');if(parts[1]==='line'){state.practice[parts.slice(2).join(':')]=(state.practice[parts.slice(2).join(':')]||0)+1;var node=state.root&&state.root.querySelector('[data-line-progress]');if(node&&state.recorderTarget&&state.recorderTarget.id===id)node.textContent='已录 '+state.practice[parts.slice(2).join(':')]+' 次 · 不等于已掌握';}
    if(parts[1]==='answer'||parts[1]==='free')state.counts[parts[2]]=(state.counts[parts[2]]||0)+1;
    if(parts[1]==='free'&&state.recorderTarget&&state.recorderTarget.id===id){state.freeRecorded=true;var next=state.root.querySelector('[data-sam-action="random"]');if(next)next.disabled=false;var hint=state.root.querySelector('[data-free-status]');if(hint)hint.textContent='这题已录音。先回听，再抽下一题；次数不代表答得正确。';}
    persist();
  });
  document.addEventListener('click',function(event){var nav=event.target.closest('[data-view]');if(!nav)return;if(!safeToChange()){event.preventDefault();event.stopImmediatePropagation();return;}stopSound();document.querySelectorAll('audio,video').forEach(function(a){if(!a.paused)a.pause();});disposeRecorder();state.needsRender=true;document.body.classList.remove('sam20-lesson-route','sam20-legacy-route');scheduleMount();},true);
  document.addEventListener('play',function(event){if(event.target!==state.audio)stopSound();},true);
  window.addEventListener('pagehide',function(){stopSound();disposeRecorder();state.needsRender=true;});
  function init(){mount();var app=document.getElementById('app');if(app)new MutationObserver(scheduleMount).observe(app,{childList:true});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
