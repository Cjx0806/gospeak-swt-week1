/* Exercise the same mounted run loop as the course, with an in-memory mic. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{createRequire}=require('node:module');
let setup=fs.readFileSync(path.join(__dirname,'test_mainline_v25.cjs'),'utf8').split('\nt.render();')[0];
setup=setup.replace('q,recordSaved,stopSound','q,recordSaved,stopSound,bootReal,realAction,examProgress,getSession:()=>session');
function run(){
  const male={window:{}};vm.runInNewContext(fs.readFileSync(path.join(site,'assets/male-v30.js'),'utf8'),male);
  const manifest=JSON.parse(fs.readFileSync(path.join(site,'lesson-audio-v22.json'),'utf8'));
  const legacySentences=manifest.sentences.map(s=>s.audio);
  const paths=[...legacySentences,...Object.values(manifest.words),...Object.values(data.lexicon),...data.questions.map(q=>q.questionAudio)];
  for(const r of paths){
    const original=r.src||r.normal;if(!original)continue;
    const converted=male.window.samMaleClip(original);assert(converted.includes('male-v30'),original);
    assert(fs.statSync(path.join(site,converted)).size>500);
  }
  sandbox.clearInterval=()=>{};sandbox.setInterval=()=>1;sandbox.window.confirm=()=>true;
  t.bootReal(data);t.render();assert(html.includes('实录重点')&&html.includes('模拟考场'));
  for(const row of data.real.topics){
    click('real-retrain',row.id);assert.equal(t.state.listeningFocus,true);
    assert(!html.includes(row.question));click('wording');assert.equal(t.state.variant,1);
    click('question-hint');assert(html.includes(row.variants[0].zh));click('answer-start');
    assert.equal(t.state.recorderTarget.expectedText,row.short[0].en);
    click('sentence-index',1);assert.equal(t.state.recorderTarget.expectedText,row.short[1].en);
    click('joined');assert.equal(t.state.recorderTarget.expectedText,row.short.map(s=>s.en).join(' '));
    assert(html.includes('先练两句交界处'));
    const seam=Object.values(t.state.clips).filter(c=>c.text===row.seam);assert.equal(seam.map(c=>c.rate).join(','),'0.78,1');
    assert(row.short[1].en===row.seam.slice(row.seam.indexOf('. ')+2));
    click('real-follow');assert.equal(t.state.recorderTarget.assessmentMode,'free');
    click('real-model');assert(t.state.recorderTarget.expectedText);
  }
  const tokens=s=>s.match(/U\.S\.|[A-Za-z0-9]+(?:[-’'][A-Za-z0-9]+)*/gi)||[];
  for(const [en,n] of Object.entries(data.real.notes)){
    assert.deepEqual(n.words.map(w=>w[0]),tokens(en));
    assert.deepEqual(tokens(n.parts.map(p=>p[1]).join(' ')),tokens(en));
    for(const [w,zh] of n.words){assert(zh);assert(data.lexicon[w.toLowerCase()].src);}
  }
  for(const p of data.real.profiles){
    click('exam-lobby');click('exam-profile',data.real.profiles.indexOf(p));click('exam-start');
    let sess=t.getSession();assert.equal(sess.turns.length,8);assert.equal(sess.turns[0].id,'intro');assert.equal(new Set(sess.turns.map(v=>v.id)).size,8);
    assert(!html.includes('Please introduce yourself.'));click('exam-next');assert.equal(sess.index,0);
    click('exam-repeat');assert.equal(sess.turns[0].repeats,1);
    t.state.recorderTarget.onTake({duration:8,hasAudio:true,transcript:'I like swimming.'});
    assert.equal(sess.turns[0].seconds,8);click('exam-next');assert.equal(sess.index,1);
    while(!sess.end)click('exam-skip');
    assert(html.includes('本场复盘')&&html.includes('1 / 8')&&html.includes('I like swimming.'));
    for(const clip of Object.values(p.audio))assert(fs.statSync(path.join(site,clip.normal)).size>500);
  }
  for(const row of data.real.topics){
    for(const v of [row.questionAudio,row.fullAudio,row.seamAudio,...row.short.map(s=>s.audio),...row.variants.map(v=>v.audio)]){
      assert(fs.statSync(path.join(site,v.normal)).size>500);
    }
    for(const k of row.related)assert(data.real.topics.some(q=>q.id===k));
  }
  console.log('PASS: original lesson and word voice routes; 19 real topics, listening, sentence scoring, boundary practice, joined scoring, related follow-ups; 4 full mock sessions.');
}
vm.runInNewContext(setup+'\n('+run.toString()+')();',{require:createRequire(__filename),__dirname,console,URL});
