"""Route original tap targets to text-matched, prerecorded US male demonstrations."""
import asyncio,json,shutil,hashlib
from real_v30 import SITE, ROOT, VOICE, speech
from build_v21 import synthesize_missing
def build():
    lessons=json.loads((SITE/'lesson-audio-v22.json').read_text())
    data=json.loads((SITE/'interview-v21.json').read_text())
    paths={}
    def add(ref,text):
        if not ref or not text or '[' in text:return
        keys=[ref] if isinstance(ref,str) else [ref.get('src'),ref.get('normal'),ref.get('slow')]
        for key in keys:
            if key:paths[key.removeprefix('./')]=text
    for l in lessons['sentences']:add(l['audio'],l['en'])
    for word,l in lessons['words'].items():add(l,word);add('audio/words/'+word+'.mp3',word)
    for word,l in data['lexicon'].items():add(l,word)
    def walk(row):
        if isinstance(row,list):
            for v in row:walk(v)
        if not isinstance(row,dict):return
        add(row.get('questionAudio'),row.get('question'))
        add(row.get('audio'),row.get('en'))
        lines=row.get('answer') or row.get('short') or row.get('sentences')
        if isinstance(lines,list) and all(isinstance(x,dict) and 'en' in x for x in lines):
            for field in ('fullAudio','answerAudio'):add(row.get(field),' '.join(x['en'] for x in lines))
            for i,clip in enumerate(row.get('cumulativeAudio') or []):add(clip,' '.join(x['en'] for x in lines[:i+1]))
        for v in row.values():
            if isinstance(v,(dict,list)):walk(v)
    walk(data['questions']);walk(data['rescuePhrases']);walk(data['knownIntro'])
    clips={p:speech(t.replace('SWT','S W T'),VOICE) for p,t in paths.items()}
    recordings=asyncio.run(synthesize_missing(set(clips.values())))
    dest=SITE/'audio/male-v30';dest.mkdir(parents=True,exist_ok=True)
    bindings={}
    for old,clip in clips.items():
        path=recordings[clip];name=path.stem+'.mp3'
        if not (dest/name).exists():shutil.copyfile(path,dest/name)
        bindings[old]='./audio/male-v30/'+name
    (SITE/'assets/male-v30.js').write_text('/* American English · Guy Neural */\n(()=>{const clips='+json.dumps(bindings,separators=(',',':'))+";window.samMaleClip=(src)=>typeof src==='string'?(clips[src.replace(/^\\.\\//,'')]||src):src;})();")
    (ROOT/'tmp/male-bindings-v30.json').write_text(json.dumps(paths,ensure_ascii=False))
    print('Male audio',len(paths),'bindings',len(recordings),'unique clips')
if __name__=='__main__':build()
