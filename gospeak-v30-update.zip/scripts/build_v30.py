"""Assemble V30 from the verified V29 release and the recorded course files."""
import hashlib,json,re,shutil
from zipfile import ZipFile,ZIP_DEFLATED
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'_site'
def sub(src,old,new):
    if src.count(old)!=1:raise ValueError(old)
    return src.replace(old,new)
def mainline(src):
    src=sub(src,"state.data=data;state.questions=data.questions;var available=", "state.data=data;state.questions=data.questions;bootReal(data);var available=")
    src=sub(src,"function practiceQuestions(){","function practiceQuestions(){\n    if(state.practiceScope==='real')return realData().topics;")
    src=sub(src,"function body25(item){","function body25(item){\n    if(realData()){if(room==='lobby')return top30()+examLobby();if(room==='exam')return top30()+examView();if(state.practiceScope==='real')return top30()+realStudyView(item);}")
    src=sub(src,"return header25(item)+'<div class=\"sam25-panel", "return (realData()?top30():'')+header25(item)+'<div class=\"sam25-panel")
    src=sub(src,"if(['stage','answer-start'", "if(realData()&&realAction(action,value))return;\n    if(['stage','answer-start'")
    src=sub(src,"function handleChange(event){var target=event.target;", "function handleChange(event){var target=event.target;if(target.matches('[data-real-topic]')){if(safeToChange())chooseReal(target.value);else target.value=state.selected;return;}")
    src=sub(src,"function staticAudioUrl(src){var url=new URL(src,", "function staticAudioUrl(src){var url=new URL(window.samMaleClip?window.samMaleClip(src):src,")
    src=sub(src,"  function render(preserveRecorder)", (ROOT/'assets/real-room-v30.js').read_text()+"\n  function render(preserveRecorder)")
    src=sub(src,"  window.addEventListener('sam-recorder-saved',recordSaved);","  window.addEventListener('sam-recorder-saved',examProgress);\n  window.addEventListener('sam-recognition-complete',examProgress);\n  window.addEventListener('sam-recorder-saved',recordSaved);")
    src=sub(src,"    var previousRecorder=preserveRecorder", "    if(!preserveRecorder)clearReplay();\n    var previousRecorder=preserveRecorder")
    src=sub(src,"  if(document.readyState==='loading')", """  if(typeof location!=='undefined'&&['#exam','#practice'].includes(location.hash)){
    const openRoute=()=>{const nav=document.querySelector('.app-nav [data-view="coach"]');if(nav){if(!nav.classList.contains('active'))nav.click();return true;}return false;};
    if(!openRoute())document.addEventListener('DOMContentLoaded',openRoute,{once:true});
  }
  if(document.readyState==='loading')""")
    return src.replace('course=29','course=30')
def build():
    with ZipFile(ROOT/'gospeak-v29-update.zip') as z:
        prev=lambda fn:z.read('_site/'+fn).decode()
        html=prev('index.html').replace('V29 ·','V30 ·').replace('design=29','design=30').replace('index-C6MAz4Oq.js?v=22','index-C6MAz4Oq.js?v=22&voice=30').replace('recorder-v19.js?v=22&design=28','recorder-v19.js?v=22&design=30')
        html=html.replace('</head>','<link rel="stylesheet" href="./assets/real-v30.css?v=22">\n<script src="./assets/male-v30.js?v=22"></script>\n</head>')
        data=json.loads(prev('interview-v21.json'));data['real']=json.loads((SITE/'real-v30.json').read_text());(SITE/'interview-v21.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
        (SITE/'index.html').write_text(html);(SITE/'assets/mainline-v21.js').write_text(mainline(prev('assets/mainline-v21.js')))
        sw=prev('sw.js').replace("set('design','29')","set('design','30')").replace("set('course','29')","set('course','30')").replace("if(u.pathname.endsWith('/interview-v21.json'))","if(u.pathname.endsWith('/recorder-v19.js'))u.searchParams.set('design','30'); if(u.pathname.endsWith('/interview-v21.json'))")
        sw=sw.replace('// V19_VERSIONED_CACHE',"core.push(...['assets/male-v30.js','assets/real-v30.css'].map(p=>new URL(p,BASE).href));\n// V19_VERSIONED_CACHE")
    (SITE/'assets/recorder-v19.js').write_text(recorder((ROOT/'assets/recorder-v28.js').read_text()))
    legacy=SITE/'assets/index-C6MAz4Oq.js';src=legacy.read_text()
    if 'Audio(Me(window.samMaleClip?' not in src:legacy.write_text(sub(src,'new Audio(Me(path))','new Audio(Me(window.samMaleClip?window.samMaleClip(path):path))'))
    shutil.copyfile(ROOT/'assets/real-v30.css',SITE/'assets/real-v30.css')
    digest=hashlib.sha256((SITE/'interview-v21.json').read_bytes()+(SITE/'assets/mainline-v21.js').read_bytes()+(SITE/'assets/male-v30.js').read_bytes()+(SITE/'assets/recorder-v19.js').read_bytes()).hexdigest()[:12]
    (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,sw))
    paths=['_site/'+f for f in ['index.html','sw.js','assets/mainline-v21.js','assets/recorder-v19.js','assets/index-C6MAz4Oq.js','assets/male-v30.js','assets/real-v30.css','interview-v21.json']]
    paths+=['assets/'+f for f in ['real-room-v30.js','real-v30.txt','real-vocab-v30.txt','real-v30.css']]
    paths+=['scripts/'+f for f in ['build_v30.py','real_v30.py','male_v30.py','verify_v22.py','test_real_v30.cjs']]
    assets=json.dumps(data['real'],ensure_ascii=False)
    paths+=[str(p.relative_to(ROOT)) for p in (SITE/'audio/real-v30').glob('*.mp3') if p.name in assets]
    paths+=[str(p.relative_to(ROOT)) for p in (SITE/'audio/male-v30').glob('*.mp3')]
    with ZipFile(ROOT/'gospeak-v30-update.zip','w',ZIP_DEFLATED) as z:
        for path in paths:z.write(ROOT/path,path)
    print('V30 ZIP:',(ROOT/'gospeak-v30-update.zip').stat().st_size)
def recorder(src):
    src=sub(src,'root.SamRecorder = { mount: mount,','root.SamRecorder = { latestAudio: async function(id){ var rows=await allRecords(); var row=rows.find(function(r){return r.targetId===id && r.blob;}); return row?row.blob:null; }, mount: mount,')
    return sub(src,'// Show the current take before waiting on IndexedDB.',"""if (typeof snapshot.onTake === 'function') {
          snapshot.onTake({transcript:record.transcriptSource==='browser-final'?record.transcript:'', duration:duration, hasAudio:hasAudio});
        }
        // Show the current take before waiting on IndexedDB.""")
if __name__=='__main__':build()
