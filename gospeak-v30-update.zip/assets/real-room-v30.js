  const examKey='sam-v30-exam';
  let room=(typeof location!=='undefined'&&location.hash==='#exam')?'lobby':'study', session=null, examiner=0, follow=null, reveal=false, model=false, clockTimer;
  try {session=JSON.parse(localStorage.getItem(examKey)||'null');} catch (_) {}
  function saveExam(){try{localStorage.setItem(examKey,JSON.stringify(session));}catch(_){}}
  function realData(){return state.data&&state.data.real;}
  function realTopic(id){return realData().topics.find(t=>t.id===id);}
  function pick(items){return items[Math.floor(Math.random()*items.length)];}
  let replayUrl=null;
  function clearReplay(){
    if(replayUrl){URL.revokeObjectURL(replayUrl);replayUrl=null;}
  }
  async function replayExam(index){
    const target=examTarget(index),host=state.root.querySelector('[data-review-player]');
    if(!host)return;
    try{
      const file=await window.SamRecorder.latestAudio(target);
      if(!host.isConnected)return;
      clearReplay();
      if(!file){host.textContent='这条录音已不在本机历史中。';return;}
      replayUrl=URL.createObjectURL(file);host.innerHTML='<audio controls playsinline></audio>';
      const player=host.querySelector('audio');player.src=replayUrl;player.play().catch(()=>{});
    }catch(_){status('暂时无法读取本机录音。');}
  }
  function bootReal(data){
    if(!data.real)return;
    Object.assign(data.lexicon,data.real.lexicon);
    Object.assign(data.languageNotes,data.real.notes);
    state.questions=data.questions.concat(data.real.topics);
    state.practiceScope='real';
    let last;try{last=localStorage.getItem('sam-real-topic');}catch(_){}
    state.selected=realTopic(last)?last:'r30-grad';
    if(!session||!Array.isArray(session.turns)||!session.turns.length||
       !data.real.profiles[session.profile]||!session.turns.every(t=>t.id==='intro'||realTopic(t.id)))session=null;
  }
  function btn(action,label,value,cls){
    return '<button type="button" data-sam-action="'+action+'"'+(value==null?'':' data-value="'+esc(value)+'"')+' class="'+(cls||'')+'">'+esc(label)+'</button>';
  }
  function top30(){
    const exam=room==='exam'||room==='lobby', study=state.practiceScope==='real'&&!exam;
    return '<nav class="r30-nav" aria-label="SWT训练入口">'+
      btn('real-study','实录重点',null,study?'current':'')+
      btn('exam-lobby','模拟考场',null,exam?'current':'')+
      btn('real-library','基础题库',null,!study&&!exam?'current':'')+'</nav>';
  }
  function loopTools(clip,en){
    return '<div class="sam25-play">'+playButton(clip,en,true,'慢速循环')+
      playButton(clip,en,false,'正常循环')+btn('stop','停止')+'</div>';
  }
  function chooseReal(id){
    const item=realTopic(id);if(!item)return;
    room='study';follow=null;model=false;reveal=false;state.practiceScope='real';state.mode='prepare';
    state.selected=id;state.round=1;resetPrompt();state.scrollLearning=true;
    try{localStorage.setItem('sam-real-topic',id);}catch(_){}render();
  }
  function realHeader(item){
    const step=follow?4:stage25();
    return '<header class="r30-header"><h1>实录重点</h1><label>换题<select data-real-topic>'+
      realData().topics.map(row=>'<option value="'+row.id+'" '+(row.id===item.id?'selected':'')+'>'+esc(row.title)+'</option>').join('')+
      '</select></label></header><nav class="sam25-steps r30-steps" aria-label="实录训练步骤">'+
      ['听懂问法','一句一句学','两句连读','随机追问'].map((name,i)=>
        '<button data-sam-action="real-step" data-value="'+(i+1)+'" aria-current="'+(i+1===step?'step':'false')+'">'+(i+1)+' · '+name+'</button>').join('')+'</nav>';
  }
  function bridge30(item){
    const tail=item.seam.split('. ')[0]+'.';
    return '<section class="r30-bridge"><h3>先练两句交界处</h3><p>'+esc(item.bridge)+'</p>'+
      '<div class="r30-join" lang="en"><span>'+esc(tail)+'</span><b aria-label="停一拍"> / </b><span>'+esc(item.short[1].en)+'</span></div>'+
      loopTools(item.seamAudio,item.seam)+'<p class="r30-hint">斜线处短停。顺了以后，把第一句从头补回来。</p></section>';
  }
  function questionOnly(v,audio,shown){
    return '<div class="sam21-question"><h2>'+ (shown?esc(v.en):'听考官提问')+'</h2>'+
      (shown?'<p>'+esc(v.zh)+'</p>':'')+loopTools(audio,v.en)+btn('real-reveal',shown?'收起文字':'显示问句与中文')+'</div>';
  }
  function startFollow(){
    const pool=q().related.filter(id=>!follow||id!==follow.id);
    const dest=realTopic(pick(pool.length?pool:q().related));
    follow={id:dest.id,variant:Math.floor(Math.random()*variants(dest).length)};
    reveal=false;model=false;render();speakOnce(variants(dest)[follow.variant]);
  }
  function speakOnce(v){
    const key=registerAudio(v.audio,v.en,false);playClip(state.clips[key],key,null,true);
  }
  function recordingTarget(id,expected,title){
    state.recorderTarget={id,expectedText:expected,kind:'answer',assessmentMode:expected?'scripted':'free',
      title,lexicon:state.data.lexicon,onStart:stopSound};
    if(room==='exam'&&session&&!session.end){
      const activeId=session.start,index=session.index;
      state.recorderTarget.onTake=function(take){
        if(!session||session.start!==activeId||session.index!==index||session.end||!(take.transcript||take.hasAudio))return;
        const turn=session.turns[index];
        turn.seconds=Math.max(1,Math.round(take.duration));turn.heard=String(take.transcript||'').slice(0,1200);
        saveExam();const hint=state.root.querySelector('[data-exam-note]');
        if(hint)hint.textContent='已收到回答，可以进入下一题。';
      };
    }
    return '<div data-sam-recorder></div>';
  }
  function followScreen(){
    const row=realTopic(follow.id),v=variants(row)[follow.variant];
    const textAll=text(row.short);
    return questionOnly(v,v.audio,reveal)+
      (model?'<div class="r30-ref">'+row.short.map(s=>'<p><b lang="en">'+esc(s.en)+'</b><br>'+esc(s.zh)+'</p>').join('')+loopTools(row.fullAudio,textAll)+'</div>':'')+
      btn('real-model',model?'回到脱稿回答':'看参考回答并跟读评分')+
      recordingTarget('sam-v25:follow:'+row.id+':'+(model?'read':'free'),model?textAll:'','随机追问')+
      '<div class="r30-actions">'+btn('real-retrain','这题逐句练',row.id)+btn('real-follow','再听一道追问',null,'r30-primary')+'</div>';
  }
  function realStudyView(item){
    let content;const stage=stage25();
    if(follow)content=followScreen();
    else if(stage===1){
      state.recorderTarget=null;
      content=questionHtml(item)+(state.questionRevealed?'<p class="r30-hint">'+esc(item.cue)+'</p>':'')+listening25(item);
    }else if(stage===2)content=sentence25(item);
    else{
      const guided=state.round===1||state.help;
      content=rounds25()+(guided?bridge30(item):'')+answer25(item)+joinedRecorder25(item)+
        '<div class="r30-actions">'+btn('real-follow','练好了，听随机追问 →',null,'r30-primary')+'</div>';
    }
    return realHeader(item)+'<div class="sam25-panel" data-stage="'+(follow?4:stage)+'">'+content+'</div>';
  }

  function examLobby(){
    state.recorderTarget=null;
    return '<section class="r30-room"><header><h1>模拟考场</h1><p>约 10–15 分钟 · 自我介绍 + 7 轮问答</p></header>'+
      '<p>每题先听英文，再开麦。没听清可以说 <strong lang="en">Could you say that again, please?</strong>（能再说一遍吗？），再点「请再说一遍」。交卷后看中文和回练建议。</p>'+
      (session&&!session.end?btn('exam-resume','继续上次考试 · 第 '+(session.index+1)+' 题',null,'r30-primary')
        :session?btn('exam-resume','看上次复盘'): '')+
      '<h3>选一位模拟考官</h3><div class="r30-profiles">'+realData().profiles.map((p,i)=>
        '<button data-sam-action="exam-profile" data-value="'+i+'" aria-pressed="'+(i===examiner)+'"><b>'+esc(p.name)+'</b><small>'+esc(p.style)+'</small></button>').join('')+'</div>'+
      btn('exam-start',session&&!session.end?'另开一场':'开始考试',null,'r30-primary')+
      '<p class="r30-hint">四种合成男声，按话题抽问。同一考官也会换问法。</p></section>';
  }
  function makeSession(profileIndex){
    const p=realData().profiles[profileIndex],remaining=p.route.slice(),order=[];
    // Open with a focus question, then draw a related follow-up when one is available.
    while(remaining.length){
      const last=order.length?realTopic(order[order.length-1]):null;
      const linked=last?remaining.filter(id=>last.related.includes(id)):[];
      const id=order.length?pick(linked.length?linked:remaining):pick(remaining.slice(0,2));
      remaining.splice(remaining.indexOf(id),1);order.push(id);
    }
    return {profile:profileIndex,start:Date.now(),index:0,turns:[{id:'intro',variant:0}].concat(
      order.map(id=>({id,variant:Math.floor(Math.random()*variants(realTopic(id)).length)})))};
  }
  function examQuestion(turn){
    if(turn.id==='intro')return {en:'Please introduce yourself.',zh:'请介绍一下你自己。'};
    return variants(realTopic(turn.id))[turn.variant];
  }
  function askExam(){
    const turn=session.turns[session.index],v=examQuestion(turn);
    speakOnce({en:v.en,audio:realData().profiles[session.profile].audio[v.en]});
  }
  function elapsed(){const seconds=Math.floor(((session.end||Date.now())-session.start)/1000);
    return Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0');}
  function examView(){
    clearInterval(clockTimer);clockTimer=null;
    if(session.end)return examReport();
    const turn=session.turns[session.index],profile=realData().profiles[session.profile];
    const v=examQuestion(turn),clip=profile.audio[v.en];
    clockTimer=setInterval(()=>{const node=state.root&&state.root.querySelector('[data-exam-clock]');
      if(node&&node.isConnected)node.textContent=elapsed();else clearInterval(clockTimer);},1000);
    return '<article class="r30-room"><header><small>模拟考官 · '+esc(profile.name)+'</small><h1>第 '+(session.index+1)+' / '+session.turns.length+' 题</h1>'+
      '<p>已用 <time data-exam-clock>'+elapsed()+'</time></p></header>'+
      '<h3>听完问题，再开口</h3><div class="r30-actions">'+btn('exam-repeat','请再说一遍')+'</div>'+loopTools(clip,v.en)+
      recordingTarget(examTarget(session.index),'','本场脱稿回答')+
      '<p data-exam-note role="status">'+(turn.seconds?'已收到这题的回答。':'说完请点录音组件里的「完成回答」。')+'</p><div class="r30-actions">'+
      btn('exam-next',session.index===session.turns.length-1?'交卷并复盘':'下一题 →',null,'r30-primary')+
      btn('exam-skip','跳过本题')+btn('exam-finish','提前交卷')+'</div></article>';
  }
  function examTarget(index){return 'sam-v25:exam:'+session.start+':'+index;}
  function examProgress(event){
    if(!session||session.end||room!=='exam')return;
    const d=event.detail||{};
    if(d.id!==examTarget(session.index)||!(d.duration>0))return;
    const turn=session.turns[session.index];turn.seconds=Math.max(1,Math.round(d.duration));
    if(d.bytes)turn.saved=true;
    saveExam();const node=state.root.querySelector('[data-exam-note]');if(node)node.textContent='已收到回答，可以进入下一题。';
  }
  function examReport(){
    state.recorderTarget=null;
    const done=session.turns.filter(t=>t.seconds).length;
    const rows=session.turns.map((turn,i)=>{
      const v=examQuestion(turn),row=realTopic(turn.id);
      return '<li><div><b>'+esc(v.en)+'</b><small>'+esc(v.zh)+'</small><span>'+
        (turn.seconds?'已答 '+turn.seconds+' 秒':turn.skip?'已跳过':'未作答')+(turn.repeats?' · 重听 '+turn.repeats+' 次':'')+
        '</span>'+(turn.heard?'<details><summary>本次识别文字</summary><p lang="en">'+esc(turn.heard)+'</p></details>':'')+'</div>'+'<div>'+(turn.saved?btn('exam-replay','回听',i):'')+(row?btn('real-retrain','回练',row.id):'')+'</div></li>';}).join('');
    const weakest=session.turns.find(t=>t.id!=='intro'&&!t.seconds)||
      session.turns.filter(t=>t.id!=='intro').sort((a,b)=>(b.repeats||0)-(a.repeats||0))[0];
    return '<section class="r30-room"><header><h1>本场复盘</h1><p>'+done+' / '+session.turns.length+' 题有回答 · 用时 '+elapsed()+'</p></header>'+
      (weakest?'<p>先回练「'+esc(realTopic(weakest.id).title)+'」'+(!weakest.seconds?'，这题还没有录下回答。':weakest.repeats?'，这题重听了 '+weakest.repeats+' 次。':'，试试换一种问法再答。')+'</p>':'')+
      '<div data-review-player aria-live="polite"></div><ol class="r30-results">'+rows+'</ol>'+btn('exam-lobby','回到考场入口')+'</section>';
  }
  function showNext(skip){
    const turn=session.turns[session.index];
    if(!skip&&!turn.seconds){status('先录下回答，或点「跳过本题」。');return;}
    if(skip&&!turn.seconds)turn.skip=true;
    if(session.index===session.turns.length-1)session.end=Date.now();else {
      // When transcription is available, prefer a related unused question.
      const cues=[['r30-swim',/swim|lifeguard/i],['r30-sales',/phone|sales/i],['r30-alone',/alone|my own/i],
        ['r30-trip',/travel|Korea|Indonesia/i],['r30-grad',/college|student/i],['r30-visit',/New York/i]];
      const unused=session.turns.slice(session.index+1), match=cues.find(([id,re])=>re.test(turn.heard||'')&&unused.some(x=>x.id===id));
      if(match){const next=session.turns.findIndex((x,i)=>i>session.index&&x.id===match[0]);[session.turns[session.index+1],session.turns[next]]=[session.turns[next],session.turns[session.index+1]];}
      session.index++;
    }
    saveExam();render();if(!session.end)askExam();
  }
  function realAction(action,value){
    if(action==='real-study'){if(state.practiceScope==='real')chooseReal(q().id);else chooseReal('r30-grad');}
    else if(action==='real-retrain')chooseReal(value);
    else if(action==='real-library'){room='study';follow=null;state.mode='prepare';setPracticeScope('core');render();}
    else if(action==='real-step'){
      if(value==='4'){startFollow();return true;}follow=null;state.mode='prepare';state.round=1;state.help=false;state.recorded=false;
      state.listeningFocus=value==='1';state.sentenceMode=value!=='3';render();
    }else if(action==='real-follow')startFollow();
    else if(action==='real-reveal'){reveal=!reveal;render(true);}
    else if(action==='real-model'){model=!model;render();}
    else if(action==='exam-lobby'){room='lobby';clearInterval(clockTimer);render();}
    else if(action==='exam-profile'){examiner=Number(value);render();}
    else if(action==='exam-start'){
      if(session&&!session.end&&!window.confirm('另开一场会替换当前考试进度。继续吗？'))return true;
      session=makeSession(examiner);room='exam';saveExam();render();askExam();
    }else if(action==='exam-resume'){room='exam';render();if(!session.end)askExam();}
    else if(action==='exam-replay'){replayExam(Number(value));}
    else if(action==='exam-repeat'){session.turns[session.index].repeats=(session.turns[session.index].repeats||0)+1;saveExam();askExam();}
    else if(action==='exam-next')showNext(false);
    else if(action==='exam-skip')showNext(true);
    else if(action==='exam-finish'){if(window.confirm('现在交卷？未回答的题会列入复盘。')){session.end=Date.now();saveExam();render();}}
    else return false;
    return true;
  }
