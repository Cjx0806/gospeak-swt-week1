import re
import shutil
import sys
from pathlib import Path


def replace_once(text, original, replacement):
    if text.count(original) != 1:
        raise ValueError(f"Expected one build anchor: {original}")
    return text.replace(original, replacement, 1)


site = Path(sys.argv[1])
page_name = "swt-employer-10day.html"
home = site / "index.html"
mainline = site / "assets/mainline-v21.js"
worker = site / "sw.js"
destination = site / page_name
shutil.copyfile(Path("employer-sprint") / page_name, destination)
page = destination.read_text()
if 'id="word-audio-data">{"word-' not in page or 'id="start-exam"' not in page:
    raise ValueError("Sprint page is missing its embedded audio or exam controls")

link = f'<a href="./{page_name}">雇主面试 · 10 天冲刺</a>'
text = home.read_text()
if link not in text:
    entry = (
        '<aside aria-label="雇主面试训练" style="max-width:1200px;margin:8px auto;'
        'padding:0 16px"><span style="display:block;padding:5px 12px;background:#e9effb;'
        'border-radius:10px"><a href="./swt-employer-10day.html" style="display:inline-flex;'
        'min-height:44px;align-items:center;color:#193ba4;font-weight:700">雇主面试 · 10 天冲刺</a>'
        '</span></aside>'
    )
    if f'href="./{page_name}"' not in text:
        text = replace_once(text, '<div id="app"></div>', entry + '\n    <div id="app"></div>')
    # Give browsers a fresh URL for the changed training view.
text, count = re.subn(
    r'(assets/mainline-v21\.js\?[^"]+?)(?=")',
    lambda match: re.sub(r"&sprint=\d+", "", match[0]) + "&sprint=3",
    text,
)
if count != 1:
    raise ValueError("Mainline script tag changed")
home.write_text(text)

text = mainline.read_text()
if link not in text:
    updated = replace_once(
        text, "return realHeader(item)+",
        f"""return realHeader(item)+'<p class="r30-actions">{link}</p>'+""",
    )
    mainline.write_text(updated)

text = worker.read_text()
text, count = re.subn(
    r"(const VERSION = '[^']+)';",
    lambda match: re.sub(r"-sprint\d+$", "", match[1]) + "-sprint3';",
    text, count=1,
)
if count != 1:
    raise ValueError("Service worker version anchor changed")
if page_name not in text:
    text = replace_once(
        text, "['echo-review.html','echo-exam.html']",
        f"['echo-review.html','echo-exam.html','{page_name}']",
    )
worker.write_text(text)
