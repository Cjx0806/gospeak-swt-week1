const assert = require('node:assert/strict');
const { webkit, devices } = require('playwright');

async function verify() {
  const browser = await webkit.launch();
  try {
    const page = await browser.newPage(devices['iPad (gen 7)']);
    const base = new URL(process.argv[2]);
    const url = new URL('./?sprint=2', base);
    await page.goto(url.href);
    const sprintLink = page.getByRole('link', { name: '雇主面试 · 10 天冲刺', exact: true }).first();
    await Promise.all([
      page.waitForURL('**/swt-employer-10day.html', { waitUntil: 'domcontentloaded' }),
      sprintLink.tap(),
    ]);
    const control = name => page.getByRole('button', { name, exact: true });
    assert.equal(await page.locator('#days button').count(), 10);
    await control('慢速').tap();
    await control('播放考官问句').tap();
    await page.waitForFunction(() => player.playbackRate < 1 && player.currentTime > 0);
    await control('停止').tap();
    assert.ok(await page.evaluate(() => player.paused));
    await control('看参考回答').tap();
    assert.equal(await page.locator('#sentences .sentence').count(), 3);
    const questionWord = page.locator('#question').getByRole('button', { name: 'lifeguard', exact: true });
    const audioIsWord = value => page.waitForFunction(
      key => player.currentTime > 0 && player.src === 'data:audio/mpeg;base64,' + clips['word-' + key],
      value,
    );
    await questionWord.tap();
    await audioIsWord('lifeguard');
    await page.locator('#sentences').getByRole('button', { name: 'swimmers', exact: true }).tap();
    await audioIsWord('swimmers');
    await control('听第 1 句').tap();
    await page.waitForFunction(() => player.currentTime > 0);
    await control('开始随机模拟').tap();
    const visited = [];
    for (let index = 0; index < 7; index++) {
      assert.equal(await page.locator('#question').textContent(), '先听考官怎么问');
      assert.equal(await page.locator('#question .word-audio').count(), 0);
      const key = await page.evaluate(() => currentKey());
      visited.push(key);
      await control('答完 · 看参考并自评').tap();
      await control(key === 'run' ? '偏题或没答 · 0 分' : '答准 · 2 分').tap();
    }
    assert.ok(visited.includes('rescue') && visited.includes('run'));
    await page.getByRole('heading', { name: '本轮自评 8.6 / 10' }).waitFor();
    assert.match(await page.locator('#results').innerText(), /小孩在池边跑/);
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    console.log('PASS employer sprint: site entry, iPad word and sentence audio, blind questions and mock feedback');
  } finally {
    await browser.close();
  }
}

verify().catch(error => { console.error(error); process.exitCode = 1; });
