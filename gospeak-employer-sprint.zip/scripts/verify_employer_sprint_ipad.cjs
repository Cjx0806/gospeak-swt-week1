const assert = require('node:assert/strict');
const { webkit, devices } = require('playwright');

async function verify() {
  const browser = await webkit.launch();
  try {
    const page = await browser.newPage(devices['iPad (gen 7)']);
    await page.addInitScript(() => {
      window.SpeechRecognition = class {
        start() { this.onstart?.(); }
        stop() {
          if (window.sprintTranscript) {
            const result = [{ transcript:window.sprintTranscript }];
            result.isFinal = true;
            this.onresult?.({results:[result]});
          }
          this.onend?.();
        }
        abort() {}
      };
    });
    const base = new URL(process.argv[2]);
    const url = new URL('./?sprint=4', base);
    await page.goto(url.href);
    const sprintLink = page.getByRole('link', { name: '雇主面试 · 10 天冲刺', exact: true }).first();
    await Promise.all([
      page.waitForURL('**/swt-employer-10day.html', { waitUntil: 'domcontentloaded' }),
      sprintLink.tap(),
    ]);
    const control = name => page.getByRole('button', { name, exact: true });
    assert.equal(await page.locator('#days button').count(), 10);
    const previous = control('上一题');
    const next = control('下一题');
    assert.equal(await previous.isEnabled(), false);
    await next.tap();
    assert.equal(await page.locator('#drill-progress').textContent(), '2 / 4');
    await previous.tap();
    assert.equal(await page.locator('#drill-progress').textContent(), '1 / 4');
    for (let index = 0; index < 3; index++) await next.tap();
    assert.equal(await next.isEnabled(), false);
    await control('开始今日训练').tap();
    await control('慢速').tap();
    await control('播放考官问句').tap();
    await page.waitForFunction(() => player.playbackRate < 1 && player.currentTime > 0);
    await control('停止').tap();
    assert.ok(await page.evaluate(() => player.paused));
    await control('看参考回答').tap();
    assert.equal(await page.locator('#sentences .sentence').count(), 3);
    const questionWord = page.locator('#question').getByRole('button', { name: 'lifeguard', exact: true });
    const audioIsWord = value => page.waitForFunction(
      key => player.currentTime > 0 && player.src === 'data:audio/mpeg;base64,' + clips['word-' + key],
      value,
    );
    await questionWord.tap();
    await audioIsWord('lifeguard');
    await page.locator('#sentences').getByRole('button', { name: 'swimmers', exact: true }).tap();
    await audioIsWord('swimmers');
    await control('听第 1 句').tap();
    await page.waitForFunction(() => player.currentTime > 0);
    await page.evaluate(() => { window.sprintTranscript = 'I watch the swimmers and look for anger'; });
    await control('第 1 句跟读评分').tap();
    await control('说完评分').tap();
    const firstFeedback = page.locator('#sentences .score-feedback').first();
    assert.match(await firstFeedback.innerText(), /跟读匹配 88 \/ 100/);
    assert.match(await firstFeedback.innerText(), /识别成别的词 · danger → anger/);
    await firstFeedback.getByRole('button', { name:'danger', exact:true }).tap();
    await audioIsWord('danger');
    await page.evaluate(() => { window.sprintTranscript = ''; });
    await control('第 1 句跟读评分').tap();
    await control('说完评分').tap();
    assert.match(await firstFeedback.innerText(), /没有得到完整转写/);
    assert.doesNotMatch(await firstFeedback.innerText(), /\/ 100/);
    await control('开始随机模拟').tap();
    assert.equal(await previous.isVisible(), false);
    const visited = [];
    for (let index = 0; index < 7; index++) {
      assert.equal(await page.locator('#question').textContent(), '先听考官怎么问');
      assert.equal(await page.locator('#question .word-audio').count(), 0);
      const key = await page.evaluate(() => currentKey());
      visited.push(key);
      if (key === 'intro') {
        await page.evaluate(() => { window.sprintTranscript = "My name is Felix. I'm a student."; });
        await control('识别回答并评分').tap();
        await control('说完评分').tap();
        assert.match(await page.locator('#exam-feedback').innerText(), /本题要点分 2 \/ 2/);
        await control('采用识别分 · 下一题').tap();
      } else {
        await control('答完 · 看参考并自评').tap();
        await control(key === 'run' ? '偏题或没答 · 0 分' : '答准 · 2 分').tap();
      }
    }
    assert.ok(visited.includes('rescue') && visited.includes('run'));
    await page.getByRole('heading', { name: '本轮训练分 8.6 / 10' }).waitFor();
    assert.match(await page.locator('#results').innerText(), /小孩在池边跑/);
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    console.log('PASS employer sprint: navigation, iPad word audio, reading feedback and mock scoring');
  } finally {
    await browser.close();
  }
}

verify().catch(error => { console.error(error); process.exitCode = 1; });
