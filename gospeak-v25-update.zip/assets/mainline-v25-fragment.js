  /* V25_SENTENCE_FIRST: one question, one visible learning step, one recording target. */
  function stage25(){return state.mode==='mock'?0:state.listeningFocus?1:state.sentenceMode?2:3;}
  function header25(item){
    var stage=stage25();
    return '<header class="sam25-header"><div><p>快乐出村计划 / SWT</p><h1>听懂，再开口。</h1></div><button data-sam-action="'+(stage===0?'mode':'after-intro')+'" data-value="prepare">'+(stage===0?'回到学习':'随机口测 ↗')+'</button></header>'+
      '<details class="sam25-picker"><summary>换一题 · '+(stage===0?'随机口测':esc(item.title))+'</summary><label>选择练习题<select data-sam-question>'+practiceQuestions().map(function(row){return '<option value="'+esc(row.id)+'" '+(row.id===state.selected?'selected':'')+'>'+esc(row.title)+'</option>';}).join('')+'</select></label><button data-sam-action="'+(state.practiceScope==='core'?'scope-more':'scope-core')+'">'+(state.practiceScope==='core'?'更多题目（选练）':'返回8类基础题')+'</button></details>'+
      (stage===0?'<div class="sam25-mock-label">模拟口测 · 听完问题，再自己回答</div>':'<nav class="sam25-steps" aria-label="口测学习步骤">'+[[1,'听懂问题'],[2,'一句一句学'],[3,'连起来说']].map(function(row){return '<button data-sam-action="stage" data-value="'+row[0]+'" data-step="'+row[0]+'" aria-current="'+(stage===row[0]?'step':'false')+'"><b>0'+row[0]+'</b><span>'+row[1]+'</span></button>';}).join('')+'</nav>');
  }
  function listening25(item){
    var options=listeningOptions(item),choice=state.listeningChoice===null?null:options[state.listeningChoice];
    var question=activeQuestion(item),clues=state.questionRevealed&&state.followup<0?list(item.listeningClues).filter(function(c){return c.audio&&question.en.toLowerCase().includes(c.en.toLowerCase());}).slice(0,2):[];
    return '<section class="sam25-listen"><h3>听完，选出考官的意思</h3><div class="sam22-meaning-options">'+options.map(function(option,index){return '<button data-sam-action="meaning" data-value="'+index+'" aria-pressed="'+(state.listeningChoice===index)+'">'+esc(option.zh)+'</button>';}).join('')+'</div>'+(choice?'<p role="status">'+(choice.correct?'✓ 选对了，可以开始学回答。':'再听一次，或点“显示题目”看中文。')+'</p>':'')+(clues.length?'<div class="sam25-clues">'+clues.map(function(c){return playButton(c.audio,c.en,true,c.en+' · '+c.zh,true);}).join('')+'</div>':'')+'<button class="sam25-next" data-sam-action="answer-start">开始学第1句 →</button></section>';
  }
  function loop25(audio,content,label){return playButton(audio,content,true,label,false).replace('data-sam-play=', 'data-loop-override="0" data-sam-play=');}
  function detail25(line){
    var words=(line.en.match(/[A-Za-z]+(?:[’\x27-][A-Za-z]+)*/g)||[]).filter(function(w,i,a){return a.map(function(x){return x.toLowerCase();}).indexOf(w.toLowerCase())===i;});
    return '<details class="sam25-detail"><summary>不懂这句？看单词、音标和句子结构</summary>'+(line.ipa?'<p class="sam25-ipa" lang="en">/'+esc(line.ipa)+'/</p>':'')+'<div class="sam25-words">'+words.map(function(word){var entry=(state.data.lexicon||{})[word.toLowerCase()];if(!entry)return '';return '<div>'+playButton(entry.src,word,false,word,true)+'<span>'+esc(entry.zh)+'</span><small>'+esc(entry.ipa||'')+'</small></div>';}).join('')+'</div>'+(line.grammar?'<p>'+esc(line.grammar)+'</p>':'')+'</details>';
  }
  function sentence25(item){
    var answer=activeAnswer(item);state.recorderTarget=null;
    if(!answer.length)return factGateHtml(item);
    state.sentenceIndex=Math.max(0,Math.min(answer.length-1,state.sentenceIndex||0));
    var index=state.sentenceIndex,line=answer[index],branch=selectedBranch(item);
    state.recorderTarget={id:'sam-v25:sentence:'+item.id+':'+(state.followup>=0?'followup-'+state.followup:'main')+':'+(branch?branch.id+':':'')+(line.id||index),expectedText:line.en,kind:'sentence',assessmentMode:'scripted',title:'第 '+(index+1)+' 句 · 录音与识别',lexicon:state.data.lexicon||{},onStart:stopSound};
    return '<section class="sam25-sentence" aria-label="逐句学习"><div class="sam25-sentence-top"><span>只练这一句</span><b>第 '+(index+1)+' 句 / 共 '+answer.length+' 句</b></div><nav class="sam25-sentence-tabs" aria-label="选择句子">'+answer.map(function(_,i){return '<button data-sam-action="sentence-index" data-value="'+i+'" aria-pressed="'+(i===index)+'">第'+(i+1)+'句</button>';}).join('')+'</nav><p class="sam25-en" lang="en">'+esc(line.en)+'</p><p class="sam25-zh">'+esc(line.zh)+'</p><div class="sam25-play">'+playButton(line.audio,line.en,true,'▶ 慢速听这一句',true)+playButton(line.audio,line.en,false,'▶ 正常速度',true)+loop25(line.audio,line.en,'↻ 慢速循环跟读')+'<button data-sam-action="stop">■ 停止</button></div>'+detail25(line)+'<details class="sam25-record"><summary>● 录这一句 · 看识别结果</summary><div data-sam-recorder></div><p class="sam25-limit">分数比较识别文字与例句；不是专业发音评分。标出的词请回听复核。</p></details><div class="sam25-sentence-next"><button data-sam-action="sentence-index" data-value="'+(index-1)+'" '+(index===0?'disabled':'')+'>← 上一句</button><button class="sam25-next" data-sam-action="'+(index===answer.length-1?'joined':'sentence-index')+'" data-value="'+(index+1)+'">'+(index===answer.length-1?'学完了，连起来说 →':'这句会了，下一句 →')+'</button></div></section>';
  }
  function answer25(item){
    var answer=activeAnswer(item),showEnglish=state.round===1||state.help,showChinese=state.round<3||state.help;
    if(!answer.length)return factGateHtml(item);
    return '<section class="sam25-joined">'+branchChoiceHtml(item)+(showChinese?'<ol class="sam25-answer-lines">'+answer.map(function(line,i){return '<li><span>'+String(i+1).padStart(2,'0')+'</span><div>'+(showEnglish?'<p lang="en">'+esc(line.en)+'</p>':'')+'<p class="sam25-zh">'+esc(line.zh)+'</p></div></li>';}).join('')+'</ol>':'<div class="sam25-blank"><b>现在，用你自己的话回答。</b><p>不必一口气说完，句子之间可以停一下。</p></div>')+(showEnglish?'<div class="sam25-play">'+playButton(answerAudio(item,answer),text(answer),true,'▶ 慢速听完整回答',true)+playButton(answerAudio(item,answer),text(answer),false,'▶ 正常听完整回答',true)+loop25(answerAudio(item,answer),text(answer),'↻ 整段慢速循环')+'<button data-sam-action="stop">■ 停止</button></div>':'<button data-sam-action="help">'+(state.help?'收起提示':'卡住了？看一下答案')+'</button>')+'<button class="sam25-back" data-sam-action="stage" data-value="2">有句不熟？回去逐句练</button></section>';
  }
  function rounds25(){return '<nav class="sam25-rounds" aria-label="逐步脱稿">'+['看英文跟读','只看中文说','脱稿回答'].map(function(label,index){return '<button data-sam-action="round" data-value="'+(index+1)+'" aria-pressed="'+(state.round===index+1)+'">'+label+'</button>';}).join('')+'</nav>';}
  function joinedRecorder25(item){
    recorderHtml(item); // Preserve the established whole-answer target and recording history.
    return '<details class="sam25-record" open><summary>● '+(state.mode==='prepare'&&state.round===1?'录完整回答 · 看识别结果':'录下自己的回答')+'</summary><div data-sam-recorder></div><p class="sam25-limit">'+(state.recorderTarget.assessmentMode==='scripted'?'文字匹配分不等于发音分；标出的词需回听复核。':'自由回答保留识别文字和录音，不按范文逐字评分。')+'</p></details>';
  }
  function body25(item){
    var stage=stage25(),html='';
    if(stage===1){state.recorderTarget=null;html=questionHtml(item)+listening25(item)+alternativeQuestionsHtml(item);}
    else if(stage===2){html=sentence25(item);}
    else if(stage===3){html=rounds25()+(state.round===3?questionHtml(item):'<p class="sam25-context">回答：'+esc(activeQuestion(item).zh)+'</p>')+answer25(item)+joinedRecorder25(item)+actionsHtml(item)+'<details class="sam25-extra"><summary>复盘与基础句型</summary>'+reviewHtml(item)+relatedHtml(item)+'</details>';}
    else{html=questionHtml(item)+(state.help?answer25(item):'<button data-sam-action="help">没思路？临时看提示</button>')+joinedRecorder25(item)+actionsHtml(item);}
    return header25(item)+'<div class="sam25-panel" data-stage="'+stage+'">'+html+'</div>';
  }
