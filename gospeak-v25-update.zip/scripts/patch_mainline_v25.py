"""Presentation and sentence rehearsal on top of the verified V22 engine."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def patch_v25(source):
    assert 'V25_SENTENCE_FIRST' not in source
    assert 'V22_LISTENING_FIRST' in source
    def once(old,new):
        nonlocal source
        assert source.count(old)==1,old[:100]
        source=source.replace(old,new)
    once("variant:0,followup:-1,listeningFocus:true", "sentenceMode:true,sentenceIndex:0,variant:0,followup:-1,listeningFocus:true")
    once('  function render(preserveRecorder){', (ROOT/'assets/mainline-v25-fragment.js').read_text()+'\n  function render(preserveRecorder){')
    once("html=sentence25(item);", "html=branchChoiceHtml(item)+sentence25(item);")
    once("html=rounds25()+(state.round===3?", "html=rounds25()+(state.help?'<button data-sam-action=\"help\">收起临时答案</button>':'')+(state.round===3?")
    start=source.index("    var item=q(),prepare=state.mode==='prepare',showScaffold=")
    end=source.index("    var placeholder=state.root.querySelector('[data-sam-recorder]');",start)
    source=source[:start]+"    state.root.querySelector('[data-sam-content]').innerHTML=body25(q());\n"+source[end:]
    once('function resetPrompt(){state.listeningFocus=', 'function resetPrompt(){state.sentenceMode=true;state.sentenceIndex=0;state.listeningFocus=')
    once("playClip(state.clips[key],key,button,button.hasAttribute('data-single'));return;", "var oldLoop=state.loop;if(button.hasAttribute('data-loop-override'))state.loop=Number(button.getAttribute('data-loop-override'));playClip(state.clips[key],key,button,button.hasAttribute('data-single'));state.loop=oldLoop;return;")
    once("if(action==='mode'){", """if(action==='stage'){
      var step=Number(value);if(step<1||step>3)return;state.mode='prepare';state.listeningFocus=step===1;state.sentenceMode=step!==3;state.round=1;state.help=false;state.recorded=false;render();
    }else if(action==='sentence-index'){
      var index=Number(value);if(!Number.isInteger(index)||index<0||index>=activeAnswer(q()).length)return;state.sentenceIndex=index;state.recorded=false;render();
    }else if(action==='joined'){
      state.sentenceMode=false;state.listeningFocus=false;state.round=1;state.help=false;state.recorded=false;render();
    }else if(action==='mode'){""")
    once("else if(action==='answer-start'){if(state.mode!=='prepare')return;", "else if(action==='answer-start'){if(state.mode!=='prepare')return;state.sentenceMode=true;state.sentenceIndex=0;")
    once("else if(action==='round'){state.listeningFocus=false;", "else if(action==='round'){state.sentenceMode=false;state.listeningFocus=false;")
    once("if(!safeToChange())return;\n    if(action==='stage')", "if(!safeToChange())return;\n    if(['stage','answer-start','sentence-index','joined','round'].indexOf(action)>=0)state.scrollLearning=true;\n    if(action==='stage')")
    once("    var placeholder=state.root.querySelector('[data-sam-recorder]');", "    if(state.scrollLearning){state.scrollLearning=false;var steps=state.root.querySelector('.sam25-steps');if(steps&&steps.scrollIntoView)steps.scrollIntoView({block:'start'});}\n    var placeholder=state.root.querySelector('[data-sam-recorder]');")
    return source
