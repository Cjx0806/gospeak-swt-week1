from pathlib import Path
import hashlib,re,shutil,zipfile
from patch_mainline_v25 import patch_v25
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'_site'
with zipfile.ZipFile(ROOT/'gospeak-v22-update.zip') as z:
    original=z.read('_site/assets/mainline-v21.js').decode()
(SITE/'assets/mainline-v21.js').write_text(patch_v25(original))
shutil.copyfile(ROOT/'assets/mainline-v25.css',SITE/'assets/mainline-v25.css')
html=(SITE/'index.html').read_text()
html=html.replace('mainline-v21.js?v=22','mainline-v21.js?v=22&design=25') if 'mainline-v21.js?v=22&design=25' not in html else html
if 'mainline-v25.css' not in html:
    html=html.replace('</head>','<link rel="stylesheet" href="./assets/mainline-v25.css?v=22">\n</head>')
html=html.replace('V24 · 快乐出村计划','V25 · 快乐出村计划')
(SITE/'index.html').write_text(html)
sw=(SITE/'sw.js').read_text()
if 'assets/mainline-v25.css' not in sw:
    sw=sw.replace("// V19_VERSIONED_CACHE", "core.push(new URL('assets/mainline-v25.css',BASE).href);\n// V19_VERSIONED_CACHE")
if "u.searchParams.set('design', '25')" not in sw:
    sw=sw.replace("u.searchParams.set('v', '22'); return u.href;", "u.searchParams.set('v', '22'); if(u.pathname.endsWith('/assets/mainline-v21.js'))u.searchParams.set('design', '25'); return u.href;")
digest=hashlib.sha256((SITE/'assets/mainline-v21.js').read_bytes()+(SITE/'assets/mainline-v25.css').read_bytes()).hexdigest()[:12]
sw=re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,sw)
(SITE/'sw.js').write_text(sw)
print('Built V25: sentence-first learning, per-sentence recording, three-stage presentation.')
