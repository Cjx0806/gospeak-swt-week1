/* Test the deployed V25 engine with real curriculum; no microphone data. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'..'),site=path.join(root,'_site');
const source=fs.readFileSync(path.join(site,'assets/mainline-v21.js'),'utf8');
assert(source.includes('V25_SENTENCE_FIRST'));
const end=source.indexOf("  window.addEventListener('sam-recorder-start'");
const instrumented=source.slice(0,end)+'window.test={state,render,handleClick,choose,resetPrompt,activeAnswer,q,recordSaved,stopSound};})();';
const data=JSON.parse(fs.readFileSync(path.join(site,'interview-v21.json'),'utf8'));
let html='',status='',recording=false,destroyed=0,scrolls=0,sequence=0;
const timers=new Map(),targets=[];
class Audio{
  constructor(){this.paused=true;this.currentTime=0;this.duration=2;this.plays=0;}
  play(){this.paused=false;this.plays++;return Promise.resolve();}
  pause(){this.paused=true;}removeAttribute(){this.src='';}load(){}
}
const sandbox={window:{dispatchEvent(){},SamRecorder:{mount(node,target){assert(node);targets.push(target);return{isRecording(){return recording;},destroy(){destroyed++;}};}}},
 document:{baseURI:'https://test.invalid/',querySelector(){return null;},querySelectorAll(){return[];}},
 localStorage:{getItem(){return null;},setItem(){}},URL,Date,Math,Audio,Promise,
 CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},
 setTimeout(fn){timers.set(++sequence,fn);return sequence;},clearTimeout(id){timers.delete(id);}};
vm.runInNewContext(instrumented,sandbox);
const t=sandbox.window.test;t.state.data=data;t.state.questions=data.questions;
const placeholder={replaceWith(){}};
t.state.root={isConnected:true,contains(){return true;},querySelector(selector){
 if(selector==='[data-sam-content]')return{set innerHTML(value){html=value;}};
 if(selector==='[data-sam-status]')return{set textContent(value){status=value;}};
 if(selector==='[data-sam-recorder]')return html.includes('data-sam-recorder')?placeholder:null;
 if(selector==='.sam25-steps')return{scrollIntoView(){scrolls++;}};
 return null;},querySelectorAll(){return[];}};
function click(action,value){const attrs={'data-sam-action':action,'data-value':String(value)};dispatch(attrs);}
function dispatch(attrs){t.handleClick({target:{closest(){return{disabled:false,hasAttribute(k){return k in attrs;},getAttribute(k){return attrs[k]??null;},classList:{add(){},remove(){}},setAttribute(){}};}}});}
function displayedSentence(row){assert(html.includes('class="sam25-en" lang="en">'+row.en));assert.equal(t.state.recorderTarget.expectedText,row.en);assert.equal(t.state.recorderTarget.assessmentMode,'scripted');}
t.render();
assert.equal(t.state.recorderTarget,null);assert(!html.includes('data-sam-recorder'));
assert(!html.includes(data.questions.find(q=>q.id==='15').short[0].en));
click('answer-start');let question=t.q();
displayedSentence(question.short[0]);
assert(!html.includes(question.short[1].en));assert(!html.includes(question.short[2].en));
assert(!Object.values(t.state.clips).some(c=>c.text===question.short.map(s=>s.en).join(' ')),'individual stage must not register whole-answer audio');
assert(html.includes('第 1 句 / 共 3 句'));assert(html.includes('慢速循环跟读'));assert(html.includes('录这一句'));
assert.equal(t.state.recorderTarget.kind,'sentence');assert(t.state.recorderTarget.id.startsWith('sam-v25:sentence:'));
const firstTarget=t.state.recorderTarget.id;
click('sentence-index',1);displayedSentence(question.short[1]);assert.notEqual(t.state.recorderTarget.id,firstTarget);
assert(!html.includes(question.short[0].en));assert(!html.includes(question.short[2].en));
const countBefore=JSON.stringify(t.state.counts);
t.recordSaved({detail:{id:t.state.recorderTarget.id,duration:3,savedAt:123}});
assert.equal(JSON.stringify(t.state.counts),countBefore,'a single sentence cannot complete an entire answer round');
click('sentence-index',2);displayedSentence(question.short[2]);assert(html.includes('学完了，连起来说'));
click('sentence-index',99);assert.equal(t.state.sentenceIndex,2,'invalid sentence cannot be selected');
recording=true;const before=t.state.recorderTarget.id,oldDestroyed=destroyed;
for(const [action,value] of [['sentence-index',0],['joined',0],['stage',1],['topic','02']])click(action,value);
assert.equal(t.state.recorderTarget.id,before);assert.equal(destroyed,oldDestroyed);assert(status.includes('停止并保存录音'));
recording=false;click('joined');
assert.equal(t.state.recorderTarget.expectedText,question.short.map(s=>s.en).join(' '));
assert(t.state.recorderTarget.id.startsWith('sam-v21:scripted:'));
assert.equal((html.match(/<li><span>0/g)||[]).length,3,'joined answer keeps visible sentence boundaries');
click('round',2);assert.equal(t.state.recorderTarget.assessmentMode,'free');assert.equal(t.state.recorderTarget.expectedText,'');
for(const line of question.short){assert(!html.includes(line.en));assert(html.includes(line.zh));}
click('round',3);for(const line of question.short){assert(!html.includes(line.en));assert(!html.includes(line.zh));}
click('help');for(const line of question.short)assert(html.includes(line.en));
click('stage',2);displayedSentence(question.short[2]);
click('stage',1);assert.equal(t.state.recorderTarget,null);assert(!html.includes('data-sam-recorder'));assert(scrolls>0);
click('topic','02');assert.equal(t.state.sentenceIndex,0);assert.equal(t.state.listeningFocus,true);

// Every populated question and every sentence: displayed text == recorder == MP3 binding.
click('scope-more');let sentences=0;
for(const row of data.questions){
 t.choose(row.id);click('answer-start');
 if(!row.short.length){assert.equal(t.state.recorderTarget,null);assert(html.includes('先确认真实情况'));continue;}
 row.short.forEach((line,index)=>{
   click('sentence-index',index);displayedSentence(line);sentences++;
   const clip=Object.values(t.state.clips).find(c=>c.text===line.en&&c.rate===(line.audio.slowRate||1));
   assert(clip,row.id+':'+index);assert.equal(clip.src,line.audio.slow||line.audio.normal);
   assert(fs.existsSync(path.join(site,clip.src)));
   assert(!html.includes('undefined'));assert(!html.includes('▶ 慢速听完整回答'));
 });
 click('joined');assert.equal(t.state.recorderTarget.expectedText,row.short.map(s=>s.en).join(' '));
}
// Recording target respects unconfirmed facts and branch identities.
t.choose('i06');click('answer-start');assert.equal(t.state.recorderTarget,null);
if(t.q().branches.some(b=>!b.sentences.some(s=>/\[.+?\]/.test(s.en)))){
 const i=t.q().branches.findIndex(b=>!b.sentences.some(s=>/\[.+?\]/.test(s.en)));
 click('confirm-branch',i);assert(t.state.recorderTarget.expectedText);click('reset-branch');assert.equal(t.state.recorderTarget,null);
}
// Loop uses only current line, keeps user's whole-answer preference, and cleans up on next.
t.choose('15');click('answer-start');question=t.q();
const loopMatch=html.match(/data-loop-override="0" data-sam-play="([^"]+)"/);assert(loopMatch);
dispatch({'data-sam-play':loopMatch[1],'data-loop-override':'0'});
const playing=t.state.audio;assert(playing.src.includes(question.short[0].audio.normal.slice(2)));assert.equal(playing.playbackRate,.78);assert.equal(t.state.loop,1);
playing.onended();assert(t.state.audioTimer);const repeat=timers.get(t.state.audioTimer);assert(repeat);repeat();assert.equal(playing.plays,2);
click('sentence-index',1);assert.equal(t.state.audio,null);assert.equal(t.state.audioTimer,null);assert(playing.paused);
click('mode','mock');assert.equal(t.state.recorderTarget.assessmentMode,'free');assert.equal(t.state.recorderTarget.expectedText,'');assert(!html.includes('data-sam-action="meaning"'));
assert(!html.includes(t.q().question));click('mode','prepare');assert.equal(t.state.recorderTarget,null);
console.log(`PASS V25: ${sentences} sentence/recording/audio bindings; split → join → independent answers; active-recording guards; loop and navigation cleanup; truthful branch gates.`);
