"""Small additive release; previous sentence lessons and continuous audio unchanged."""
from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parents[1]
paths=['_site/index.html','_site/sw.js','_site/assets/mainline-v21.js','_site/assets/mainline-v25.css',
       'assets/mainline-v25.css','assets/mainline-v25-fragment.js','scripts/patch_mainline_v25.py',
       'scripts/build_v25.py','scripts/package_v25.py','scripts/verify_v22.py','scripts/test_mainline_v25.cjs']
with zipfile.ZipFile(ROOT/'gospeak-v25-update.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name in paths: archive.write(ROOT/name,name)
workflow=ROOT/'.github/workflows/pages.yml';text=workflow.read_text().replace('Deploy 快乐出村计划 V24','Deploy 快乐出村计划 V25')
if 'unzip -q -o gospeak-v25-update.zip' not in text:
    text=text.replace('unzip -q -o gospeak-v24-update.zip -d .','unzip -q -o gospeak-v24-update.zip -d .\n          unzip -q -o gospeak-v25-update.zip -d .')
if 'node scripts/test_mainline_v25.cjs' not in text:
    text=text.replace('node scripts/test_listening_first_v22.cjs','node scripts/test_listening_first_v22.cjs\n          node scripts/test_mainline_v25.cjs')
workflow.write_text(text)
print('Packaged V25:',(ROOT/'gospeak-v25-update.zip').stat().st_size,'bytes')
