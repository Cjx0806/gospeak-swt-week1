"""Release gate: every displayed sentence and word has content-bound audio."""
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import zipfile
from mutagen.mp3 import MP3
from verify_v21 import verify as verify_interview
from build_v22 import NODE, ROOT, TIP_FIXES, MAINLINE_COPY
from v22_week3 import LESSONS
from patch_mainline_v22 import patch_mainline
from patch_core_v22 import patch_core
from patch_listening_first_v22 import patch_listening_first
from v22_interview_supplement import SUPPLEMENTAL_QUESTIONS, QUESTION_SOURCE_MAP


def sha(value): return hashlib.sha256(value if isinstance(value,bytes) else value.encode()).hexdigest()


def verify(site):
    site=Path(site).resolve()
    verify_interview(site,shell_version='22',check_original_shell=False)
    manifest=json.loads((site/'lesson-audio-v22.json').read_text())
    base=json.loads((ROOT/'assets/lesson-baseline-v21.json').read_text())
    baseline=[p for lesson in base['lessons'] for p in lesson['phrases']]
    expected=baseline+[p for lesson in LESSONS for p in lesson['phrases']]
    assert manifest['version']=='v22' and manifest['sentenceCount']==105
    assert len(manifest['sentences'])==105 and len({s['id'] for s in manifest['sentences']})==105
    assert len(manifest['words'])==manifest['wordCount']
    seen=set()
    def check_audio(audio,text,kind):
        assert audio['spokenText']==text
        assert audio['textSha256']==sha(text)
        assert audio['provenance']
        expected_path=f'./audio/lesson-v22/{kind}-{sha(text)[:20]}-{audio["sha256"][:16]}.mp3'
        assert audio['src']==expected_path
        file=site/audio['src']; assert file.is_file()
        assert sha(file.read_bytes())==audio['sha256']
        length=MP3(file).info.length; assert math.isfinite(length) and .05<length<60
        seen.add(audio['src'])
    for index,(row,wanted) in enumerate(zip(manifest['sentences'],expected)):
        assert row['id']==f'p{index+1:02d}'
        assert row['day']==index//5+1 and row['sentence']==index%5+1
        assert row['en']==wanted['en'] and row['zh']==wanted['zh']
        check_audio(row['audio'],row['en'],'s')
        if index<70:
            old=base['phrases'][index]
            assert row['audio']['sha256']==old['recommendedAudio']['sha256'],row['id']
            if old['confirmedStaleBySource']:
                assert row['audio']['sha256']!=old['currentAudio']['sha256'],row['id']
    words={w.lower() for p in expected for w in re.findall(r'[A-Za-z]+(?:-[A-Za-z]+)?',p['en'])}
    assert words==set(manifest['words'])
    for word,row in manifest['words'].items():
        assert row['zh'] and row['ipa']
        check_audio(row,word,'w')
    # The interview questions/recording implementation are not reauthored by this fix.
    with zipfile.ZipFile(ROOT/'gospeak-v21-update.zip') as archive:
        for name in ('assets/mainline-v21.js','assets/mainline-v21.css','assets/recorder-v19.js','assets/recorder-v19.css'):
            original=archive.read('_site/'+name)
            if name=='assets/mainline-v21.js':
                text=original.decode()
                for old,new in MAINLINE_COPY.items(): text=text.replace(old,new)
                original=patch_listening_first(patch_core(patch_mainline(text))).replace("var VERSION='21'", "var VERSION='22'").encode()
                if b'V25_SENTENCE_FIRST' in (site/name).read_bytes():
                    from patch_mainline_v25 import patch_v25
                    original=patch_v25(original.decode()).encode()
            assert (site/name).read_bytes()==original,name
        original_data=json.loads(archive.read('_site/interview-v21.json'))
    data=json.loads((site/'interview-v21.json').read_text())
    assert data['coreQuestionIds']==['02','15','16','s01','i04','b01','i03','s03']
    assert data['release']=='v22' and len(data['questions'])==44
    by_id={item['id']:item for item in data['questions']}
    for old in original_data['questions']:
        current=dict(by_id[old['id']]);current.pop('listeningClues',None)
        if old['id']!='s01': assert current==old,old['id']
    assert [s['en'] for s in by_id['s01']['short']]==['I would like to be a lifeguard.','I have a Chinese lifeguard certificate.','I swim almost every day.']
    for expected in SUPPLEMENTAL_QUESTIONS:
        assert [s['en'] for s in by_id[expected['id']]['short']]==[s['en'] for s in expected['short']]
        assert [s['zh'] for s in by_id[expected['id']]['short']]==[s['zh'] for s in expected['short']]
    assert data['imageQuestionMap']=={str(k):v for k,v in QUESTION_SOURCE_MAP.items()}
    assert by_id['i06']['requiresConfirmation'] and not by_id['i06']['short']
    for path,row in json.loads((site/'interview-audio-v22.json').read_text()).items():
        assert sha((site/path).read_bytes())==row['sha256']
        assert row['text'].replace('SWT','S W T')==row['spokenText']
        assert .05<MP3(site/path).info.length<60
    html=(site/'index.html').read_text()
    assert '<title>快乐出村计划｜英语口语练习</title>' in html
    assert './assets/polish-v22.css?v=22' in html
    assert (site/'assets/polish-v22.css').is_file()
    assert json.loads((site/'manifest.webmanifest').read_text())['name']=='快乐出村计划'
    subprocess.run([NODE,str(ROOT/'scripts/test_sentence_v22.cjs'),str(site)],check=True)
    print(f'V22 verified: 105 exact text/audio bindings, {len(words)} complete word bindings, {len(seen)} valid content-addressed clips; prior learning IDs and separate SWT mainline preserved.')


if __name__=='__main__': verify(sys.argv[1] if len(sys.argv)>1 else ROOT/'_site')
