/* BEGIN_V22_LESSON_PLAYBACK_UI
 * Insert inside the retained lesson module. Ordinary play/stop only updates
 * button state; the sentence, vocabulary, grammar, feedback and microphone
 * nodes keep their identity and keyboard focus. Navigation and failures still
 * use the established full renderer. No audio/network work occurs here.
 */
function samRefreshLessonPlayback() {
  if (v !== 'lesson' || !_ || !_.querySelector) return false;
  var sentence = _.querySelector('#play-sentence');
  var normal = _.querySelector('#play-normal');
  var slow = _.querySelector('#play-slow');
  if (!sentence || !normal || !slow) return false;

  var number = String(b * 5 + C + 1).padStart(2, '0');
  var normalPlaying = D === 'phrase-' + number + '-normal';
  var slowPlaying = D === 'phrase-' + number + '-slow';
  function setButton(button, playing, label) {
    button.classList.toggle('playing', playing);
    button.setAttribute('aria-pressed', String(playing));
    button.textContent = label;
  }
  setButton(sentence, normalPlaying, normalPlaying ? '■' : '▶');
  sentence.setAttribute('aria-label', normalPlaying ? '停止整句循环' : '循环播放整句');
  setButton(normal, normalPlaying, normalPlaying ? '停止标准音' : '循环标准音');
  setButton(slow, slowPlaying, slowPlaying ? '停止慢速' : '循环慢速');
  _.querySelectorAll('[data-word]').forEach(function (button) {
    var playing = D === 'word-' + button.dataset.word;
    button.classList.toggle('playing', playing);
    button.setAttribute('aria-pressed', String(playing));
    var icon = button.querySelector('i');
    if (icon) icon.textContent = playing ? '■' : '▶';
  });

  var stop = _.querySelector('#stop-audio');
  if (D && !stop) {
    stop = document.createElement('button');
    stop.id = 'stop-audio';
    stop.className = 'stop-audio';
    stop.type = 'button';
    stop.textContent = '■ 结束播放';
    stop.onclick = function () { q(); };
    _.appendChild(stop);
  } else if (!D && stop) {
    stop.remove();
  }
  return true;
}

function samRenderPlaybackState() {
  // A partial DOM from navigation must not leave controls stuck. Falling back
  // is exceptional; the normal lesson path retains all existing nodes.
  try { if (samRefreshLessonPlayback()) return; } catch (_) {}
  $();
}
/* END_V22_LESSON_PLAYBACK_UI */
