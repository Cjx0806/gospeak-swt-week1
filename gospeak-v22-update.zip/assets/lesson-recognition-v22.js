/* V22: replace the compiled module's async ut() with this whole fragment.
 * Keeps e/b/C/v/T/E/j/$/we and gospeak-independent-progress bindings unchanged.
 * Browser speech recognition only; no new voice endpoint or recording upload.
 */
var samLessonRecognitionStateV22 = { nextId: 0, current: null, micReady: false };

function samLessonOwnsV22(run) {
  return !!run && !run.closed && samLessonRecognitionStateV22.current === run;
}
function samLessonLocationV22(run) {
  return v === 'lesson' && b === run.day && C === run.index &&
    e[b] && e[b].phrases[C] && e[b].phrases[C].en === run.text;
}
function samLessonNoticeV22(message) {
  window.dispatchEvent(new CustomEvent('gospeak-audio-status', { detail: { message: message } }));
}
function samLessonDetachV22(recognition) {
  if (!recognition) return;
  recognition.onstart = recognition.onresult = recognition.onerror = recognition.onend = null;
}
function samLessonFinishV22(run, message, render, abort) {
  if (!samLessonOwnsV22(run)) return;
  var sameLocation = samLessonLocationV22(run);
  run.closed = true;
  clearTimeout(run.timer);
  run.timer = 0;
  samLessonRecognitionStateV22.current = null;
  T = false;
  samLessonDetachV22(run.recognition);
  if (abort && run.recognition) { try { run.recognition.abort(); } catch (_) {} }
  if (sameLocation) {
    if (typeof message === 'string') E = message;
    // Navigation capture must clear this class before the mainline's navigation
    // guard sees it. Do not replace the DOM while the clicked control is dispatching.
    var practice = _.querySelector('.practice');
    if (practice) practice.classList.remove('listening');
    if (render) $();
    else {
      // Playback and navigation may no longer call the legacy whole-page render.
      // Restore this small control in place, so its click never keeps a closed
      // run's stop closure and the next recording works immediately.
      var button = _.querySelector('#record');
      if (button) { button.disabled = false; button.textContent = '开始跟读'; button.onclick = ut; }
      if (practice) {
        var title = practice.querySelector('h3');
        var help = practice.querySelector('p');
        if (title) title.textContent = '轮到你开口了';
        if (help) help.textContent = '先理解、再听两遍，最后完整说一次';
      }
    }
  }
}
function samLessonDeadlineV22(run, milliseconds, message) {
  clearTimeout(run.timer);
  run.timer = setTimeout(function () {
    if (!samLessonOwnsV22(run)) return;
    samLessonFinishV22(run, message, true, true);
    if (samLessonLocationV22(run)) samLessonNoticeV22(message);
  }, milliseconds);
}
function samLessonStopV22(run) {
  if (!samLessonOwnsV22(run)) return;
  if (run.phase !== 'listening' || !run.recognition) {
    samLessonFinishV22(run, '已取消，可以立即重新开始跟读。', true, true);
    return;
  }
  run.phase = 'stopping';
  E = '正在整理识别结果，请稍等；也可以取消等待。';
  samLessonDeadlineV22(run, 4000, '暂未收到识别结果。请点「开始跟读」再试，不会记作低分。');
  samLessonRenderV22(run);
  try { run.recognition.stop(); }
  catch (_) { samLessonFinishV22(run, '本次识别未完成。请点「开始跟读」再试。', true, true); }
}
function samLessonRenderV22(run) {
  if (!samLessonOwnsV22(run) || !samLessonLocationV22(run)) return;
  $();
  var button = _.querySelector('#record');
  var practice = _.querySelector('.practice');
  if (button) {
    button.disabled = false;
    button.textContent = run.phase === 'preparing' ? '取消麦克风等待' : run.phase === 'stopping' ? '取消结果等待' : '停止识别';
    button.onclick = function () { samLessonStopV22(run); };
  }
  if (practice) {
    var title = practice.querySelector('h3');
    var help = practice.querySelector('p');
    if (title) title.textContent = run.phase === 'preparing' ? '正在准备麦克风…' : run.phase === 'stopping' ? '正在整理识别结果…' : '正在听你说…';
    if (help) help.textContent = run.phase === 'preparing' ? '首次使用请允许麦克风；等待中也能取消，不用连续点。' : run.phase === 'stopping' ? '收到识别文字后显示原来的逐词对照和匹配分。' : '说完这一句后停顿，或点「停止识别」查看结果。';
  }
}

async function ut() {
  var previous = samLessonRecognitionStateV22.current;
  if (samLessonOwnsV22(previous)) {
    if (samLessonLocationV22(previous)) return; // Lock before any permission await.
    samLessonFinishV22(previous, null, false, true);
  }
  if (v !== 'lesson' || !e[b] || !e[b].phrases[C]) return;
  var Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) { E = '当前浏览器不支持自动识别，请使用支持语音识别的 Safari。'; T = false; $(); return; }
  var run = {
    id: ++samLessonRecognitionStateV22.nextId, day: b, index: C,
    text: e[b].phrases[C].en, phase: 'preparing', recognition: null,
    closed: false, timer: 0
  };
  samLessonRecognitionStateV22.current = run;
  T = true;
  E = '正在准备麦克风，请稍等；首次使用请允许权限。';
  window.dispatchEvent(new CustomEvent('sam-recorder-start', { detail: { owner: 'legacy-lesson-v22' } }));
  samLessonDeadlineV22(run, 18000, '麦克风准备超时。请确认 Safari 麦克风权限后重试，也可以先继续点读。');
  samLessonRenderV22(run);
  try {
    // Check permission once per page, then let Recognition handle subsequent
    // starts directly. Every temporary stream is stopped, including late grants.
    if (!samLessonRecognitionStateV22.micReady && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      var stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(function (track) { track.stop(); });
      if (!samLessonOwnsV22(run) || !samLessonLocationV22(run)) {
        samLessonFinishV22(run, null, false, true); return;
      }
      samLessonRecognitionStateV22.micReady = true;
    }
  } catch (_) {
    samLessonFinishV22(run, '麦克风没有准备好。请在 Safari 网站设置中允许麦克风，然后重试。', true, true);
    return;
  }
  if (!samLessonOwnsV22(run) || !samLessonLocationV22(run)) {
    samLessonFinishV22(run, null, false, true); return;
  }
  try {
    var recognition = new Recognition();
    run.recognition = recognition;
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.continuous = false;
    recognition.onstart = function () {
      if (!samLessonOwnsV22(run)) return;
      if (!samLessonLocationV22(run)) { samLessonFinishV22(run, null, false, true); return; }
      if (run.phase === 'stopping') return;
      run.phase = 'listening'; E = '';
      samLessonRenderV22(run);
    };
    recognition.onresult = function (event) {
      if (!samLessonOwnsV22(run)) return;
      if (!samLessonLocationV22(run)) { samLessonFinishV22(run, null, false, true); return; }
      var parts = [];
      for (var i = 0; event.results && i < event.results.length; i++) {
        var result = event.results[i];
        if (result && result.isFinal !== false && result[0] && result[0].transcript) parts.push(result[0].transcript);
      }
      var transcript = parts.join(' ').trim();
      if (!transcript) return; // No final words means no score and no false completion.
      j = [].concat(j.slice(-19), we(run.text, transcript).score);
      try { localStorage.setItem('gospeak-independent-progress', JSON.stringify(j)); }
      catch (_) { samLessonNoticeV22('已识别本次跟读，但浏览器未能保存进度；可以先看本次结果。'); }
      samLessonFinishV22(run, transcript, true, true);
    };
    recognition.onerror = function (event) {
      if (!samLessonOwnsV22(run)) return;
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed' || event.error === 'audio-capture') samLessonRecognitionStateV22.micReady = false;
      var message = {
        'not-allowed': '麦克风权限被关闭，请在 Safari 网站设置中改为允许。',
        'service-not-allowed': '浏览器的语音识别服务未获允许，请检查 Safari 与语音识别设置。',
        'no-speech': '没有听到声音，请靠近麦克风再试。',
        'network': '语音识别服务暂时没有连通，请检查网络后重试；本次不计分。',
        'audio-capture': '没有检测到可用麦克风。',
        'aborted': '识别已停止，可以重新开始跟读。'
      }[event.error] || '这次没有识别成功，请再试一次；本次不计分。';
      samLessonFinishV22(run, message, true, true);
    };
    recognition.onend = function () {
      if (!samLessonOwnsV22(run)) return;
      samLessonFinishV22(run, '没有收到识别文字。请点「开始跟读」再试，不会记作低分。', true, false);
    };
    run.phase = 'listening'; E = '';
    samLessonDeadlineV22(run, 18000, '18 秒内没有收到识别结果，已结束等待。请点「开始跟读」重试，本次不计分。');
    samLessonRenderV22(run);
    recognition.start();
  } catch (_) {
    samLessonFinishV22(run, '语音识别没有启动。请点「开始跟读」重试；若仍失败，请重新打开 Safari。', true, true);
  }
}

// Window capture runs before the mainline's document-capture navigation guard.
window.addEventListener('click', function (event) {
  var run = samLessonRecognitionStateV22.current;
  if (!samLessonOwnsV22(run) || !event.target || typeof event.target.closest !== 'function') return;
  if (event.target.closest('[data-view], [data-day], #previous, #next')) samLessonFinishV22(run, '', false, true);
}, true);
window.addEventListener('pagehide', function () {
  samLessonFinishV22(samLessonRecognitionStateV22.current, null, false, true);
});
document.addEventListener('visibilitychange', function () {
  if (document.hidden) samLessonFinishV22(samLessonRecognitionStateV22.current, '页面已切到后台，识别已停止。返回后请重新开始跟读。', true, true);
});
window.addEventListener('gospeak-playback-request', function () {
  samLessonFinishV22(samLessonRecognitionStateV22.current, '示范播放前已停止识别。听完后可以重新跟读。', false, true);
});
window.addEventListener('sam-recorder-start', function (event) {
  if (!event.detail || event.detail.owner !== 'legacy-lesson-v22') samLessonFinishV22(samLessonRecognitionStateV22.current, null, false, true);
});
window.__samLessonRecognitionV22 = {
  isRecording: function () { return samLessonOwnsV22(samLessonRecognitionStateV22.current); },
  cancel: function () { samLessonFinishV22(samLessonRecognitionStateV22.current, '已停止识别，可以重新开始跟读。', true, true); }
};
/* END_V22_LESSON_RECOGNITION */
