/* Eight-question defaults, optional full bank, and existing recorder safeguards. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),cp=require('node:child_process');
const root=path.join(__dirname,'..'),root_site=process.argv[2]||process.env.ROOT_SITE||path.join(root,'_site');
const python=process.env.PYTHON||process.env.PYTHON3||'python3';
const original=fs.readFileSync(path.join(root,'assets/mainline-v21.js'),'utf8');
const compose='import sys;sys.path.insert(0,sys.argv[1]);from patch_mainline_v22 import patch_mainline;from patch_core_v22 import patch_core;print(patch_core(patch_mainline(sys.stdin.read())))';
const source=cp.execFileSync(python,['-c',compose,__dirname],{input:original,encoding:'utf8',maxBuffer:2*1024*1024});
const ids=['02','15','16','s01','i04','b01','i03','s03'];
assert(source.includes('/* V22_CORE_EIGHT */'));
assert(source.includes("var VERSION='21', STORE='gospeak-sam-v21-interview';"),'version/storage unchanged by route patch');
const payload=JSON.parse(fs.readFileSync(path.join(root_site,'interview-v21.json'),'utf8'));
// These fixtures are TEST ONLY. Before the build has added new data, missing
// core cards receive explicit dummy text; nothing here is written to the site.
const fixtureIds=[];
for(const id of ['i04','b01','i03'])if(!payload.questions.some(q=>q.id===id)){
  const item=JSON.parse(JSON.stringify(payload.questions.find(q=>q.id==='15')));
  Object.assign(item,{id,title:'TEST ONLY '+id,question:'Test-only question '+id+'?',questionZh:'仅测试缺失基础题 '+id,category:'测试补充题',variants:[],followups:[]});
  payload.questions.push(item);fixtureIds.push(id);
}
if(!payload.questions.some(q=>q.id==='i05')){
  const item=JSON.parse(JSON.stringify(payload.questions.find(q=>q.id==='15')));
  Object.assign(item,{id:'i05',title:'TEST ONLY optional travel',question:'Test-only optional travel?',questionZh:'仅测试选练旅行题',category:'测试选练题',variants:[],followups:[]});
  payload.questions.push(item);fixtureIds.push('i05');
}
const boundary=source.indexOf("  window.addEventListener('sam-recorder-start'");assert(boundary>0);
const instrumented=source.slice(0,boundary)+'window.test={state,render,load,filterQuestions,categories,practiceQuestions,setPracticeScope,postIntroHtml,handleClick,handleChange,pickRandomQuestion,choose,stopSound};})();';

function context(savedSelected='15',questions=payload.questions){
  let html='',status='',recording=false,randomValue=0,timerId=0,created=0;
  const timers=new Map(),targets=[];
  class Audio {constructor(){created++;this.paused=true;this.currentTime=0;this.duration=2;}play(){this.paused=false;return Promise.resolve();}pause(){this.paused=true;}removeAttribute(){this.src='';}load(){}}
  const math=Object.create(Math);math.random=()=>randomValue;
  const sandbox={window:{dispatchEvent(){},SamRecorder:{mount(node,options){targets.push(options);return{destroy(){},isRecording(){return recording;}};}}},document:{baseURI:'https://example.test/',querySelector(){return null;},querySelectorAll(){return[];}},localStorage:{getItem(){return JSON.stringify({selected:savedSelected,counts:{'15':2}});},setItem(){}},fetch(){return Promise.resolve({ok:true,json(){return Promise.resolve({...payload,questions});}});},URL,Date,Math:math,Audio,Promise,CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},setTimeout(fn){const id=++timerId;timers.set(id,fn);return id;},clearTimeout(id){timers.delete(id);}};
  vm.runInNewContext(instrumented,sandbox);const t=sandbox.window.test;
  t.state.data={...payload,questions};t.state.questions=questions;
  const node={replaceWith(){}};
  t.state.root={isConnected:true,contains(){return true;},querySelector(selector){if(selector==='[data-sam-content]')return{set innerHTML(value){html=value;}};if(selector==='[data-sam-status]')return{set textContent(value){status=value;}};return node;},querySelectorAll(){return[];}};
  function click(action,value){const button={disabled:false,hasAttribute(){return false;},getAttribute(key){return key==='data-sam-action'?action:key==='data-value'?value:null;}};t.handleClick({target:{closest(){return button;}}});}
  return{t,click,html:()=>html,status:()=>status,targets,timers,recording(value){recording=value;},random(value){randomValue=value;},created:()=>created};
}
const c=context('i05'),t=c.t;
assert.equal(t.state.practiceScope,'core');assert.equal(t.state.selected,'15');assert.equal(t.state.counts['15'],2,'old progress preserved');
assert.deepEqual(Array.from(t.filterQuestions(),q=>q.id),ids);
for(const saved of ['01','i05','18','s02','does-not-exist'])assert.equal(context(saved).t.state.selected,'15','old non-core selection reset');
for(const saved of ids)assert.equal(context(saved).t.state.selected,saved,'valid core selection preserved');
t.render();
assert(c.html().includes('随机听答这8题'));assert(c.html().includes('更多题目（选练）'));
assert(c.html().includes('<details class="sam22-topic-picker"><summary>选择基础题</summary>'));
assert(!c.html().includes('sam22-topic-group'),'no grouped dashboard or oversized routing heading');
for(const id of ids)assert(c.html().includes('data-sam-action="topic" data-value="'+id+'"'));
for(const id of ['01','i05','s02','18'])assert(!c.html().includes('data-sam-action="topic" data-value="'+id+'"'));
const select=c.html().match(/<select data-sam-question>(.*?)<\/select>/s)[1];
assert.equal((select.match(/<option /g)||[]).length,8);assert(!select.includes('value="01"'));assert(!select.includes('value="i05"'));
assert(!c.html().includes('51 题'));assert(!c.html().includes('全题模拟（选练）'));

c.click('after-intro');assert.equal(t.state.mode,'mock');assert.equal(t.state.practiceScope,'core');
for(let i=0;i<200;i++){
  c.random((i%10)/10);c.click('random');assert(ids.includes(t.state.selected),'random remains in core');
  const current=payload.questions.find(q=>q.id===t.state.selected);
  assert(!c.html().includes(current.question),'mock question remains hidden');
  for(const line of current.short)assert(!c.html().includes(line.en),'mock answer remains hidden');
}
c.click('mode','prepare');assert.deepEqual(Array.from(t.filterQuestions(),q=>q.id),ids);
c.click('mode','mock');assert.deepEqual(Array.from(t.filterQuestions(),q=>q.id),ids,'ordinary mode tab does not unlock full bank');

// Optional mode is explicit. Introduction and travel can be selected there.
c.click('scope-more');assert.equal(t.state.practiceScope,'all');assert.equal(t.state.mode,'prepare');
assert(c.html().includes('返回基础题'));assert(c.html().includes('全题模拟（选练）'));
assert(t.filterQuestions().some(q=>q.id==='01'));assert(t.filterQuestions().some(q=>q.id==='i05'));
c.click('topic','i05');assert.equal(t.state.selected,'i05');
c.click('scope-core');assert.equal(t.state.practiceScope,'core');assert.equal(t.state.selected,'15');
c.click('topic','01');assert.equal(t.state.selected,'15','non-core topic action cannot bypass pool');
t.choose('i05');assert.equal(t.state.selected,'15','direct choose also validates pool');
c.click('scope-more');c.random(0);c.click('mock-all');assert.equal(t.state.practiceScope,'all');assert.equal(t.state.mode,'mock');assert.equal(t.state.selected,'01');
c.click('after-intro');assert.equal(t.state.practiceScope,'core');assert(ids.includes(t.state.selected));

// Existing guard runs before changing scope, mode, topic or selected question.
c.click('topic','15');c.recording(true);
const snapshot=JSON.stringify({selected:t.state.selected,scope:t.state.practiceScope,mode:t.state.mode,round:t.state.round});
for(const [action,value] of [['scope-more'],['scope-core'],['mock-all'],['after-intro'],['mode','mock'],['topic','02'],['random']]){
  c.click(action,value);assert.equal(JSON.stringify({selected:t.state.selected,scope:t.state.practiceScope,mode:t.state.mode,round:t.state.round}),snapshot,action+' bypassed recorder guard');
}
t.choose('02');assert.equal(t.state.selected,'15');assert(c.status().includes('停止并保存录音'));c.recording(false);
c.click('topic','02');assert.equal(t.state.selected,'02');

// A partially updated payload exposes only real core cards, never old extras.
const subset=payload.questions.filter(q=>!['i04','b01','i03'].includes(q.id));
const partial=context('15',subset);assert.deepEqual(Array.from(partial.t.filterQuestions(),q=>q.id),ids.filter(id=>!['i04','b01','i03'].includes(id)));
partial.t.render();assert(!partial.html().includes('data-value="b01"'));partial.click('after-intro');
for(let i=0;i<30;i++){partial.random((i%10)/10);partial.click('random');assert(partial.t.filterQuestions().some(q=>q.id===partial.t.state.selected));}
const sole=context('02',payload.questions.filter(q=>['02','01','i05'].includes(q.id)));sole.t.render();sole.click('after-intro');assert.equal(sole.t.state.selected,'02');assert.equal(sole.t.state.mode,'mock');
const empty=context('15',payload.questions.filter(q=>['01','i05'].includes(q.id)));
assert.equal(empty.t.filterQuestions().length,0);assert.equal(empty.t.pickRandomQuestion(),false);assert.equal(empty.t.state.selected,'15');
assert.equal(empty.t.setPracticeScope('core'),false);assert(empty.status().includes('基础题暂未载入'));
assert(c.created()<=1,'same audio element reused');t.stopSound();assert.equal(c.timers.size,0);

// This patch must leave the listening-first agent's insertion anchors intact.
const listeningPath=path.join(__dirname,'patch_listening_first_v22.py');
if(fs.existsSync(listeningPath)){
  const integrated=cp.execFileSync(python,['-c','import sys;sys.path.insert(0,sys.argv[1]);from patch_listening_first_v22 import patch_listening_first;print(patch_listening_first(sys.stdin.read()))',__dirname],{input:source,encoding:'utf8',maxBuffer:2*1024*1024});
  assert(integrated.includes('/* V22_LISTENING_FIRST */'));new vm.Script(integrated);
}
for(const bad of [original,source,source.replace('/* V22_CORE_EIGHT */','changed marker')]){
  const result=cp.spawnSync(python,['-c','import sys;sys.path.insert(0,sys.argv[1]);from patch_core_v22 import patch_core;patch_core(sys.stdin.read())',__dirname],{input:bad,encoding:'utf8'});
  assert.notEqual(result.status,0);assert(result.stderr.includes('ValueError'));
}
(async()=>{
  // Exercise the actual asynchronous load path, including later remounts.
  empty.t.load();await new Promise(resolve=>setImmediate(resolve));
  assert.equal(empty.t.state.questions.length,0);assert.equal(empty.t.state.needsRender,false);
  assert(empty.html().includes('基础题暂未载入'));const errorHtml=empty.html();empty.t.render();assert.equal(empty.html(),errorHtml,'later render cannot silently show unrelated first question');
  const unavailableSaved=context('b01',subset);unavailableSaved.t.load();await new Promise(resolve=>setImmediate(resolve));assert.equal(unavailableSaved.t.state.selected,'15');
  const no15=context('15',payload.questions.filter(q=>['01','02','i05'].includes(q.id)));no15.t.load();await new Promise(resolve=>setImmediate(resolve));assert.equal(no15.t.state.selected,'02','uses an existing core card when default 15 is unavailable');
  console.log('PASS V22 core: eight defaults; optional full bank; persistent scoped random; missing-ID and async-load behavior; recorder guards; blind audio practice; listening-first composition. Test-only fixtures: '+(fixtureIds.join(', ')||'none')+'.');
})().catch(error=>{console.error(error);process.exitCode=1;});
