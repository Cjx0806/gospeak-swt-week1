"""Additive V22 patch: course/audio fix and week 3, no learner recordings."""
from pathlib import Path
import zipfile
from verify_v22 import verify

root=Path(__file__).resolve().parents[1]
site=root/'_site'
verify(site)
paths=[site/name for name in ('index.html','sw.js','manifest.webmanifest','lesson-audio-v22.json','assets/index-C6MAz4Oq.js','assets/polish-v22.css','assets/mainline-v21.js','assets/listening-v18.js','icon-192.png','icon-512.png','apple-touch-icon.png','og.png')]
paths+=list((site/'audio/lesson-v22').glob('*.mp3'))
paths+=list((site/'audio/interview-v22').glob('*.mp3'))
paths+=[site/'interview-v21.json',site/'interview-audio-v22.json']
paths+=[p for folder in ('scripts','assets') for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.startswith('.')]
target=root/'gospeak-v22-update.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(set(paths)): archive.write(file,file.relative_to(root))
assert target.stat().st_size<24_000_000
print(f'V22 patch: {target.stat().st_size:,} bytes. No personal recordings, photos or source PDF.')
