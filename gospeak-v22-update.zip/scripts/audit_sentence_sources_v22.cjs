/* Read-only provenance audit. Extract literal data, never run the application bundle.
 * Usage: node scripts/audit_sentence_sources_v22.cjs [_site]
 * JSON goes to stdout; no files or application state are changed.
 * Provenance is metadata/byte evidence, not an acoustic transcription guarantee.
 */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');

function sha(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function fileSha(filename) { return fs.existsSync(filename) ? sha(fs.readFileSync(filename)) : null; }

function literalAt(source, start) {
  const opening = source[start];
  if (opening !== '[' && opening !== '{') throw new Error('Expected object/array literal');
  const stack = [];
  let quote = null, escaped = false;
  for (let i = start; i < source.length; i++) {
    const ch = source[i];
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (ch === '\\') { escaped = true; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '`' || ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '[' || ch === '{') stack.push(ch);
    else if (ch === ']' || ch === '}') {
      const previous = stack.pop();
      if ((ch === ']' && previous !== '[') || (ch === '}' && previous !== '{')) throw new Error('Unbalanced literal');
      if (!stack.length) return { source: source.slice(start, i + 1), end: i + 1 };
    }
  }
  throw new Error('Unclosed literal');
}

function dataLiteral(source, marker) {
  const found = source.indexOf(marker);
  if (found < 0) throw new Error(`Missing literal marker: ${marker}`);
  const extracted = literalAt(source, found + marker.length);
  // Only the isolated data literal is evaluated, under a bounded empty context.
  if (extracted.source.includes('${')) throw new Error('Unexpected interpolation in data literal');
  return { value: vm.runInNewContext(`(${extracted.source})`, Object.create(null), { timeout: 1000 }), ...extracted };
}

function extractLegacyData(source) {
  return {
    lessons: dataLiteral(source, 'var e=').value,
    meanings: dataLiteral(source, '],t=').value,
    phonetics: dataLiteral(source, '},n=').value,
    grammar: dataLiteral(source, 'var a=').value,
  };
}

function buildAudit(sitePath) {
  const root = path.resolve(__dirname, '..');
  const site = path.resolve(sitePath || path.join(root, '_site'));
  const bundlePath = path.join(site, 'assets/index-C6MAz4Oq.js');
  const bundle = fs.readFileSync(bundlePath, 'utf8');
  const extracted = extractLegacyData(bundle);
  const originalRoot = path.resolve(root, '../../gospeak-mainland-week1');
  const originalSourcePath = path.join(originalRoot, 'src/course-data.ts');
  const originalSource = fs.readFileSync(originalSourcePath, 'utf8');
  const originalPhrases = [...originalSource.matchAll(/\{ en: '([^']+)', zh:/g)].map(m => m[1]);
  const flat = extracted.lessons.flatMap((lesson, day) => lesson.phrases.map((phrase, index) => ({ day: day + 1, sentence: index + 1, ...phrase })));
  if (originalPhrases.length !== flat.length) throw new Error('Current/original phrase counts differ');
  const audioByText = new Map();
  const lexicalSources = new Map();
  for (const filename of ['interview-v19.json', 'interview-v20.json', 'interview-v21.json']) {
    const payload = JSON.parse(fs.readFileSync(path.join(site, filename), 'utf8'));
    function walk(value, keypath) {
      if (!value || typeof value !== 'object') return;
      if (value.en && value.audio && value.audio.normal && !audioByText.has(value.en)) {
        audioByText.set(value.en, { audio: value.audio, source: `${filename}:${keypath}` });
      }
      for (const [key, item] of Object.entries(value)) walk(item, `${keypath}.${key}`);
    }
    walk(payload, '');
    for (const [word, item] of Object.entries(payload.lexicon || {})) {
      if (!lexicalSources.has(word)) lexicalSources.set(word, { ...item, source: `${filename}:lexicon.${word}` });
    }
  }
  const phrases = flat.map((phrase, index) => {
    const id = `p${String(index + 1).padStart(2, '0')}`;
    const currentPath = `./audio/${id}.mp3`;
    const originalAudio = path.join(originalRoot, 'public', currentPath);
    const currentSha256 = fileSha(path.join(site, currentPath));
    const originalSha256 = fileSha(originalAudio);
    const textChanged = phrase.en !== originalPhrases[index];
    const bytesStillOriginal = currentSha256 === originalSha256;
    const exact = audioByText.get(phrase.en);
    const chosen = textChanged && exact
      ? { ...exact.audio, provenance: exact.source }
      : { normal: currentPath, slow: currentPath, slowRate: .78, provenance: 'original src/course-data.ts + generate-course-audio.py + byte equality' };
    const tokens = phrase.en.match(/[A-Za-z]+(?:-[A-Za-z]+)?/g) || [];
    return {
      id, day: phrase.day, sentence: phrase.sentence, en: phrase.en, zh: phrase.zh, tip: phrase.tip,
      currentAudio: { src: currentPath, sha256: currentSha256 },
      originalGeneration: { text: originalPhrases[index], sha256: originalSha256, textChanged, bytesStillOriginal },
      confirmedStaleBySource: textChanged && bytesStillOriginal,
      recommendedAudio: { ...chosen, sha256: fileSha(path.join(site, chosen.normal)), exists: fs.existsSync(path.join(site, chosen.normal)) },
      ipaFromCurrentWordMap: tokens.map(w => extracted.phonetics[w.toLowerCase()] || '').filter(Boolean).join(' '),
      missingIPA: tokens.filter(w => !extracted.phonetics[w.toLowerCase()]),
      missingMeaning: tokens.filter(w => !extracted.meanings[w.toLowerCase()]),
      grammar: extracted.grammar[index],
    };
  });
  const words = [...new Set(flat.flatMap(p => p.en.match(/[A-Za-z]+(?:-[A-Za-z]+)?/g) || []).map(w => w.toLowerCase()))].sort().map(word => {
    const current = `./audio/words/${word}.mp3`;
    const exists = fs.existsSync(path.join(site, current));
    const fallback = lexicalSources.get(word);
    const chosen = exists ? current : fallback && fallback.src;
    return {
      word, zh: extracted.meanings[word] || null, ipa: extracted.phonetics[word] || null,
      currentAudio: current, exists,
      recommendedAudio: chosen || null,
      recommendedSha256: chosen ? fileSha(path.join(site, chosen)) : null,
      correctedMeaning: !extracted.meanings[word] && fallback ? fallback.zh : null,
      correctedIPA: !extracted.phonetics[word] && fallback ? fallback.ipa : null,
      fallbackSource: !exists && fallback ? fallback.source : null,
    };
  });
  return {
    caveat: 'Text and byte provenance only; not an acoustic transcription. Current original-source files are used as historical evidence, not changed.',
    bundle: bundlePath, bundleSha256: fileSha(bundlePath),
    originalGenerationSource: { path: originalSourcePath, sha256: fileSha(originalSourcePath), generator: path.join(originalRoot, 'scripts/generate-course-audio.py'), voice: 'en-US-EmmaNeural', rate: '-8%', stalePolicy: 'skips any existing MP3 larger than 1000 bytes, without comparing text' },
    summary: { phraseCount: phrases.length, wordCount: words.length, staleSentences: phrases.filter(p => p.confirmedStaleBySource).map(p => p.id), missingWordAudio: words.filter(w => !w.exists).map(w => w.word), missingMeanings: words.filter(w => !w.zh).map(w => w.word), missingIPA: words.filter(w => !w.ipa).map(w => w.word), allRecommendationsExist: phrases.every(p => p.recommendedAudio.exists) && words.every(w => w.recommendedSha256) },
    phrases, words,
  };
}

if (require.main === module) process.stdout.write(JSON.stringify(buildAudit(process.argv[2]), null, 2) + '\n');
module.exports = { literalAt, extractLegacyData, buildAudit };
