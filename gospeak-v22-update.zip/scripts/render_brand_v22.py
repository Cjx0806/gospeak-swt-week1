"""Render the small typographic app mark; no external image or font download."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/brand-v22'
OUT.mkdir(parents=True,exist_ok=True)
FONT='/System/Library/Fonts/STHeiti Medium.ttc'
for size,name in ((192,'icon-192.png'),(512,'icon-512.png'),(180,'apple-touch-icon.png')):
    image=Image.new('RGB',(size,size),'#173d2e')
    draw=ImageDraw.Draw(image)
    font=ImageFont.truetype(FONT,int(size*.54))
    draw.text((size/2,size/2),'出',font=font,fill='#ffffff',anchor='mm')
    image.save(OUT/name,optimize=True)
image=Image.new('RGB',(1200,630),'#f7f8f6')
draw=ImageDraw.Draw(image)
draw.rounded_rectangle((80,90,190,200),radius=24,fill='#173d2e')
draw.text((135,145),'出',font=ImageFont.truetype(FONT,62),fill='white',anchor='mm')
draw.text((80,268),'快乐出村计划',font=ImageFont.truetype(FONT,76),fill='#173d2e')
draw.text((84,400),'一句一句学，连起来说。',font=ImageFont.truetype(FONT,34),fill='#5a625d')
image.save(OUT/'og.png',optimize=True)
