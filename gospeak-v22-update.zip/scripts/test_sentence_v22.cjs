/* V22 real sentence-course bindings. Offline only: no browser, mic, network or user state. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const { extractLegacyData } = require('./audit_sentence_sources_v22.cjs');

const root = path.resolve(__dirname, '..');
const site = path.resolve(process.argv[2] || path.join(root, '_site'));
const source = fs.readFileSync(path.join(site, 'assets/index-C6MAz4Oq.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(site, 'lesson-audio-v22.json'), 'utf8'));
const original = cp.execFileSync('unzip', ['-p', path.join(root, 'gospeak-v21-update.zip'), '_site/assets/index-C6MAz4Oq.js'], { encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 });
const baseline = extractLegacyData(original);
const initial = extractLegacyData(source);

function fn(name) {
  const start = source.indexOf(`function ${name}(`);
  assert(start >= 0, `function ${name} exists in real bundle`);
  // i() is followed by large static data declarations, not another function.
  // Stop before that declaration so this test never initializes the app/DOM.
  // Every other selected function is adjacent to the next named function.
  const next = name === 'i' ? source.indexOf('var a=', start) : source.indexOf('function ', start + 9);
  assert(next > start, `function ${name} has a known boundary`);
  const declaration = source.slice(start, next).trim();
  assert(declaration.endsWith('}'), `function ${name} boundary ends at its body`);
  return declaration;
}

const dataStart = source.indexOf('/* BEGIN_V22_LESSON_DATA */');
const dataEnd = source.indexOf('/* END_V22_LESSON_DATA */');
assert(dataStart >= 0 && dataEnd > dataStart, 'V22 data has an auditable boundary');
assert(dataEnd < source.indexOf('try{b=Math.min'), 'course is extended before persisted day is clamped');
assert(dataEnd < source.indexOf('var K=[],Ne=new Set'), 'course is extended before vocabulary is indexed');
const dataInit = source.slice(dataStart, dataEnd);
const playerStart = source.indexOf('/* V19.2 replacement');
const playerEnd = source.indexOf('/* END_V19_2_LEGACY_AUDIO */');
assert(playerStart >= 0 && playerEnd > playerStart);
const player = source.slice(playerStart, playerEnd);
const urlStart = source.indexOf('var Me=');
const urlEnd = source.indexOf(',G=', urlStart);
assert(urlStart >= 0 && urlEnd > urlStart);

const storage = new Map();
const timers = new Map();
const listeners = new Map();
const documentListeners = new Map();
const activeResources = new Set();
const audios = [];
let timerID = 0, maximumResources = 0, renders = 0, lastHTML = '', recorder = null;
let mediaPermission = () => Promise.resolve({ getTracks() { return [{ stop() {} }]; } });
class FakeAudio {
  constructor(src) {
    this.src = src; this.currentTime = 0; this.readyState = 4; this.paused = true;
    this.ended = false; this.playCalls = 0; this.loadCalls = 0;
    activeResources.add(this); audios.push(this);
    maximumResources = Math.max(maximumResources, activeResources.size);
  }
  play() { this.paused = false; this.playCalls++; return Promise.resolve(); }
  pause() { this.paused = true; }
  removeAttribute(name) { if (name === 'src') { this.src = ''; activeResources.delete(this); } }
  load() { this.loadCalls++; }
}
class FakeRecognition {
  constructor() { recorder = this; }
  start() { this.started = true; if (this.onstart) this.onstart(); }
  stop() { this.stopped = true; }
  abort() { this.aborted = true; }
}
function node(dataset = {}) {
  const attributes = new Map(), classes = new Set(), icon = { textContent: '▶' };
  return {
    dataset, id: '', textContent: '', className: '', onclick: null, showModal() {}, close() {},
    classList: {
      toggle(name, force) { if (force) classes.add(name); else classes.delete(name); },
      contains(name) { return classes.has(name); },
      add(name) { classes.add(name); }, remove(name) { classes.delete(name); },
    },
    setAttribute(name, value) { attributes.set(name, value); }, getAttribute(name) { return attributes.get(name) ?? null; },
    querySelector(selector) { return dataset.word && selector === 'i' ? icon : null; },
    closest(selector) {
      return selector.split(',').some(part => {
        const simple = part.trim();
        return (simple.startsWith('#') && this.id === simple.slice(1)) ||
          (simple === '[data-view]' && this.dataset.view !== undefined) ||
          (simple === '[data-day]' && this.dataset.day !== undefined);
      }) ? this : null;
    },
    focus() { sandbox.document.activeElement = this; },
    remove() { for (const [key, value] of nodes) if (value === this) nodes.delete(key); },
  };
}
let nodes = new Map(), wordNodes = [], dayNodes = [], viewNodes = [];
const window = {
  __samMainlineV19: { isRecording() { return false; } },
  SpeechRecognition: FakeRecognition,
  scrollTo() {},
  dispatchEvent(event) { for (const callback of listeners.get(event.type) || []) callback(event); },
  addEventListener(name, callback) { if (!listeners.has(name)) listeners.set(name, []); listeners.get(name).push(callback); },
};
const sandbox = {
  e: initial.lessons, t: initial.meanings, n: initial.phonetics, a: initial.grammar,
  b: 0, C: 0, v: 'lesson', y: 0, x: 0, w: 'core', E: '', O: false, k: 'day', D: '', A: null,
  T: false, j: [], ee: Array(7).fill({}), window, Audio: FakeAudio, Promise, URL, Date,
  navigator: { mediaDevices: { getUserMedia() { return mediaPermission(); } } },
  localStorage: { getItem(key) { return storage.get(key) ?? null; }, setItem(key, value) { storage.set(key, value); } },
  document: {
    baseURI: 'https://example.test/gospeak-swt-week1/', activeElement: null, hidden: false,
    createElement(tag) { assert.equal(tag, 'button'); return node(); },
    addEventListener(name, callback) {
      if (!documentListeners.has(name)) documentListeners.set(name, []);
      documentListeners.get(name).push(callback);
    },
  },
  _: {
    querySelector(selector) { return nodes.get(selector) || null; },
    querySelectorAll(selector) { return selector === '[data-word]' ? wordNodes : selector === '[data-day]' ? dayNodes : selector === '[data-view]' ? viewNodes : []; },
    appendChild(element) { assert(element.id); nodes.set('#' + element.id, element); },
  },
  CustomEvent: class { constructor(type, options) { this.type = type; this.detail = options.detail; } },
  setTimeout(callback) { const id = ++timerID; timers.set(id, callback); return id; },
  clearTimeout(id) { timers.delete(id); },
  W(value) { return value.replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]); },
  we(expected, spoken) {
    const normalize = text => text.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();
    const words = normalize(expected).split(' ').filter(Boolean), actual = normalize(spoken).split(' ');
    const missing = words.filter(word => !actual.includes(word));
    return { score: Math.round((words.length - missing.length) / Math.max(words.length, 1) * 100), missing };
  },
  $() { render(); },
};
vm.createContext(sandbox);
vm.runInContext(dataInit, sandbox, { timeout: 1000 });
vm.runInContext(source.slice(urlStart, urlEnd) + ';\n' + player + '\n' + ['r', 'i', 'Le', 'qe', 'ze', 'ot', 'st'].map(fn).join('\n'), sandbox, { timeout: 1000 });
const recognitionStart = source.indexOf('/* V22: replace the compiled module');
const recognitionMarker = '/* END_V22_LESSON_RECOGNITION */';
const recognitionEnd = source.indexOf(recognitionMarker, recognitionStart);
assert(recognitionStart >= 0 && recognitionEnd > recognitionStart, 'V22 recognizer and helpers have an isolated auditable boundary');
const recognitionFragment = source.slice(recognitionStart, recognitionEnd + recognitionMarker.length);
assert(recognitionFragment.includes('async function ut()'), 'real fragment includes the original recognition entry point');
vm.runInContext(recognitionFragment, sandbox, { timeout: 1000 });

function render() {
  renders++;
  sandbox.document.activeElement = null;
  nodes = new Map(['#help', '#install-help', '#close-help', '#play-sentence', '#play-slow', '#play-normal', '#previous', '#next', '#record'].map(selector => {
    const element = node(); element.id = selector.slice(1); return [selector, element];
  }));
  const practice = node(), practiceTitle = node(), practiceHelp = node();
  practice.classList.toggle('listening', sandbox.T);
  practice.querySelector = selector => selector === 'h3' ? practiceTitle : selector === 'p' ? practiceHelp : null;
  nodes.set('.practice', practice);
  nodes.get('#record').disabled = sandbox.T;
  nodes.get('#record').textContent = sandbox.T ? '识别中' : '开始跟读';
  if (sandbox.D) { const stop = node(); stop.id = 'stop-audio'; nodes.set('#stop-audio', stop); }
  wordNodes = (sandbox.e[sandbox.b].phrases[sandbox.C].en.match(/[A-Za-z]+(?:-[A-Za-z]+)?/g) || []).map(word => node({ word: word.toLowerCase() }));
  dayNodes = sandbox.e.map((_, day) => node({ day: String(day) }));
  viewNodes = ['coach', 'lesson', 'vocab', 'camp', 'nce'].map(view => node({ view }));
  if (sandbox.v === 'lesson') lastHTML = sandbox.qe();
  sandbox.ot();
  if (sandbox.v === 'lesson') sandbox.st();
}
function click(element) {
  // Include window capture, where V22 cancels a pending/active recognition
  // before the actual legacy navigation handler changes the selected sentence.
  window.dispatchEvent({ type: 'click', target: element });
  if (element.onclick) return element.onclick();
}
function select(day, sentence) { sandbox.q(false); sandbox.v = 'lesson'; sandbox.b = day; sandbox.C = sentence; sandbox.E = ''; render(); }
function assertAudio(expected, rate, label) {
  assert(sandbox.A, `${label}: creates a player`);
  const actual = new URL(sandbox.A.src), wanted = new URL(expected, sandbox.document.baseURI);
  assert.equal(actual.pathname, wanted.pathname, `${label}: source matches exact displayed sentence/word`);
  assert.equal(actual.searchParams.get('v'), '22', `${label}: updated URL avoids obsolete browser cache`);
  assert.equal(sandbox.A.playbackRate, rate, `${label}: correct speed`);
  assert.equal(sandbox.A.loop, true, `${label}: loops until stopped`);
}

assert.equal(manifest.version, 'v22');
assert.equal(manifest.sentenceCount, 105);
assert.equal(manifest.sentences.length, 105);
assert.equal(sandbox.e.length, 21);
assert.equal(sandbox.a.length, 105);
assert.equal(Object.keys(manifest.words).length, manifest.wordCount);
const flattened = sandbox.e.flatMap(lesson => lesson.phrases);
assert.equal(flattened.length, 105);
assert(source.includes('function samRefreshLessonPlayback()'), 'local playback-state helper is shipped');
assert(source.includes('if (shouldRender) samRenderPlaybackState();'), 'ordinary stop avoids whole app rendering');

// Normal taps retain the expensive course subtree, including focused controls.
select(0, 0);
const focusedNormal = nodes.get('#play-normal'), retainedRecord = nodes.get('#record'), retainedNext = nodes.get('#next'), retainedWord = wordNodes[0];
const ordinaryRenders = renders;
focusedNormal.focus(); focusedNormal.onclick();
assert.equal(renders, ordinaryRenders, 'ordinary sentence play never calls full renderer');
assert.equal(nodes.get('#play-normal'), focusedNormal); assert.equal(nodes.get('#record'), retainedRecord); assert.equal(nodes.get('#next'), retainedNext);
assert.equal(sandbox.document.activeElement, focusedNormal, 'play keeps keyboard focus on the same button');
assert.equal(focusedNormal.textContent, '停止标准音'); assert.equal(focusedNormal.getAttribute('aria-pressed'), 'true');
assert.equal(nodes.get('#play-sentence').getAttribute('aria-label'), '停止整句循环');
assert(nodes.get('#stop-audio'), 'floating stop control is created without replacing the app');
const focusedSlow = nodes.get('#play-slow'); focusedSlow.focus(); focusedSlow.onclick();
assert.equal(renders, ordinaryRenders); assert.equal(sandbox.document.activeElement, focusedSlow);
assert.equal(focusedNormal.getAttribute('aria-pressed'), 'false'); assert.equal(focusedSlow.textContent, '停止慢速');
retainedWord.focus(); retainedWord.onclick();
assert.equal(wordNodes[0], retainedWord); assert.equal(renders, ordinaryRenders); assert.equal(sandbox.document.activeElement, retainedWord);
assert.equal(retainedWord.getAttribute('aria-pressed'), 'true'); assert.equal(retainedWord.querySelector('i').textContent, '■');
retainedWord.onclick();
assert.equal(sandbox.A, null); assert.equal(renders, ordinaryRenders, 'same-word stop keeps all course nodes');
assert.equal(sandbox.document.activeElement, retainedWord); assert.equal(retainedWord.querySelector('i').textContent, '▶');
assert.equal(retainedWord.getAttribute('aria-pressed'), 'false'); assert.equal(nodes.has('#stop-audio'), false);
focusedNormal.focus(); focusedNormal.onclick(); sandbox.A.onpause();
assert.equal(renders, ordinaryRenders, 'native pause also uses local state update');
assert.equal(nodes.get('#record'), retainedRecord); assert.equal(sandbox.document.activeElement, focusedNormal);
focusedNormal.onclick(); sandbox.A.onerror();
assert.equal(renders, ordinaryRenders + 1, 'real audio failure still renders actionable feedback');
assert(sandbox.E.includes('音频')); assert.notEqual(nodes.get('#record'), retainedRecord);
select(0, 0); let fallbackRenders = renders;
nodes.delete('#play-slow'); sandbox.q(); assert.equal(renders, fallbackRenders + 1, 'incomplete DOM falls back safely');
fallbackRenders = renders; nodes.get('#play-normal').classList.toggle = () => { throw new Error('test partial DOM'); };
sandbox.q(); assert.equal(renders, fallbackRenders + 1, 'unexpected partial DOM cannot strand the playback controls');
fallbackRenders = renders; sandbox.v = 'vocab'; sandbox.q(); assert.equal(renders, fallbackRenders + 1, 'non-lesson routes retain their established renderer');
select(0, 0);
for (let index = 0; index < 70; index++) {
  const old = baseline.lessons.flatMap(lesson => lesson.phrases)[index];
  assert.equal(flattened[index].en, old.en, `original phrase ${index + 1} unchanged`);
  assert.equal(flattened[index].zh, old.zh, `original translation ${index + 1} unchanged`);
  assert.equal(JSON.stringify(sandbox.a[index]), JSON.stringify(baseline.grammar[index]), `original grammar ${index + 1} unchanged`);
}
let checkedWords = 0;
for (let index = 0; index < 105; index++) {
  const day = Math.floor(index / 5), sentence = index % 5, phrase = flattened[index], entry = manifest.sentences[index];
  assert.equal(entry.day, day + 1); assert.equal(entry.sentence, sentence + 1); assert.equal(entry.en, phrase.en);
  assert.equal(entry.zh, phrase.zh); assert.equal(entry.audio.spokenText, phrase.en);
  assert.equal(sandbox.samLessonSources[phrase.en], entry.audio.src);
  const bytes = fs.readFileSync(path.join(site, entry.audio.src));
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), entry.audio.sha256, `MP3 hash: ${entry.id}`);
  select(day, sentence);
  assert(lastHTML.includes(`<h3>${phrase.en}</h3>`), `${entry.id}: text is rendered by original course template`);
  assert(lastHTML.includes('句子结构')); assert(lastHTML.includes('id="record"')); assert(lastHTML.includes('sentence-ipa'));
  assert(!lastHTML.includes('undefined')); assert(!lastHTML.includes('结合句子理解')); assert(!lastHTML.includes('<em>//</em>'));
  for (const [button, rate] of [['#play-sentence', 1], ['#play-slow', .78], ['#play-normal', 1]]) {
    sandbox.q(false); nodes.get(button).onclick(); assertAudio(entry.audio.src, rate, `${entry.id}/${button}`);
  }
  sandbox.q(false); render();
  for (const wordNode of [...wordNodes]) {
    const word = wordNode.dataset.word, record = manifest.words[word];
    assert(record && record.zh && record.ipa, `${word}: meaning and IPA exist`);
    assert.equal(sandbox.samWordSources[word], record.src);
    sandbox.q(false); wordNode.onclick(); assertAudio(record.src, 1, `${entry.id}/${word}`); checkedWords++;
  }
}
sandbox.q(false);
assert.equal(activeResources.size, 0); assert.equal(maximumResources, 1, 'only one audio resource remains active across all taps');

select(13, 4); nodes.get('#play-normal').onclick(); const day14Audio = sandbox.A;
nodes.get('#next').onclick(); assert.equal(sandbox.b, 14); assert.equal(sandbox.C, 0); assert.equal(sandbox.A, null); assert.equal(day14Audio.src, '');
assert.equal(storage.get('gospeak-lesson-day'), '14'); assert(lastHTML.includes('第三周')); assert(lastHTML.includes(flattened[70].en));
select(20, 4); const finalHTML = lastHTML; assert(/完成第三周|完成全部|三周完成/.test(finalHTML), 'last button describes all three weeks');
nodes.get('#play-normal').onclick(); const endAudio = sandbox.A;
nodes.get('#next').onclick(); assert.equal(sandbox.b, 20); assert.equal(sandbox.C, 4); assert.equal(sandbox.A, null); assert.equal(endAudio.src, '');
assert(!sandbox.E.includes('第二周的35'));
select(14, 2); nodes.get('#play-slow').onclick(); const previousAudio = sandbox.A;
nodes.get('#previous').onclick(); assert.equal(sandbox.C, 1); assert.equal(sandbox.A, null); assert.equal(previousAudio.src, '');
nodes.get('#play-sentence').onclick(); const changedDayAudio = sandbox.A;
dayNodes[20].onclick(); assert.equal(sandbox.b, 20); assert.equal(sandbox.C, 0); assert.equal(changedDayAudio.src, '');
nodes.get('#play-normal').onclick(); const changedViewAudio = sandbox.A;
viewNodes.find(item => item.dataset.view === 'coach').onclick(); assert.equal(sandbox.v, 'coach'); assert.equal(changedViewAudio.src, '');

const initStart = source.indexOf('try{b=Math.min'), initEnd = source.indexOf('try{x=', initStart);
assert(initStart >= 0 && initEnd > initStart);
storage.set('gospeak-lesson-day', '20'); sandbox.b = 7;
vm.runInContext(source.slice(initStart, initEnd), sandbox); assert.equal(sandbox.b, 20, 'reload keeps chosen third-week day');
select(14, 0); const nav = sandbox.Le();
assert.equal((nav.match(/data-day=/g) || []).length, 21); assert(nav.includes('第3周')); assert(nav.includes('二十一天') || nav.includes('21天'));
assert(source.includes('Day 1—Day 21'), 'vocabulary navigation includes third week');

async function settle() { for (let i = 0; i < 5; i++) await Promise.resolve(); }
(async () => {
  // Tests actual getUserMedia/recognition callbacks against the visible exercise.
  select(14, 0); const expected = flattened[70].en;
  click(nodes.get('#record')); await settle(); assert(recorder && recorder.started);
  const completedEnd = recorder.onend;
  recorder.onresult({ results: [[{ transcript: expected }]] });
  assert.equal(sandbox.j.at(-1), 100, 'new third-week sentence is recognition reference');
  completedEnd(); const scoreCount = sandbox.j.length;
  click(nodes.get('#record')); await settle(); const oldRecorder = recorder;
  const oldResult = oldRecorder.onresult, oldEnd = oldRecorder.onend;
  click(nodes.get('#next')); oldResult({ results: [[{ transcript: expected }]] });
  assert.equal(sandbox.j.length, scoreCount, 'late results do not score the newly selected sentence');
  assert.equal(oldRecorder.aborted, true, 'changing the sentence releases the old recognizer');
  oldEnd();
  let resolvePermission; mediaPermission = () => new Promise(resolve => { resolvePermission = resolve; });
  // A fresh permission check is normally needed only on first use or after a
  // permission/capture error. Force that branch for this delayed-grant test.
  sandbox.samLessonRecognitionStateV22.micReady = false;
  select(14, 0); const beforePermissionRecorder = recorder;
  click(nodes.get('#record'));
  assert.equal(sandbox.T, true, 'new third-week exercise locks immediately while permission is pending');
  assert.match(nodes.get('#record').textContent, /取消麦克风/);
  click(nodes.get('#next'));
  let lateTrackStopped = false;
  resolvePermission({ getTracks() { return [{ stop() { lateTrackStopped = true; } }]; } }); await settle();
  assert.equal(recorder, beforePermissionRecorder, 'late mic permission cannot start recognition for a different exercise');
  assert.equal(lateTrackStopped, true, 'late temporary microphone stream is stopped');
  assert.equal(sandbox.T, false, 'navigation never leaves the next exercise locked');
  sandbox.q(false);
  console.log(`PASS V22: 105 displayed sentences × 3 real audio buttons, ${checkedWords} word taps, preserved nodes/focus on play and stop, safe error fallback, original course, 21-day navigation/reload, loop release on navigation, new lesson recognition and stale-result guards. ${renders} mock renders; no microphone/network used.`);
})().catch(error => { console.error(error); process.exitCode = 1; });
