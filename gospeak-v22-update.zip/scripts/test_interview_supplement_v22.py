"""Offline checks for screenshot coverage, true facts and safe audio inputs."""
from __future__ import annotations

from copy import deepcopy
import json
import re
import unittest

import v21_curriculum as previous

ORIGINAL_QUESTIONS = deepcopy(previous.QUESTIONS)
ORIGINAL_SUPPLEMENTS = deepcopy(previous.SUPPLEMENTAL_QUESTIONS)

import v22_interview_supplement as course


def texts(lines):
    return [line["en"] for line in lines]


class InterviewSupplementTests(unittest.TestCase):
    def test_all_ten_source_questions_are_mapped_without_duplicating_intro(self):
        self.assertEqual(set(course.QUESTION_SOURCE_MAP), set(range(1, 11)))
        self.assertEqual(course.QUESTION_SOURCE_MAP[1], "01")
        self.assertEqual([q["id"] for q in course.SUPPLEMENTAL_QUESTIONS],
                         [f"i{n:02d}" for n in range(2, 11)])
        old_ids = {q["id"] for q in previous.QUESTIONS + previous.SUPPLEMENTAL_QUESTIONS}
        new_ids = {q["id"] for q in course.SUPPLEMENTAL_QUESTIONS}
        self.assertFalse(old_ids & new_ids)
        self.assertEqual(previous.QUESTIONS, ORIGINAL_QUESTIONS)
        self.assertEqual(previous.SUPPLEMENTAL_QUESTIONS, ORIGINAL_SUPPLEMENTS)
        for q in course.SUPPLEMENTAL_QUESTIONS:
            self.assertEqual(q["sourceNumbers"], [])
            self.assertEqual(q["sourceQuestions"], [])
            self.assertEqual(q["sourceId"], "user-image-10-questions")
            self.assertEqual(course.QUESTION_SOURCE_MAP[q["imageQuestionNumber"]], q["id"])

    def test_v21_card_and_sentence_contract(self):
        required = set(previous.q(1))
        for q in course.SUPPLEMENTAL_QUESTIONS:
            self.assertFalse(required - set(q), (q["id"], required - set(q)))
            self.assertTrue(q["question"] and q["questionZh"] and q["note"])
            self.assertEqual(bool(q["short"]), q["readyForAutoplay"])
            self.assertTrue(q["followups"])
            for followup in q["followups"]:
                self.assertTrue(followup["hint"])
                self.assertEqual(followup["assessmentMode"], "free")
            self.assertTrue(2 <= len(q["scaffold"]) <= 3)
        for sentence in course.all_sentences():
            self.assertEqual(sentence["id"], previous.sentence_id(sentence["en"]))
            self.assertTrue(sentence["en"] and sentence["zh"] and sentence["grammar"])
            self.assertTrue(sentence["chunks"] and sentence["pronunciation"])
            self.assertLessEqual(len(re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", sentence["en"])), 8,
                                 sentence["en"])
            self.assertTrue(sentence["ipa"], sentence["en"])
        self.assertTrue(course.validate())

    def test_known_profile_and_confirmed_swimming_are_exact(self):
        self.assertEqual(texts(course.question(2)["short"]),
                         ["I am a first-year student.", "My major is physical fitness training."])
        self.assertEqual(texts(course.question(3)["short"]),
                         ["Yes, they do.", "My parents are very supportive."])
        self.assertEqual(texts(course.question(4)["short"]),
                         ["I usually swim one thousand meters.", "I swim almost every day."])
        self.assertEqual(course.question(4)["branches"], [])
        self.assertNotIn("without stopping", " ".join(texts(course.question(4)["short"])))
        stopping = next(f for f in course.question(4)["followups"] if "without stopping" in f["en"])
        self.assertEqual(stopping["answer"], [])
        self.assertTrue(stopping["requiresConfirmation"])

    def test_confirmed_overseas_trips_and_ages(self):
        q = course.question(5)
        self.assertFalse(q["requiresConfirmation"])
        self.assertEqual(texts(q["short"]), ["Yes, I have.",
            "I have been to Malaysia and Singapore.", "I have also visited South Korea."])
        followups = {f["en"]: texts(f["answer"]) for f in q["followups"]}
        self.assertEqual(followups["Which other countries have you visited?"],
                         ["I have visited Indonesia and Vietnam."])
        for country, expected in {
            "Malaysia": "I went there at sixteen and seventeen.",
            "Indonesia": "I was seventeen.", "Singapore": "I was seventeen.",
            "Vietnam": "I was eighteen.", "South Korea": "I was nineteen.",
        }.items():
            self.assertEqual(followups[f"When did you visit {country}?"], [expected])
        self.assertNotIn("I have not been overseas yet.", texts(course.all_sentences()))

    def test_passport_is_not_inferred_from_overseas_travel(self):
        q = course.question(6)
        self.assertTrue(q["requiresConfirmation"])
        self.assertFalse(q["readyForAutoplay"])
        self.assertEqual(q["short"], [])
        self.assertEqual({b["id"] for b in q["branches"]}, {"yes", "no", "applying"})
        for branch in q["branches"]:
            self.assertFalse(branch["confirmed"])
            self.assertFalse(branch["readyForAutoplay"])
            self.assertTrue(branch["requiresConfirmation"])
            self.assertTrue(branch["condition"])
            self.assertIsNone(branch["fullAudio"])
            self.assertEqual(len(branch["sentences"]), 2)
        validity = q["followups"][0]
        self.assertTrue(validity["requiresConfirmation"])
        self.assertEqual(validity["answer"], [])

    def test_domestic_followup_chain_preserves_hainan_as_a_place(self):
        self.assertEqual(texts(course.question(7)["short"]),
                         ["Yes, I have.", "I have visited many cities in China."])
        cities = next(f for f in course.question(7)["followups"] if "Which cities" in f["en"])
        self.assertEqual(texts(cities["answer"]),
                         ["I have visited Beijing and Shanghai.", "I have visited Guangzhou and Shenzhen."])
        self.assertTrue(any(f.get("relatedQuestionId") == "i08" for f in course.question(7)["followups"]))
        self.assertTrue(any(f.get("relatedQuestionId") == "i09" for f in course.question(8)["followups"]))
        q = course.question(8)
        self.assertEqual(q["question"], "Which place do you like best?")
        self.assertEqual(q["sourceQuestion"], "Which city do you like best among them?")
        self.assertEqual(texts(q["short"]), ["I like Hainan Island best.", "I cycled around the island."])
        self.assertIn("不是城市", q["note"])
        strict_city = next(f for f in q["followups"] if f["en"] == "Which city do you like best?")
        self.assertTrue(strict_city["requiresConfirmation"])
        self.assertEqual(strict_city["answer"], [])
        reason = course.question(9)
        self.assertEqual(reason["sourceQuestion"], "Why do you like this city?")
        self.assertEqual(reason["question"], "Why do you like Hainan?")
        self.assertEqual(texts(reason["short"]), ["I cycled around Hainan Island."])
        self.assertTrue(reason["needsReasonDetail"])
        self.assertEqual(reason["dependsOnQuestionIds"], ["i07", "i08"])
        self.assertFalse(any(word in " ".join(texts(reason["short"])).lower()
                             for word in ["beautiful", "special", "enjoyed", "food"]))

    def test_career_is_instructor_and_return_to_college_remains_distinct(self):
        self.assertEqual(texts(course.question(10)["short"]),
                         ["I want to be a swimming instructor.", "I want to teach people to swim."])
        return_followup = course.question(10)["followups"][0]
        self.assertEqual(return_followup["relatedQuestionId"], "s03")
        self.assertEqual(texts(return_followup["answer"]),
                         ["I will return to China after SWT.", "I will continue my studies."])
        self.assertNotIn("lifeguard", " ".join(texts(course.question(10)["short"])))

    def test_unknown_detail_followups_have_no_fabricated_answer(self):
        unknown = [(q["id"], f) for q in course.SUPPLEMENTAL_QUESTIONS for f in q["followups"]
                   if f["requiresConfirmation"]]
        self.assertGreaterEqual(len(unknown), 5)
        for question_id, followup in unknown:
            self.assertEqual(followup["answer"], [], (question_id, followup["en"]))

    def test_any_new_unfilled_slot_has_no_audio_ipa_or_scoring(self):
        # Confirmed distances/cities no longer contain placeholders. Keep the
        # safety contract for any future unconfirmed personalization field.
        example = course.slot("I can swim [distance] meters.", "我能游[距离]米。", distance="真实距离")
        self.assertIsNone(example["audio"])
        self.assertFalse(example["audioEligible"])
        self.assertFalse(example["assessmentEnabled"])
        self.assertTrue(example["needsPersonalization"])
        self.assertEqual(example["ipa"], "")
        self.assertEqual(example["slots"], [{"key": "distance", "label": "真实距离", "value": None, "confirmed": False}])
        self.assertEqual([s for s in course.all_sentences() if "[" in s["en"]], [])

    def test_every_answer_word_has_chinese_and_ipa(self):
        tokens = set()
        for sentence in course.all_sentences():
            tokens.update(w.lower() for w in re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", sentence["en"]))
        self.assertFalse(tokens - set(course.EXTRA_WORDS))
        for word in tokens:
            self.assertTrue(course.EXTRA_WORDS[word]["zh"], word)
            self.assertTrue(course.EXTRA_WORDS[word]["ipa"], word)
        for proper_word in ["malaysia", "singapore", "indonesia", "vietnam", "south", "korea",
                            "sixteen", "seventeen", "eighteen", "nineteen", "hainan", "island",
                            "beijing", "shanghai", "guangzhou", "shenzhen", "thousand", "instructor"]:
            self.assertIn(proper_word, tokens)
        json.dumps({"questions": course.SUPPLEMENTAL_QUESTIONS,
                    "map": course.QUESTION_SOURCE_MAP, "words": course.EXTRA_WORDS}, ensure_ascii=False)


if __name__ == "__main__":
    unittest.main()
