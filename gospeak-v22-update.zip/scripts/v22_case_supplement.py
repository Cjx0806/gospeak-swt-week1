"""Eight missing topics from Sam's two interview-question screenshots.

The A (6 questions) and B (19 questions) lists are practice references, not an
exam forecast. Existing main questions and follow-ups are mapped, not copied.
Answers are short teaching examples. Current *biggest* pressure and food
preferences need confirmation; a hypothetical action is not a past experience.
This module never mutates V21 or the separate i02–i10 image-question supplement.
"""
from __future__ import annotations

from copy import deepcopy
import json
import re

import v21_curriculum as previous
from v22_week3 import WORDS as WEEK3_WORDS

S = previous.S
TOKENS = r"[A-Za-z]+(?:['’-][A-Za-z]+)*"


def choice(id, label, condition, sentences):
    result = previous.branch(id, label, condition, sentences)
    result.update({"requiresConfirmation": True, "readyForAutoplay": False,
                   "fullAudio": None})
    return result


def slot(en, zh, key, label):
    result = previous.template(en, zh)
    result.update({"audio": None, "audioEligible": False,
                   "assessmentEnabled": False,
                   "slots": [{"key": key, "label": label, "value": None,
                              "confirmed": False}]})
    return result


def card(id, title, question, zh, scaffold, intent, *, short=(), branches=(), category="SWT 项目"):
    ready = bool(short)
    return {
        "id": id, "title": title, "question": question, "questionZh": zh,
        "category": category, "sourceNumbers": [], "sourceQuestions": [],
        "sourceId": "user-two-question-lists", "priority": "先练",
        "examinerIntent": intent, "intent": intent,
        "scaffold": list(scaffold), "keywords": list(scaffold),
        "short": deepcopy(list(short)), "extra": [], "variants": [],
        "followups": [], "branches": deepcopy(list(branches)),
        "requiresConfirmation": not ready, "readyForAutoplay": ready,
        "answerType": "short-beginner" if ready else "confirm-facts-first",
        "relatedLessons": [],
        "learningGoal": "先听清问什么，再用 2—3 个短句回答这一题。",
        "connectionTip": "说完一句轻停，再接下一句；不需要把所有准备内容一次说完。",
        "note": ("情景表达，可根据实际调整；不是过去经历，也不是唯一标准答案。" if ready else
                 "先确认符合自己的真实情况，再使用示例；方括号未填完不能播放或评分。"),
    }


FAST_ENGLISH = S("Fast English may be hard for me.", "语速快的英语对我可能比较难。",
                 "fæst ˈɪŋɡlɪʃ meɪ bi hɑrd fər mi",
                 "Fast English 主语；may be 表示可能；hard 表语；for me 表示对我而言。")
ASK_SLOW = S("I would ask people to speak slowly.", "我会请对方说慢一点。",
             "aɪ wʊd æsk ˈpipəl tə spik ˈsloʊli",
             "I 主语＋would ask 谓语＋people 宾语；to speak slowly 是希望对方做的事。would 表示假设情景中的做法。")
LEARN_CUSTOMS = S("I would learn about local customs.", "我会了解当地习俗。",
                 "aɪ wʊd lɝn əˈbaʊt ˈloʊkəl ˈkʌstəmz",
                 "I 主语＋would learn about 谓语短语＋local customs 宾语；local 修饰 customs。")
ASK_POLITELY = S("I would ask questions politely.", "我会礼貌地提问。",
                "aɪ wʊd æsk ˈkwɛstʃənz pəˈlaɪtli",
                "I 主语＋would ask 谓语＋questions 宾语；politely 说明提问方式。")
INTERVIEW_PRESSURE = S("My English interview worries me most.", "英语口测是我目前最担心的事。",
                      "maɪ ˈɪŋɡlɪʃ ˈɪntərvju ˈwɝiz mi moʊst",
                      "My English interview 主语＋worries 谓语＋me 宾语；most 表示最，只有符合真实情况才这样说。")
PRACTICING = S("I am practicing short answers.", "我正在练习简短回答。",
              "aɪ æm ˈpræktɪsɪŋ ʃɔrt ˈænsərz",
              "I 主语＋am practicing 现在进行时谓语＋short answers 宾语。")
WORKING_ON_IT = S("I am working on it.", "我正在努力处理这件事。",
                 "aɪ æm ˈwɝkɪŋ ɑn ɪt",
                 "I 主语＋am working on 谓语短语＋it 宾语；it 指前一句说的困难。")
SIMPLE_WORDS = S("I would use simple words.", "我会用简单的词表达。",
                "aɪ wʊd juz ˈsɪmpəl wɝdz",
                "I 主语＋would use 谓语＋simple words 宾语；simple 修饰 words。")
ANOTHER_WAY = S("I would try another way.", "我会换一种方式表达。",
               "aɪ wʊd traɪ əˈnʌðər weɪ",
               "I 主语＋would try 谓语＋another way 宾语；another 表示另一种。")
DUMPLINGS = S("I would recommend dumplings.", "我会推荐饺子。",
             "aɪ wʊd ˌrɛkəˈmɛnd ˈdʌmplɪŋz",
             "I 主语＋would recommend 谓语＋dumplings 宾语；这是推荐示例，不表示会做饺子。")
FILLINGS = S("They can have meat or vegetables.", "饺子可以有肉馅，也可以有蔬菜馅。",
            "ðeɪ kən hæv mit ɔr ˈvɛdʒtəbəlz",
            "They 主语指饺子＋can have 谓语＋meat or vegetables 并列宾语；can 表示可能的馅料，不是所有饺子都相同。")
DIFFERENCES = S("Food and daily routines may be different.", "饮食和日常作息可能有所不同。",
               "fud ænd ˈdeɪli ruˈtinz meɪ bi ˈdɪfrənt",
               "Food and daily routines 并列主语；may be 表示可能；different 表语。不是对两国所有人的统一判断。")
LEARN_PROGRAM = S("I want to learn through this program.", "我想通过这个项目进一步了解。",
                 "aɪ wɑnt tə lɝn θru ðɪs ˈproʊɡræm",
                 "I 主语＋want 谓语；to learn 表示想做的事；through this program 说明途径。")
CULTURAL_EXCHANGE = S("I am interested in cultural exchange.", "我对文化交流感兴趣。",
                      "aɪ æm ˈɪntrəstɪd ɪn ˈkʌltʃərəl ɪksˈtʃeɪndʒ",
                      "I 主语＋am 系动词＋interested in cultural exchange 表语；be interested in 表示对……感兴趣。")
LEARN_CULTURE = S("I want to learn about American culture.", "我想了解美国文化。",
                 "aɪ wɑnt tə lɝn əˈbaʊt əˈmɛrɪkən ˈkʌltʃər",
                 "I 主语＋want 谓语；to learn about American culture 表示想做的事。")
CAREFUL_WORK = S("I would do my work carefully.", "我会认真完成工作。",
                "aɪ wʊd du maɪ wɝk ˈkɛrfəli",
                "I 主语＋would do 谓语＋my work 宾语；carefully 说明做事方式。这是计划做法，不是已发生的工作经历。")


CASE_QUESTIONS = [
    card("c01", "预计在美国遇到的困难", "What difficulties might you face in the U.S.?",
         "你觉得在美国可能遇到什么困难？", ["英语语速可能较快", "会请对方慢一点"],
         "先指出一种可能的困难，再说应对办法；不要只背‘遇到困难怎么办’。",
         short=[FAST_ENGLISH, ASK_SLOW]),
    card("c02", "适应不同文化和地区", "How would you adapt to a different culture?",
         "你会怎样适应不同的文化？", ["了解习俗", "礼貌提问", "尊重习惯"],
         "说可以采取的具体行动，不假装已经熟悉美国各地，也不评价哪个文化更好。",
         short=[LEARN_CUSTOMS, ASK_POLITELY, *previous.take("room_respect")]),
    card("c03", "目前最大的压力", "What is your biggest source of stress now?",
         "你目前最大的压力是什么？", ["确认真正最大的压力", "说正在怎样处理"],
         "这是当前个人感受，不是‘能否承受工作压力’；英语口测只是一种待确认答案。",
         category="个人介绍", branches=[
             choice("english-interview", "英语口测是最大压力（真实才选）",
                    "只有你认为英语口测确实是目前最担心的事，而且正在练习时选择。",
                    [INTERVIEW_PRESSURE, PRACTICING]),
             choice("other", "其他压力：先填真实内容",
                    "填写目前真正最大的压力；第二句也仅在确实正在处理时使用。",
                    [slot("My biggest worry is [topic].", "我最担心的是[真实事情]。", "topic", "目前真正最担心的事"), WORKING_ON_IT]),
         ]),
    card("c04", "英语不够时怎样表达", "What if you cannot express your ideas clearly?",
         "如果你不能清楚表达自己的想法，怎么办？", ["用简单词", "换种表达", "需要时求助"],
         "题目问‘说不出来’；回答换词、换说法和求助。听不懂时再使用慢说或重复请求。",
         short=[SIMPLE_WORDS, ANOTHER_WAY, *previous.take("help")]),
    card("c05", "推荐一道中国菜", "What Chinese dish would you recommend?",
         "你会推荐哪一道中国菜？", ["选择自己愿意介绍的菜", "简单说明是什么"],
         "先选一道具体食物；饺子只是可选示例，不编造会做、常吃或家乡特产等经历。",
         category="美国生活", branches=[
             choice("dumplings", "示例：我愿意推荐饺子",
                    "仅当你愿意推荐饺子，并理解馅料可不同，才选择；不表示你会做饺子。",
                    [DUMPLINGS, FILLINGS]),
             choice("other-dish", "我想推荐别的菜：先填写",
                    "填写自己了解且愿意推荐的菜，并核对实际主要食材。",
                    [slot("I would recommend [dish].", "我会推荐[菜名]。", "dish", "想推荐的中国菜英文名"),
                     slot("It has [ingredients].", "它有[主要食材]。", "ingredients", "这道菜实际使用的主要食材")]),
         ]),
    card("c06", "中美日常生活的差异", "What differences might you notice in daily life?",
         "你觉得中美日常生活可能有什么不同？", ["饮食和作息可能不同", "通过项目进一步了解"],
         "给出谨慎的观察方向；不声称有美国生活经历，不把所有中国人或美国人说成一样。",
         category="美国生活", short=[DIFFERENCES, LEARN_PROGRAM]),
    card("c07", "对项目哪部分感兴趣", "Which part of SWT interests you most, and why?",
         "SWT 的哪部分最让你感兴趣？为什么？", ["文化交流", "想了解美国文化"],
         "先指出具体部分，再给一个简单理由；这里使用你已说明的文化兴趣，可按真实偏好调整。",
         short=[CULTURAL_EXCHANGE, LEARN_CULTURE]),
    card("c08", "对整个项目的计划", "What are your plans for the SWT program?",
         "你对 SWT 项目有什么计划？", ["认真工作", "参加文化活动", "项目后回国"],
         "回答项目内打算做什么，再说已确认的回国安排；不猜未确定日期或承诺长期留美工作。",
         short=[CAREFUL_WORK, *previous.take("local_events", "return")]),
]

# Different superlative wording changes the answer focus. Keep the hint so the
# UI does not mistake it for an interchangeable, identical-intent question.
CASE_QUESTIONS[0]["variants"] = [{
    "en": "What might be your biggest challenge in the U.S.?",
    "zh": "在美国，什么可能是你最大的挑战？",
    "hint": "biggest 问最大的困难；只有确实认为英语是主要障碍时用本题短答，其他情况应说真实困难。",
}]
CASE_QUESTIONS[5]["variants"] = [{
    "en": "What is the biggest difference between daily life in China and the U.S.?",
    "zh": "你认为中美日常生活最大的差异是什么？",
    "hint": "没有亲身了解时，可以谨慎说可能的差异和想进一步了解，不必编造一个确定的‘最大差异’。",
}]
CASE_QUESTIONS[0]["relatedLessons"] = [previous.lesson(5, 2, "请对方慢一点")]
CASE_QUESTIONS[1]["relatedLessons"] = [previous.lesson(10, 4, "尊重不同文化")]
CASE_QUESTIONS[3]["relatedLessons"] = [previous.lesson(5, 1, "听不懂时请求重复")]
CASE_QUESTIONS[4]["relatedLessons"] = [previous.lesson(13, 4, "分享中国文化")]
CASE_QUESTIONS[6]["relatedLessons"] = [previous.lesson(4, 1, "了解美国文化")]
CASE_QUESTIONS[7]["relatedLessons"] = [previous.lesson(9, 5, "项目期间的安排"), previous.lesson(14, 1, "回国继续学业")]


def mapped(number, source_question, question_id, *, related=(), followup=None, variant=None, note=""):
    result = {"number": number, "sourceQuestion": source_question, "questionId": question_id,
              "relatedQuestionIds": list(related)}
    if followup is not None:
        result["followupIndex"] = followup
    if variant is not None:
        result["variantIndex"] = variant
    if note:
        result["note"] = note
    return result


# Entries point to the actual existing card or its zero-based follow-up/variant.
# Related IDs are extra practice, never an instruction to recite several answers.
CASE_SOURCE_MAP = {
    "A": {
        "title": "用户提供的 6 题口测清单", "count": 6,
        "items": [
            mapped(1, "自我介绍", "01"),
            mapped(2, "你觉得你在美国会遇到哪些问题", "c01", related=["18"]),
            mapped(3, "你觉得你可以应对不同文化和不同地区吗", "c02", related=["27"]),
            mapped(4, "你最喜欢的工作是什么", "s01", note="复用真实救生员岗位意向；不把意向当成已有工作经验。"),
            mapped(5, "为什么想参加 SWT", "15"),
            mapped(6, "你目前最大的压力是什么", "c03"),
        ],
    },
    "B": {
        "title": "用户提供的 19 题口测清单", "count": 19,
        "items": [
            mapped(1, "自我介绍，包括姓名、大学、专业、性格", "01", related=["02", "03", "07"], note="性格在 07 题选择真实分支后补充；不虚构性格。"),
            mapped(2, "为什么想参加这个项目", "15"),
            mapped(3, "你有什么爱好", "04"),
            mapped(4, "为什么选择这个项目来美国", "16", related=["15"]),
            mapped(5, "如果犯了错误影响同事怎么办", "25", related=["14"], note="复用犯错题的报告、补救和改进；涉及同事时应承认影响并道歉。"),
            mapped(6, "语言不通，不能表达自己的想法怎么办", "c04", related=["18"]),
            mapped(7, "你想通过项目获得什么", "17"),
            mapped(8, "你去旅游过吗", "i05", related=["i07", "i08", "i09", "26"], note="泛问旅行可用已确认的出国旅行；国内城市与独自旅行分别回答。"),
            mapped(9, "有没有兼职过", "08", note="先确认有没有真实兼职；持有救生员证不等于工作过。"),
            mapped(10, "你具备什么去美国的品质", "06", related=["07", "14"], note="选真实优点和做法，不把准备态度当作已证实的经历。"),
            mapped(11, "和同事有冲突怎么办", "14", followup=0, note="已存在的追问含先听、礼貌解释、必要时求助三句，不另复制一张。"),
            mapped(12, "推荐一道菜给美国人", "c05", related=["20"]),
            mapped(13, "在美国最大的障碍是什么", "c01", variant=0, related=["s02"], note="只说自己真实认为的主要困难。"),
            mapped(14, "想要的岗位是什么", "s01"),
            mapped(15, "说一下你的优点和缺点", "06", related=["s02"], note="分别选一个真实优点和一个正在改善的困难；不把两题完整长答拼接。"),
            mapped(16, "项目期间怎么改善缺点", "19", related=["s02"], note="当前确认的困难是英语；19 题提供未来行动，s02 题说明困难和已有进步。"),
            mapped(17, "中美日常生活最大的不同", "c06", variant=0),
            mapped(18, "对项目哪部分最感兴趣，为什么", "c07"),
            mapped(19, "你对项目有什么计划", "c08", related=["s03", "29"]),
        ],
    },
}


# Include every spoken-answer token and question token with contextual Chinese
# and rhotic American IPA. Blank personalization slots are never guessed.
_ADDITIONAL_WORDS = [
    ("adapt", "适应", "əˈdæpt"), ("am", "是；用于 I", "æm"),
    ("american", "美国的", "əˈmɛrɪkən"), ("and", "和；并且", "ænd"),
    ("another", "另一种；另一个", "əˈnʌðər"), ("answers", "回答（复数）", "ˈænsərz"),
    ("are", "是；用于 you 或复数", "ɑr"), ("be", "是；处于某种状态", "bi"),
    ("between", "在两者之间", "bɪˈtwin"), ("biggest", "最大的", "ˈbɪɡəst"),
    ("cannot", "不能", "ˈkænɑt"), ("carefully", "认真地；仔细地", "ˈkɛrfəli"),
    ("challenge", "挑战", "ˈtʃælɪndʒ"), ("clearly", "清楚地", "ˈklɪrli"),
    ("cultural", "文化的", "ˈkʌltʃərəl"), ("customs", "习俗（复数）", "ˈkʌstəmz"),
    ("daily", "日常的；每天的", "ˈdeɪli"), ("difference", "差异；不同", "ˈdɪfrəns"),
    ("differences", "差异（复数）", "ˈdɪfrənsɪz"), ("different", "不同的", "ˈdɪfrənt"),
    ("difficulties", "困难（复数）", "ˈdɪfɪkəltiz"), ("dish", "一道菜", "dɪʃ"),
    ("dumplings", "饺子（复数）", "ˈdʌmplɪŋz"), ("exchange", "交流", "ɪksˈtʃeɪndʒ"),
    ("express", "表达", "ɪkˈsprɛs"), ("face", "面对；面临", "feɪs"),
    ("fast", "快的；语速快的", "fæst"), ("habits", "习惯（复数）", "ˈhæbɪts"),
    ("hard", "困难的", "hɑrd"), ("has", "有（用于第三人称单数）", "hæz"),
    ("have", "有", "hæv"), ("ideas", "想法（复数）", "aɪˈdiəz"),
    ("if", "如果", "ɪf"), ("interested", "感兴趣的", "ˈɪntrəstɪd"),
    ("interests", "使……感兴趣", "ˈɪntrəsts"), ("interview", "面试；口测", "ˈɪntərvju"),
    ("is", "是；用于第三人称单数", "ɪz"), ("join", "参加", "dʒɔɪn"),
    ("life", "生活", "laɪf"), ("local", "当地的", "ˈloʊkəl"),
    ("may", "可能", "meɪ"), ("meat", "肉", "mit"),
    ("might", "可能", "maɪt"), ("most", "最；最大的程度", "moʊst"),
    ("notice", "注意到", "ˈnoʊtɪs"), ("now", "现在；目前", "naʊ"),
    ("or", "或者", "ɔr"), ("part", "部分", "pɑrt"),
    ("people", "人们；对方", "ˈpipəl"), ("plans", "计划（复数）", "plænz"),
    ("politely", "礼貌地", "pəˈlaɪtli"), ("practicing", "正在练习", "ˈpræktɪsɪŋ"),
    ("questions", "问题（复数）", "ˈkwɛstʃənz"), ("recommend", "推荐", "ˌrɛkəˈmɛnd"),
    ("return", "返回", "rɪˈtɝn"), ("routines", "日常作息；惯常安排", "ruˈtinz"),
    ("s", "字母 S（U.S. 中的一部分）", "ɛs"), ("short", "简短的", "ʃɔrt"),
    ("simple", "简单的", "ˈsɪmpəl"), ("slowly", "慢慢地", "ˈsloʊli"),
    ("source", "来源", "sɔrs"), ("speak", "说话", "spik"),
    ("stress", "压力", "strɛs"), ("swt", "暑期工作旅行项目缩写", "ˌɛs ˌdʌbəlju ˈti"),
    ("their", "他们的", "ðɛr"), ("they", "他们；它们", "ðeɪ"),
    ("through", "通过", "θru"), ("u", "字母 U（U.S. 中的一部分）", "ju"),
    ("vegetables", "蔬菜（复数）", "ˈvɛdʒtəbəlz"), ("way", "方式", "weɪ"),
    ("which", "哪一个", "wɪtʃ"), ("why", "为什么", "waɪ"),
    ("working", "正在努力做；正在工作", "ˈwɝkɪŋ"), ("worries", "使……担心", "ˈwɝiz"),
    ("worry", "担心的事", "ˈwɝi"), ("your", "你的", "jʊr"),
    ("activities", "活动（复数）", "ækˈtɪvətiz"), ("of", "……的", "əv"),
]
_VOCABULARY = deepcopy(WEEK3_WORDS)
_VOCABULARY.update({word: {"zh": zh, "ipa": ipa} for word, zh, ipa in _ADDITIONAL_WORDS})


def all_sentences():
    for question in CASE_QUESTIONS:
        yield from question["short"]
        for branch in question["branches"]:
            yield from branch["sentences"]


_TEXTS = [q["question"] for q in CASE_QUESTIONS]
_TEXTS += [v["en"] for q in CASE_QUESTIONS for v in q["variants"]]
_TEXTS += [line["en"] for line in all_sentences()]
_USED = {word.lower().replace("’", "'") for text in _TEXTS
         for word in re.findall(TOKENS, re.sub(r"\[[^]]*\]", "", text))}
CASE_WORDS = {word: deepcopy(_VOCABULARY[word]) for word in sorted(_USED)}


def validate():
    assert len(CASE_QUESTIONS) == 8
    assert len({q["id"] for q in CASE_QUESTIONS}) == 8
    existing_ids = {q["id"] for q in previous.QUESTIONS + previous.SUPPLEMENTAL_QUESTIONS}
    ids = existing_ids | {f"i{n:02d}" for n in range(2, 11)} | {q["id"] for q in CASE_QUESTIONS}
    assert not existing_ids.intersection(q["id"] for q in CASE_QUESTIONS)
    for letter, count in (("A", 6), ("B", 19)):
        group = CASE_SOURCE_MAP[letter]
        assert group["count"] == len(group["items"]) == count
        assert [row["number"] for row in group["items"]] == list(range(1, count + 1))
        for row in group["items"]:
            assert row["questionId"] in ids
            assert all(id in ids for id in row["relatedQuestionIds"])
            if "followupIndex" in row:
                question = next(q for q in previous.QUESTIONS if q["id"] == row["questionId"])
                assert 0 <= row["followupIndex"] < len(question["followups"])
    for question in CASE_QUESTIONS:
        assert question["requiresConfirmation"] == (question["id"] in {"c03", "c05"})
        assert bool(question["short"]) == question["readyForAutoplay"]
        if question["short"]:
            assert 2 <= len(question["short"]) <= 3
        for branch in question["branches"]:
            assert not branch["confirmed"] and branch["condition"]
            assert 2 <= len(branch["sentences"]) <= 3
    for line in all_sentences():
        assert len(re.findall(TOKENS, line["en"])) <= 8, line["en"]
        assert line["zh"] and line["chunks"]
        if "[" in line["en"]:
            assert line["needsPersonalization"] and line["slots"]
            assert not line["audioEligible"] and not line["assessmentEnabled"]
        else:
            assert line["ipa"] and line["grammar"]
        assert line["id"] == previous.sentence_id(line["en"])
    assert all(value["zh"] and value["ipa"] for value in CASE_WORDS.values())
    return True


validate()
if __name__ == "__main__":
    print(json.dumps({"questions": CASE_QUESTIONS, "sourceMap": CASE_SOURCE_MAP,
                      "words": CASE_WORDS}, ensure_ascii=False, indent=2))
