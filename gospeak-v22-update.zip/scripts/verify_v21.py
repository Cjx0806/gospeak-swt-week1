"""V21 publication gate: distinct modes, genuine PDF coverage, existing lesson preserved."""
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit, parse_qs
from mutagen.mp3 import MP3
from verify_v20 import References


def verify(root, shell_version='21', check_original_shell=True):
    root = Path(root).resolve()
    data = json.loads((root/'interview-v21.json').read_text())
    assert data['version'] == 'v21' and data['audioReady'] is True
    primary = [q for q in data['questions'] if q['id'].isdigit()]
    assert [q['id'] for q in primary] == [f'{i:02d}' for i in range(1,31)]
    assert len({q['id'] for q in data['questions']}) == len(data['questions'])
    assert data['profile']['englishName'] == 'Sam'
    assert data['profile']['majorZh'] == '体育体能训练'
    assert data['profile']['schoolZh'] == '广西幼儿师范高等专科学校'
    assert '未' in data['profile']['returnPlan']
    durations = {}

    def mp3(src):
        assert src.startswith('./audio/') and not urlsplit(src).query, src
        path = (root/src).resolve()
        assert path.is_relative_to(root/'audio') and path.is_file(), src
        if src not in durations: durations[src] = MP3(path).info.length
        assert math.isfinite(durations[src]) and durations[src] > 0

    def walk(value):
        if isinstance(value, dict):
            for key, val in value.items():
                if key in ('src','normal','slow') and isinstance(val,str) and val.endswith('.mp3'): mp3(val)
                else: walk(val)
        elif isinstance(value, list):
            for val in value: walk(val)

    def audio(value):
        assert value and value['normal'] and value['slow']
        assert .5 <= value['slowRate'] <= 1
        mp3(value['normal']); mp3(value['slow'])

    for q in data['questions']:
        for field in ('question','questionZh','intent','category','scaffold'): assert q[field], (q['id'],field)
        related=q.get('relatedLesson')
        if related:
            assert 1 <= related['day'] <= 14 and 1 <= related['sentence'] <= 5, q['id']
        audio(q['questionAudio'])
        groups = [q['short']] + [b['sentences'] for b in q.get('branches',[])]
        if not q['short']: assert q.get('requiresConfirmation') and q.get('branches'), q['id']
        else:
            assert 1 <= len(q['short']) <= 4, q['id']
            audio(q['fullAudio'])
        for b in q.get('branches',[]): assert b['confirmed'] is False and b['condition']
        for v in q['variants'] + q['followups']:
            audio(v['audio'])
            if v.get('answer') and not any(re.search(r'\[|\]|____',s['en']) for s in v['answer']):
                audio(v['answerAudio'])
            groups.append(v.get('answer',[]))
        for group in groups:
            for line in group:
                assert line['en'] and line['zh'], q['id']
                if re.search(r'\[|\]|____',line['en']): assert line.get('audio') is None
                else:
                    audio(line['audio'])
                    n = len(re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*",line['en']))
                    assert n <= 8 or ('Guangxi College for Preschool Education' in line['en'] and n <= 9), line['en']
    for word, entry in data['lexicon'].items():
        assert entry['ipa'] and entry['zh'], word
        mp3(entry['src'])
    walk(data)
    legacy_audio = json.loads((root/'listening-v18.json').read_text())
    assert (root/'listening-v18.json').read_bytes() == (root/'audio/v18/manifest.json').read_bytes()
    assert len(legacy_audio['modules']) == 14
    for module in legacy_audio['modules']:
        assert len(module['tracks']) == 3
        for track in module['tracks'].values():
            mp3(track['src'])
            assert abs(durations[track['src']]-track['durationSeconds']) < .3
            assert track['built'] and track['cues']
    walk(legacy_audio)

    html = (root/'index.html').read_text()
    refs=References(); refs.feed(html)
    names={Path(urlsplit(ref).path).name for ref in refs.assets}
    assert {'mainline-v21.js','mainline-v21.css','recorder-v19.js','audio-recovery.js'} <= names
    assert not names.intersection({'mainline-v20.js','mainline-v20.css','mainline-v19.js','mainline-v19.css'})
    for ref in refs.assets:
        assert parse_qs(urlsplit(ref).query).get('v') == [shell_version], ref
        assert (root/urlsplit(ref).path).is_file(), ref
    js=(root/'assets/mainline-v21.js').read_text()
    css=(root/'assets/mainline-v21.css').read_text()
    assert 'interview-v21.json' in js and 'sam-review-word' in js
    assert 'subtree:true' not in js and 'subtree: true' not in js
    assert 'sam20-lesson-host' not in css and 'sam21-lesson-host' not in css
    assert 'lesson-route' not in css, 'sentence course hidden again'
    legacy=(root/'assets/index-C6MAz4Oq.js').read_text()
    # V22 has separate 105-sentence content/audio/real-bindings verification.
    # The original V21 command still enforces the exact V21 shell hashes.
    if check_original_shell:
        begin=legacy.index('var e=[')+6; finish=legacy.index('],t={',begin)+1
        assert hashlib.sha256(legacy[begin:finish].encode()).hexdigest()=='37b4664509e61aab0b1cb7831924789ab8e2ed596282a88b3e47a64ae7ad31a5', 'original 70-sentence content changed'
        for marker,digest in [('<main class="layout"','c706c903b38f48e30c3c10d87b26a2330b9062dca55efd38b1993d11bbcfd347'),('_.querySelector(`#play-sentence`)','6d872fae6b303ca78e732b94d7ebab0c3944ce8ff9f527b1ef83238062eb6a9b')]:
            pos=legacy.index(marker); begin=legacy.rfind('function ',0,pos); finish=legacy.index('function ',pos)
            assert hashlib.sha256(legacy[begin:finish].encode()).hexdigest()==digest, 'original sentence template/controls changed'
    assert './sw.js?v='+shell_version in legacy
    sw=(root/'sw.js').read_text()
    assert re.search(r'gospeak-independent-v'+re.escape(shell_version)+r'-[0-9a-f]{12}',sw)
    assert 'interview-v21.json' in sw and 'mainline-v21.js' in sw
    assert 'interview-v20.json' not in sw and 'mainline-v20.js' not in sw
    assert "requestUrl.pathname.includes('/audio/')" in sw and "headers.has('range')" in sw
    assert not re.search(r'\.\.\.(?:phraseAudio|coachAudio|shadowAudio)',sw)
    assert not re.search(r'core\.push\([^\n]*\.mp3',sw)
    for content in (html,json.dumps(data,ensure_ascii=False),legacy):
        for bad in ('Junxi','junxi','My major is business.','我的专业是商科。'): assert bad not in content
    print(f'V21 interview regression verified in shell V{shell_version}: 30 PDF questions + {len(data["questions"])-30} personal supplements; {len(durations)} valid MP3s; no old overlay active.')


if __name__=='__main__': verify(sys.argv[1] if len(sys.argv)>1 else '_site')
