"""Keep the default V22 interview route to Sam's eight basic question types.

Apply after patch_mainline(), before patch_listening_first(). The optional full
bank remains available. No question data, recorder state, version or storage
key is changed. Missing core IDs never fall back to unrelated questions.
"""
from patch_mainline_v22 import _HELPERS as _MAINLINE_HELPERS

_MARKER = '/* V22_CORE_EIGHT */'
_CORE_IDS = "['02','15','16','s01','i04','b01','i03','s03']"

_CORE_HELPERS = r'''  /* V22_CORE_EIGHT */
  function practiceQuestions(){
    if(state.practiceScope==='all')return state.questions;
    return coreQuestionIds.map(function(id){return state.questions.find(function(item){return item.id===id;});}).filter(Boolean);
  }
  function setPracticeScope(scope){
    var next=scope==='all'?'all':'core';
    var available=next==='all'?state.questions:coreQuestionIds.map(function(id){return state.questions.find(function(item){return item.id===id;});}).filter(Boolean);
    if(!available.length){status(next==='core'?'基础题暂未载入，请重试载入课程。':'暂时没有可用题目。');return false;}
    state.practiceScope=next;state.category='all';
    if(!available.some(function(item){return item.id===state.selected;}))state.selected=available.some(function(item){return item.id==='15';})?'15':available[0].id;
    resetPrompt();persist();return true;
  }
'''

_CORE_NAV = r'''  function postIntroHtml(){
    var basics=[['02','学校专业'],['15','项目目的'],['16','为何美国'],['s01','救生员岗位'],['i04','游泳能力'],['b01','听不懂怎么办'],['i03','家人支持'],['s03','回国读书']];
    var shortcuts=basics.filter(function(pair){return state.questions.some(function(item){return item.id===pair[0];});}).map(function(pair){return '<button type="button" data-sam-action="topic" data-value="'+esc(pair[0])+'">'+esc(pair[1])+'</button>';}).join('');
    var core=state.practiceScope==='core';
    return '<section class="sam22-post-intro" aria-label="基础口测练习"><p>'+(core?'自我介绍后停下来听题；先把这几类基础问答练熟。':'这里是选练题目，可以随时回到基础题。')+'</p><div class="sam22-post-intro-actions">'+(core?'<button type="button" class="sam21-primary" data-sam-action="after-intro">随机听答这8题</button><button type="button" data-sam-action="scope-more">更多题目（选练）</button>':'<button type="button" class="sam21-primary" data-sam-action="scope-core">返回基础题</button><button type="button" data-sam-action="mock-all">全题模拟（选练）</button>')+'</div>'+(core?'<details class="sam22-topic-picker"><summary>选择基础题</summary><nav class="sam22-topic-shortcuts" aria-label="基础问题快捷入口">'+shortcuts+'</nav></details>':'')+'</section>';
  }
'''


def _once(source, old, new):
    count = source.count(old)
    if count != 1:
        raise ValueError(f'V22 core anchor expected once, got {count}: {old[:100]!r}')
    return source.replace(old, new, 1)


def patch_core(source):
    """Return JS with a default eight-question pool; reject unknown anchors."""
    if _MARKER in source:
        raise ValueError('V22 core patch already applied; start with the baseline')
    if '/* V22_POST_INTRO_ROUTE */' not in source:
        raise ValueError('Apply patch_mainline before patch_core')
    if '/* V22_LISTENING_FIRST */' in source:
        raise ValueError('Apply patch_core before patch_listening_first')
    source = _once(source, '  var state={root:null,data:null,questions:[],',
                   f'  var coreQuestionIds={_CORE_IDS};\n  var state={{root:null,data:null,questions:[],')
    source = _once(source, "category:'all',mode:'prepare',mockScope:'all',round:1,",
                   "category:'all',mode:'prepare',practiceScope:'core',mockScope:'all',round:1,")
    source = _once(source, "  if(state.selected==='01')state.selected='15';",
                   "  if(coreQuestionIds.indexOf(state.selected)<0)state.selected='15';")
    old_filter = "  function filterQuestions(){return state.questions.filter(function(item){return (state.category==='all'||item.category===state.category)&&(state.mode!=='mock'||state.mockScope!=='after-intro'||item.id!=='01');});}"
    source = _once(source, old_filter,
                   _CORE_HELPERS + old_filter.replace('state.questions.filter(', 'practiceQuestions().filter('))
    source = _once(source, "function categories(){return state.questions.map(function(item){return item.category;})",
                   "function categories(){return practiceQuestions().map(function(item){return item.category;})")
    old_nav = '  function postIntroHtml(){' + _MAINLINE_HELPERS.split('  function postIntroHtml(){', 1)[1].split('  function alternativeQuestionsHtml(item){', 1)[0]
    old_nav = old_nav.replace("<details class=\"sam22-topic-picker\" '+(state.mode==='prepare'?'open':'')+'>", '<details class="sam22-topic-picker">')
    source = _once(source, old_nav, _CORE_NAV)
    source = _once(source, "esc(value==='all'?'全部题目':value)",
                   "esc(value==='all'?(state.practiceScope==='core'?'基础题目':'全部题目'):value)")
    source = _once(source,
                   "state.data=data;state.questions=data.questions;if(!state.questions.some(function(item){return item.id===state.selected;}))state.selected=state.questions[0].id;state.needsRender=true;",
                   "state.data=data;state.questions=data.questions;var available=practiceQuestions();if(!available.length){state.questions=[];state.needsRender=false;loadError('基础题暂未载入，请重试载入课程。');return;}if(!available.some(function(item){return item.id===state.selected;}))state.selected=available.some(function(item){return item.id==='15';})?'15':available[0].id;state.needsRender=true;")
    source = _once(source,
                   "function choose(id){if(!safeToChange())return;state.selected=id;resetPrompt();persist();render();}",
                   "function choose(id){if(!safeToChange())return;if(!practiceQuestions().some(function(item){return item.id===id;}))return;state.selected=id;resetPrompt();persist();render();}")
    source = _once(source,
                   "    var pool=filterQuestions().filter(function(item){return item.id!==state.selected;});\n    if(!pool.length){status('这类暂时没有其他可抽题目，可以选择其他类别。');return false;}",
                   "    var available=filterQuestions(),pool=available.filter(function(item){return item.id!==state.selected;});\n    if(!pool.length)pool=available;\n    if(!pool.length){status('当前没有可抽题目，请先选择可用题目。');return false;}")
    source = _once(source,
                   "if(action==='mode'){state.mode=value==='mock'?'mock':'prepare';state.mockScope='all';state.round=1;resetPrompt();render();}",
                   "if(action==='mode'){state.mode=value==='mock'?'mock':'prepare';state.mockScope=state.practiceScope==='core'?'after-intro':'all';state.round=1;resetPrompt();render();}")
    source = _once(source,
                   "else if(action==='after-intro'){state.mode='mock';state.mockScope='after-intro';state.category='all';state.round=1;pickRandomQuestion();}",
                   "else if(action==='after-intro'){if(!setPracticeScope('core'))return;state.mode='mock';state.mockScope='after-intro';state.round=1;pickRandomQuestion();}")
    source = _once(source,
                   "else if(action==='mock-all'){state.mode='mock';state.mockScope='all';state.category='all';state.round=1;pickRandomQuestion();}",
                   "else if(action==='mock-all'){if(!setPracticeScope('all'))return;state.mode='mock';state.mockScope='all';state.round=1;pickRandomQuestion();}\n"
                   "    else if(action==='scope-more'){if(!setPracticeScope('all'))return;state.mode='prepare';state.mockScope='all';state.round=1;resetPrompt();render();}\n"
                   "    else if(action==='scope-core'){if(!setPracticeScope('core'))return;state.mode='prepare';state.mockScope='after-intro';state.round=1;resetPrompt();render();}")
    source = _once(source,
                   "else if(action==='topic'){if(!state.questions.some(function(item){return item.id===value;}))return;state.mode='prepare';state.mockScope='all';state.category='all';state.round=1;choose(value);}",
                   "else if(action==='topic'){if(!practiceQuestions().some(function(item){return item.id===value;}))return;state.mode='prepare';state.mockScope=state.practiceScope==='core'?'after-intro':'all';state.category='all';state.round=1;choose(value);}")
    return source
