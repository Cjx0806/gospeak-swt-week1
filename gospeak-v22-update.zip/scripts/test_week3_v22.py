"""Offline guardrails for the new week; does not request speech or microphone."""
import re
import unittest

from v22_week3 import GUIDES, LESSONS, SENTENCE_IPA, WORDS


class Week3Tests(unittest.TestCase):
    def setUp(self):
        self.lines = [phrase for lesson in LESSONS for phrase in lesson['phrases']]

    def test_days_and_line_count(self):
        self.assertEqual(len(LESSONS), 7)
        self.assertEqual(len(self.lines), 35)
        for day, lesson in enumerate(LESSONS, 15):
            self.assertTrue(lesson['subtitle'].startswith(f'Day {day} · '))
            self.assertEqual(len(lesson['phrases']), 5)
            self.assertTrue(lesson['title'])

    def test_short_unique_sentences(self):
        sentences = [line['en'] for line in self.lines]
        self.assertEqual(len(set(sentences)), 35)
        for sentence in sentences:
            words = re.findall(r'[A-Za-z]+(?:-[A-Za-z]+)?', sentence)
            self.assertGreaterEqual(len(words), 3, sentence)
            self.assertLessEqual(len(words), 8, sentence)
            self.assertNotRegex(sentence, r'\[|\]|____|Junxi|business')

    def test_translations_stress_and_ipa(self):
        self.assertEqual(set(SENTENCE_IPA), {line['en'] for line in self.lines})
        for line in self.lines:
            self.assertRegex(line['zh'], r'[\u4e00-\u9fff]')
            self.assertTrue(line['tip'])
            ipa = SENTENCE_IPA[line['en']]
            self.assertTrue(ipa.strip())
            self.assertNotIn('//', ipa)

    def test_word_coverage(self):
        used = {word.lower() for line in self.lines for word in re.findall(r'[A-Za-z]+(?:-[A-Za-z]+)?', line['en'])}
        self.assertEqual(used, set(WORDS), f'missing: {used-set(WORDS)}; extra: {set(WORDS)-used}')
        for word, info in WORDS.items():
            self.assertEqual(word, word.lower())
            self.assertTrue(info['zh'].strip(), word)
            self.assertTrue(info['ipa'].strip(), word)
            self.assertNotIn('结合句子理解', info['zh'])

    def test_structures_aligned(self):
        self.assertEqual(len(GUIDES), 35)
        for line, guide in zip(self.lines, GUIDES):
            self.assertTrue(guide['pattern'])
            self.assertTrue(guide['note'])
            self.assertGreaterEqual(len(guide['parts']), 3)
            for part in guide['parts']:
                self.assertEqual(set(part), {'role', 'text', 'meaning'})
                self.assertTrue(all(part.values()))
                # A role may name several determiners as "my / work".
                for text in part['text'].split(' / '):
                    self.assertIn(text.lower(), line['en'].lower(), (line['en'], part))

    def test_truth_and_situation_boundaries(self):
        self.assertIn('假设', WORDS['would']['zh'])
        for line, guide in zip(self.lines, GUIDES):
            if 'would' in line['en'].lower():
                self.assertTrue(any(part['text'] == 'would' and '假设' in part['meaning'] for part in guide['parts']))
        self.assertEqual(LESSONS[-1]['phrases'][-1]['en'], 'I will continue my studies in China.')
        for line in self.lines:
            self.assertNotRegex(line['en'], r'I (?:have worked|worked|have traveled|traveled)|June|September|American lifeguard certificate')


if __name__ == '__main__':
    unittest.main()
