"""Small, fail-closed additions to the preserved V21 interview workbench.

Call patch_mainline(source) on the baseline script after the V22 copy edits.
No new questions, answers, audio or personal facts are created here.
"""

_MARKER = '/* V22_POST_INTRO_ROUTE */'

_HELPERS = r'''  /* V22_POST_INTRO_ROUTE */
  function postIntroHtml(){
    var groups=[
      {label:'项目动机',items:[['15','为什么参加 SWT']]},
      {label:'为什么去美国',items:[['16','为什么选择美国']]},
      {label:'专业与证书',items:[['02','我的专业'],['s01','岗位与救生员证']]},
      {label:'工作中的困难',items:[['18','遇到困难怎么办']]},
      {label:'优点与改进',items:[['06','我的优点'],['s02','英语困难与改进']]},
      {label:'回国安排',items:[['s03','回国继续读书']]}
    ];
    var shortcuts=groups.map(function(group){var items=group.items.filter(function(pair){return state.questions.some(function(item){return item.id===pair[0];});});return items.length?'<div class="sam22-topic-group"><span>'+esc(group.label)+'</span><div>'+items.map(function(pair){return '<button type="button" data-sam-action="topic" data-value="'+esc(pair[0])+'">'+esc(pair[1])+'</button>';}).join('')+'</div></div>':'';}).join('');
    return '<section class="sam22-post-intro" aria-label="自我介绍之后怎么练"><h2>自我介绍之后，听考官提问</h2><p>自我介绍说完可以停下来，不必主动背下一段。听清这一题，再答两三句；不确定时先请对方重复。</p><div class="sam22-post-intro-actions"><button type="button" class="sam21-primary" data-sam-action="after-intro">自我介绍后的随机问答</button>'+(state.mode==='mock'?'<button type="button" data-sam-action="mock-all">全部题目模拟</button>':'')+'</div>'+(state.mode==='mock'?'<p class="sam22-pool-note">'+(state.mockScope==='after-intro'?'当前练习：随机问答，不抽自我介绍。':'当前练习：全部题目，包含自我介绍。')+'</p>':'')+'<details class="sam22-topic-picker" '+(state.mode==='prepare'?'open':'')+'><summary>先练这些问题</summary><nav class="sam22-topic-shortcuts" aria-label="口测问题快捷入口">'+shortcuts+'</nav></details><p class="sam22-route-note">这些是练习方向，不是预测考官的提问顺序。按真实情况作答。</p></section>';
  }
  function alternativeQuestionsHtml(item){
    var blind=state.mode==='mock'||state.round===3;
    if(blind&&!state.questionRevealed)return '';
    var current=activeQuestion(item),options=state.followup>=0?[]:variants(item).filter(function(option){return option.en!==current.en;});
    return '<details class="sam22-question-variants"><summary>考官可能还会这样问</summary>'+(options.length?'<ul>'+options.map(function(option){return '<li><div><p lang="en">'+esc(option.en)+'</p><p>'+esc(option.zh||'')+'</p></div>'+playButton(option.audio,option.en,false,'▶ 听这个问法',true)+'</li>';}).join('')+'</ul>':'<p>这题暂未添加其他同义问法，先用上面的问法练习。实际提问可能不同。</p>')+'</details>';
  }
  function pickRandomQuestion(){
    var pool=filterQuestions().filter(function(item){return item.id!==state.selected;});
    if(!pool.length){status('这类暂时没有其他可抽题目，可以选择其他类别。');return false;}
    var picked=pool[Math.floor(Math.random()*pool.length)];state.selected=picked.id;resetPrompt();state.variant=Math.floor(Math.random()*variants(picked).length);persist();render();playQuestion();return true;
  }
'''


def _once(source, old, new):
    count = source.count(old)
    if count != 1:
        raise ValueError(f'V22 mainline anchor expected once, got {count}: {old[:100]!r}')
    return source.replace(old, new, 1)


def patch_mainline(source):
    """Return patched JS, raising rather than silently patching an unknown build."""
    if _MARKER in source:
        raise ValueError('V22 mainline patch already applied; use the baseline source')
    source = _once(source, "category:'all',mode:'prepare',round:1,",
                   "category:'all',mode:'prepare',mockScope:'all',round:1,")
    source = _once(source, '  var api={remount:mount,isRecording:isRecording,stopPlayback:stopSound};',
                   "  if(state.selected==='01')state.selected='15';\n  var api={remount:mount,isRecording:isRecording,stopPlayback:stopSound};")
    source = _once(source,
                   "function filterQuestions(){return state.questions.filter(function(item){return state.category==='all'||item.category===state.category;});}",
                   "function filterQuestions(){return state.questions.filter(function(item){return (state.category==='all'||item.category===state.category)&&(state.mode!=='mock'||state.mockScope!=='after-intro'||item.id!=='01');});}")
    # Keep the everyday view short; optional topic shortcuts expand on demand.
    helpers=_HELPERS.replace("<details class=\"sam22-topic-picker\" '+(state.mode==='prepare'?'open':'')+'>", '<details class="sam22-topic-picker">')
    source = _once(source, '  function headerHtml(item){', helpers+'  function headerHtml(item){')
    source = _once(source, '</header><nav class="sam21-modes"', "</header>'+postIntroHtml()+'<nav class=\"sam21-modes\"")
    source = _once(source,
                   "<h3>先想这 '+Math.min(3,cues.length)+' 个意思，不背长篇</h3>",
                   '<h3>我该回答什么</h3>')
    source = _once(source, "+questionHtml(item)+(showScaffold?scaffoldHtml(item):'')",
                   "+questionHtml(item)+alternativeQuestionsHtml(item)+(showScaffold?scaffoldHtml(item):'')")
    source = _once(source,
                   "if(action==='mode'){state.mode=value==='mock'?'mock':'prepare';state.round=1;resetPrompt();render();}",
                   "if(action==='mode'){state.mode=value==='mock'?'mock':'prepare';state.mockScope='all';state.round=1;resetPrompt();render();}\n"
                   "    else if(action==='after-intro'){state.mode='mock';state.mockScope='after-intro';state.category='all';state.round=1;pickRandomQuestion();}\n"
                   "    else if(action==='mock-all'){state.mode='mock';state.mockScope='all';state.category='all';state.round=1;pickRandomQuestion();}\n"
                   "    else if(action==='topic'){if(!state.questions.some(function(item){return item.id===value;}))return;state.mode='prepare';state.mockScope='all';state.category='all';state.round=1;choose(value);}")
    source = _once(source,
                   "else if(action==='random'){var pool=filterQuestions().filter(function(item){return item.id!==state.selected;});if(!pool.length){status('这类暂时只有这一题，可先换问法或选择其他类别。');return;}var picked=pool[Math.floor(Math.random()*pool.length)];state.selected=picked.id;resetPrompt();state.variant=Math.floor(Math.random()*variants(picked).length);persist();render();playQuestion();}",
                   "else if(action==='random')pickRandomQuestion();")
    return source

