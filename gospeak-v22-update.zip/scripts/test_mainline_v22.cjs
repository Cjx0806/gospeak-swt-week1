/* V22 post-introduction practice: actual curriculum, offline DOM and audio doubles. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),cp=require('node:child_process');
const root=path.join(__dirname,'..'),python=process.env.PYTHON||process.env.PYTHON3||'python3';
const original=fs.readFileSync(path.join(root,'assets/mainline-v21.js'),'utf8');
const source=cp.execFileSync(python,['-c','import sys;sys.path.insert(0,sys.argv[1]);from patch_mainline_v22 import patch_mainline;print(patch_mainline(sys.stdin.read()))',__dirname],{input:original,encoding:'utf8',maxBuffer:2*1024*1024});
assert(source.includes('/* V22_POST_INTRO_ROUTE */'));
assert(source.includes("selected:'15'"),'unlearned interview questions remain the default');
assert(!source.includes('class="word-grid"'),'mainline is not a duplicate sentence-course grid');
assert(source.includes('我该回答什么'));
const boundary=source.indexOf("  window.addEventListener('sam-recorder-start'");assert(boundary>0);
const instrumented=source.slice(0,boundary)+'window.test={state,render,filterQuestions,postIntroHtml,alternativeQuestionsHtml,handleClick,handleChange,pickRandomQuestion,recordSaved,stopSound};})();';
const payload=JSON.parse(fs.readFileSync(path.join(root,'_site/interview-v21.json'),'utf8'));
function context(savedSelected){
  let html='',status='',recording=false,timerId=0,created=0,mountCount=0,randomValue=0;
  const timers=new Map(),targets=[];
  class Audio {constructor(){created++;this.paused=true;this.currentTime=0;this.duration=2;}play(){this.paused=false;return Promise.resolve();}pause(){this.paused=true;}removeAttribute(){this.src='';}load(){}}
  const math=Object.create(Math);math.random=()=>randomValue;
  const sandbox={window:{dispatchEvent(){},SamRecorder:{mount(node,options){mountCount++;targets.push(options);return{destroy(){},isRecording(){return recording;}};}}},document:{baseURI:'https://example.test/',querySelector(){return null;},querySelectorAll(){return[];}},localStorage:{getItem(){return savedSelected?JSON.stringify({selected:savedSelected}):null;},setItem(){}},URL,Date,Math:math,Audio,Promise,CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},setTimeout(fn){const id=++timerId;timers.set(id,fn);return id;},clearTimeout(id){timers.delete(id);}};
  vm.runInNewContext(instrumented,sandbox);const t=sandbox.window.test;
  t.state.data=payload;t.state.questions=payload.questions;
  const node={replaceWith(){}};
  t.state.root={isConnected:true,contains(){return true;},querySelector(selector){if(selector==='[data-sam-content]')return{set innerHTML(value){html=value;}};if(selector==='[data-sam-status]')return{set textContent(value){status=value;}};return node;},querySelectorAll(){return[];}};
  function click(action,value){const button={disabled:false,hasAttribute(){return false;},getAttribute(key){return key==='data-sam-action'?action:key==='data-value'?value:null;}};t.handleClick({target:{closest(){return button;}}});}
  return{t,click,html:()=>html,status:()=>status,targets,timers,recording(value){recording=value;},random(value){randomValue=value;},created:()=>created,mountCount:()=>mountCount};
}
const c=context('01'),t=c.t;
assert.equal(t.state.selected,'15','last saved introduction cannot remain the initial focus after upgrade');
t.render();
assert(c.html().includes('自我介绍之后，听考官提问'));
assert(c.html().includes('自我介绍说完可以停下来'));
assert(c.html().includes('不是预测考官的提问顺序'));
assert.equal((c.html().match(/class="sam22-topic-group"/g)||[]).length,6);
for(const id of ['15','16','02','s01','18','06','s02','s03'])assert(c.html().includes('data-sam-action="topic" data-value="'+id+'"'),id+' shortcut missing');
assert(c.html().includes('考官可能还会这样问'));
assert(c.html().includes('Why are you interested in SWT?'));
assert(c.html().includes('你为什么对 SWT 感兴趣？'));
assert(c.html().includes('▶ 听这个问法'));
assert(c.html().includes('我该回答什么'));
assert.equal(c.targets.at(-1).assessmentMode,'scripted');

c.click('after-intro');
assert.equal(t.state.mode,'mock');assert.equal(t.state.mockScope,'after-intro');assert.equal(t.state.category,'all');assert.notEqual(t.state.selected,'01');
assert(!t.filterQuestions().some(q=>q.id==='01'));
assert(c.html().includes('当前练习：随机问答，不抽自我介绍。'));
assert(!c.html().includes('sam22-question-variants'),'blind mock does not render alternative question text at all');
assert(!c.html().includes('我该回答什么'),'blind mock does not render answer cues');
assert.equal(c.targets.at(-1).assessmentMode,'free');assert.equal(c.targets.at(-1).expectedText,'');
let current=payload.questions.find(q=>q.id===t.state.selected);
assert(!c.html().includes(current.question));for(const line of current.short)assert(!c.html().includes(line.en));
for(let i=0;i<100;i++){c.random((i%10)/10);c.click('random');assert.notEqual(t.state.selected,'01','post-intro pool survives subsequent random draws');assert.equal(t.state.mockScope,'after-intro');}

// Explicit text reveal can expose wording, but not a model answer.
c.click('topic','15');t.state.mode='mock';t.state.mockScope='after-intro';t.state.questionRevealed=false;t.render();
c.click('question-hint');assert(c.html().includes('Why are you interested in SWT?'));assert(c.html().includes('sam22-question-variants'));
for(const line of payload.questions.find(q=>q.id==='15').short)assert(!c.html().includes(line.en));
c.click('question-hint');assert(!c.html().includes('sam22-question-variants'));

// Round 3 also preserves blind listening and truth-gated free responses.
c.click('topic','15');c.click('round','3');assert.equal(t.state.mode,'prepare');assert(!c.html().includes('sam22-question-variants'));assert(!c.html().includes('Why are you interested in SWT?'));
c.click('topic','s01');assert(!c.html().includes('Do you have any relevant qualifications?'),'different-intent variants with hints are not mislabeled synonyms');
assert(c.html().includes('这题暂未添加其他同义问法'));
c.click('topic','06');assert(c.html().includes('先确认真实情况'),'strength shortcut does not invent a personality');assert.equal(c.targets.at(-1).assessmentMode,'free');
c.click('topic','s03');assert(c.html().includes('回国'));assert(!c.html().includes('When does your next semester begin?'),'dates are not synonyms for return plans');

// All-question practice remains available and can include the introduction.
c.random(0);c.click('mock-all');assert.equal(t.state.mockScope,'all');assert.equal(t.state.selected,'01');assert(t.filterQuestions().some(q=>q.id==='01'));
assert(c.html().includes('当前练习：全部题目，包含自我介绍。'));
c.click('after-intro');c.click('mode','mock');assert.equal(t.state.mockScope,'all','ordinary mock tab resets to all questions');

// Safety/cleanup: shortcuts must not abandon an active recorder or stale audio.
const before=t.state.selected,mode=t.state.mode;c.recording(true);c.click('topic','15');assert.equal(t.state.selected,before);assert.equal(t.state.mode,mode);assert(c.status().includes('停止并保存录音'));c.click('after-intro');assert.equal(t.state.mockScope,'all');c.recording(false);
c.click('topic','15');assert.equal(t.state.mode,'prepare');assert.equal(t.state.round,1);assert.equal(t.state.category,'all');assert.equal(t.state.selected,'15');
const beforeInvalid=t.state.selected;c.click('topic','does-not-exist');assert.equal(t.state.selected,beforeInvalid);
assert(c.created()<=1,'random practice reuses the existing single audio element');t.stopSound();assert.equal(c.timers.size,0);

// Every actual question obeys blind-mode secrecy and source-only alternate audio.
for(const item of payload.questions){
  t.state.selected=item.id;t.state.mode='prepare';t.state.round=1;t.state.followup=-1;t.state.variant=0;t.state.questionRevealed=false;t.state.help=false;t.state.reference=true;t.render();
  assert(!c.html().includes('undefined'),item.id+' undefined rendering');
  for(const clip of Object.values(t.state.clips))assert(clip.src||/\[/.test(clip.text),item.id+' empty audio mapping');
  t.state.mode='mock';t.state.questionRevealed=false;t.state.reference=false;t.render();
  assert(!c.html().includes('sam22-question-variants'),item.id+' blind wording list leaked');
  assert(!c.html().includes(item.question),item.id+' blind question leaked');
  for(const line of item.short)assert(!c.html().includes(line.en),item.id+' blind answer leaked');
}

// Patching unknown or already-patched sources must fail closed.
for(const bad of [original.replace("category:'all',mode:'prepare',round:1,",'changed source'),source]){
  const check=cp.spawnSync(python,['-c','import sys;sys.path.insert(0,sys.argv[1]);from patch_mainline_v22 import patch_mainline;patch_mainline(sys.stdin.read())',__dirname],{input:bad,encoding:'utf8'});
  assert.notEqual(check.status,0);assert(check.stderr.includes('ValueError'));
}
console.log('PASS V22: post-intro guidance, six shortcut groups, persistent no-intro random pool, optional full pool, source-only alternative questions, blind-mode secrecy, truth gates, existing recorder/audio safety and fail-closed patching.');
