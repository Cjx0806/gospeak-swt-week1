"""Pure, fail-closed listening-before-answer layer for the V22 interview route.

Apply after patch_mainline_v22.patch_mainline. No extra facts, audio service,
exam score, recording storage, or curriculum content is introduced here.
"""

_MARKER = '/* V22_LISTENING_FIRST */'

_HELPERS = r'''  /* V22_LISTENING_FIRST */
  function listeningOptions(item){
    var question=activeQuestion(item),correct=String(question.zh||item.questionZh||'').trim();
    var ownMeanings=variants(item).map(function(option){return String(option.zh||'').trim();});
    ownMeanings.push(correct);
    var alternatives=[],pool=typeof practiceQuestions==='function'?practiceQuestions():state.questions;
    pool.forEach(function(other){var meaning=String(other.questionZh||'').trim();if(other.id!==item.id&&meaning&&ownMeanings.indexOf(meaning)<0&&alternatives.indexOf(meaning)<0)alternatives.push(meaning);});
    var seed=String(item.id)+':'+state.variant+':'+state.followup,total=0;
    for(var i=0;i<seed.length;i++)total+=seed.charCodeAt(i);
    var answers=[{zh:correct,correct:true}];
    if(alternatives.length){var start=total%alternatives.length;for(var offset=0;offset<Math.min(2,alternatives.length);offset++)answers.push({zh:alternatives[(start+offset)%alternatives.length],correct:false});}
    var rotate=answers.length?total%answers.length:0;
    return answers.slice(rotate).concat(answers.slice(0,rotate));
  }
  function listeningFirstHtml(item){
    var options=listeningOptions(item),selected=state.listeningChoice,chosen=selected===null?null:options[selected];
    var feedback=chosen?(chosen.correct?'选对了，这题在问：'+chosen.zh+' 再听一次，把声音和意思连起来。':'这次还没选对。请再听一遍；卡住时可以显示题目，也可以看帮助后继续。'):'';
    var question=activeQuestion(item),clues=state.questionRevealed&&state.followup<0?list(item.listeningClues).filter(function(clue){return clue&&clue.en&&clue.audio&&String(question.en||'').toLowerCase().includes(String(clue.en).toLowerCase());}).slice(0,2):[];
    var clueHtml=clues.length?'<div class="sam22-listening-clues"><p>点听题目里的关键词，把声音和中文意思连起来。</p>'+clues.map(function(clue){return playButton(clue.audio,clue.en,true,clue.en+' · '+clue.zh,true);}).join('')+'</div>':'';
    return '<section class="sam22-listening-first"><h3>第一步：先听懂考官在问什么</h3><p>先点“听问题”。暂时不用想英文答案，听完选一句最接近的中文意思。可以反复听，也可以用慢速。</p>'+clueHtml+'<div class="sam22-meaning-options" role="group" aria-label="这道问题是什么意思">'+options.map(function(option,index){return '<button type="button" data-sam-action="meaning" data-value="'+index+'" aria-pressed="'+(selected===index)+'">'+esc(option.zh)+'</button>';}).join('')+'</div>'+(feedback?'<p class="sam22-meaning-feedback" role="status">'+esc(feedback)+'</p>':'')+'<p class="sam22-listening-limit">这里只帮你检查是否听懂题意，不是机构口测评分；不会扣分，也不会强制卡关。</p><button type="button" class="sam21-primary" data-sam-action="answer-start">听懂了，开始练回答</button><p>没听懂也能先点“没听懂？显示题目”，看清意思后再继续。</p></section>';
  }
'''


def _once(source, old, new):
    count = source.count(old)
    if count != 1:
        raise ValueError(f'Listening-first anchor expected once, got {count}: {old[:100]!r}')
    return source.replace(old, new, 1)


def patch_listening_first(source):
    if _MARKER in source:
        raise ValueError('Listening-first patch already applied; use the baseline source')
    if '/* V22_POST_INTRO_ROUTE */' not in source:
        raise ValueError('Apply patch_mainline_v22.patch_mainline first')
    source = _once(source, 'variant:0,followup:-1,questionRevealed:false,',
                   'variant:0,followup:-1,listeningFocus:true,listeningChoice:null,questionRevealed:false,')
    old_blind = "var blind=state.mode==='mock'||state.round===3;"
    source = _once(source, old_blind,
                   "var blind=state.mode==='mock'||state.round===3||(state.mode==='prepare'&&state.listeningFocus);")
    source = _once(source, "var question=activeQuestion(item),blind=state.mode==='mock'||state.round===3;",
                   "var question=activeQuestion(item),blind=state.mode==='mock'||state.round===3||(state.mode==='prepare'&&state.listeningFocus);")
    source = _once(source, '  function headerHtml(item){', _HELPERS+'  function headerHtml(item){')
    source = _once(source, '</nav><div class="sam21-selectors">',
                   "</nav>'+(state.mode==='prepare'&&state.listeningFocus?'<details class=\"sam22-listening-topic-picker\"><summary>换练习题目（可选）</summary>':'')+'<div class=\"sam21-selectors\">")
    source = _once(source, "+'</div>'+(state.mode==='prepare'?'<div class=\"sam21-progress\">",
                   "+'</div>'+(state.mode==='prepare'&&state.listeningFocus?'</details>':'')+(state.mode==='prepare'&&!state.listeningFocus?'<div class=\"sam21-progress\">")
    source = _once(source,
                   "    var item=q(),prepare=state.mode==='prepare',showScaffold=prepare&&state.round<3;",
                   "    var item=q(),prepare=state.mode==='prepare',showScaffold=prepare&&state.round<3;\n"
                   "    if(prepare&&state.listeningFocus){state.recorderTarget=null;state.root.querySelector('[data-sam-content]').innerHTML=headerHtml(item)+questionHtml(item)+alternativeQuestionsHtml(item)+listeningFirstHtml(item);return;}")
    source = _once(source, "innerHTML=headerHtml(item)+(prepare?roundsHtml():'')",
                   "innerHTML=headerHtml(item)+(prepare?'<div class=\"sam22-answer-stage\"><b>第二步：用短句回答</b><button type=\"button\" data-sam-action=\"listen-first\">回到听题</button></div>':'')+(prepare?roundsHtml():'')")
    source = _once(source, "function resetPrompt(){state.variant=0;",
                   "function resetPrompt(){state.listeningFocus=state.mode==='prepare';state.listeningChoice=null;state.variant=0;")
    source = _once(source, "    else if(action==='round'){state.round=",
                   "    else if(action==='meaning'){if(state.mode!=='prepare'||!state.listeningFocus)return;var choice=Number(value),options=listeningOptions(q());if(!Number.isInteger(choice)||choice<0||choice>=options.length)return;state.listeningChoice=choice;render(true);}\n"
                   "    else if(action==='answer-start'){if(state.mode!=='prepare')return;state.listeningFocus=false;state.round=1;state.reference=true;state.help=false;state.recorded=false;render();}\n"
                   "    else if(action==='listen-first'){if(state.mode!=='prepare')return;state.listeningFocus=true;state.listeningChoice=null;state.questionRevealed=false;state.help=false;state.reference=false;render();}\n"
                   "    else if(action==='round'){state.listeningFocus=false;state.round=")
    source = _once(source,
                   "else if(action==='wording'){state.variant=(state.variant+1)%variants(q()).length;state.questionRevealed=false;",
                   "else if(action==='wording'){state.variant=(state.variant+1)%variants(q()).length;state.listeningChoice=null;if(state.mode==='prepare')state.listeningFocus=true;state.questionRevealed=false;")
    return source
