"""Add the user's image question list, with exact-text static audio bindings."""
import asyncio
import copy
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

from build_v18_listening import Speech, _clip_key
from build_v21 import synthesize_missing
from v22_interview_supplement import SUPPLEMENTAL_QUESTIONS, QUESTION_SOURCE_MAP, EXTRA_WORDS
from v21_curriculum import S

ROOT=Path(__file__).resolve().parents[1]
TOKENS=r"[A-Za-z]+(?:['’-][A-Za-z]+)*"

def build_interview(site, skip_audio=False):
    site=Path(site)
    with zipfile.ZipFile(ROOT/'gospeak-v21-update.zip') as archive:
        original=json.loads(archive.read('_site/interview-v21.json'))
    payload=copy.deepcopy(original)
    questions=copy.deepcopy(SUPPLEMENTAL_QUESTIONS)
    trouble=copy.deepcopy(next(item for item in payload['questions'] if item['id']=='18'))
    prompt=trouble['followups'][0]
    trouble.update(id='b01',title='听不懂怎么办',question=prompt['en'],questionZh=prompt['zh'],sourceNumbers=[],sourceQuestions=[],category='基础听答',
                   scaffold=['请对方说慢一点','不清楚时请重复','不要假装听懂'],intent='先说会怎么做，再练一句请求重复的自救表达。',examinerIntent='听清问题，必要时请对方重复。',
                   short=[S('I would ask them to speak slowly.','我会请对方说慢一点。','aɪ wʊd æsk ðɛm tə spik ˈsloʊli','I 主语；would ask 谓语；them 宾语；to speak slowly 宾语补足语。'),copy.deepcopy(prompt['answer'][1])],
                   variants=[{'en':'What will you do if you do not understand?','zh':'如果你没听懂，你会怎么做？'}],
                   followups=[{'en':'What could you say to ask for help?','zh':'请求帮助时，你可以怎么说？','answer':copy.deepcopy(prompt['answer']),'scaffold':['直接说一句请求慢速或重复的话']}])
    questions.append(trouble)
    lifeguard=next(item for item in payload['questions'] if item['id']=='s01')
    lifeguard['short']=lifeguard['short'][:2]+[S('I swim almost every day.','我几乎每天都游泳。','aɪ swɪm ˈɔlmoʊst ˈɛvri deɪ','I 主语；swim 谓语；almost every day 表示频率。')]
    lifeguard['scaffold']=['首选救生员','持有中国救生员证','几乎每天游泳']
    lifeguard['followups'].append({'en':'Are you comfortable working in the sun?','zh':'你能适应在太阳下工作吗？','hint':'说你的实际意愿，不把不怕晒说成不需要防护。','answer':[S('Yes, I can work outdoors.','可以，我能在户外工作。','jɛs aɪ kæn wɝk aʊtˈdɔrz','I 主语；can work 谓语；outdoors 地点状语。'),S('I would follow the safety rules.','我会遵守安全规定。','aɪ wʊd ˈfɑloʊ ðə ˈseɪfti rulz','I 主语；would follow 谓语；the safety rules 宾语。')]})
    # Rebuild changed answers and their audio together, without touching other topics.
    updated_questions=[lifeguard]
    known={}
    def remember(value):
        if isinstance(value,dict):
            if value.get('en') and isinstance(value.get('audio'),dict) and value['audio'].get('normal'):
                known[value['en']]=value['audio']
            for child in value.values(): remember(child)
        elif isinstance(value,list):
            for child in value: remember(child)
    for version in (19,20,21): remember(json.loads((site/f'interview-v{version}.json').read_text()))
    for row in json.loads((site/'lesson-audio-v22.json').read_text())['sentences']:
        known[row['en']]={'normal':row['audio']['src'],'slow':row['audio']['src'],'slowRate':.78}
    requested={}; provenance={}; used=set()
    def audio(text,collect=True):
        if collect:
            used.update(w.lower().replace('’',"'") for w in re.findall(TOKENS,re.sub(r'\[[^]]*\]','',text)))
        if not text or re.search(r'\[|\]|____',text): return None
        if text in known:
            result=copy.deepcopy(known[text])
            if result['normal'].startswith('./audio/interview-v22/'):
                provenance[result['normal']]={'text':text,'spokenText':text.replace('SWT','S W T'),'voice':result.get('voice','en-US-AvaNeural'),'rate':'-5%'}
            return result
        spoken=text.replace('SWT','S W T')
        speech=Speech(spoken,'en-US-AvaNeural','-5%')
        path=f'./audio/interview-v22/{_clip_key(speech)}.mp3'
        requested[speech]=site/path
        provenance[path]={'text':text,'spokenText':spoken,'voice':speech.voice,'rate':speech.rate}
        return {'normal':path,'slow':path,'slowRate':.78,'voice':speech.voice}
    def lines(group):
        for line in group: line['audio']=audio(line['en'])
    def paragraph(group):
        return audio(' '.join(line['en'] for line in group),False) if group else None
    clue_bank={
        '02':[('major','专业'),('study','学习；就读')],
        '15':[('Why','为什么'),('join','参加'),('program','项目')],
        '16':[('Why','为什么'),('United States','美国'),('America','美国')],
        's01':[('job','工作；岗位'),('interested in','对……感兴趣')],
        'i04':[('How many','多少'),('meters','米'),('swim','游泳')],
        'b01':[('cannot','不能'),('understand','听懂；理解')],
        'i03':[('parents','父母'),('support','支持')],
        's03':[('after','在……之后'),('program','项目')],
    }
    for question in payload['questions']+questions:
        if question['id'] in clue_bank:
            question['listeningClues']=[{'en':en,'zh':zh,'audio':audio(en,False)} for en,zh in clue_bank[question['id']]]
    for question in questions+updated_questions:
        question['questionAudio']=audio(question['question'],False)
        for sub in question.get('variants',[])+question.get('followups',[]):
            sub['audio']=audio(sub['en'],False)
            lines(sub.get('answer',[]));sub['answerAudio']=paragraph(sub.get('answer',[]))
        for part,group in [(question,question.get('short',[]))]+[(b,b['sentences']) for b in question.get('branches',[])]:
            lines(group);part['fullAudio']=paragraph(group);part['cumulativeAudio']=[]
    lexicon=payload['lexicon']
    lesson_words=json.loads((site/'lesson-audio-v22.json').read_text())['words']
    for word in sorted(used-set(lexicon)):
        entry=EXTRA_WORDS.get(word) or lesson_words.get(word) or {'outdoors':{'zh':'在户外','ipa':'aʊtˈdɔrz'}}.get(word)
        if not entry: raise ValueError('Missing new word annotation: '+word)
        assert entry.get('zh') and entry.get('ipa'),word
        src=lesson_words[word]['src'] if word in lesson_words else audio(word,False)['normal']
        lexicon[word]={'zh':entry['zh'],'ipa':entry['ipa'],'src':src}
    if not skip_audio:
        cache=asyncio.run(synthesize_missing(requested))
        for speech,target in requested.items():
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(cache[speech],target)
    missing=[str(p) for p in requested.values() if not p.is_file() or not p.stat().st_size]
    if missing: raise ValueError('Supplement audio incomplete: '+repr(missing))
    for path,record in provenance.items(): record['sha256']=hashlib.sha256((site/path).read_bytes()).hexdigest()
    payload['questions']+=questions
    payload['imageQuestionMap']=QUESTION_SOURCE_MAP
    payload['coreQuestionIds']=['02','15','16','s01','i04','b01','i03','s03']
    payload['release']='v22'
    payload['profile']['confirmedTravel']=[{'age':16,'countries':['Malaysia']},{'age':17,'countries':['Indonesia','Malaysia','Singapore']},{'age':18,'countries':['Vietnam']},{'age':19,'countries':['South Korea']}]
    payload['profile']['preferredSwtJob']='lifeguard'
    payload['profile']['afterGraduationGoal']='swimming instructor'
    payload['sources'].append({'title':'用户提供的10道口测问题截图','note':'练习参考，不保证考试原题或出题顺序；旅行经历由Sam本人补充。'})
    (site/'interview-v21.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    (site/'interview-audio-v22.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
    print(f'V22 interview: {len(questions)} added image questions; {len(requested)} exact-text audio clips.',flush=True)
    return payload

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('site',nargs='?',type=Path,default=ROOT/'_site');parser.add_argument('--skip-audio',action='store_true')
    args=parser.parse_args();build_interview(args.site,args.skip_audio)
