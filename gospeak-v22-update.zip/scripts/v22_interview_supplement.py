"""Nine short interview cards from Sam's ten-question screenshot.

Question 1 reuses V21's introduction. These are teaching answers, not official
answers. Personal facts are included only after Sam's explicit confirmation.
Unconfirmed passport status remains behind an explicit choice; unfilled slots cannot
be synthesized or assessed. No existing V21 card is mutated by this module.
"""
from __future__ import annotations

from copy import deepcopy
import json
import re

import v21_curriculum as previous

VERSION = "v22"
S = previous.S
TAKE = previous.take
SOURCE_ID = "user-image-10-questions"
QUESTION_SOURCE_MAP = {1: "01", **{n: f"i{n:02d}" for n in range(2, 11)}}


def line(en, zh, ipa, grammar):
    return S(en, zh, ipa, grammar)


def slot(en, zh, **fields):
    result = previous.template(en, zh)
    result.update({"audio": None, "audioEligible": False,
                   "assessmentEnabled": False,
                   "slots": [{"key": key, "label": label, "value": None,
                              "confirmed": False} for key, label in fields.items()]})
    return result


def choice(id, label, condition, sentences):
    result = previous.branch(id, label, condition, sentences)
    result.update({"requiresConfirmation": True, "readyForAutoplay": False,
                   "fullAudio": None})
    return result


def card(number, title, question, question_zh, scaffold, intent, *, short=(), branches=()):
    confirmed = bool(short)
    return {
        "id": QUESTION_SOURCE_MAP[number], "title": title,
        "question": question, "questionZh": question_zh,
        "category": "图片补充题", "sourceNumbers": [], "sourceQuestions": [],
        "sourceId": SOURCE_ID, "imageQuestionNumber": number,
        "priority": "先练", "examinerIntent": intent, "intent": intent,
        "scaffold": list(scaffold), "keywords": list(scaffold),
        "short": deepcopy(list(short)), "extra": [], "variants": [],
        "followups": [], "branches": deepcopy(list(branches)),
        "requiresConfirmation": not confirmed, "readyForAutoplay": confirmed,
        "answerType": "short-beginner" if confirmed else "confirm-facts-first",
        "relatedLessons": [],
        "learningGoal": "听懂这一题，用 2—3 个短句回答，再接一个追问。",
        "connectionTip": "每句自然停一下，再接下一句；先让人听懂，不强求连音。",
        "note": ("短答只使用已经确认的信息；具体追问只回答对应内容。" if confirmed else
                 "这里的个人情况尚未确认。先选真实分支；方括号未填写时不能播放或评分。"),
    }


YES_HAVE = line("Yes, I have.", "是的，我有过。", "jɛs aɪ hæv",
                "Yes 先肯定回答；I 主语＋have 助动词，省略题目已说的经历。")
FIRST_YEAR = TAKE("year", "major")
SUPPORT = line("Yes, they support my plan.", "是的，他们支持我的计划。",
               "jɛs ðeɪ səˈpɔrt maɪ plæn", "they 主语指父母；support 谓语＋my plan 宾语。")
KNOW_PROGRAM = line("They know about the SWT program.", "他们了解 SWT 项目。",
                    "ðeɪ noʊ əˈbaʊt ðə ˌɛs ˌdʌbəlju ˈti ˈproʊɡræm",
                    "They 主语＋know about 谓语短语＋the SWT program 宾语。")
NO_SUPPORT = line("They do not support it yet.", "他们目前还不支持。",
                  "ðeɪ du nɑt səˈpɔrt ɪt jɛt", "They 主语＋do not support 否定谓语＋it 宾语；yet 表示目前尚未。")
DISCUSSING = line("We are still discussing it.", "我们仍在讨论这件事。",
                  "wi ɑr stɪl dɪˈskʌsɪŋ ɪt", "We 主语＋are discussing 现在进行时谓语＋it 宾语；still 表示仍然。")
NEED_DISCUSS = line("I still need to discuss it.", "我还需要讨论这件事。",
                    "aɪ stɪl nid tə dɪˈskʌs ɪt", "I 主语＋need 谓语＋to discuss it 表示需要做的事。")
EXPLAIN_PROGRAM = line("I will explain the program to them.", "我会向他们介绍这个项目。",
                       "aɪ wɪl ɪkˈspleɪn ðə ˈproʊɡræm tə ðɛm",
                       "I 主语＋will explain 谓语＋the program 宾语；to them 指向父母说明。")
CHECK_DISTANCE = line("I need to check my swimming distance.", "我需要确认自己能游的距离。",
                      "aɪ nid tə tʃɛk maɪ ˈswɪmɪŋ ˈdɪstəns",
                      "I 主语＋need 谓语；to check 表示需要做的事；my swimming distance 是 check 的宾语。")
MALAYSIA_SINGAPORE = line("I have been to Malaysia and Singapore.", "我去过马来西亚和新加坡。",
                         "aɪ hæv bɪn tə məˈleɪʒə ænd ˈsɪŋəpɔr",
                         "I 主语＋have been to 表示去过；Malaysia 和 Singapore 是两个目的地。")
SOUTH_KOREA = line("I have also visited South Korea.", "我还去过韩国。",
                  "aɪ hæv ˈɔlsoʊ ˈvɪzɪtɪd saʊθ kəˈriə",
                  "I 主语＋have visited 现在完成时谓语＋South Korea 宾语；also 表示还。")
INDONESIA_VIETNAM = line("I have visited Indonesia and Vietnam.", "我去过印度尼西亚和越南。",
                        "aɪ hæv ˈvɪzɪtɪd ˌɪndoʊˈniʒə ænd ˌviɛtˈnɑm",
                        "I 主语＋have visited 谓语＋Indonesia 和 Vietnam 并列宾语。")
AGE_MALAYSIA = line("I went there at sixteen and seventeen.", "我十六岁和十七岁时去过那里。",
                    "aɪ wɛnt ðɛr ət ˌsɪksˈtin ænd ˌsɛvənˈtin",
                    "I 主语＋went 过去时谓语；there 指马来西亚；at... 说明当时的年龄。")
AGES = {age: line(f"I was {age}.", f"我当时{zh}岁。", f"aɪ wəz {ipa}",
                   f"I 主语＋was 过去时系动词＋{age} 表语，回答旅行时的年龄。")
        for age, zh, ipa in [("seventeen", "十七", "ˌsɛvənˈtin"),
                             ("eighteen", "十八", "ˌeɪˈtin"),
                             ("nineteen", "十九", "ˌnaɪnˈtin")]}
HAS_PASSPORT = line("Yes, I have a passport.", "是的，我有护照。", "jɛs aɪ hæv ə ˈpæspɔrt",
                    "I 主语＋have 谓语＋a passport 宾语。")
CHECK_PASSPORT = line("I will check its expiry date.", "我会核对它的到期日期。",
                      "aɪ wɪl tʃɛk ɪts ɪkˈspaɪri deɪt",
                      "I 主语＋will check 谓语＋its expiry date 宾语；its 指护照的。")
NO_PASSPORT = line("I do not have a passport yet.", "我目前还没有护照。", "aɪ du nɑt hæv ə ˈpæspɔrt jɛt",
                   "I 主语＋do not have 否定谓语＋a passport 宾语；yet 表示还没有。")
APPLY_PASSPORT = line("I need to apply for one.", "我需要申请一本。", "aɪ nid tə əˈplaɪ fər wʌn",
                      "I 主语＋need 谓语；apply for 表示申请；one 代指一本护照。")
APPLIED = line("I have applied for a passport.", "我已经申请了护照。", "aɪ hæv əˈplaɪd fər ə ˈpæspɔrt",
               "I 主语＋have applied for 现在完成时谓语短语＋a passport 宾语。")
WAITING = line("I am waiting for it.", "我正在等它办好。", "aɪ æm ˈweɪtɪŋ fər ɪt",
               "I 主语＋am waiting for 现在进行时谓语短语＋it 宾语，it 指护照。")
NO_DOMESTIC = line("I have not visited other cities yet.", "我还没有去过其他城市。",
                   "aɪ hæv nɑt ˈvɪzɪtɪd ˈʌðər ˈsɪtiz jɛt",
                   "I 主语＋have not visited 否定谓语＋other cities 宾语；本题指中国境内其他城市。")
ABROAD = line("I have traveled abroad, though.", "不过，我出国旅行过。", "aɪ hæv ˈtrævəld əˈbrɔd ðoʊ",
              "I 主语＋have traveled 谓语；abroad 表示在国外；句尾 though 表示不过。")
BEEN_THERE = line("I have been there.", "我去过那里。", "aɪ hæv bɪn ðɛr",
                  "I 主语＋have been 谓语；there 指刚刚说出的真实城市。")
NO_FAVORITE = line("I do not have a favorite yet.", "我还没有最喜欢的城市。", "aɪ du nɑt hæv ə ˈfeɪvərɪt jɛt",
                   "I 主语＋do not have 否定谓语＋a favorite 宾语；favorite 在这里指最喜欢的城市。")
HARD_CHOOSE = line("It is hard to choose.", "很难选出一个。", "ɪt ɪz hɑrd tə tʃuz",
                   "It 是形式主语＋is 系动词＋hard 表语；to choose 说明难在哪里。")
CANNOT_COMPARE = line("I cannot compare them yet.", "我暂时还无法比较它们。", "aɪ ˈkænɑt kəmˈpɛr ðɛm jɛt",
                      "I 主语＋cannot compare 否定谓语＋them 宾语，指这些城市。")
FOOD = line("I like the food there.", "我喜欢那里的食物。", "aɪ laɪk ðə fud ðɛr",
            "I 主语＋like 谓语＋the food 宾语；there 指真实去过的城市。")
TASTES = line("It tastes good.", "味道很好。", "ɪt teɪsts ɡʊd",
              "It 主语指食物；tastes 感官系动词＋good 表语。")
VIEWS = line("I like the views there.", "我喜欢那里的景色。", "aɪ laɪk ðə vjuz ðɛr",
             "I 主语＋like 谓语＋the views 宾语；there 指真实去过的城市。")
BEAUTIFUL = line("They are beautiful.", "景色很美。", "ðeɪ ɑr ˈbjutɪfəl",
                 "They 主语指景色＋are 系动词＋beautiful 表语。")
UNDECIDED = line("I have not decided yet.", "我还没有决定。", "aɪ hæv nɑt dɪˈsaɪdɪd jɛt",
                 "I 主语＋have not decided 现在完成时否定谓语；yet 表示尚未。")
FINISH_COLLEGE = line("I want to finish college first.", "我想先完成大学学业。", "aɪ wɑnt tə ˈfɪnɪʃ ˈkɑlɪdʒ fɝst",
                      "I 主语＋want 谓语；to finish college 表示想做的事；first 表示首先。")


SUPPLEMENTAL_QUESTIONS = [
    card(2, "图片题：你读几年级", "What grade are you in?", "你今年读几年级？",
         ["大一", "体育体能训练专业"], "大学里常用 year 问年级；先答大一，再补一句专业即可。", short=FIRST_YEAR),
    card(3, "图片题：父母是否支持", "Do your parents support you to join the SWT program?", "父母支持你参加 SWT 吗？",
         ["是否支持", "如实补一句当前情况"], "只说明父母的真实态度；不要假定支持或出资。", branches=[
             choice("yes", "支持并了解项目（真实才选）", "仅当父母支持参加，且已了解项目时选择。", [SUPPORT, KNOW_PROGRAM]),
             choice("discussing", "暂不支持，正在讨论（真实才选）", "仅当目前不支持，而且你们仍在讨论时选择。", [NO_SUPPORT, DISCUSSING]),
             choice("not-discussed", "尚需讨论（真实才选）", "仅当还需要与父母讨论，并确实打算介绍项目时选择。", [NEED_DISCUSS, EXPLAIN_PROGRAM]),
         ]),
    card(4, "图片题：能游多少米", "How many meters can you swim?", "你能游多少米？",
         ["真实可完成的米数", "中国救生员证"], "问的是游泳距离，不是有没有证；不把证书推算成距离或美国资质。", branches=[
             choice("known-distance", "知道真实距离：先填米数", "填写最近实际安全完成的距离；不要为了面试夸大，也不要把累计距离说成连续距离。", [
                 slot("I can swim [distance] meters.", "我能游[真实距离]米。", distance="实际能游的米数"), *TAKE("certificate")]),
             choice("check-distance", "需要确认距离（真实才选）", "仅当你目前确实无法确认可靠距离时选择；这不代表没有游泳能力。", [CHECK_DISTANCE, *TAKE("certificate")]),
         ]),
    card(5, "图片题：出国经历", "Have you ever been overseas?", "你出过国吗？",
         ["有", "马来西亚和新加坡", "也去过韩国"], "先简答是否出国；追问时再分开说其他国家和旅行年龄。", short=[YES_HAVE, MALAYSIA_SINGAPORE, SOUTH_KOREA]),
    card(6, "图片题：是否有护照", "Do you hold a passport?", "你有护照吗？",
         ["目前是否持有护照", "如实说明办理或检查安排"], "曾出国不能证明现在仍持有有效护照；不要臆测有效期。", branches=[
             choice("yes", "现在有护照（真实才选）", "仅当目前确实持有护照，并会核对到期日期时选择；不声称已确认有效期。", [HAS_PASSPORT, CHECK_PASSPORT]),
             choice("no", "目前没有护照（真实才选）", "仅当现在没有护照，需要申请时选择；曾经有过与现在持有不同。", [NO_PASSPORT, APPLY_PASSPORT]),
             choice("applying", "已经申请、等待办理（真实才选）", "仅当确实已递交申请并正在等待办理时选择。", [APPLIED, WAITING]),
         ]),
    card(7, "图片题：国内旅行", "Have you travelled to other cities in China?", "你去过中国其他城市旅行吗？",
         ["有没有国内旅行", "有：填写真实城市"], "国内旅行与出国经历是不同问题；不拿海外国家名当作国内城市回答。", branches=[
             choice("yes", "去过：先填真实城市", "只填写确实去过的中国城市；不从你的学校或出国行程推断。", [YES_HAVE, slot("I have visited [city].", "我去过[真实中国城市]。", city="真实去过的中国城市")]),
             choice("no", "没有国内城市旅行（真实才选）", "仅当确实没有题目所问的国内城市旅行时选择；出国旅行已确认，可补一句区分。", [NO_DOMESTIC, ABROAD]),
         ]),
    card(8, "图片题：最喜欢的城市", "Which city do you like best among them?", "在去过的城市里，你最喜欢哪个？",
         ["先确认上一题的真实城市", "说其中最喜欢的一个"], "among them 指上一题去过的中国城市；不能凭空换成没去过的城市。", branches=[
             choice("favorite", "有最喜欢的城市：先填名称", "必须先确认第 7 题去过哪些中国城市，再从中选一个真正喜欢的城市。", [slot("I like [city] best.", "我最喜欢[去过的中国城市]。", city="第 7 题去过且最喜欢的中国城市"), BEEN_THERE]),
             choice("undecided", "去过，但没有最喜欢的（真实才选）", "仅当去过国内其他城市，但确实没有选出最喜欢的一个时选择。", [NO_FAVORITE, HARD_CHOOSE]),
             choice("not-visited", "还没去过，不能比较（真实才选）", "仅当第 7 题已如实选择没有去过国内其他城市时选择。", [NO_DOMESTIC, CANNOT_COMPARE]),
         ]),
    card(9, "图片题：喜欢城市的原因", "Why do you like this city?", "你为什么喜欢这座城市？",
         ["接着第 8 题同一城市", "只给一个真实原因"], "this city 必须承接已确认城市；食物、景色只是可选表达，不是替你编造体验。", branches=[
             choice("food", "确实喜欢那里的食物", "先确认第 8 题城市，而且你确实喜欢那里的食物及味道，才选择此分支。", [FOOD, TASTES]),
             choice("views", "确实喜欢那里的景色", "先确认第 8 题城市，而且你确实看过并喜欢那里的景色，才选择此分支。", [VIEWS, BEAUTIFUL]),
             choice("custom", "其他真实原因：先填内容", "先确认第 8 题城市，再填写自己真正喜欢的事物和评价。", [slot("I like [feature] there.", "我喜欢那里的[真实事物]。", feature="在该城市真正喜欢的事物"), slot("It is [description].", "它很[真实评价]。", description="与事物相符的真实评价")]),
         ]),
    card(10, "图片题：毕业与职业打算", "What are your plans after graduation and what job do you want to do?", "你毕业后有什么打算？想做什么工作？",
         ["是否决定毕业安排", "已决定：真实计划和职业；未定：如实说明"], "想在 SWT 做救生员，不等于已确定毕业后的职业；回国读书也不等于毕业就业计划。", branches=[
             choice("undecided", "职业未决定（真实才选）", "仅当毕业后安排确实尚未决定，且当前打算先完成学业时选择。", [UNDECIDED, FINISH_COLLEGE]),
             choice("decided", "有毕业计划：先填真实内容", "只填真实计划和想做的职业；不能把现阶段 SWT 岗位偏好当成毕业决定。", [slot("After graduation, I want to [plan].", "毕业后，我想[真实计划]。", plan="毕业后真实打算做的事"), slot("I would like to be a [job].", "我想做[真实职业]。", job="真实希望从事的职业")]),
         ]),
]


def question(number):
    return next(item for item in SUPPLEMENTAL_QUESTIONS if item["imageQuestionNumber"] == number)


# Sam confirmed these details after the initial card skeleton was prepared.
# Replace the unconfirmed branches, rather than leaving contradictory examples
# beside the confirmed short answers. The passport remains unconfirmed.
PARENTS_SUPPORT = line("My parents are very supportive.", "我的父母非常支持我。",
                       "maɪ ˈpɛrənts ɑr ˈvɛri səˈpɔrtɪv",
                       "My parents 主语＋are 系动词＋very supportive 表语；very 表示非常。")
YES_DO = line("Yes, they do.", "是的，他们支持。", "jɛs ðeɪ du",
              "Yes 先回答；they 指父母；do 代替题目中的 support。")
THOUSAND = line("I usually swim one thousand meters.", "我通常游一千米。",
                "aɪ ˈjuʒuəli swɪm wʌn ˈθaʊzənd ˈmitərz",
                "I 主语＋swim 谓语＋one thousand meters 距离；usually 表示通常，不代表连续不停。")
DAILY_SWIM = line("I swim almost every day.", "我几乎每天都游泳。", "aɪ swɪm ˈɔlmoʊst ˈɛvri deɪ",
                  "I 主语＋swim 谓语；almost every day 时间状语，表示几乎每天。")
MANY_CITIES = line("I have visited many cities in China.", "我去过中国的很多城市。",
                   "aɪ hæv ˈvɪzɪtɪd ˈmɛni ˈsɪtiz ɪn ˈtʃaɪnə",
                   "I 主语＋have visited 谓语＋many cities 宾语；in China 修饰城市所在范围。")
BEIJING_SHANGHAI = line("I have visited Beijing and Shanghai.", "我去过北京和上海。",
                        "aɪ hæv ˈvɪzɪtɪd beɪˈdʒɪŋ ænd ʃæŋˈhaɪ",
                        "I 主语＋have visited 谓语＋Beijing 和 Shanghai 并列宾语。")
GUANGZHOU_SHENZHEN = line("I have visited Guangzhou and Shenzhen.", "我去过广州和深圳。",
                          "aɪ hæv ˈvɪzɪtɪd ɡwɑŋˈdʒoʊ ænd ʃɛnˈdʒɛn",
                          "I 主语＋have visited 谓语＋Guangzhou 和 Shenzhen 并列宾语；地名音标为近似提示。")
HAINAN = line("I like Hainan Island best.", "我最喜欢海南岛。", "aɪ laɪk haɪˈnɑn ˈaɪlənd bɛst",
              "I 主语＋like 谓语＋Hainan Island 宾语；best 表示最喜欢；海南岛不是城市。")
CYCLED = line("I cycled around Hainan Island.", "我曾骑自行车环游海南岛。",
              "aɪ ˈsaɪkəld əˈraʊnd haɪˈnɑn ˈaɪlənd",
              "I 主语＋cycled 过去时谓语；around Hainan Island 表示环海南岛。")
CYCLED_THERE = line("I cycled around the island.", "我曾骑自行车环游这座岛。",
                    "aɪ ˈsaɪkəld əˈraʊnd ði ˈaɪlənd",
                    "I 主语＋cycled 过去时谓语；around the island 表示环岛，承接海南岛。")
HAINAN_PLACE = line("It is an island, not a city.", "它是一座岛，不是一座城市。",
                    "ɪt ɪz ən ˈaɪlənd nɑt ə ˈsɪti",
                    "It 指海南岛＋is 系动词＋an island 表语；not a city 补充澄清，避免把海南说成城市。")
SWIM_INSTRUCTOR = line("I want to be a swimming instructor.", "我想成为游泳教练。",
                       "aɪ wɑnt tə bi ə ˈswɪmɪŋ ɪnˈstrʌktər",
                       "I 主语＋want 谓语；to be a swimming instructor 表示想成为游泳教练。")
TEACH_SWIM = line("I want to teach people to swim.", "我想教别人游泳。",
                  "aɪ wɑnt tə titʃ ˈpipəl tə swɪm",
                  "I 主语＋want 谓语；teach people to swim 表示教别人游泳，people 是 teach 的宾语。")


def confirm(number, sentences, scaffold):
    question(number).update({"short": deepcopy(sentences), "branches": [],
                             "requiresConfirmation": False, "readyForAutoplay": True,
                             "answerType": "short-beginner", "scaffold": list(scaffold),
                             "keywords": list(scaffold),
                             "note": "短答使用你已确认的信息。追问未确认的细节时，先如实核对，不临时编造。"})


confirm(3, [YES_DO, PARENTS_SUPPORT], ["父母非常支持", "不擅自增加出资或具体理由"])
confirm(4, [THOUSAND, DAILY_SWIM], ["通常游一千米", "几乎每天游", "没说一定连续不停"])
confirm(7, [YES_HAVE, MANY_CITIES], ["有国内旅行", "去过中国很多城市"])
confirm(8, [HAINAN, CYCLED_THERE], ["最喜欢海南岛", "曾环岛骑行"])
confirm(9, [CYCLED], ["用环海南岛骑行的真实经历补充", "更具体的喜欢原因还需你补充"])
confirm(10, [SWIM_INSTRUCTOR, TEACH_SWIM], ["毕业想做游泳教练", "教别人游泳"])
question(3)["intent"] = question(3)["examinerIntent"] = "先说父母支持，再用一句简单评价补充；不擅自补父母出资或动机。"
question(4)["note"] = "你已确认几乎每天游一公里；这里不声称一千米连续不停，也不代表通过美国岗位考核。"
question(7)["intent"] = question(7)["examinerIntent"] = "先回答去过国内很多城市；听到具体追问时再举北京、上海、广州、深圳。"
question(8).update({"title": "图片题：最喜欢的地方（海南）",
                    "sourceQuestion": "Which city do you like best among them?",
                    "sourceQuestionZh": "在去过的城市中，你最喜欢哪个？",
                    "question": "Which place do you like best?", "questionZh": "你最喜欢哪个地方？",
                    "intent": "你的真实偏好是海南。练 place 问法；遇到原图 city 问法时先澄清海南岛不是城市。",
                    "examinerIntent": "区分 place 地方、island 岛和 city 城市；不替你编一个最喜欢的城市。",
                    "note": "海南是省；Hainan Island 指海南岛，不是城市。原图问 city，如果对方坚持要城市，请另选一个自己真正喜欢且去过的城市。"})
question(9).update({"title": "图片题：喜欢海南的经历",
                    "sourceQuestion": "Why do you like this city?", "sourceQuestionZh": "你为什么喜欢这座城市？",
                    "question": "Why do you like Hainan?", "questionZh": "你为什么喜欢海南？",
                    "intent": "先补充已确认的环岛骑行经历；具体喜欢什么尚未提供，不替你编食物、风景或感受。",
                    "examinerIntent": "用真实经历补充偏好；喜欢的具体原因还需要你自己说明。",
                    "note": "目前只确认环岛骑行经历，所以先练这一句。若老师追问具体原因，补你真实的感受；这里不编‘风景很美’或‘难忘’。",
                    "answerType": "confirmed-fact-with-detail-pending", "needsReasonDetail": True})
question(10)["intent"] = question(10)["examinerIntent"] = "你已确认毕业后想做游泳教练；别把 instructor 教练说成 lifeguard 救生员。"
question(10)["note"] = "毕业职业目标是游泳教练；SWT 项目结束后回国继续读书，是另一件已确认的安排。"


def follow(number, en, zh, hint, answer=(), *, target=None, confirmation=False):
    item = {"en": en, "zh": zh, "hint": hint, "answer": deepcopy(list(answer)),
            "requiresConfirmation": confirmation, "assessmentMode": "free"}
    if target:
        item["relatedQuestionId"] = target
    question(number)["followups"].append(item)


def follow_card(number, target, hint):
    other = question(target)
    follow(number, other["question"], other["questionZh"], hint, other["short"],
           target=other["id"], confirmation=other["requiresConfirmation"])


question(2)["variants"] = [{"en": "What year are you in?", "zh": "你读大学几年级？"}]
question(5)["variants"] = [{"en": "Have you traveled abroad before?", "zh": "你以前出国旅行过吗？"}]
question(6)["variants"] = [{"en": "Do you have a passport?", "zh": "你有护照吗？"}]
question(2)["relatedLessons"] = [previous.lesson(2, 3, "大一学生"), previous.lesson(2, 2, "真实专业")]
question(4)["relatedLessons"] = [previous.lesson(12, 2, "中国救生员证")]
question(10)["relatedLessons"] = [previous.lesson(14, 1, "区分项目后返校与毕业计划")]
question(8)["dependsOnQuestionIds"] = ["i07"]
question(9)["dependsOnQuestionIds"] = ["i07", "i08"]

follow(2, "What is your major?", "你是什么专业？", "听到 major，只说真实专业即可。", TAKE("major"), target="02")
follow(3, "Why do you want to join SWT?", "你为什么想参加 SWT？", "从父母态度转到自己的真实动机；不替父母编理由。", TAKE("english", "learn_culture"), target="15")
follow(3, "What concerns do your parents have?", "父母有什么顾虑？", "只说父母真正提过的顾虑；目前没有确认，不能猜。", confirmation=True)
follow(4, "Can you swim that distance without stopping?", "你能不间断游完这个距离吗？", "先确认真实米数，再如实回答是否能连续完成；证书不能替代这个答案。", confirmation=True)
follow(5, "Which other countries have you visited?", "你还去过哪些国家？", "只补充前面没有列出的两个国家。", [INDONESIA_VIETNAM])
for country, answer in [("Malaysia", AGE_MALAYSIA), ("Indonesia", AGES["seventeen"]),
                        ("Singapore", AGES["seventeen"]), ("Vietnam", AGES["eighteen"]),
                        ("South Korea", AGES["nineteen"])]:
    name = {"Malaysia": "马来西亚", "Indonesia": "印度尼西亚", "Singapore": "新加坡", "Vietnam": "越南", "South Korea": "韩国"}[country]
    follow(5, f"When did you visit {country}?", f"你什么时候去过{name}？",
           "回答当时的年龄即可；不用猜年份，也不用重背全部旅行经历。", [answer])
follow(6, "Is your passport still valid?", "你的护照还在有效期内吗？", "查看护照再确认，不根据过去出国经历猜测当前有效期。", confirmation=True)
follow(7, "Which cities have you visited?", "你去过哪些城市？", "分成两个短句说城市名；不用一次列出所有旅行。", [BEIJING_SHANGHAI, GUANGZHOU_SHENZHEN])
follow_card(7, 8, "从去过的国内城市转到喜欢的地方；你的真实偏好是海南岛，不把它误说成城市。")
follow_card(8, 9, "继续谈海南，先补充环岛骑行的真实经历；其他感受由你自己补充。")
follow(8, "Is Hainan a city?", "海南是城市吗？", "Hainan Island 是海南岛；用一句话澄清。", [HAINAN_PLACE])
follow(8, "Which city do you like best?", "你最喜欢哪个城市？", "对方如果严格问城市，需另外选一个你真正喜欢的城市；不能替你默认海口、三亚或其他城市。", confirmation=True)
follow(9, "What did you do there?", "你在那里做了什么？", "直接说环岛骑行，不添加未确认的路线、天数或同行者。", [CYCLED_THERE])
follow(9, "What did you like about the trip?", "你喜欢那次旅行的什么？", "请补充真实感受；目前没确认，不能把景色、食物或气候当成你的答案。", confirmation=True)
follow(10, "What will you do after SWT?", "SWT 结束后你会做什么？", "这问项目结束，不是毕业；你已确认回国继续读书。", TAKE("return", "studies"), target="s03")


# A complete annotation map for every answer token (including confirmed country
# names and ages), so adding a new branch cannot silently produce blank words.
_WORD_ROWS = [
    ("a", "一个／一名", "ə"), ("about", "关于；了解", "əˈbaʊt"),
    ("abroad", "在国外；到国外", "əˈbrɔd"), ("after", "在……之后", "ˈæftər"),
    ("also", "也；还", "ˈɔlsoʊ"), ("am", "是（与 I 连用）", "æm"),
    ("and", "和", "ænd"), ("applied", "已申请", "əˈplaɪd"),
    ("apply", "申请", "əˈplaɪ"), ("are", "是（与复数等连用）", "ɑr"),
    ("at", "在；在……岁时", "æt"), ("be", "成为；是", "bi"),
    ("beautiful", "美丽的", "ˈbjutɪfəl"), ("been", "去过（have been）", "bɪn"),
    ("best", "最；最好", "bɛst"), ("can", "能够", "kæn"),
    ("cannot", "不能", "ˈkænɑt"), ("certificate", "证书", "sərˈtɪfɪkət"),
    ("check", "核对；确认", "tʃɛk"), ("china", "中国", "ˈtʃaɪnə"),
    ("chinese", "中国的", "tʃaɪˈniz"), ("choose", "选择", "tʃuz"),
    ("cities", "城市（复数）", "ˈsɪtiz"), ("college", "大学；学院", "ˈkɑlɪdʒ"),
    ("compare", "比较", "kəmˈpɛr"), ("continue", "继续", "kənˈtɪnju"),
    ("culture", "文化", "ˈkʌltʃər"), ("date", "日期", "deɪt"),
    ("decided", "已决定", "dɪˈsaɪdɪd"), ("discuss", "讨论", "dɪˈskʌs"),
    ("discussing", "正在讨论", "dɪˈskʌsɪŋ"), ("distance", "距离", "ˈdɪstəns"),
    ("do", "否定／疑问助动词；做", "du"), ("eighteen", "十八", "ˌeɪˈtin"),
    ("english", "英语", "ˈɪŋɡlɪʃ"), ("expiry", "到期；期满", "ɪkˈspaɪri"),
    ("explain", "解释；介绍", "ɪkˈspleɪn"), ("favorite", "最喜欢的人或事物", "ˈfeɪvərɪt"),
    ("finish", "完成", "ˈfɪnɪʃ"), ("first", "首先；第一", "fɝst"),
    ("first-year", "第一学年的；大一的", "ˈfɝst jɪr"), ("fitness", "体能；健身", "ˈfɪtnəs"),
    ("food", "食物", "fud"), ("for", "为了；申请……", "fər"),
    ("good", "好的", "ɡʊd"), ("graduation", "毕业", "ˌɡrædʒuˈeɪʃən"),
    ("hard", "困难的", "hɑrd"), ("have", "有；完成时助动词", "hæv"),
    ("i", "我", "aɪ"), ("improve", "提高", "ɪmˈpruv"),
    ("indonesia", "印度尼西亚", "ˌɪndoʊˈniʒə"), ("is", "是", "ɪz"),
    ("it", "它；这件事", "ɪt"), ("its", "它的", "ɪts"),
    ("know", "知道；了解", "noʊ"), ("korea", "韩国（与 South 连用）", "kəˈriə"),
    ("learn", "学习；了解", "lɝn"), ("lifeguard", "救生员", "ˈlaɪfɡɑrd"),
    ("like", "喜欢；would like 想要", "laɪk"), ("major", "大学专业", "ˈmeɪdʒər"),
    ("malaysia", "马来西亚", "məˈleɪʒə"), ("meters", "米（复数）", "ˈmitərz"),
    ("my", "我的", "maɪ"), ("need", "需要", "nid"),
    ("nineteen", "十九", "ˌnaɪnˈtin"), ("not", "不；没有", "nɑt"),
    ("one", "一个；一本（代指护照）", "wʌn"), ("other", "其他的", "ˈʌðər"),
    ("passport", "护照", "ˈpæspɔrt"), ("physical", "身体的；体能的", "ˈfɪzɪkəl"),
    ("plan", "计划", "plæn"), ("program", "项目", "ˈproʊɡræm"),
    ("return", "返回", "rɪˈtɝn"), ("seventeen", "十七", "ˌsɛvənˈtin"),
    ("singapore", "新加坡", "ˈsɪŋəpɔr"), ("sixteen", "十六", "ˌsɪksˈtin"),
    ("south", "南；South Korea 韩国", "saʊθ"), ("still", "仍然", "stɪl"),
    ("student", "学生", "ˈstudənt"), ("studies", "学业", "ˈstʌdiz"),
    ("support", "支持", "səˈpɔrt"), ("swim", "游泳", "swɪm"),
    ("swimming", "游泳的；游泳", "ˈswɪmɪŋ"), ("swt", "暑期工作旅行项目", "ˌɛs ˌdʌbəlju ˈti"),
    ("tastes", "尝起来", "teɪsts"), ("the", "这个；那个", "ðə"),
    ("them", "他们；它们（宾格）", "ðɛm"), ("there", "那里", "ðɛr"),
    ("they", "他们；它们", "ðeɪ"), ("though", "不过（句尾）", "ðoʊ"),
    ("to", "去；动词不定式标记", "tə"), ("training", "训练", "ˈtreɪnɪŋ"),
    ("traveled", "旅行过", "ˈtrævəld"), ("vietnam", "越南", "ˌviɛtˈnɑm"),
    ("views", "景色", "vjuz"), ("visited", "去过；参观过", "ˈvɪzɪtɪd"),
    ("waiting", "正在等待", "ˈweɪtɪŋ"), ("want", "想要", "wɑnt"),
    ("was", "过去是；当时是", "wəz"), ("we", "我们", "wi"),
    ("went", "去过（go 的过去式）", "wɛnt"), ("will", "会；将", "wɪl"),
    ("would", "会；想要（礼貌表达）", "wʊd"), ("yes", "是的", "jɛs"),
    ("yet", "还；尚未", "jɛt"), ("american", "美国的", "əˈmɛrɪkən"),
    ("almost", "几乎", "ˈɔlmoʊst"), ("an", "一个（元音前）", "ən"),
    ("around", "环绕；围绕", "əˈraʊnd"), ("beijing", "北京", "beɪˈdʒɪŋ"),
    ("city", "城市", "ˈsɪti"), ("cycled", "骑自行车（过去式）", "ˈsaɪkəld"),
    ("day", "天", "deɪ"), ("every", "每一", "ˈɛvri"),
    ("guangzhou", "广州", "ɡwɑŋˈdʒoʊ"), ("hainan", "海南", "haɪˈnɑn"),
    ("in", "在……里面；在某地", "ɪn"), ("instructor", "教练；指导员", "ɪnˈstrʌktər"),
    ("island", "岛", "ˈaɪlənd"), ("many", "很多", "ˈmɛni"),
    ("parents", "父母", "ˈpɛrənts"), ("people", "人们", "ˈpipəl"),
    ("shanghai", "上海", "ʃæŋˈhaɪ"), ("shenzhen", "深圳", "ʃɛnˈdʒɛn"),
    ("supportive", "支持的；给予支持的", "səˈpɔrtɪv"), ("teach", "教", "titʃ"),
    ("thousand", "千", "ˈθaʊzənd"), ("usually", "通常", "ˈjuʒuəli"),
    ("very", "非常", "ˈvɛri"),
]
EXTRA_WORDS = {word: {"zh": zh, "ipa": ipa} for word, zh, ipa in _WORD_ROWS}


def all_sentences():
    for item in SUPPLEMENTAL_QUESTIONS:
        yield from item["short"]
        for branch in item["branches"]:
            yield from branch["sentences"]
        for followup in item["followups"]:
            yield from followup["answer"]


def validate():
    assert len(SUPPLEMENTAL_QUESTIONS) == 9
    assert QUESTION_SOURCE_MAP[1] == "01"
    for item in SUPPLEMENTAL_QUESTIONS:
        assert item["requiresConfirmation"] == (item["imageQuestionNumber"] == 6)
        assert bool(item["short"]) == item["readyForAutoplay"]
        if item["short"]:
            assert (2 <= len(item["short"]) <= 3) or (item["id"] == "i09" and len(item["short"]) == 1 and item["needsReasonDetail"])
        for branch in item["branches"]:
            assert not branch["confirmed"] and branch["condition"]
            assert 2 <= len(branch["sentences"]) <= 3
    for sentence in all_sentences():
        assert sentence["id"] == previous.sentence_id(sentence["en"])
        assert len(re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", sentence["en"])) <= 8, sentence["en"]
        assert sentence["zh"] and sentence["grammar"] and sentence["chunks"]
        if "[" in sentence["en"]:
            assert sentence["needsPersonalization"] and sentence["slots"]
            assert sentence["audio"] is None and not sentence["audioEligible"]
            assert not sentence["assessmentEnabled"] and not sentence["ipa"]
        else:
            assert sentence["ipa"] and sentence["pronunciation"]
        for token in re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", re.sub(r"\[[^]]*\]", "", sentence["en"])):
            assert token.lower() in EXTRA_WORDS, token
    return True


validate()
if __name__ == "__main__":
    print(json.dumps({"supplementalQuestions": SUPPLEMENTAL_QUESTIONS,
                      "questionSourceMap": QUESTION_SOURCE_MAP,
                      "extraWords": EXTRA_WORDS}, ensure_ascii=False, indent=2))
