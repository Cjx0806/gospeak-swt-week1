'use strict';
// Offline state-machine tests. No microphone, speech service, or network is used.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../assets/lesson-recognition-v22.js'), 'utf8');

function harness() {
  const timers = new Map(), windowEvents = new Map(), documentEvents = new Map();
  const recordings = [], streams = [], writes = [], notices = [];
  let timerId = 0, mediaCalls = 0, renders = 0, startFailure = false, stopFailure = false;
  let getMedia = () => Promise.resolve(makeStream());
  const button = { disabled: false, textContent: '', onclick: null };
  const title = { textContent: '' }, help = { textContent: '' };
  const classes = new Set();
  const practice = {
    classList: { remove(name) { classes.delete(name); } },
    querySelector(selector) { return selector === 'h3' ? title : selector === 'p' ? help : null; }
  };
  function makeStream() {
    const track = { stopped: false, stop() { this.stopped = true; } };
    const stream = { getTracks() { return [track]; } };
    streams.push(stream); return stream;
  }
  class Recognition {
    constructor() { this.started = 0; this.stopped = 0; this.aborted = 0; recordings.push(this); }
    start() { this.started++; if (startFailure) throw new Error('mock start failure'); if (this.onstart) this.onstart(); }
    stop() { this.stopped++; if (stopFailure) throw new Error('mock stop failure'); }
    abort() { this.aborted++; }
  }
  function add(map, name, callback) {
    if (!map.has(name)) map.set(name, []);
    map.get(name).push(callback);
  }
  const window = {
    SpeechRecognition: Recognition,
    addEventListener(name, callback) { add(windowEvents, name, callback); },
    dispatchEvent(event) {
      if (event.type === 'gospeak-audio-status') notices.push(event.detail.message);
      for (const callback of windowEvents.get(event.type) || []) callback(event);
    }
  };
  const document = { hidden: false, addEventListener(name, callback) { add(documentEvents, name, callback); } };
  const sandbox = {
    window, document, navigator: { mediaDevices: { getUserMedia() { mediaCalls++; return getMedia(); } } },
    e: [{ phrases: [{ en: 'My name is Sam.' }, { en: 'I am a student.' }] }], b: 0, C: 0, v: 'lesson', T: false, E: '', j: [],
    _: { querySelector(selector) { return selector === '#record' ? button : selector === '.practice' ? practice : null; } },
    $() {
      renders++;
      if (sandbox.T) classes.add('listening'); else classes.delete('listening');
      button.disabled = sandbox.T;
      button.textContent = sandbox.T ? '识别中' : '开始跟读';
      button.onclick = () => sandbox.ut();
    },
    we(expected, actual) { return { score: expected.toLowerCase() === actual.toLowerCase() ? 100 : 50 }; },
    localStorage: { setItem(key, value) { writes.push({ key, value }); } },
    setTimeout(callback, milliseconds) { const id = ++timerId; timers.set(id, { callback, milliseconds }); return id; },
    clearTimeout(id) { timers.delete(id); },
    CustomEvent: class { constructor(type, options) { this.type = type; this.detail = options.detail; } },
    Promise, JSON
  };
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox);
  return {
    sandbox, recordings, streams, writes, timers, button, title, help, classes, notices,
    makeStream, mediaCalls: () => mediaCalls, renders: () => renders,
    setMedia(fn) { getMedia = fn; }, setStartFailure(value) { startFailure = value; }, setStopFailure(value) { stopFailure = value; },
    tick() { const pending = [...timers.values()]; timers.clear(); for (const item of pending) item.callback(); },
    event(type, payload = {}) { window.dispatchEvent({ type, ...payload }); },
    navigate(index = 1) {
      window.dispatchEvent({ type: 'click', target: { closest(selector) { return selector.includes('[data-view]') ? {} : null; } } });
      sandbox.C = index; sandbox.E = 'new-page-feedback';
    },
    hide() { document.hidden = true; for (const fn of documentEvents.get('visibilitychange') || []) fn(); }
  };
}
function final(recognition, transcript) { const result = [{ transcript }]; result.isFinal = true; recognition.onresult({ results: [result] }); }
async function flush() { await Promise.resolve(); await Promise.resolve(); }

(async function () {
  {
    const h = harness(); let grant;
    h.setMedia(() => new Promise(resolve => { grant = resolve; }));
    const waiting = h.sandbox.ut();
    assert.equal(h.sandbox.T, true, 'permission is locked before await');
    assert.match(h.title.textContent, /正在准备麦克风/);
    assert.equal(h.button.disabled, false, 'permission wait remains cancellable');
    assert.match(h.button.textContent, /取消麦克风/);
    await h.sandbox.ut(); await h.sandbox.ut();
    assert.equal(h.mediaCalls(), 1, 'rapid duplicate calls create one request');
    h.button.onclick();
    assert.equal(h.sandbox.T, false);
    const stream = h.makeStream(); grant(stream); await waiting;
    assert.equal(stream.getTracks()[0].stopped, true, 'late permission grant is released');
    assert.equal(h.recordings.length, 0, 'canceled request never starts recognition');
    assert.equal(h.timers.size, 0);
  }
  {
    const h = harness(); let grantOld;
    h.setMedia(() => new Promise(resolve => { grantOld = resolve; }));
    const old = h.sandbox.ut(); h.button.onclick();
    h.setMedia(() => Promise.resolve(h.makeStream())); await h.sandbox.ut();
    const current = h.recordings.at(-1);
    grantOld(h.makeStream()); await old;
    assert.equal(h.sandbox.T, true, 'late old grant cannot cancel new recognition');
    assert.equal(current.aborted, 0);
    assert.equal(h.recordings.length, 1);
    h.sandbox.window.__samLessonRecognitionV22.cancel();
  }
  {
    const h = harness(); let rejectOld;
    h.setMedia(() => new Promise((_, reject) => { rejectOld = reject; }));
    const old = h.sandbox.ut(); h.button.onclick();
    h.setMedia(() => Promise.resolve(h.makeStream())); await h.sandbox.ut();
    rejectOld(new Error('denied old')); await old;
    assert.equal(h.sandbox.T, true, 'late rejection cannot release a newer session');
    h.sandbox.window.__samLessonRecognitionV22.cancel();
  }
  {
    const h = harness(); await h.sandbox.ut(); const recognition = h.recordings[0];
    const oldResult = recognition.onresult, oldError = recognition.onerror, oldEnd = recognition.onend;
    h.navigate();
    assert.equal(h.sandbox.T, false); assert.equal(h.classes.has('listening'), false, 'navigation guard no longer traps the learner');
    assert.equal(recognition.aborted, 1);
    const renderCount = h.renders();
    oldResult({ results: [[{ transcript: 'My name is Sam.' }]] }); oldError({ error: 'network' }); oldEnd();
    assert.equal(h.sandbox.E, 'new-page-feedback'); assert.equal(h.renders(), renderCount, 'late events never repaint a new page');
    assert.equal(h.writes.length, 0); assert.equal(h.timers.size, 0);
  }
  {
    const h = harness(); h.sandbox.j = Array.from({ length: 20 }, () => 40);
    await h.sandbox.ut(); const r = h.recordings[0]; const oldEnd = r.onend;
    final(r, 'My name is Sam.');
    assert.equal(h.sandbox.T, false); assert.equal(h.sandbox.E, 'My name is Sam.');
    assert.equal(h.sandbox.j.length, 20); assert.equal(h.sandbox.j.at(-1), 100);
    assert.equal(h.writes[0].key, 'gospeak-independent-progress');
    const count = h.renders(); oldEnd(); assert.equal(h.renders(), count, 'completion is rendered once');
    await h.sandbox.ut(); assert.equal(h.mediaCalls(), 1, 'second attempt skips the redundant mic preflight');
    assert.equal(h.recordings.length, 2); h.sandbox.window.__samLessonRecognitionV22.cancel();
  }
  {
    const h = harness(); await h.sandbox.ut();
    h.tick(); assert.equal(h.sandbox.T, false); assert.match(h.sandbox.E, /18 秒/);
    assert.equal(h.writes.length, 0); assert.equal(h.recordings[0].aborted, 1);
    await h.sandbox.ut(); assert.equal(h.sandbox.T, true, 'timeout allows immediate retry');
    h.sandbox.window.__samLessonRecognitionV22.cancel();
  }
  {
    const h = harness(); let grant;
    h.setMedia(() => new Promise(resolve => { grant = resolve; })); const pending = h.sandbox.ut();
    h.tick(); assert.equal(h.sandbox.T, false); assert.match(h.sandbox.E, /准备超时/);
    grant(h.makeStream()); await pending; assert.equal(h.recordings.length, 0);
  }
  {
    const h = harness(); h.setStartFailure(true); await h.sandbox.ut();
    assert.equal(h.sandbox.T, false); assert.equal(h.timers.size, 0); assert.match(h.sandbox.E, /没有启动/);
    h.setStartFailure(false); await h.sandbox.ut(); assert.equal(h.sandbox.T, true);
    h.sandbox.window.__samLessonRecognitionV22.cancel();
  }
  {
    const h = harness(); await h.sandbox.ut(); const r = h.recordings[0];
    h.button.onclick(); assert.equal(r.stopped, 1); assert.match(h.button.textContent, /取消结果/);
    final(r, 'My name is Sam.'); assert.equal(h.sandbox.j.at(-1), 100);
    assert.equal(h.timers.size, 0);
  }
  {
    const h = harness(); await h.sandbox.ut(); h.button.onclick(); h.tick();
    assert.equal(h.sandbox.T, false); assert.equal(h.writes.length, 0); assert.match(h.sandbox.E, /不会记作低分/);
  }
  {
    const h = harness(); await h.sandbox.ut(); const r = h.recordings[0];
    const interim = [{ transcript: 'My name' }]; interim.isFinal = false;
    r.onresult({ results: [interim] }); assert.equal(h.writes.length, 0);
    r.onend(); assert.equal(h.sandbox.T, false); assert.equal(h.writes.length, 0);
  }
  {
    const h = harness(); await h.sandbox.ut(); h.hide();
    assert.equal(h.sandbox.T, false); assert.equal(h.recordings[0].aborted, 1); assert.equal(h.timers.size, 0);
  }
  {
    const h = harness(); await h.sandbox.ut();
    const oldStopClosure = h.button.onclick;
    const rendersBeforePlayback = h.renders();
    h.event('gospeak-playback-request', { detail: { owner: 'legacy-lesson' } });
    assert.equal(h.sandbox.T, false); assert.equal(h.recordings[0].aborted, 1);
    assert.equal(h.renders(), rendersBeforePlayback, 'playback cleanup does not replace the page DOM');
    assert.equal(h.button.disabled, false); assert.equal(h.button.textContent, '开始跟读');
    assert.equal(h.title.textContent, '轮到你开口了'); assert.match(h.help.textContent, /完整说一次/);
    assert.notEqual(h.button.onclick, oldStopClosure, 'closed stop callback is detached from the visible button');
    await h.button.onclick();
    assert.equal(h.sandbox.T, true, 'record button immediately starts again after playback cancellation');
    assert.equal(h.recordings.length, 2); assert.equal(h.recordings[1].started, 1);
    oldStopClosure();
    assert.equal(h.sandbox.T, true, 'even a queued old stop callback cannot cancel the new session');
    assert.equal(h.recordings[1].aborted, 0);
    h.sandbox.window.__samLessonRecognitionV22.cancel();
  }
  {
    const h = harness(); await h.sandbox.ut(); h.event('pagehide');
    assert.equal(h.sandbox.T, false); assert.equal(h.timers.size, 0);
  }
  await flush();
  console.log('PASS: immediate permission state, one request, cancellation, late grants/rejections, navigation isolation, preserved scoring/progress, fast retry, timeouts, start failure, stop/final result, no fake empty scores, visibility/playback/pagehide cleanup.');
})().catch(error => { console.error(error); process.exitCode = 1; });
