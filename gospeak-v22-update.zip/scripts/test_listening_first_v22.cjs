/* Listening before speaking: actual curriculum, offline DOM/audio/recorder doubles. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),cp=require('node:child_process');
const root=path.join(__dirname,'..'),python=process.env.PYTHON||process.env.PYTHON3||'python3';
const original=fs.readFileSync(path.join(root,'assets/mainline-v21.js'),'utf8');
const code='import sys;sys.path.insert(0,sys.argv[1]);from patch_mainline_v22 import patch_mainline;from patch_core_v22 import patch_core;from patch_listening_first_v22 import patch_listening_first;print(patch_listening_first(patch_core(patch_mainline(sys.stdin.read()))))';
const source=cp.execFileSync(python,['-c',code,__dirname],{input:original,encoding:'utf8',maxBuffer:2*1024*1024});
assert(source.includes('/* V22_LISTENING_FIRST */'));
const boundary=source.indexOf("  window.addEventListener('sam-recorder-start'");assert(boundary>0);
const instrumented=source.slice(0,boundary)+'window.test={state,render,handleClick,handleChange,choose,resetPrompt,q,activeQuestion,variants,listeningOptions,filterQuestions,practiceQuestions,stopSound};})();';
const payload=JSON.parse(fs.readFileSync(path.join(root,'_site/interview-v21.json'),'utf8'));
function context(){
  let html='',status='',recording=false,mounts=0,destroys=0,timerId=0;
  const targets=[],timers=new Map();
  class Audio{constructor(){this.paused=true;this.currentTime=0;this.duration=2;}play(){this.paused=false;return Promise.resolve();}pause(){this.paused=true;}removeAttribute(){this.src='';}load(){}}
  const sandbox={window:{dispatchEvent(){},SamRecorder:{mount(node,options){assert(node,'recorder must have a target');mounts++;targets.push(options);return{isRecording(){return recording;},destroy(){destroys++;}};}}},document:{baseURI:'https://example.test/',querySelector(){return null;},querySelectorAll(){return[];}},localStorage:{getItem(){return JSON.stringify({selected:'01'});},setItem(){}},URL,Date,Math,Audio,Promise,CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},setTimeout(fn){const id=++timerId;timers.set(id,fn);return id;},clearTimeout(id){timers.delete(id);}};
  vm.runInNewContext(instrumented,sandbox);const t=sandbox.window.test;
  t.state.data=payload;t.state.questions=payload.questions;
  const placeholder={replaceWith(){}};
  t.state.root={isConnected:true,contains(){return true;},querySelector(selector){if(selector==='[data-sam-content]')return{set innerHTML(value){html=value;}};if(selector==='[data-sam-status]')return{set textContent(value){status=value;}};if(selector==='[data-sam-recorder]')return html.includes('data-sam-recorder')?placeholder:null;return null;},querySelectorAll(){return[];}};
  function click(action,value){const button={disabled:false,hasAttribute(){return false;},getAttribute(key){return key==='data-sam-action'?action:key==='data-value'?String(value):null;}};t.handleClick({target:{closest(){return button;}}});}
  return{t,click,html:()=>html,status:()=>status,targets,mounts:()=>mounts,destroys:()=>destroys,recording(value){recording=value;}};
}
const c=context(),t=c.t;
t.render();const first=t.q();
assert.equal(t.state.selected,'15','default moves past the already-learned introduction');
assert.equal(t.state.listeningFocus,true);
assert.equal(c.mounts(),0,'listening stage does not initialize a microphone/recorder');
assert.equal(t.state.recorderTarget,null);
assert(c.html().includes('第一步：先听懂考官在问什么'));
assert(c.html().includes('▶ 听问题'));assert(c.html().includes('▶ 慢速听问题'));
assert(c.html().includes('先听问题，不看题目文字'));
assert(!c.html().includes(first.question),'English question is hidden until help is requested');
for(const line of first.short)assert(!c.html().includes(line.en),'initial view must not expose an answer');
for(const forbidden of ['class="sam21-scaffold"','class="sam21-reference"','class="sam21-rounds"','data-sam-recorder','class="sam21-review"','class="sam21-related"','class="sam21-progress"'])assert(!c.html().includes(forbidden),forbidden+' must be absent while listening');
assert(!c.html().includes('sam22-question-variants'));
assert(!c.html().includes('sam22-listening-clues'),'keywords never hint at a hidden question');
const picker=c.html().match(/<details class="sam22-listening-topic-picker"[^>]*>/);
assert(picker&&!picker[0].includes('open'),'question title/category controls are initially collapsed');
assert(c.html().includes('<summary>换练习题目（可选）</summary>'),'collapsed label never exposes selected question title');

const options=t.listeningOptions(first);
assert.equal(options.length,3);assert.equal(new Set(options.map(x=>x.zh)).size,3);
assert.equal(options.filter(x=>x.correct).length,1);
assert.equal(options.find(x=>x.correct).zh,t.activeQuestion(first).zh);
const ownMeanings=t.variants(first).map(x=>x.zh);
for(const wrong of options.filter(x=>!x.correct))assert(!ownMeanings.includes(wrong.zh),'same-question synonyms are not distractors');
for(const option of options)assert(t.practiceQuestions().some(item=>item.questionZh===option.zh),'default meaning choices stay inside the basic practice pool');
const category=t.state.category;t.state.category=first.category;
assert.equal(t.listeningOptions(first).length,3,'narrow category must not remove the three meaning choices');t.state.category=category;
const beforeCounts=JSON.stringify(t.state.counts),beforeRounds=JSON.stringify(t.state.rounds);
c.click('meaning',options.findIndex(x=>!x.correct));
assert(c.html().includes('还没选对'));assert.equal(c.mounts(),0);assert.equal(t.state.listeningFocus,true);
assert.equal(JSON.stringify(t.state.counts),beforeCounts);assert.equal(JSON.stringify(t.state.rounds),beforeRounds);
c.click('meaning',options.findIndex(x=>x.correct));assert(c.html().includes('选对了'));assert(c.html().includes('不是机构口测评分'));
c.click('question-hint');assert(c.html().includes(first.question));assert(c.html().includes('sam22-question-variants'));
for(const line of first.short)assert(!c.html().includes(line.en),'revealing question text must not reveal answer');
const matchingClues=(first.listeningClues||[]).filter(clue=>first.question.toLowerCase().includes(clue.en.toLowerCase())).slice(0,2);
if(matchingClues.length){
  const block=c.html().match(/<div class="sam22-listening-clues">([\s\S]*?)<\/div>/);assert(block);
  assert.equal((block[1].match(/data-sam-play=/g)||[]).length,matchingClues.length,'at most two question keywords, not a word grid');
  for(const clue of matchingClues){assert(block[1].includes(clue.en+' · '+clue.zh));const clip=Object.values(t.state.clips).find(x=>x.text===clue.en);assert(clip);assert.equal(clip.src,clue.audio.slow||clue.audio.normal);assert.equal(clip.rate,clue.audio.slowRate||1);}
}
c.click('question-hint');assert(!c.html().includes(first.question));assert(!c.html().includes('sam22-question-variants'));assert(!c.html().includes('sam22-listening-clues'));

// Wrong choices never force a beginner into a dead end; continuing is explicit.
c.click('meaning',options.findIndex(x=>!x.correct));c.click('answer-start');
assert.equal(t.state.listeningFocus,false);assert.equal(t.state.round,1);
assert(c.html().includes('第二步：用短句回答'));assert(c.html().includes('回到听题'));
assert(c.html().includes('class="sam21-rounds"'));assert(c.html().includes('data-sam-recorder'));
assert.equal(c.mounts(),1);assert.equal(c.targets.at(-1).assessmentMode,'scripted');
for(const line of first.short)assert(c.html().includes(line.en));

// Any route-changing action still respects the existing active-recorder guard.
c.recording(true);const mounted=t.state.recorder,beforeDestroys=c.destroys();
c.click('listen-first');assert.equal(t.state.listeningFocus,false);assert.equal(t.state.recorder,mounted);assert.equal(c.destroys(),beforeDestroys);assert(c.status().includes('停止并保存录音'));
c.click('topic','02');assert.equal(t.state.selected,'15');assert.equal(c.destroys(),beforeDestroys);
c.recording(false);c.click('listen-first');
assert.equal(t.state.listeningFocus,true);assert.equal(t.state.listeningChoice,null);assert.equal(t.state.questionRevealed,false);
assert(!c.html().includes('data-sam-recorder'));assert.equal(t.state.recorder,null);assert(c.destroys()>beforeDestroys);

c.click('question-hint');c.click('answer-start');c.click('round','2');
assert.equal(t.state.round,2);assert.equal(t.state.listeningFocus,false);assert.equal(c.targets.at(-1).assessmentMode,'free');
c.click('round','3');assert.equal(t.state.round,3);assert(!c.html().includes(first.question),'third answer round remains blind');
c.click('topic','02');assert.equal(t.state.selected,'02');assert.equal(t.state.listeningFocus,true);assert.equal(t.state.listeningChoice,null);assert(!c.html().includes('data-sam-recorder'),'new topic resets listening before answering');
c.click('answer-start');c.click('random');assert.equal(t.state.listeningFocus,true);assert(!c.html().includes('data-sam-recorder'));
t.state.listeningChoice=1;t.state.questionRevealed=true;t.resetPrompt();assert.equal(t.state.listeningFocus,true);assert.equal(t.state.listeningChoice,null);assert.equal(t.state.questionRevealed,false);

// Same question, new spoken wording: hide text and reset the meaning attempt.
c.click('topic','15');c.click('answer-start');c.click('wording');
assert.equal(t.state.listeningFocus,true);assert.equal(t.state.listeningChoice,null);assert.equal(t.state.questionRevealed,false);
assert.equal(t.listeningOptions(t.q()).find(x=>x.correct).zh,t.activeQuestion(t.q()).zh);
c.click('question-hint');
const currentQuestion=t.activeQuestion(t.q());
for(const clue of t.q().listeningClues||[]){if(!currentQuestion.en.toLowerCase().includes(clue.en.toLowerCase()))assert(!Object.values(t.state.clips).some(clip=>clip.text===clue.en),'wording only offers keywords actually present in its question');}
const savedClues=t.q().listeningClues;t.q().listeningClues=[];t.render();assert(!c.html().includes('sam22-listening-clues'),'missing clue data shows no dead controls');t.q().listeningClues=savedClues;
if(t.q().followups&&t.q().followups.length){t.state.followup=0;t.state.questionRevealed=true;t.render();assert(!c.html().includes('sam22-listening-clues'),'main-question clues cannot leak into followups');t.state.followup=-1;}

// Mock is still blind free-response practice, not the multiple-choice learning step.
c.click('mode','mock');assert.equal(t.state.listeningFocus,false);assert.equal(t.state.mode,'mock');
assert(!c.html().includes('sam22-listening-first'));assert(!c.html().includes('data-sam-action="meaning"'));
assert(c.html().includes('data-sam-recorder'));assert.equal(c.targets.at(-1).assessmentMode,'free');
assert.equal(c.targets.at(-1).expectedText,'');assert(!c.html().includes(t.q().question));
c.click('after-intro');assert.equal(t.state.mode,'mock');assert.equal(t.state.mockScope,'after-intro');assert.equal(t.state.listeningFocus,false);assert.notEqual(t.state.selected,'01');
for(let i=0;i<10;i++){c.click('random');assert.notEqual(t.state.selected,'01');assert.equal(t.state.listeningFocus,false);}
c.click('mode','prepare');assert.equal(t.state.listeningFocus,true);assert(!c.html().includes('data-sam-recorder'));

// Check options/hidden output against every available question without hardcoding bank size.
c.click('scope-more');assert.equal(t.state.practiceScope,'all');assert.equal(t.state.listeningFocus,true);
for(const item of payload.questions){
  t.state.mode='prepare';t.choose(item.id);
  assert.equal(t.state.listeningFocus,true);assert(!c.html().includes('data-sam-recorder'));
  const choices=t.listeningOptions(item);assert.equal(choices.length,3,item.id+' must offer 3 distinct meanings');
  assert.equal(new Set(choices.map(x=>x.zh)).size,3);assert.equal(choices.filter(x=>x.correct).length,1);
  assert.equal(choices.find(x=>x.correct).zh,t.activeQuestion(item).zh);
  assert(!c.html().includes('undefined'));for(const clip of Object.values(t.state.clips))assert(clip.src,'listening only registers actual question audio');
}
t.stopSound();
for(const bad of [original,source]){
  const check=cp.spawnSync(python,['-c','import sys;sys.path.insert(0,sys.argv[1]);from patch_listening_first_v22 import patch_listening_first;patch_listening_first(sys.stdin.read())',__dirname],{input:bad,encoding:'utf8'});
  assert.notEqual(check.status,0);assert(check.stderr.includes('ValueError'));
}
console.log('PASS V22 listening first: hidden answers and selectors, question-only audio/reveal, 3 distinct meanings with ungraded feedback, optional continuation, existing 3 answer rounds, reset on new questions/wording, unchanged blind mock/no-intro random, active-recording safety, all actual question data and fail-closed patching.');
