"""Bind sentence audio to exact text; extend the retained course to 21 days.

The original published bundle is the V21 ZIP, not the obsolete TypeScript
checkout. Only new lesson data, explicit audio bindings, and week labels change.
"""
import argparse
import asyncio
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

from build_v18_listening import Speech, _clip_key
from build_v21 import synthesize_missing
from v22_week3 import LESSONS, GUIDES, SENTENCE_IPA, WORDS
from patch_mainline_v22 import patch_mainline
from patch_core_v22 import patch_core
from patch_listening_first_v22 import patch_listening_first

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = 'assets/index-C6MAz4Oq.js'
NODE = shutil.which('node') or '/Users/chenjunxi/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
TOKENS = r'[A-Za-z]+(?:-[A-Za-z]+)?'
TIP_FIXES = {
    5: 'FIRST-year · STU-dent · COL-lege · PRE-school · edu-CA-tion',
    6: 'MA-jor · PHY-si-cal · FIT-ness · TRAIN-ing',
    7: 'FIRST-year · STU-dent',
    9: 'TRAIN-ing · SAFE EX-er-cise · FIT-ness · TEAM-work',
}
MAINLINE_COPY = {
    'SAM · SWT INTERVIEW PRACTICE': '英语口语练习',
    '会读一句，也要会回答一题。': 'SWT 口测训练',
    '句子课练基础；这里练听题、短答和随机追问。': '听题、短答，再练随机追问。',
    '<span class="sam21-version">V21</span>': '<span class="sam21-version">V22</span>',
    '句子课保留原样。这里专练听懂问题、组织短答和脱稿应答。': '已载入，可以开始听题。',
    '>准备回答<span>一题练三遍</span>': '>听懂再回答<span>先听题，再练短答</span>',
    '先听问题，不看题目文字。': '先听考官的问题',
}


def digest(value):
    return hashlib.sha256(value if isinstance(value, bytes) else value.encode()).hexdigest()


def node_json(code, stdin=None):
    return json.loads(subprocess.run([NODE, '-e', code], input=stdin, text=True,
                                    cwd=ROOT, check=True, capture_output=True).stdout)


def baseline(site, source):
    target = ROOT/'assets/lesson-baseline-v21.json'
    if target.exists():
        saved = json.loads(target.read_text())
        assert saved['bundleSha256'] == digest(source)
        return saved
    assert (site/BUNDLE).read_text() == source, 'Capture provenance before changing the published bundle'
    data = node_json("const fs=require('fs'); const a=require('./scripts/audit_sentence_sources_v22.cjs'); console.log(JSON.stringify(a.extractLegacyData(fs.readFileSync(0,'utf8'))));", source)
    audit = node_json("console.log(JSON.stringify(require('./scripts/audit_sentence_sources_v22.cjs').buildAudit('_site')))")
    assert audit['summary']['staleSentences'] == ['p06','p07','p08','p10']
    saved = {'bundleSha256':digest(source), **data, 'summary':audit['summary'],
             'phrases':audit['phrases'], 'words':audit['words']}
    target.write_text(json.dumps(saved, ensure_ascii=False, indent=2)+'\n')
    return saved


def build(site, skip_audio=False):
    with zipfile.ZipFile(ROOT/'gospeak-v21-update.zip') as archive:
        source = archive.read('_site/'+BUNDLE).decode()
        base_html = archive.read('_site/index.html').decode()
        base_sw = archive.read('_site/sw.js').decode()
        base_manifest = json.loads(archive.read('_site/manifest.webmanifest'))
        mainline = archive.read('_site/assets/mainline-v21.js').decode()
    base = baseline(site, source)
    lessons = copy.deepcopy(base['lessons']) + copy.deepcopy(LESSONS)
    flat = [p for day in lessons for p in day['phrases']]
    assert len(lessons) == 21 and len(flat) == 105 and len(GUIDES) == 35
    for index, tip in TIP_FIXES.items(): flat[index]['tip'] = tip
    meanings, phonetics = dict(base['meanings']), dict(base['phonetics'])
    # Existing word meanings stay intact, except the previously missing safe.
    for word, entry in WORDS.items():
        meanings.setdefault(word, entry['zh']); phonetics.setdefault(word, entry['ipa'])
    meanings['safe'], phonetics['safe'] = '安全的', 'seɪf'
    all_words = sorted({w.lower() for p in flat for w in re.findall(TOKENS,p['en'])})
    assert all(meanings.get(w) and phonetics.get(w) for w in all_words)

    known = {}
    for version in (19,20,21):
        payload = json.loads((site/f'interview-v{version}.json').read_text())
        def walk(value):
            if isinstance(value,dict):
                if value.get('en') and value.get('audio',{}):
                    pair=value['audio']
                    known.setdefault(value['en'],(site/pair['normal'], f'exact text in interview-v{version}.json'))
                for item in value.values(): walk(item)
            elif isinstance(value,list):
                for item in value: walk(item)
        walk(payload)
        for word, entry in payload.get('lexicon',{}).items():
            known.setdefault(word,(site/entry['src'],f'lexicon.{word} in interview-v{version}.json'))
    # Evidence for all prior sentences/words was captured before editing.
    for entry in base['phrases']:
        src=site/entry['recommendedAudio']['normal']
        assert digest(src.read_bytes()) == entry['recommendedAudio']['sha256']
        known[entry['en']] = (src, entry['recommendedAudio']['provenance'])
    for entry in base['words']:
        src=site/entry['recommendedAudio']
        assert digest(src.read_bytes()) == entry['recommendedSha256']
        known[entry['word']] = (src,entry['fallbackSource'] or 'original isolated-word generation')

    needed={}
    for text in [p['en'] for p in flat] + all_words:
        if text in known: continue
        speech=Speech(text,'en-US-AvaNeural','-5%')
        cached=ROOT/'.audio-cache-v18'/f'{_clip_key(speech)}.mp3'
        needed[speech]=cached
        known[text]=(cached,'Microsoft Edge TTS; exact text; en-US-AvaNeural; -5%')
    print(f'V22: {len(flat)} sentences; {len(all_words)} words; {sum(not p.is_file() or not p.stat().st_size for p in needed.values())} new clips',flush=True)
    if not skip_audio: asyncio.run(synthesize_missing(needed))
    missing=[speech.text for speech,p in needed.items() if not p.is_file() or not p.stat().st_size]
    if missing: raise RuntimeError('Audio incomplete; publication blocked: '+repr(missing))

    output=site/'audio/lesson-v22'; output.mkdir(parents=True,exist_ok=True)
    def clip(text, kind):
        origin, provenance=known[text]
        audio_bytes=origin.read_bytes()
        sha=digest(audio_bytes); text_sha=digest(text)
        filename=f'{kind}-{text_sha[:20]}-{sha[:16]}.mp3'
        if origin.resolve()!=(output/filename).resolve(): shutil.copy2(origin,output/filename)
        return {'src':'./audio/lesson-v22/'+filename,'sha256':sha,'textSha256':text_sha,
                'spokenText':text,'provenance':provenance}
    sentences=[{'id':f'p{index+1:02d}','day':index//5+1,'sentence':index%5+1,
                'en':p['en'],'zh':p['zh'],'audio':clip(p['en'],'s')} for index,p in enumerate(flat)]
    words={w:{**clip(w,'w'),'zh':meanings[w],'ipa':phonetics[w]} for w in all_words}
    manifest={'version':'v22','sentenceCount':len(sentences),'wordCount':len(words),
              'sentences':sentences,'words':words,'verification':'Exact generation-text/source binding and audio SHA256; not phoneme-level assessment.'}
    (site/'lesson-audio-v22.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    sentence_sources={p['en']:p['audio']['src'] for p in sentences}
    word_sources={w:entry['src'] for w,entry in words.items()}
    extra_meanings={w:meanings[w] for w in all_words if base['meanings'].get(w)!=meanings[w]}
    extra_phonetics={w:phonetics[w] for w in all_words if base['phonetics'].get(w)!=phonetics[w]}
    encode=lambda data: json.dumps(data,ensure_ascii=False,separators=(',',':'))
    inject='\n/* BEGIN_V22_LESSON_DATA */\n'
    inject+='e.push(...'+encode(LESSONS)+');\na.push(...'+encode(GUIDES)+');\n'
    inject+='Object.assign(t,'+encode(extra_meanings)+');\nObject.assign(n,'+encode(extra_phonetics)+');\n'
    for index,tip in TIP_FIXES.items(): inject+=f'e[{index//5}].phrases[{index%5}].tip={encode(tip)};\n'
    inject+='var samLessonSources='+encode(sentence_sources)+';\nvar samWordSources='+encode(word_sources)+';\nvar samSentenceIPA='+encode(SENTENCE_IPA)+';\nvar samWeek3Words='+encode(WORDS)+';\n'
    inject+='/* END_V22_LESSON_DATA */\n'
    def replace(old,new,count=1):
        nonlocal source
        assert source.count(old)==count,(old,source.count(old))
        source=source.replace(old,new)
    replace(',_=document.querySelector(`#app`)', ';'+inject+'var _=document.querySelector(`#app`)')
    replace('function r(e){return(e.match(/[A-Za-z]+(?:-[A-Za-z]+)?/g)??[]).map(e=>({word:e,meaning:t[e.toLowerCase()]??`结合句子理解`,phonetic:n[e.toLowerCase()]??``}))}', 'function r(sentence){let scoped=typeof samSentenceIPA!==`undefined`&&samSentenceIPA[sentence]?samWeek3Words:{};return(sentence.match(/[A-Za-z]+(?:-[A-Za-z]+)?/g)??[]).map(word=>({word,meaning:scoped[word.toLowerCase()]?.zh??t[word.toLowerCase()]??`结合句子理解`,phonetic:scoped[word.toLowerCase()]?.ipa??n[word.toLowerCase()]??``}))}')
    replace('function i(e){return r(e).map', 'function i(e){if(typeof samSentenceIPA!==`undefined`&&samSentenceIPA[e])return samSentenceIPA[e];return r(e).map')
    replace('n=`./audio/p${t}.mp3`;_.querySelector(`#play-sentence`)', 'n=samLessonSources[e[b].phrases[C].en];_.querySelector(`#play-sentence`)')
    replace('function J(path, rate = 1, key = path) {', '''function J(path, rate = 1, key = path) {
  var wordPath = typeof path === 'string' && /^\\.\\/audio\\/words\\/(.+)\\.mp3$/.exec(path);
  if (wordPath && samWordSources[wordPath[1]]) path = samWordSources[wordPath[1]];
  if (!path) { q(false); E = '本句音频对应关系缺失，请刷新页面；不会播放其他句子。'; samAudioNotice(E); $(); return; }''')
    replace('var samLegacyTimer = 0;', (ROOT/'assets/lesson-playback-ui-v22.js').read_text()+'\nvar samLegacyTimer = 0;')
    replace('if (shouldRender) $();', 'if (shouldRender) samRenderPlaybackState();')
    replace("samAudioNotice('播放已暂停，再点句子可重新播放。'); $();", "samAudioNotice('播放已暂停，再点句子可重新播放。'); samRenderPlaybackState();")
    replace('  $();\n}\n// The former warmer', '  samRenderPlaybackState();\n}\n// The former warmer')
    replace('u.searchParams.set(`v`,`19.1`)', 'u.searchParams.set(`v`,`22`)')
    replace('<div class="brand"><span>G</span><b>GoSpeak <i>SWT</i></b></div>', '<div class="brand"><span aria-hidden="true">出</span><b>快乐出村计划</b></div>')
    replace('id="install-help">iPad安装</button>', 'id="install-help">安装与帮助</button>')
    replace('<small>APPLE iPAD</small>', '<small>快乐出村计划</small>')
    replace('必须用 iPad 的 <b>Safari</b> 打开网站，不要在微信内打开。', '在手机或平板的浏览器中打开。iPhone 和 iPad 建议用 <b>Safari</b>。')
    replace('如需文字识别，请在设置中开启 Siri；即使识别不可用，录音、回放和节奏报告仍可使用。', '口测录音与英文识别是两个选项。识别需要浏览器支持和联网；识别不成功时，仍可保存录音并回听。')
    replace('./sw.js?v=21','./sw.js?v=22')
    replace('十四天句子课程','二十一天句子课程')
    replace('t===7?`<span class="week-label new">第2周 · 新</span>`:``', 't===7?`<span class="week-label">第2周</span>`:t===14?`<span class="week-label new">第3周 · 新</span>`:``')
    replace('b<7?`第一周 · 基础生存英语`:`第二周 · SWT口测核心`', 'b<7?`第一周 · 基础生存英语`:b<14?`第二周 · SWT口测核心`:`第三周 · 工作情景短答`')
    replace('b<7?`距离美国，<br>从一句话开始。`:`第一周完成，<br>开始回答口测。`', 'b<7?`基础表达`:b<14?`口测常用句`:`工作情景短答`')
    replace('`本周集中训练优缺点、项目动机、困难应对、岗位选择、文化差异与毕业计划。`', 'b<14?`本周集中训练优缺点、项目动机、困难应对、岗位选择、文化差异与毕业计划。`:`本周练听题澄清、主管任务、犯错迟到、同事合作、顾客服务和独立生活。情景表达要按实际情况使用；先精学短句，再到SWT主线练整题。`')
    replace('完成第二周 ✓','完成第三周 ✓')
    replace('第二周的35句话已经全部完成，下一步请进入每日监督进行脱稿口测。','三周105句已学到最后一句，下一步请进入SWT口测主线练脱稿回答。')
    replace('Day 1—Day 14 全部开放','Day 1—Day 21 全部开放')
    replace('十四天新词全部学完','二十一天新词全部学完')
    replace('Fe(),et(),v===`coach`&&ke()}function et()', 'Fe(),et(),v===`coach`&&ke();if(v===`lesson`){let nav=_.querySelector(`.days`),active=nav?.querySelector(`.active`);if(nav&&active)nav.scrollLeft=active.offsetLeft-nav.offsetLeft-(nav.clientWidth-active.offsetWidth)/2}}function et()')
    # Keep the matching scorer; replace the unbounded microphone startup lifecycle.
    start=source.index('async function ut(){')
    end=source.index('$(),`serviceWorker`',start)
    source=source[:start]+(ROOT/'assets/lesson-recognition-v22.js').read_text()+'\n'+source[end:]
    (site/BUNDLE).write_text(source)
    html=base_html.replace('?v=21','?v=22').replace('GoSpeak SWT V21｜','GoSpeak SWT V22｜')
    html=re.sub(r'<title>.*?</title>', '<title>快乐出村计划｜英语口语练习</title>', html)
    html=re.sub(r'(<meta (?:name|property)="(?:apple-mobile-web-app-title|og:title|twitter:title)" content=")[^"]*', r'\1快乐出村计划', html)
    html=re.sub(r'(<meta (?:name|property)="(?:description|og:description|twitter:description)" content=")[^"]*', r'\1三周105句：慢速点读、词义音标与语法拆解；另有SWT口测短答、录音回听和随机追问。', html)
    html=html.replace('V21 · 句子课练基础，口测主线练应答', 'V22 · 三周句子课')
    html=html.replace('声音没反应？恢复声音', '恢复声音').replace('加载时会显示提示，不用反复连点。', '点读可循环，再点停止。')
    html=html.replace('</head>', '<link rel="stylesheet" href="./assets/polish-v22.css?v=22">\n</head>')
    for name in ('apple-touch-icon.png','icon-192.png','icon-512.png','og.png'):
        shutil.copy2(ROOT/'assets/brand-v22'/name,site/name)
        html=html.replace(name+'"',name+'?v=22"')
    html=html.replace('./manifest.webmanifest"','./manifest.webmanifest?v=22"')
    (site/'index.html').write_text(html)
    shutil.copy2(ROOT/'assets/polish-v22.css', site/'assets/polish-v22.css')
    for old, new in MAINLINE_COPY.items():
        assert old in mainline
        mainline=mainline.replace(old,new)
    mainline=patch_listening_first(patch_core(patch_mainline(mainline))).replace("var VERSION='21'", "var VERSION='22'")
    (site/'assets/mainline-v21.js').write_text(mainline)
    listening=site/'assets/listening-v18.js'
    listening.write_text(listening.read_text().replace('album: "GoSpeak SWT V19"','album: "快乐出村计划"'))
    sw=base_sw.replace("'21'","'22'")
    sw=sw.replace("core.push(new URL('assets/audio-recovery.js', BASE).href);", "core.push(...['assets/audio-recovery.js', 'assets/polish-v22.css', 'lesson-audio-v22.json'].map(path => new URL(path, BASE).href));")
    release_hash=digest(source+mainline+(ROOT/'assets/polish-v22.css').read_text())[:12]
    sw=re.sub(r"const VERSION = '[^']+';",f"const VERSION = 'gospeak-independent-v22-{release_hash}';",sw)
    (site/'sw.js').write_text(sw)
    base_manifest.update(name='快乐出村计划',short_name='快乐出村计划',description='三周105句精学与SWT口测练习。',background_color='#f7f8f6',theme_color='#173d2e')
    for icon in base_manifest['icons']: icon['src']=icon['src'].split('?')[0]+'?v=22'
    (site/'manifest.webmanifest').write_text(json.dumps(base_manifest,ensure_ascii=False,indent=2)+'\n')
    print('V22 built: no learning history was cleared; original sentence IDs remain stable.',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('site',nargs='?',type=Path,default=ROOT/'_site');parser.add_argument('--skip-audio',action='store_true')
    args=parser.parse_args();build(args.site,args.skip_audio)
