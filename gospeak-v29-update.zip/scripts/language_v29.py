"""Build audited word glosses and authored constituent spans. Never guess a parse."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'_site'
PATTERN=r"U\.S\.|\[[^\]]+\]|[A-Za-z0-9]+(?:[-'’][A-Za-z0-9]+)*"
def tokens(text):return re.findall(PATTERN,text,re.I)
def key(text):return ' '.join(w.lower() for w in tokens(text))
LABELS={'S':'主语','V':'谓语','K':'系动词','O':'宾语','P':'表语','U':'助动词','W':'疑问状语','T':'时间状语','L':'地点状语','M':'方式或程度状语','R':'状语','C':'条件状语从句','TIME':'时间状语从句','G':'介词短语','B':'宾语补足语','F':'定语','I':'间接宾语','D':'直接宾语','X':'礼貌用语','J':'连接词','PO':'介词的宾语','PRE':'介词','E':'假设问法','MEASURE':'距离','PUR':'目的状语','EX':'存在的事物','V2':'补充的动作'}
def annotated(file):
    table={}
    for line in (ROOT/'assets'/file).read_text().splitlines():
        if not line.strip() or line.startswith('#'):continue
        segments=[part.split(' ',1) for part in line.split('|')]
        assert all(role in LABELS for role,_ in segments),line
        k=key(' '.join(p for _,p in segments))
        assert k not in table,k
        table[k]=segments
    return table
def corpus(data):
    texts=[]
    for q in data['questions']:
        texts += [q['question']]+[v['en'] for v in q['variants'] if not v.get('hint')]+[v['en'] for v in q['followups']]
        lines=q['short']+q['extra']+[s for v in q['followups'] for s in v.get('answer',[])]+[s for b in q['branches'] for s in b['sentences']]
        texts += [s['en'] for s in lines]
    return list(dict.fromkeys(texts))
PHRASES={'at work':'at work 合起来表示“在工作时”。','at school':'at school 是地点，every day 是时间。','cultural exchange':'cultural 修饰 exchange，合起来是“文化交流”。','the swim test':'swim 修饰 test，表示游泳测试。','without stopping':'without stopping 是“不停下来”；听清这个条件再回答距离。','physical fitness training':'physical fitness training 放在一起是“体能训练”。','what if':'What if …? 表示“如果……怎么办？”','how many meters':'how many meters 问米数。1 kilometer 就是 1,000 meters。','would like':'would like to … 表示“想要做……”。','interested in':'be interested in … 表示“对……感兴趣”。','have been to':'have been to … 表示“曾经去过……”。','did you':'did 表示过去，后面的动作动词用原形。','days off':'days off 是“休息日”。','work under pressure':'under pressure 表示“在压力下”。','apply for':'apply for … 表示“申请……”。','one at a time':'at a time 表示“每次”。','one thousand':'one thousand 是“一千”。','deal with':'deal with 表示“处理、应对”。','free time':'free time 表示“空闲时间”。','without reading':'without reading 表示“不看稿”。','feel stressed':'feel 后面是表语 stressed，说明感觉如何。','tell me':'tell me … 是“告诉我……”，me 是听消息的人。'}
MODIFIERS={'cultural':'exchange / activities','chinese':'lifeguard certificate / food','lifeguard':'certificate','swim':'test','national':'certificate','american':'culture','physical':'fitness training','fitness':'training','first-year':'student','preschool':'education','safety':'rules / risk','free':'time','work':'experience / tasks / travel','difficult':'customers / task','previous':'job','college':'calendar','daily':'life','shared':'rules / spaces','own':'tasks','short':'answers / conversations','weekly':'budget','local':'activities','other':'cities / questions / countries','different':'countries','valid':'passport','optional':'activities','simple':'dishes','useful':'words','required':'training','arrival':'time','travel':'dates','expiry':'date','swimming':'instructor','unsafe':'action','scheduling':'problem'}
# Use the actual head present to avoid describing a different phrase.
def modifiers(ws):
    result=[]
    for i,word in enumerate(ws[:-1]):
        targets=MODIFIERS.get(word.lower(),'').split(' / ') if word.lower() in MODIFIERS else []
        if word.lower() in ('my','your','our','their','its'):
            phrase=' '.join(n.lower() for n in ws[i+1:i+3])
            groups={'own tasks','free time','previous job','shared rules','travel dates','arrival time','expiry date','college calendar','swim test'}
            head=ws[i+2] if phrase in groups else ws[i+1]
            result.append([word,head])
        for target in targets:
            head=target.split()[-1]
            if head in [x.lower() for x in ws[i+1:i+4]]:
                result.append([word,head]);break
    return result
def gloss(word,idx,words,role,lex,context):
    w=word.lower(); before=' '.join(words[:idx]);after=' '.join(words[idx+1:])
    if w=='do':return '助动词，构成一般疑问句' if role=='U' and not before.endswith('they') else '代替前面的动作（表示支持）' if role=='U' else '做'
    if w=='did':return '助动词，表示过去的提问'
    if w=='have':return ('助动词，与过去分词组成完成时' if role=='U' or role=='V' and any(k in after for k in ('worked','traveled','checked','confirmed','visited','chosen','applied','been')) else '有；持有')
    if w=='to':
        if after.startswith(('the united states','china','malaysia','other cities','my coworker','my teammates','advice','the customer','[place]','[end]')):return '到；向；对（引出目的地或对象）'
        return '不定式标记，后面接动作动词'
    if w=='is' and role=='U':return '与 accepted 一起表示“被认可”'
    if w in ('am','are','is') and role=='V':return '助动词，和后面的动词组成谓语'
    if w=='what' and role=='E':return '与 if 合起来问“如果……怎么办”'
    if w=='what' and after.startswith(('kind','job','places','year','grade','concerns','progress')):return '什么；哪一种（修饰后面的名词）'
    if w=='how' and after.startswith(('many','far')):return '多；多少（和后面的词一起问数量或距离）'
    if w=='many' and before.endswith('how'):return '与 how 一起表示“多少”'
    if w=='at' and ('sixteen' in after or 'seventeen' in after):return '在……岁时'
    if w=='work' and context.startswith('it includes'):return '工作（名词）'
    if w=='it' and context.startswith('it includes'):return '它（这里指 SWT 项目）'
    if w=='think' and context.startswith('i think'):return '觉得；认为'
    if w=='test':return '测试；考核'
    if w=='pass' and 'swim test' in context:return '通过（考核）'
    if w=='kilometer':return '公里；一公里等于一千米'
    if w=='with' and 'deal with' in context:return '与 deal 一起表示“处理”'
    if w=='right' and after.startswith('away'):return '立刻（与 away 合用）'
    if w=='away' and before.endswith('right'):return '与 right 一起表示“马上”'
    if w=='make' and 'budget' in after:return '制定'
    if w=='have' and context.startswith('yes i have') and role=='U':return '代替前面问过的经历，表示“有过”'
    if w=='swim' and after.startswith('test'):return '游泳的（修饰 test）'
    if w=='one' and context.endswith('apply for one'):return '一本（这里指护照）'
    if w=='one' and after.startswith(('kilometer','thousand')):return '一（数量）'
    if w=='every' and after.startswith('day'):return '每；每一'
    if w=='day' and before.endswith('every'):return '天（every day 就是“每天”）'
    if w=='would':return '想要（would like）' if after.startswith('like') else '会；用于假设或礼貌提问'
    if w=='like' and 'would' in before:return '与 would 一起表示“想要”'
    if w=='when':return '什么时候' if idx==0 else '当……时'
    if w=='hard':return '困难的'
    if w=='there' and ('there is' in context or 'there was' in context):return '与 be 一起表示“有……”'
    if w=='best' and role=='M':return '最（like … best 最喜欢……）'
    if w=='experience':return '经验；经历'
    if w=='support':return '支持'
    if w=='working' and after.startswith('on'):return '正在努力改进（work on）'
    if w in ('also','still','usually','almost'):return {'also':'也','still':'仍然','usually':'通常','almost':'几乎'}[w]
    return lex[w]['zh']
def build(data):
    table=annotated('swt-structure-v29.txt');inner=annotated('swt-inner-v29.txt')
    lex=data['lexicon'];lesson=json.loads((SITE/'lesson-audio-v22.json').read_text())['words']
    extra={w:{'ipa':ipa,'zh':zh} for w,ipa,zh in (line.split('|') for line in (ROOT/'assets/swt-vocab-v29.txt').read_text().splitlines())}
    slots={w:v for w,v in extra.items() if w.startswith('[')}
    for slot in slots:lex.pop(slot,None)
    alltext=corpus(data)
    for w in sorted({w.lower() for t in alltext for w in tokens(t)}):
        if w in lex or w in slots:continue
        item=lesson.get(w,{})
        row={'ipa':item.get('ipa',''),'zh':item.get('zh',''),**extra.get(w,{})}
        assert row['zh'] and (row['ipa'] or w.startswith('[')),w
        if not w.startswith('['):
            candidates=[item.get('src'),f'./audio/words/{w}.mp3',f'./audio/interview-v29/word-{w.replace(".","")}.mp3']
            row['src']=next((src for src in candidates if src and (SITE/src).is_file()),None)
            assert row['src'],f'No audio for {w}'
        lex[w]=row
    notes={}
    for t in alltext:
        k=key(t);assert k in table,'Missing structure: '+t
        parts=table[k];ws=tokens(t);lower=[w.lower() for w in ws]
        roles=[role for role,part in parts for _ in tokens(part)]
        assert len(roles)==len(ws),t
        notes[t]={'parts':parts,'words':[[w,slots[w]['zh'] if w in slots else gloss(w,i,lower,roles[i],lex,k)] for i,w in enumerate(ws)],
                  'mod':modifiers(ws),'inner':[inner[key(part)] for _,part in parts if key(part) in inner],
                  'tips':[tip for phrase,tip in PHRASES.items() if ' '+phrase+' ' in ' '+k+' '][:1]}
        if t=='I have a Chinese lifeguard certificate.':
            notes[t]['tips']=['这里说的是你持有的中国国职游泳救生员证。Chinese 修饰后面的证书名称。']
    data['languageNotes']=notes;data['languageRoles']=LABELS
    return data
