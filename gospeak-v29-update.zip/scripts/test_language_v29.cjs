/* Regression cases from the app: all displayed tokens survive, correct roles, no hints in blind rounds. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{createRequire}=require('node:module');
const base=fs.readFileSync(path.join(__dirname,'test_mainline_v25.cjs'),'utf8').split('\nt.render();')[0];
function cases(){
  const lines=new Set();
  for(const q of data.questions){
    [q.question,...q.variants.filter(v=>!v.hint).map(v=>v.en),...q.followups.map(f=>f.en),
      ...[...q.short,...q.extra,...q.followups.flatMap(f=>f.answer||[]),...q.branches.flatMap(b=>b.sentences)].map(s=>s.en)].forEach(s=>lines.add(s));
  }
  function tokens(s){return s.match(/U\.S\.|\[[^\]]+\]|[A-Za-z0-9]+(?:[-’'][A-Za-z0-9]+)*/gi)||[];}
  assert.equal(Object.keys(data.languageNotes).length,lines.size);
  for(const en of lines){
    const n=data.languageNotes[en];assert(n,en);
    assert.deepEqual(n.words.map(p=>p[0]),tokens(en),en);
    assert.deepEqual(tokens(n.parts.map(p=>p[1]).join(' ')).map(w=>w.toLowerCase()),tokens(en).map(w=>w.toLowerCase()),en);
    n.words.forEach(([w,zh])=>{
      assert(zh.trim(),en+' / '+w);
      if(w.startsWith('['))return;
      const word=data.lexicon[w.toLowerCase()];assert(word.ipa&&word.src&&fs.existsSync(path.join(site,word.src)),w);
    });
  }
  t.render();assert(!html.includes('sam29-parts'));
  click('question-hint');assert(html.includes('逐词意思与句子结构'));assert(html.includes('疑问状语'));
  click('answer-start');click('sentence-index',1);
  assert(html.includes('<details class="sam29-language" open>'));
  assert(html.indexOf('每个词的意思')<html.indexOf('aria-label="录这一句"'));
  for(const s of ['主语</small><b lang="en">I','谓语</small><b lang="en">can practice','宾语</small><b lang="en">English','地点状语</small><b lang="en">at work'])assert(html.includes(s),s);
  assert.equal((html.match(/<li><div class="sam29-word-audio">/g)||[]).length,6);
  click('joined');assert.equal((html.match(/class="sam29-language"/g)||[]).length,3);
  click('round',2);assert(!html.includes('sam29-parts'));
  click('round',3);assert(!html.includes('sam29-parts'));
  click('topic','i04');click('answer-start');
  assert(t.state.recorderTarget.expectedText==='I swim one kilometer at school every day.');
  click('sentence-index',1);
  assert.deepEqual(data.languageNotes[t.state.recorderTarget.expectedText].words.map(p=>p[0]),['I','think','I','can','pass','the','swim','test']);
  assert(html.includes('宾语</small><b lang="en">I can pass the swim test'));
  assert(html.includes('谓语</small><b lang="en">can pass'));
  assert(html.includes('swim</b> 修饰 <b lang="en">test'));
  click('sentence-index',2);assert(html.includes('lifeguard</b> 修饰 <b lang="en">certificate'));
  click('joined');assert.equal(t.state.recorderTarget.expectedText,data.questions.find(q=>q.id==='i04').short.map(l=>l.en).join(' '));
  const cards=JSON.parse(fs.readFileSync(path.join(site,'cards-v24.json'),'utf8'));
  assert.deepEqual(cards.topics[4].rows.filter(r=>r.kind==='answer').map(r=>r.en),data.questions.find(q=>q.id==='i04').short.map(r=>r.en));
  console.log('PASS V29: '+lines.size+' distinct prompts and answers, every word and role aligned, exact word audio, default visible notes, hidden mock answers, updated swim answer and card match.');
}
vm.runInNewContext(base+'\n('+cases.toString()+')();',{require:createRequire(__filename),__dirname,console,process,URL,Promise,Math,Date},{filename:__filename});
