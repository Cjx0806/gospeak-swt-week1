import asyncio,hashlib,json,shutil,subprocess
from pathlib import Path
from zipfile import ZipFile
from build_v18_listening import Speech
from build_v21 import synthesize_missing
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'_site';AUDIO=SITE/'audio/interview-v29'
SWIM=[('I swim one kilometer at school every day.','我每天在学校游一公里。'),
      ('I think I can pass the swim test.','我觉得我能通过游泳测试。'),
      ('I have a Chinese lifeguard certificate.','我有中国的游泳救生员证。')]
def render():
    import imageio_ffmpeg
    with ZipFile(ROOT/'gospeak-v22-update.zip') as z:
        data=json.loads(z.read('_site/interview-v21.json'))
    items={q['id']:q for q in data['questions']};out=AUDIO;out.mkdir(parents=True,exist_ok=True)
    synth={en:Speech(en,'en-US-AvaNeural','-5%') for en,_ in SWIM[:2]}
    clips=asyncio.run(synthesize_missing(synth.values()))
    lines=[]
    metadata=[('aɪ swɪm wʌn kɪˈlɑmətɚ æt skul ˈɛvri deɪ',['I swim one kilometer','at school','every day'],'I 主语，swim 谓语；one kilometer 是距离，at school 是地点，every day 是时间。'),
              ('aɪ θɪŋk aɪ kən pæs ðə swɪm tɛst',['I think','I can pass the swim test'],'I 主语，think 谓语；I can pass the swim test 是宾语从句。')]
    for (en,zh),(ipa,chunks,grammar) in zip(SWIM,metadata):
        src='./audio/interview-v29/s-'+hashlib.sha256(en.encode()).hexdigest()[:18]+'.mp3'
        shutil.copyfile(clips[synth[en]],SITE/src)
        lines.append(dict(id='s-'+hashlib.sha256(en.encode()).hexdigest()[:12],en=en,zh=zh,ipa=ipa,chunks=chunks,grammar=grammar,pronunciation='按短语停顿，再一起读。',audio=dict(normal=src,slow=src,slowRate=.78,voice='en-US-AvaNeural')))
    cert=dict(items['s01']['short'][1]);cert['zh']=SWIM[2][1];lines.append(cert)
    items['i04']['short']=lines
    items['s01']['short'][-1]=lines[0]
    q=items['i04'];q['scaffold']=q['keywords']=['每天在学校游一公里','有信心通过考核','持有中国救生员证']
    q['intent']=q['examinerIntent']='先回答距离，再补考核信心和证书。'
    q['note']='你持有的是中国的国职游泳救生员证。若问 without stopping，再按实际情况说能连续游多远。'
    for q in [items['s01'],items['i04']]:
        relative='./audio/interview-v29/joined-'+q['id']+'.mp3'
        args=[imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-y']
        for line in q['short']:args+=['-i',str(SITE/line['audio']['normal'])]
        filters=';'.join(f'[{n}:a]aresample=24000,apad=pad_dur=0.25[a{n}]' for n in range(3))+';[a0][a1][a2]concat=n=3:v=0:a=1[out]'
        subprocess.run(args+['-filter_complex',filters,'-map','[out]','-codec:a','libmp3lame','-b:a','64k',str(SITE/relative)],check=True)
        q['fullAudio']=dict(normal=relative,slow=relative,slowRate=.78)
    (SITE/'interview-v21.json').write_text(json.dumps(data,ensure_ascii=False))
def cards():
    card=json.loads((ROOT/'assets/cards-source-v24.json').read_text())
    card[3][3][-1]=list(SWIM[0]);card[4][1]='how many meters＝多少米；how far＝多远'
    card[4][3]=[list(x) for x in SWIM];card[4][4]='一公里等于一千米。真被追问能不停游多远时，再说实测距离。';card[4][5]=[]
    (ROOT/'assets/cards-source-v29.json').write_text(json.dumps(card,ensure_ascii=False,indent=2))
if __name__=='__main__':cards();render()
