"""Render only isolated words absent from both verified vocabulary banks."""
import asyncio,json,re,shutil
from pathlib import Path
from build_v18_listening import Speech,_clip_key
from build_v21 import synthesize_missing
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'_site'
TOKEN=r"U\.S\.|\[[^\]]+\]|[A-Za-z0-9]+(?:[-'’][A-Za-z0-9]+)*"
def tokens(s): return re.findall(TOKEN,s,re.I)
def run():
    interview=json.loads((SITE/'interview-v21.json').read_text())['lexicon']
    lesson=json.loads((SITE/'lesson-audio-v22.json').read_text())['words']
    words=set()
    for line in (ROOT/'assets/swt-structure-v29.txt').read_text().splitlines():
        if not line or line.startswith('#'):continue
        for part in line.split('|'):
            words.update(w.lower() for w in tokens(part.split(' ',1)[1]))
    words.update(('kilometer','pass','test'))
    need=[w for w in sorted(words) if not(w.startswith('[') or w in interview or w in lesson or (SITE/'audio/words'/f'{w}.mp3').is_file())]
    out=SITE/'audio/interview-v29';out.mkdir(exist_ok=True,parents=True)
    speech={w:Speech('U S' if w=='u.s.' else w,'en-US-AvaNeural','-5%') for w in need}
    clips=asyncio.run(synthesize_missing(set(speech.values())))
    for w,entry in speech.items(): shutil.copyfile(clips[entry],out/('word-'+w.replace('.','')+'.mp3'))
    print(len(need),'isolated words ready.')
if __name__=='__main__':run()
