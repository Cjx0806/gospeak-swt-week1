"""Apply the authored language layer to the existing interview course."""
import hashlib,json,re,shutil
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from language_v29 import build as add_language
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'_site'

def replace(source,old,new):
    assert source.count(old)==1,old
    return source.replace(old,new)
def mainline(source):
    start=source.index('  function detail25(line)')
    end=source.index('  function sentence25(item)',start)
    source=source[:start]+(ROOT/'assets/language-v29-fragment.js').read_text()+'\n'+source[end:]
    old="""+'<section aria-label="录这一句"><div data-sam-recorder></div></section>'+detail25(line)"""
    source=replace(source,old,"""+detail29(line,true)+'<section aria-label="录这一句"><div data-sam-recorder></div></section>'""")
    source=replace(source,"+'</p></div></li>';}).join('')+'</ol>':'<div class=\"sam25-blank\">",
                   "+'</p>'+(showEnglish?detail29(line,i===0):'')+'</div></li>';}).join('')+'</ol>':'<div class=\"sam25-blank\">")
    source=replace(source,"+'</div><div class=\"sam21-question-tools\">'","+'</div>'+(!blind||state.questionRevealed?detail29(question,true):'')+'<div class=\"sam21-question-tools\">'")
    source=replace(source,"esc(option.zh||'')+'</p></div>'","esc(option.zh||'')+'</p>'+detail29(option,false)+'</div>'")
    return replace(source,"'interview-v21.json?v='+VERSION","'interview-v21.json?v='+VERSION+'&course=29'")
def build():
    with ZipFile(ROOT/'gospeak-v28-update.zip') as package:
        previous=lambda name:package.read('_site/'+name).decode()
        (SITE/'assets/mainline-v21.js').write_text(mainline(previous('assets/mainline-v21.js')))
        html=previous('index.html').replace('V28 ·','V29 ·').replace('mainline-v21.js?v=22&design=28','mainline-v21.js?v=22&design=29').replace('cards.html?v=26','cards.html?v=29')
        worker=previous('sw.js').replace('// V19_VERSIONED_CACHE',"core.push(new URL('assets/language-v29.css',BASE).href,new URL('assets/taps-v29.js',BASE).href);\n// V19_VERSIONED_CACHE")
        worker=worker.replace('return u.href;',"""if(u.pathname.endsWith('/mainline-v21.js'))u.searchParams.set('design','29'); if(u.pathname.endsWith('/interview-v21.json'))u.searchParams.set('course','29'); return u.href;""")
    for name in ('language-v29.css','taps-v29.js'):shutil.copyfile(ROOT/'assets'/name,SITE/'assets'/name)
    def feedback(page):
        page=page.replace('</head>','<link rel="stylesheet" href="./assets/language-v29.css?v=22">\n</head>')
        return page.replace('</body>','<script defer src="./assets/taps-v29.js?v=22"></script>\n</body>')
    toggle='<button type="button" data-tap-sound aria-pressed="true">点按音效 开</button>'
    html=feedback(html).replace('</aside>',toggle+'</aside>')
    (SITE/'index.html').write_text(html)
    data=add_language(json.loads((SITE/'interview-v21.json').read_text()))
    (SITE/'interview-v21.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')))
    cards=json.loads((SITE/'cards-v24.json').read_text())
    for i in (4,5):
        file=f'Sam-SWT-{i:02}-v29.png'
        shutil.copyfile(ROOT/'tmp/cards-v29'/f'Sam-SWT-{i:02}.png',SITE/'study-cards'/file)
        cards['topics'][i-1]['image']='./study-cards/'+file
    (SITE/'cards-v24.json').write_text(json.dumps(cards,ensure_ascii=False,separators=(',',':')))
    zipname='study-cards/Sam-SWT-8张学习卡-v29.zip'
    with ZipFile(SITE/zipname,'w',ZIP_DEFLATED) as z:
        for t in cards['topics']:z.write(SITE/t['image'],f"Sam-SWT-{t['id']:02}.png")
    with ZipFile(ROOT/'gospeak-v26-update.zip') as pkg:cardhtml=pkg.read('_site/cards.html').decode()
    cardhtml=feedback(cardhtml).replace('</header>',toggle+'</header>').replace('./?v=24','./?v=29').replace('Sam-SWT-8张学习卡.zip','Sam-SWT-8张学习卡-v29.zip').replace('cards-v24.js?v=24','cards-v24.js?v=29')
    (SITE/'cards.html').write_text(cardhtml)
    player=(ROOT/'assets/cards-v24.js').read_text().replace('cards-v24.json?v=24','cards-v24.json?v=24&course=29')
    (SITE/'assets/cards-v24.js').write_text(player)
    digest=hashlib.sha256((SITE/'interview-v21.json').read_bytes()+html.encode()+(SITE/'assets/taps-v29.js').read_bytes()+(SITE/'assets/mainline-v21.js').read_bytes()).hexdigest()[:12]
    (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,worker))
    paths=['_site/'+k for k in ['index.html','sw.js','assets/mainline-v21.js','assets/taps-v29.js','assets/language-v29.css','interview-v21.json','cards.html','assets/cards-v24.js','cards-v24.json',cards['audio'].removeprefix('./'),zipname]]
    paths+=['_site/'+cards['topics'][i-1]['image'].removeprefix('./') for i in (4,5)]
    paths+=list((SITE/'audio/interview-v29').glob('*.mp3'))
    paths+=['assets/'+k for k in ['cards-source-v29.json','swt-vocab-v29.txt','swt-structure-v29.txt','swt-inner-v29.txt','language-v29-fragment.js','taps-v29.js','language-v29.css']]
    paths+=['scripts/'+k for k in ['build_v29.py','verify_v22.py','language_v29.py','audio_words_v29.py','build_cards_v29.py','card_images_v29.py','swim_v29.py','test_language_v29.cjs']]
    with ZipFile(ROOT/'gospeak-v29-update.zip','w',ZIP_DEFLATED) as archive:
        for p in paths:
            p=ROOT/p;archive.write(p,p.relative_to(ROOT))
    workflow=ROOT/'.github/workflows/pages.yml';config=workflow.read_text().replace('Deploy 快乐出村计划 V28','Deploy 快乐出村计划 V29')
    if 'unzip -q -o gospeak-v29-update.zip' not in config:
        config=config.replace('unzip -q -o gospeak-v28-update.zip -d .','unzip -q -o gospeak-v28-update.zip -d .\n          unzip -q -o gospeak-v29-update.zip -d .')
        config=config.replace('node scripts/test_mainline_v25.cjs','node scripts/test_mainline_v25.cjs\n          node scripts/test_language_v29.cjs')
    workflow.write_text(config);print('V29 ready:',len(data['languageNotes']),'different English questions/answers.')
if __name__=='__main__':build()
