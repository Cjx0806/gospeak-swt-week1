"""Precompose bilingual card audio: EN, ZH, slow EN x3. One MP3 for iPad."""
import ast, asyncio, hashlib, json, shutil, subprocess, wave
from pathlib import Path
from build_v18_listening import Speech, _clip_key
from build_v21 import synthesize_missing
import imageio_ffmpeg

ROOT=Path(__file__).resolve().parents[1]; SITE=ROOT/'_site'
cards=json.loads((ROOT/'assets/cards-source-v29.json').read_text())
OUT=SITE/'audio/cards-v24';OUT.mkdir(parents=True,exist_ok=True)
TEMP=ROOT/'.audio-cache-v24';TEMP.mkdir(exist_ok=True)
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
topics=[];speeches={}
for n,(title,clues,questions,answers,note,extra) in enumerate(cards,1):
    entries=[('question',*p) for p in questions]+[('answer',*p) for p in answers]
    if n==1:
        entries=[('question',*p) for p in questions]+[('answer',*answers[0]),('question',*extra[0]),('answer',*answers[1]),('question',*extra[1]),('answer',*extra[2])]
    elif n==5 and extra:
        entries=[('question',*p) for p in questions]+[('answer',*answers[0]),('question',*extra[0]),('answer',*answers[1])]
    elif n==6:entries += [('rescue',*p) for p in extra]
    elif n==8:
        entries += [('question','What do you want to do after graduation?','毕业后你想做什么？'),('answer',*extra[0])]
    rows=[]
    for j,(kind,en,zh) in enumerate(entries):
        row={'id':f'{n}-{j}','kind':kind,'en':en,'zh':zh}
        for mode,text,voice,rate in [('normal',en,'en-US-AvaNeural','-5%'),('chinese',zh,'zh-CN-XiaoxiaoNeural','+0%'),('slow',en,'en-US-AvaNeural','-25%')]:
            speech=Speech(text.replace('SWT','S W T'),voice,rate)
            speeches[speech]=None;row[mode]=_clip_key(speech)
        rows.append(row)
    topics.append({'id':n,'title':title,'clues':clues,'note':note,'image':f'./study-cards/Sam-SWT-{n:02}.png','rows':rows})
cache=asyncio.run(synthesize_missing(speeches))
pcm={};provenance={}
for speech,path in cache.items():
    key=_clip_key(speech)
    result=subprocess.run([ffmpeg,'-v','error','-i',str(path),'-f','s16le','-ac','1','-ar','24000','pipe:1'],capture_output=True,check=True)
    pcm[key]=result.stdout
    provenance[key]={'text':speech.text,'voice':speech.voice,'rate':speech.rate,'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest()}
rate=24000; total_frames=0; cues=[]
wav=TEMP/'all.wav'
with wave.open(str(wav),'wb') as stream:
    stream.setnchannels(1);stream.setsampwidth(2);stream.setframerate(rate)
    def silence(seconds):
        global total_frames
        count=round(seconds*rate);stream.writeframes(b'\0\0'*count);total_frames+=count
    for topic in topics:
        topic['start']=total_frames/rate
        for row in topic['rows']:
            row['start']=total_frames/rate
            for step,mode in enumerate(['normal','chinese','slow','slow','slow']):
                data=pcm[row[mode]];start=total_frames/rate
                stream.writeframes(data);total_frames+=len(data)//2
                spoken_end=total_frames/rate
                gap=.7 if step<2 else min(4.5,max(1.8,len(row['en'].split())*.28))
                silence(gap)
                cues.append({'topic':topic['id'],'row':row['id'],'step':step,'mode':mode,'start':start,'spokenEnd':spoken_end,'end':total_frames/rate,'source':row[mode]})
            row['end']=total_frames/rate
        silence(1.0);topic['end']=total_frames/rate
digest=hashlib.sha256(json.dumps({'topics':topics,'provenance':provenance},sort_keys=True).encode()).hexdigest()[:16]
audio=OUT/f'eight-topics-{digest}.mp3'
subprocess.run([ffmpeg,'-v','error','-y','-i',str(wav),'-c:a','libmp3lame','-b:a','64k',str(audio)],check=True)
manifest={'version':24,'audio':'./'+audio.relative_to(SITE).as_posix(),'duration':total_frames/rate,'sha256':hashlib.sha256(audio.read_bytes()).hexdigest(),'topics':topics,'cues':cues,'provenance':provenance,'sequence':['normal','chinese','slow','slow','slow'],'speechNote':'微软美式英语 Ava 与普通话 Xiaoxiao 合成音。慢速英语已制作在音频里。'}
(SITE/'cards-v24.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(f'Built {len(topics)} topics, {sum(len(t["rows"]) for t in topics)} bilingual sentences, {len(cues)} passes; {manifest["duration"]/60:.1f} minutes, {audio.stat().st_size:,} bytes.',flush=True)
