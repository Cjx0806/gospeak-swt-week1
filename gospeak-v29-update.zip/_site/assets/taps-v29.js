/* Local tap feedback. No media downloads and no interference with English playback. */
(function () {
  'use strict';
  var key='sam-interface-sounds', enabled=true, context=null, lastTime=-Infinity, idleTimer=0, ringTimer=0;
  var voices=new Set();
  try { enabled=localStorage.getItem(key)!=='off'; } catch (_) {}
  var toggle=document.querySelector('[data-tap-sound]');
  function drawToggle(){
    if(!toggle)return;
    toggle.textContent='点按音效 '+(enabled?'开':'关');
    toggle.setAttribute('aria-pressed',String(enabled));
  }
  function busy(){
    var main=window.__samMainlineV21, lesson=window.__samLessonRecognitionV22;
    return !!((main && main.isRecording()) || (lesson && lesson.isRecording()));
  }
  function silence(){
    clearTimeout(idleTimer);
    voices.forEach(function(v){try{v.stop();}catch(_){}});
    if(context && context.state==='running')context.suspend().catch(function(){});
  }
  function chirp(kind){
    if(!enabled || document.hidden || busy())return;
    var Constructor=window.AudioContext||window.webkitAudioContext;
    if(!Constructor)return;
    try {
      var ctx=context || (context=new Constructor());
      clearTimeout(idleTimer);
      var start=function(){
        if(!enabled || document.hidden || busy() || ctx!==context || ctx.state!=='running')return;
        var freq={play:650,stop:330,move:500,control:440,confirm:730}[kind]||440;
        var osc=ctx.createOscillator(),gain=ctx.createGain(),now=ctx.currentTime;
        osc.type='sine';osc.frequency.setValueAtTime(freq,now);
        osc.frequency.exponentialRampToValueAtTime(kind==='stop'?freq*.78:freq*1.18,now+.042);
        gain.gain.setValueAtTime(.0001,now);
        gain.gain.exponentialRampToValueAtTime(.065,now+.005);
        gain.gain.exponentialRampToValueAtTime(.0001,now+.052);
        osc.connect(gain);gain.connect(ctx.destination);voices.add(osc);
        osc.onended=function(){voices.delete(osc);osc.disconnect();gain.disconnect();};
        osc.start(now);osc.stop(now+.055);
        idleTimer=setTimeout(function(){if(ctx===context && ctx.state==='running')ctx.suspend().catch(function(){});},220);
      };
      if(ctx.state==='running')start();else ctx.resume().then(start).catch(function(){});
    } catch(_) {}
  }
  var ring=document.createElement('div');ring.className='sam29-tap-ring';ring.hidden=true;ring.setAttribute('aria-hidden','true');document.body.appendChild(ring);
  function flash(target){
    var rect=target.getBoundingClientRect();
    if(!rect.width||!rect.height)return;
    ring.style.left=rect.left+'px';ring.style.top=rect.top+'px';ring.style.width=rect.width+'px';ring.style.height=rect.height+'px';ring.hidden=false;
    clearTimeout(ringTimer);ringTimer=setTimeout(function(){ring.hidden=true;},130);
  }
  document.addEventListener('click',function(event){
    var el=event.target.closest && event.target.closest('button,summary,select,a[href],input[type="checkbox"],input[type="radio"],[role="button"]');
    if(!el || el.disabled || el.getAttribute('aria-disabled')==='true')return;
    flash(el);
    if(el===toggle){
      enabled=!enabled;try{localStorage.setItem(key,enabled?'on':'off');}catch(_){}
      drawToggle();if(!enabled)silence();else chirp('confirm');return;
    }
    if(busy() || el.closest('.sam-recorder__controls,.swt-options') || el.matches('#record,[data-score-only],[data-coach-record],[data-main-record]'))return;
    var now=performance.now();if(now-lastTime<45)return;lastTime=now;
    var action=el.getAttribute('data-sam-action')||el.getAttribute('data-action')||'';
    if(el.matches('[data-sam-play],[data-review-word],[data-word],[id^="play-"]') && !el.classList.contains('playing'))chirp('play');
    else if(action==='stop'||/停止|结束播放|暂停/.test(el.textContent))chirp('stop');
    else if(el.matches('[data-view],summary,select,[data-day],a[href]') || /stage|joined|sentence-index|round/.test(action))chirp('move');
    else chirp('control');
  },true);
  window.addEventListener('sam-recorder-start',silence);
  window.addEventListener('pagehide',function(){silence();if(context)context.close().catch(function(){});context=null;});
  drawToggle();
})();
