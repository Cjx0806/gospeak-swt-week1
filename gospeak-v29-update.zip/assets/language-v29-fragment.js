function detail29(line, expanded) {
    var note=state.data.languageNotes && state.data.languageNotes[line.en];
    if (!note) return '<p>本句词义资料尚未载入，请刷新页面。</p>';
    var labels=state.data.languageRoles;
    function spans(parts) {
      return parts.map(function(part){
        return '<span class="sam29-part" data-role="'+esc(part[0])+'"><small>'+esc(labels[part[0]])+'</small><b lang="en">'+esc(part[1])+'</b></span>';
      }).join('');
    }
    var words=note.words.map(function(pair){
      var word=pair[0], entry=state.data.lexicon[word.toLowerCase()];
      var english=entry && entry.src ? playButton(entry.src,word,false,word,true) : '<b>'+esc(word)+'</b>';
      var slow=entry && entry.src ? playButton({slow:entry.src,slowRate:.78},word,true,'慢',true)
        .replace('data-sam-play=', 'aria-label="'+esc(word)+' 慢速循环" data-sam-play=') : '';
      return '<li><div class="sam29-word-audio">'+english+slow+'</div><span>'+esc(pair[1])+'</span>'+
        (entry&&entry.ipa?'<small lang="en">/'+esc(entry.ipa)+'/</small>':'')+'</li>';
    }).join('');
    var inner=note.inner.map(function(parts){
      return '<div class="sam29-sub"><small>短语里再拆一层</small><div class="sam29-parts">'+spans(parts)+'</div></div>';
    }).join('');
    var modifiers=note.mod.map(function(pair){return '<b lang="en">'+esc(pair[0])+'</b> 修饰 <b lang="en">'+esc(pair[1])+'</b>';}).join('；');
    return '<details class="sam29-language" '+(expanded?'open':'')+'><summary>逐词意思与句子结构</summary><section>'+
      '<h4>句子结构</h4><div class="sam29-parts">'+spans(note.parts)+'</div>'+inner+
      (modifiers?'<p class="sam29-mod"><strong>定语</strong> · '+modifiers+'</p>':'')+
      (note.tips.length?'<p class="sam29-tip">'+esc(note.tips[0])+'</p>':'')+
      '<h4>每个词的意思</h4><p class="sam29-word-help">点英文按正常语速循环，点“慢”慢速循环。</p>'+
      '<ol class="sam29-words">'+words+'</ol>'+(line.ipa?'<p class="sam29-ipa">整句读音　/'+esc(line.ipa)+'/</p>':'')+'</section></details>';
  }
