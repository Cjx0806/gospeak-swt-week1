const VERSION = 'gospeak-independent-v8';
const BASE = self.registration.scope;
const phraseAudio = Array.from({ length: 35 }, (_, index) => `audio/p${String(index + 1).padStart(2, '0')}.mp3`);
const core = ['./', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png', ...phraseAudio].map((path) => new URL(path, BASE).href);

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(VERSION).then((cache) => cache.addAll(core)));
  self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== VERSION).map((key) => caches.delete(key)))));
  self.clients.claim();
});
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).then((response) => {
      if (response.ok) caches.open(VERSION).then((cache) => cache.put(new URL('./', BASE).href, response.clone()));
      return response;
    }).catch(() => caches.match(new URL('./', BASE).href)));
    return;
  }
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {
    if (response.ok) caches.open(VERSION).then((cache) => cache.put(event.request, response.clone()));
    return response;
  }).catch(() => undefined)));
});
