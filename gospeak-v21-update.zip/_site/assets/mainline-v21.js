/* SWT interview workbench. The original sentence course remains a separate view. */
(function () {
  'use strict';
  if (window.__samMainlineV21) return;
  var VERSION='21', STORE='gospeak-sam-v21-interview';
  var state={root:null,data:null,questions:[],selected:'15',category:'all',mode:'prepare',round:1,
    variant:0,followup:-1,questionRevealed:false,reference:true,help:false,branchChoices:{},loop:1,
    clips:{},clipCounter:0,audio:null,audioElement:null,audioToken:0,audioTimer:null,watchdog:null,audioKey:'',
    recorder:null,recorderTarget:null,loading:false,loadingToken:0,scheduled:false,continuous:false,
    counts:{},rounds:{},gaps:{},seen:{},recorded:false,needsRender:true};
  try { var saved=JSON.parse(localStorage.getItem(STORE)||'{}');state.selected=saved.selected||'15';state.counts=saved.counts||{};state.rounds=saved.rounds||{};state.gaps=saved.gaps||{}; } catch (_) {}
  var api={remount:mount,isRecording:isRecording,stopPlayback:stopSound};
  window.__samMainlineV21=api;window.__samMainlineV19=api;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function list(v){return Array.isArray(v)?v:[];}
  function q(){return state.questions.find(function(x){return x.id===state.selected;})||state.questions[0];}
  function text(lines){return list(lines).map(function(line){return line.en;}).join(' ');}
  function hasSlots(value){return /\[[^\]]+\]/.test(value||'');}
  function today(){return new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Shanghai'});}
  function roundKey(item){return today()+':'+item.id;}
  function selectedBranch(item){return list(item.branches).find(function(b){return b.id===state.branchChoices[item.id];});}
  function answerLines(item){var direct=list(item.short);if(direct.length)return direct;var branch=selectedBranch(item);return branch?list(branch.sentences).filter(function(line){return !hasSlots(line.en);}):[];}
  function variants(item){return [{en:item.question,zh:item.questionZh,audio:item.questionAudio}].concat(list(item.variants).filter(function(v){return !v.hint&&v.en!==item.question;}));}
  function activeQuestion(item){return state.followup>=0?list(item.followups)[state.followup]||variants(item)[0]:variants(item)[state.variant]||variants(item)[0];}
  function activeAnswer(item){return state.followup>=0?list(activeQuestion(item).answer):answerLines(item);}
  function persist(){try{localStorage.setItem(STORE,JSON.stringify({selected:state.selected,counts:state.counts,rounds:state.rounds,gaps:state.gaps}));}catch(_){}}
  function note(message,kind){return '<p class="sam21-note '+(kind||'')+'">'+esc(message)+'</p>';}
  function status(message){var node=state.root&&state.root.querySelector('[data-sam-status]');if(node)node.textContent=message;window.dispatchEvent(new CustomEvent('gospeak-audio-status',{detail:{message:message}}));}
  function isRecording(){return !!(state.recorder&&state.recorder.isRecording&&state.recorder.isRecording());}
  function safeToChange(){if(isRecording()){status('请先停止并保存录音，再换题或切换练习。');return false;}return true;}
  function disposeRecorder(){if(state.recorder){try{var result=state.recorder.destroy();if(result&&result.catch)result.catch(function(){});}catch(_){}state.recorder=null;}state.recorderTarget=null;}
  function mount(){
    var active=document.querySelector('.app-nav [data-view].active');
    var nav=document.querySelector('.app-nav [data-view="coach"]');if(nav&&nav.textContent!=='SWT口测主线')nav.textContent='SWT口测主线';
    var host=active&&active.getAttribute('data-view')==='coach'?document.querySelector('.coach-layout'):null;
    if(!host){if(state.root&&state.root.isConnected===false){stopSound();disposeRecorder();state.needsRender=true;}return;}
    if(!state.root){state.root=document.createElement('section');state.root.id='oral-mainline';state.root.className='sam21';state.root.innerHTML='<div class="sam21-app"><div data-sam-content>正在载入口测题库…</div><p class="sam21-status" data-sam-status role="status" aria-live="polite"></p></div>';state.root.addEventListener('click',handleClick);state.root.addEventListener('change',handleChange);}
    host.classList.add('sam21-coach-host');
    if(state.root.parentNode!==host){host.insertBefore(state.root,host.firstChild);state.needsRender=true;}
    state.root.classList.toggle('sam21-show-continuous',state.continuous);
    if(!state.data&&!state.loading)load();else if(state.data&&state.needsRender)render();
  }
  function scheduleMount(){if(state.scheduled)return;state.scheduled=true;(window.requestAnimationFrame||function(cb){setTimeout(cb,0);})(function(){state.scheduled=false;mount();});}
  function load(){
    if(state.loading)return;state.loading=true;var token=++state.loadingToken;
    var controller=typeof AbortController==='function'?new AbortController():null;
    var timer=setTimeout(function(){if(controller)controller.abort();if(token===state.loadingToken){state.loading=false;state.loadingToken++;loadError('网络等待较久，请点“重试载入”。');}},15000);
    fetch(new URL('interview-v21.json?v='+VERSION,document.baseURI).href,{cache:'no-cache',signal:controller?controller.signal:undefined}).then(function(r){if(!r.ok)throw new Error('课程暂时无法下载');return r.json();}).then(function(data){
      if(token!==state.loadingToken)return;clearTimeout(timer);state.loading=false;if(!Array.isArray(data.questions)||!data.questions.length)throw new Error('题库数据为空');
      state.data=data;state.questions=data.questions;if(!state.questions.some(function(item){return item.id===state.selected;}))state.selected=state.questions[0].id;state.needsRender=true;render();status('句子课保留原样。这里专练听懂问题、组织短答和脱稿应答。');
    }).catch(function(error){if(token!==state.loadingToken)return;clearTimeout(timer);state.loading=false;loadError(error.name==='AbortError'?'题库载入超时，请重试。':error.message);});
  }
  function loadError(message){if(state.root)state.root.querySelector('[data-sam-content]').innerHTML='<h2>题库还没有载入</h2>'+note(message)+'<button data-sam-action="retry">重试载入</button>';}
  function registerAudio(audio,content,slow){var src=typeof audio==='string'?audio:audio&&(slow?audio.slow||audio.normal||audio.src:audio.normal||audio.src);var key='clip-'+(++state.clipCounter);state.clips[key]={src:src||'',text:content||'',rate:slow&&audio&&audio.slowRate?Number(audio.slowRate):1};return key;}
  function playButton(audio,content,slow,label,single){var key=registerAudio(audio,content,slow),disabled=hasSlots(content);return '<button type="button" data-sam-play="'+key+'" '+(single?'data-single="true" ':'')+(disabled?'disabled title="先填写真实信息" ':'')+'>'+esc(disabled?'先补真实信息':label||(slow?'▶ 慢速听整段':'▶ 正常听整段'))+'</button>';}
  function audioRow(audio,content){return '<div class="sam21-audio">'+playButton(audio,content,true)+playButton(audio,content,false)+'</div>';}
  function filterQuestions(){return state.questions.filter(function(item){return state.category==='all'||item.category===state.category;});}
  function categories(){return state.questions.map(function(item){return item.category;}).filter(function(value,index,all){return value&&all.indexOf(value)===index;});}
  function headerHtml(item){
    var completed=list(state.rounds[roundKey(item)]).length;
    return '<header class="sam21-header"><div><p class="sam21-eyebrow">SAM · SWT INTERVIEW PRACTICE</p><h1>会读一句，也要会回答一题。</h1><p>句子课练基础；这里练听题、短答和随机追问。</p></div><span class="sam21-version">V21</span></header><nav class="sam21-modes" aria-label="口测训练模式"><button data-sam-action="mode" data-value="prepare" aria-pressed="'+(state.mode==='prepare')+'">准备回答<span>一题练三遍</span></button><button data-sam-action="mode" data-value="mock" aria-pressed="'+(state.mode==='mock')+'">模拟口测<span>听题后自己答</span></button></nav><div class="sam21-selectors"><label>题目类别<select data-sam-category>'+['all'].concat(categories()).map(function(value){return '<option value="'+esc(value)+'" '+(value===state.category?'selected':'')+'>'+esc(value==='all'?'全部题目':value)+'</option>';}).join('')+'</select></label>'+(state.mode==='prepare'?'<label>今天主攻一题<select data-sam-question>'+filterQuestions().map(function(item){return '<option value="'+esc(item.id)+'" '+(item.id===state.selected?'selected':'')+'>'+esc(item.title)+'</option>';}).join('')+'</select></label>':'<button class="sam21-primary" data-sam-action="random">随机抽题并听问题</button>')+'</div>'+(state.mode==='prepare'?'<div class="sam21-progress"><b>今天这题：已录 <span data-round-count>'+completed+'</span> / 3 遍</b><span>录下才计数，次数不代表掌握。</span></div>':'<p class="sam21-brief">像视频口测：先听问题，停下来想一想，再用自己的短句回答。</p>');
  }
  function roundsHtml(){var labels=['① 看短答跟读','② 只看中文思路','③ 不看提示回答'];return '<nav class="sam21-rounds" aria-label="同题回答三遍">'+labels.map(function(label,index){return '<button data-sam-action="round" data-value="'+(index+1)+'" aria-pressed="'+(state.round===index+1)+'">'+label+'</button>';}).join('')+'</nav>';}
  function questionHtml(item){
    var question=activeQuestion(item),blind=state.mode==='mock'||state.round===3;
    return '<section class="sam21-question"><div class="sam21-question-label"><small>'+(state.followup>=0?'面试官追问':'面试官提问')+'</small><span>'+(blind?'先听，再开口':'听懂在问什么')+'</span></div>'+(blind&&!state.questionRevealed?'<h2>先听问题，不看题目文字。</h2>':'<h2 lang="en">'+esc(question.en)+'</h2><p>'+esc(question.zh)+'</p>')+'<div class="sam21-audio">'+playButton(question.audio,question.en,false,'▶ 听问题',true)+playButton(question.audio,question.en,true,'▶ 慢速听问题',true)+(blind?'<button data-sam-action="question-hint">'+(state.questionRevealed?'收起题目文字':'没听懂？显示题目')+'</button>':'')+'</div><div class="sam21-question-tools">'+(state.followup>=0?'<button data-sam-action="base">回到主问题</button>':variants(item).length>1?'<button data-sam-action="wording">同一题，换个问法</button>':'')+'</div></section>';
  }
  function factGateHtml(item){
    var required=Array.isArray(item.requiresConfirmation)?item.requiresConfirmation.join('、'):'这道题涉及的个人经历';
    return '<section class="sam21-fact"><h3>先确认真实情况，再练回答</h3>'+note(required+'还没有确认。不会替你编经历；你可以选符合实际的答法，或直接脱稿回答。','sam21-caution')+list(item.branches).map(function(branch,index){var slots=hasSlots(text(branch.sentences));return '<article><h4>'+esc(branch.label||'条件答法')+'</h4>'+note(branch.condition||'只在与你的实际情况一致时使用')+(slots?note('这里需要填写你的真实信息。先告诉我具体内容，再生成专属答法。'):'<button data-sam-action="confirm-branch" data-value="'+index+'">这符合我的真实情况</button>')+'</article>';}).join('')+'</section>';
  }
  function branchChoiceHtml(item){var branch=!list(item.short).length&&selectedBranch(item);return branch?'<div class="sam21-branch"><span>真实情况：'+esc(branch.label||branch.id)+'</span><button data-sam-action="reset-branch">重新选择</button></div>':'';}
  function scaffoldHtml(item){var question=activeQuestion(item),cues=state.followup>=0?list(question.scaffold):list(item.scaffold);if(!cues.length)cues=[question.hint||'先直接回答问题','再补一句真实的理由或做法'];return '<section class="sam21-scaffold"><h3>先想这 '+Math.min(3,cues.length)+' 个意思，不背长篇</h3><ol>'+cues.slice(0,3).map(function(cue){return '<li>'+esc(cue)+'</li>';}).join('')+'</ol>'+note(state.followup>=0?question.hint||'追问要重新听懂，不能只重复刚才的答案。':item.examinerIntent||item.intent||'回答眼前的问题，补一句真实信息即可。')+'</section>';}
  function answerAudio(item,answer){if(state.followup>=0){var question=activeQuestion(item);return question.fullAudio||question.answerAudio||(answer.length===1?answer[0].audio:null);}var source=selectedBranch(item)||item;return source.fullAudio||list(source.cumulativeAudio)[answer.length-1]||(answer.length===1?answer[0].audio:null);}
  function referenceHtml(item){var answer=activeAnswer(item);return '<section class="sam21-reference"><button class="sam21-reference-toggle" data-sam-action="reference" aria-expanded="'+state.reference+'">'+(state.reference?'收起短答参考':'卡住了？展开短答参考')+'<span>会说自己的版本也可以</span></button>'+(state.reference?(answer.length?'<div class="sam21-reference-body">'+branchChoiceHtml(item)+'<p class="sam21-answer" lang="en">'+esc(text(answer))+'</p><p class="sam21-translation">'+esc(answer.map(function(line){return line.zh;}).join(' '))+'</p>'+audioRow(answerAudio(item,answer),text(answer))+'<details><summary>有一句没听清？单独慢速听</summary><ol class="sam21-lines">'+answer.map(function(line){return '<li><div><p lang="en">'+esc(line.en)+'</p><small>'+esc(line.zh)+'</small></div>'+playButton(line.audio,line.en,true,'▶ 慢速',true)+'</li>';}).join('')+'</ol></details></div>':state.followup>=0?note('这条追问没有预设个人答案。先用中文想清真实内容，再用会说的简单句表达。'):factGateHtml(item)):'')+'</section>';}
  function recorderHtml(item){
    var answer=activeAnswer(item),scripted=state.mode==='prepare'&&state.round===1&&answer.length>0;
    var branch=state.followup<0&&!list(item.short).length&&selectedBranch(item),suffix=state.followup>=0?'followup-'+state.followup:'main';
    state.recorderTarget={id:'sam-v21:'+(scripted?'scripted':'free')+':'+item.id+':'+suffix+':'+(state.mode==='mock'?'mock':'round-'+state.round)+(branch?':branch-'+branch.id:''),expectedText:scripted?text(answer):'',kind:'answer',assessmentMode:scripted?'scripted':'free',title:scripted?'第一遍：连起来跟读 · 录音识别与文字匹配':'自己回答 · 录音、识别和回听',lexicon:state.data.lexicon||{},onStart:stopSound};
    return '<section class="sam21-output"><h3>'+(scripted?'现在把短句连成一段，录下来。':'现在开口，用你会的短句回答。')+'</h3>'+note(scripted?'先展开短答，听一遍，再录音。句子之间可以停顿，不要求一口气读完。':'先直接回答，再补一个真实原因或做法。目标是说清楚，不要求和参考答案相同。')+'<div data-sam-recorder></div>'+(!scripted?'<p class="sam21-limits">自由回答不按范文逐字打分。看识别文字、回听录音，检查有没有答到问题；文字识别也可能听错。</p>':'<p class="sam21-limits">文字匹配分不等于发音分。标出的词只是需回听复核，不能据此断言哪个音发错。</p>')+'</section>';
  }
  function relatedHtml(item){var lesson=item.relatedLesson||list(item.relatedLessons)[0];return lesson?'<aside class="sam21-related"><div><b>句型不熟，再回句子课补一小段</b><p>'+esc(lesson.label||lesson.title||'相关基础句型')+' · 第 '+esc(lesson.day)+' 天 / 第 '+esc(lesson.sentence||1)+' 句</p><small>这是相关句型，不是本题完整答案。原句子课里的经历、家庭、计划是语言示例，符合真实情况才使用。</small></div><button data-sam-action="related">去原句子课复习 →</button></aside>':'';}
  function controlsHtml(){return '<div class="sam21-controls"><label>参考音频 <select data-sam-loop aria-label="参考播放次数">'+[[1,'播放1遍'],[3,'3遍，留空跟读'],[0,'循环直到停止']].map(function(x){return '<option value="'+x[0]+'" '+(state.loop===x[0]?'selected':'')+'>'+x[1]+'</option>';}).join('')+'</select></label><button data-sam-action="stop">■ 停止示范音</button></div>';}
  function reviewHtml(item){var gaps=list(state.gaps[item.id]);return '<details class="sam21-review"><summary>录完怎么改？只记最卡的 1～5 处</summary><ol><li>先听自己的录音，确认有没有回答问题。</li><li>对照识别文字，找漏词或没被听出的词；识别错误也可能来自环境。</li><li>只记最多 5 处卡点，听一遍示范，再重新说一遍。</li></ol><label>每行一处：不会说的意思 / 想复核的词<textarea data-sam-gaps rows="4" maxlength="500" placeholder="例如：没听懂问题里的 experience\n不知道怎么说“继续读书”">'+esc(gaps.join('\n'))+'</textarea></label><p data-gap-status>已记录 '+gaps.length+' / 5 处，仅保存在本机浏览器。</p></details>';}
  function actionsHtml(item){return '<div class="sam21-next"><span data-record-status>'+(state.recorded?'已录这一遍。先回听，再继续。':'听和看不计完成；至少留下一次自己的回答。')+'</span><div>'+(state.mode==='prepare'&&state.round<3?'<button class="sam21-primary" data-sam-action="round" data-value="'+(state.round+1)+'">进入第 '+(state.round+1)+' 遍 →</button>':'<button class="sam21-primary" data-sam-action="followup" '+(!list(item.followups).length?'disabled':'')+'>试一道追问 →</button>')+'<button data-sam-action="random">换一道题</button></div></div>';}
  function footerHtml(){return '<details class="sam21-help"><summary>每天怎么用？先做一题，不刷一堆题。</summary><p>先完成 1 道新题＋1 道旧题复测：1 条问题录音 → 最多 5 个表达缺口 → 同题回答 3 遍 → 明天先脱稿复测 1 次。</p><ol><li>10 分钟：复测昨天的问题。</li><li>15 分钟：听今天的问题，用中文想好 2～3 点。</li><li>25 分钟：从看短答到看中文，再到脱稿，实际录 3 遍。</li><li>10 分钟：练一道追问；有不同问法时再练听辨。</li></ol><p>有 90 分钟：完成上述保底后，再加 15 分钟旧题复测＋15 分钟问题听辨。有 120 分钟：再加 30 分钟随机模拟和回听纠正，不增加大量新题或新视频。</p><p>只有遇到不会的基础句型，才回原句子课补练。模拟回答不要求背长句、说得很快或逐字照搬。没有录音识别时不编造分数。</p></details><div class="sam21-secondary"><button data-sam-action="continuous">'+(state.continuous?'收起拓展连续听练':'拓展：连续听练（与本页题库不同）')+'</button></div>';}
  function render(preserveRecorder){
    if(!state.data||!q()||!state.root)return;if(state.root.isConnected===false){state.needsRender=true;return;}stopSound();
    var previousRecorder=preserveRecorder&&state.recorder,previousTarget=state.recorderTarget,previousNode=previousRecorder&&state.root.querySelector('[data-sam-recorder]');
    if(!previousRecorder)disposeRecorder();state.clips={};state.clipCounter=0;state.needsRender=false;
    var item=q(),prepare=state.mode==='prepare',showScaffold=prepare&&state.round<3;
    state.root.querySelector('[data-sam-content]').innerHTML=headerHtml(item)+(prepare?roundsHtml():'')+questionHtml(item)+(showScaffold?scaffoldHtml(item):'')+(prepare&&state.round===1?referenceHtml(item):'<div class="sam21-hint-action"><button data-sam-action="help" aria-expanded="'+state.help+'">'+(state.help?'收起临时提示':'卡住了？临时看提示')+'</button></div>'+(state.help?scaffoldHtml(item)+referenceHtml(item):''))+controlsHtml()+recorderHtml(item)+actionsHtml(item)+reviewHtml(item)+(prepare?relatedHtml(item):'')+footerHtml();
    var placeholder=state.root.querySelector('[data-sam-recorder]');
    if(previousRecorder&&previousNode&&previousTarget&&state.recorderTarget&&previousTarget.id===state.recorderTarget.id&&placeholder&&placeholder.replaceWith){placeholder.replaceWith(previousNode);return;}
    if(previousRecorder){var nextTarget=state.recorderTarget;disposeRecorder();state.recorderTarget=nextTarget;}
    if(state.recorderTarget&&window.SamRecorder)state.recorder=window.SamRecorder.mount(placeholder,state.recorderTarget);else if(state.recorderTarget)placeholder.innerHTML=note('录音组件还没有载入，请刷新重试。');
  }
  function stopSound(message){var wasActive=!!(state.audio||state.audioKey||state.audioTimer||state.watchdog);state.audioToken++;clearTimeout(state.audioTimer);clearTimeout(state.watchdog);state.audioTimer=state.watchdog=null;if(state.audio){var audio=state.audio;audio.onended=audio.onerror=audio.onplaying=audio.onwaiting=audio.onstalled=audio.onpause=null;audio.pause();audio.removeAttribute('src');audio.load();state.audio=null;}state.audioKey='';if(state.root)state.root.querySelectorAll('[data-sam-play]').forEach(function(button){button.classList.remove('playing');button.setAttribute('aria-pressed','false');});if(wasActive)status(typeof message==='string'?message:'示范音已停止。');}
  function staticAudioUrl(src){var url=new URL(src,document.baseURI);if(url.protocol==='https:'||url.protocol==='http:')url.searchParams.set('v',VERSION);return url.href;}
  function playClip(clip,key,button,single){
    if(clip&&hasSlots(clip.text)){status('先补真实信息，不播放占位内容。');return;}if(!clip||!clip.src){status('这段示范音暂不可用，请先看文字练习。');return;}if(isRecording()){status('请先停止录音，再听示范音。');return;}if(state.audio&&state.audioKey===key){stopSound();return;}stopSound();
    window.dispatchEvent(new CustomEvent('gospeak-playback-request',{detail:{owner:'mainline-v21'}}));document.querySelectorAll('audio,video').forEach(function(audio){if(!audio.paused)audio.pause();});
    var token=state.audioToken,played=0,limit=single?1:state.loop,audio=state.audioElement||(state.audioElement=new Audio());audio.src=staticAudioUrl(clip.src);audio.preload='auto';audio.playbackRate=clip.rate||1;audio.preservesPitch=true;state.audio=audio;state.audioKey=key;if(button){button.classList.add('playing');button.setAttribute('aria-pressed','true');}
    function fail(message){if(token!==state.audioToken)return;stopSound();status(message);}
    function watch(){if(token!==state.audioToken)return;clearTimeout(state.watchdog);var from=audio.currentTime||0;state.watchdog=setTimeout(function(){if(token!==state.audioToken)return;if(!audio.paused&&audio.currentTime>from+0.2){state.watchdog=null;return;}fail('播放等待超时，已解除等待。请再点一次，或用顶部“恢复声音”。');},15000);}
    function attempt(){if(token!==state.audioToken)return;watch();try{Promise.resolve(audio.play()).then(function(){if(token!==state.audioToken)return;clearTimeout(state.watchdog);state.watchdog=null;status('正在播放。再点同一按钮或“停止示范音”可结束。');}).catch(function(){fail('播放未启动，请检查网络和音量后再点一次。');});}catch(_){fail('暂时无法播放，请再试一次。');}}
    audio.onplaying=function(){if(token===state.audioToken){clearTimeout(state.watchdog);state.watchdog=null;}};audio.onwaiting=watch;audio.onstalled=function(){if(audio.readyState<3)watch();};audio.onpause=function(){if(token===state.audioToken&&!audio.ended){stopSound();status('示范音已暂停，可重新点读。');}};audio.onended=function(){if(token!==state.audioToken)return;played++;clearTimeout(state.watchdog);if(limit===0||played<limit)state.audioTimer=setTimeout(function(){if(token===state.audioToken){audio.currentTime=0;attempt();}},Math.max(1200,(audio.duration||1)*700));else stopSound('这段示范音已播放结束。');};audio.onerror=function(){fail('音频加载失败，已停止等待。检查网络后再点一次。');};status('正在加载示范音…再点同一按钮可取消。');attempt();
  }
  function playQuestion(){var item=activeQuestion(q()),key=registerAudio(item.audio,item.en,false);playClip(state.clips[key],key,null,true);}
  function resetPrompt(){state.variant=0;state.followup=-1;state.questionRevealed=false;state.reference=state.mode==='prepare'&&state.round===1;state.help=false;state.recorded=false;}
  function choose(id){if(!safeToChange())return;state.selected=id;resetPrompt();persist();render();}
  function goRelated(){
    var item=q(),lesson=item.relatedLesson||list(item.relatedLessons)[0],day=Number(lesson&&lesson.day),sentence=Number(lesson&&(lesson.sentence||1));
    if(!lesson||!Number.isInteger(day)||day<1||day>14||!Number.isInteger(sentence)||sentence<1||sentence>5){status('这题暂时没有关联的基础句型，请使用顶部原句子课。');return;}if(!safeToChange())return;stopSound();disposeRecorder();state.needsRender=true;
    var nav=document.querySelector('.app-nav [data-view="lesson"]');if(!nav){status('请点击顶部“句子课”复习。');return;}nav.click();var dayButton=document.querySelector('.days [data-day="'+(day-1)+'"]');if(!dayButton)return;dayButton.click();for(var index=1;index<sentence;index++){var next=document.querySelector('main.layout #next');if(!next||next.disabled)break;next.click();}
  }
  function saveGaps(value){var gaps=String(value||'').split(/\n/).map(function(value){return value.trim();}).filter(Boolean).slice(0,5);state.gaps[q().id]=gaps;persist();var node=state.root.querySelector('[data-gap-status]');if(node)node.textContent='已记录 '+gaps.length+' / 5 处，仅保存在本机浏览器。';return gaps;}
  function handleChange(event){var target=event.target;if(target.matches('[data-sam-question]')){if(safeToChange())choose(target.value);else target.value=state.selected;}else if(target.matches('[data-sam-category]')){if(!safeToChange()){target.value=state.category;return;}state.category=target.value;var pool=filterQuestions();if(pool.length&&!pool.some(function(item){return item.id===state.selected;}))state.selected=pool[0].id;resetPrompt();persist();render();}else if(target.matches('[data-sam-loop]'))state.loop=Number(target.value);else if(target.matches('[data-sam-gaps]'))target.value=saveGaps(target.value).join('\n');}
  function handleClick(event){
    var button=event.target.closest('button');if(!button||!state.root.contains(button)||button.disabled)return;if(button.hasAttribute('data-sam-play')){var key=button.getAttribute('data-sam-play');playClip(state.clips[key],key,button,button.hasAttribute('data-single'));return;}
    var action=button.getAttribute('data-sam-action'),value=button.getAttribute('data-value');if(!action)return;if(action==='stop'){stopSound();status('示范音已停止。');return;}if(action==='retry'){load();return;}if(!safeToChange())return;
    if(action==='mode'){state.mode=value==='mock'?'mock':'prepare';state.round=1;resetPrompt();render();}
    else if(action==='round'){state.round=Math.max(1,Math.min(3,Number(value)||1));state.mode='prepare';state.followup=-1;state.questionRevealed=false;state.reference=state.round===1;state.help=false;state.recorded=false;render();}
    else if(action==='reference'){state.reference=!state.reference;render(true);}
    else if(action==='help'){state.help=!state.help;state.reference=false;render(true);}
    else if(action==='question-hint'){state.questionRevealed=!state.questionRevealed;render(true);}
    else if(action==='wording'){state.variant=(state.variant+1)%variants(q()).length;state.questionRevealed=false;state.recorded=false;render();playQuestion();}
    else if(action==='base'){state.followup=-1;state.questionRevealed=false;state.reference=false;state.help=false;state.recorded=false;render();playQuestion();}
    else if(action==='followup'){var followups=list(q().followups);state.followup=followups.length?(state.followup+1)%followups.length:-1;state.mode='mock';state.questionRevealed=false;state.reference=false;state.help=false;state.recorded=false;render();playQuestion();}
    else if(action==='random'){var pool=filterQuestions().filter(function(item){return item.id!==state.selected;});if(!pool.length){status('这类暂时只有这一题，可先换问法或选择其他类别。');return;}var picked=pool[Math.floor(Math.random()*pool.length)];state.selected=picked.id;resetPrompt();state.variant=Math.floor(Math.random()*variants(picked).length);persist();render();playQuestion();}
    else if(action==='related')goRelated();
    else if(action==='confirm-branch'){var branch=list(q().branches)[Number(value)];if(!branch||hasSlots(text(branch.sentences)))return;state.branchChoices[q().id]=branch.id;state.reference=true;render();status('已按你确认的真实情况选答法。情况改变时请重新选择。');}
    else if(action==='reset-branch'){delete state.branchChoices[q().id];state.recorded=false;render();status('已撤回这个选择。旧录音仍保留，请重新确认真实情况。');}
    else if(action==='continuous'){state.continuous=!state.continuous;state.root.classList.toggle('sam21-show-continuous',state.continuous);button.textContent=state.continuous?'收起拓展连续听练':'拓展：连续听练（与本页题库不同）';if(state.continuous){var player=state.root.querySelector('#swt-listening-v18');if(player)player.scrollIntoView({behavior:'smooth',block:'start'});}else{var media=state.root.querySelector('#swt-listening-v18 audio');if(media)media.pause();}}
  }
  function recordSaved(event){
    var d=event.detail||{},id=String(d.id||d.targetId||''),stamp=d.savedAt||d.createdAt||Date.now();if(!id.startsWith('sam-v21:')||Number(d.duration)<=0)return;var unique=id+':'+stamp;if(state.seen[unique])return;state.seen[unique]=true;var parts=id.split(':');state.counts[parts[2]]=(state.counts[parts[2]]||0)+1;
    if(state.recorderTarget&&state.recorderTarget.id===id){state.recorded=true;if(state.mode==='prepare'&&state.followup<0){var key=roundKey(q()),rounds=list(state.rounds[key]);if(rounds.indexOf(state.round)===-1)rounds.push(state.round);state.rounds[key]=rounds;var count=state.root.querySelector('[data-round-count]');if(count)count.textContent=String(rounds.length);}var hint=state.root.querySelector('[data-record-status]');if(hint)hint.textContent='已录这一遍。先回听，修正一处卡点，再继续；次数不代表答对。';}persist();
  }
  window.addEventListener('sam-recorder-start',stopSound);
  window.addEventListener('gospeak-playback-request',function(event){if(!event.detail||event.detail.owner!=='mainline-v21')stopSound();});
  window.addEventListener('sam-review-word',function(event){var detail=event.detail||{};if(!state.recorderTarget||detail.targetId!==state.recorderTarget.id)return;var key=registerAudio(detail.src,detail.word,false);playClip(state.clips[key],key,null,true);});
  window.addEventListener('sam-recorder-saved',recordSaved);
  document.addEventListener('click',function(event){var nav=event.target.closest('[data-view]');if(!nav)return;if(document.querySelector('main.layout .practice.listening')){event.preventDefault();event.stopImmediatePropagation();window.dispatchEvent(new CustomEvent('gospeak-audio-status',{detail:{message:'原句子课正在识别，请先完成这一句的录音再切换板块。'}}));return;}if(!safeToChange()){event.preventDefault();event.stopImmediatePropagation();return;}stopSound();document.querySelectorAll('audio,video').forEach(function(audio){if(!audio.paused)audio.pause();});disposeRecorder();state.needsRender=true;scheduleMount();},true);
  document.addEventListener('play',function(event){if(event.target!==state.audio)stopSound();},true);
  window.addEventListener('pagehide',function(){stopSound();disposeRecorder();state.needsRender=true;});
  function init(){mount();var app=document.getElementById('app');if(app)new MutationObserver(scheduleMount).observe(app,{childList:true});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
