"""Small V21 overlay; retain all V19/V20 media and auditable sources."""
from pathlib import Path
import zipfile
from verify_v21 import verify
root=Path(__file__).resolve().parents[1]
site=root/'_site'
verify(site)
paths=[site/name for name in ('index.html','sw.js','manifest.webmanifest','interview-v21.json')]
paths += list((site/'assets').glob('*.js')) + list((site/'assets').glob('*.css'))
paths += list((site/'audio/v21').glob('*.mp3'))
paths += [p for folder in ('assets','scripts') for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.startswith('.')]
with zipfile.ZipFile(root/'gospeak-v21-update.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(set(paths)): archive.write(p,p.relative_to(root))
size=(root/'gospeak-v21-update.zip').stat().st_size
assert size < 24_000_000
print(f'V21 overlay: {size:,} bytes; no source PDF, private learner recordings or personal photos.')
