"""V21 interview practice, separate from the unchanged 14-day sentence course.

The 30 primary prompts are transcribed from Sam's one-page reference bank.
Answers are original teaching examples, not supplied/official answers. No
unconfirmed experience, personality or travel plan becomes a default fact.
"""
from __future__ import annotations

from copy import deepcopy
import json
import re

import v20_curriculum as previous

VERSION = "v21"
PROFILE = deepcopy(previous.PROFILE)
S = previous.S
sentence_id = previous.sentence_id
template = previous.template
LINES = deepcopy(previous.LINES)


def add(key, en, zh, ipa, grammar):
    LINES[key] = S(en, zh, ipa, grammar)


add("no_work", "I have no work experience yet.", "我目前还没有工作经验。", "aɪ hæv noʊ wɝk ɪkˈspɪriəns jɛt", "I 主语＋have 谓语＋no work experience 宾语；yet 表示目前还没有。")
add("no_service", "I have not worked in customer service.", "我没有做过客服或顾客服务工作。", "aɪ hæv nɑt wɝkt ɪn ˈkʌstəmər ˈsɝvɪs", "I 主语＋have not worked 现在完成时否定；in customer service 说明工作领域。")
add("no_places", "I have not worked in those places.", "我没有在那些地方工作过。", "aɪ hæv nɑt wɝkt ɪn ðoʊz ˈpleɪsɪz", "I 主语＋have not worked 现在完成时否定；those places 指题目中的餐厅、酒店和商店。")
add("no_solo", "I have not traveled alone yet.", "我还没有独自旅行过。", "aɪ hæv nɑt ˈtrævəld əˈloʊn jɛt", "I 主语＋have not traveled 现在完成时否定；alone 表示独自。")
add("service_calm", "I would stay calm and listen.", "我会保持冷静，听对方说。", "aɪ wʊd steɪ kɑm ænd ˈlɪsən", "I 主语；would 后接 stay 和 listen 两个动作；calm 是 stay 的表语。")
add("ask_problem", "I would ask about the problem.", "我会询问是什么问题。", "aɪ wʊd æsk əˈbaʊt ðə ˈprɑbləm", "I 主语＋would ask about 谓语短语＋the problem 宾语。")
add("help_within_role", "I would help within my role.", "我会在自己职责范围内提供帮助。", "aɪ wʊd hɛlp wɪˈðɪn maɪ roʊl", "I 主语＋would help 谓语；within my role 表示在自己的职责范围内。")
add("ask_supervisor", "I would ask my supervisor for help.", "我会向主管求助。", "aɪ wʊd æsk maɪ ˈsupərvaɪzər fər hɛlp", "I 主语＋would ask 谓语＋my supervisor 宾语；for help 表示请求帮助。")
add("try_best", "I would do my best.", "我会尽力。", "aɪ wʊd du maɪ bɛst", "I 主语＋would do 谓语＋my best 宾语；do my best 表示尽力。")
add("one_task", "I would do one task at a time.", "我会一次处理一项任务。", "aɪ wʊd du wʌn tæsk ət ə taɪm", "I 主语＋would do 谓语＋one task 宾语；at a time 表示一次。")
add("team_listen", "I would listen to my teammates.", "我会听取队友的意见。", "aɪ wʊd ˈlɪsən tə maɪ ˈtimmeɪts", "I 主语＋would listen to 谓语短语＋my teammates 宾语。")
add("team_task", "I would finish my own tasks.", "我会完成自己负责的任务。", "aɪ wʊd ˈfɪnɪʃ maɪ oʊn tæsks", "I 主语＋would finish 谓语＋my own tasks 宾语；own 表示自己的。")
add("team_help", "I would help when I can.", "能帮忙时，我会帮忙。", "aɪ wʊd hɛlp wɛn aɪ kæn", "I 主语＋would help 谓语；when I can 表示在我能够帮忙时。")
add("short_talk", "I would try short conversations.", "我会尝试简短交流。", "aɪ wʊd traɪ ʃɔrt ˌkɑnvərˈseɪʃənz", "I 主语＋would try 谓语＋short conversations 宾语。")
add("write_new", "I would write down useful words.", "我会记下实用的词。", "aɪ wʊd raɪt daʊn ˈjusfəl wɝdz", "I 主语＋would write down 谓语短语＋useful words 宾语。")
add("share_food", "I would like to share Chinese food.", "我想分享中国美食。", "aɪ wʊd laɪk tə ʃɛr tʃaɪˈniz fud", "I 主语；would like to 表示想做；share 的宾语是 Chinese food。")
add("explain_food", "I could explain some simple dishes.", "我可以介绍一些简单的菜。", "aɪ kʊd ɪkˈspleɪn sʌm ˈsɪmpəl ˈdɪʃɪz", "I 主语＋could explain 谓语＋some simple dishes 宾语；could 表示可以。")
add("late_call", "I would call my supervisor right away.", "我会马上给主管打电话。", "aɪ wʊd kɔl maɪ ˈsupərvaɪzər raɪt əˈweɪ", "I 主语＋would call 谓语＋my supervisor 宾语；right away 表示马上。")
add("late_reason", "I would explain why and say sorry.", "我会解释原因并道歉。", "aɪ wʊd ɪkˈspleɪn waɪ ænd seɪ ˈsɑri", "I 主语；would 后接 explain 和 say 两个动作；why 指迟到原因。")
add("late_time", "I would give my arrival time.", "我会告知预计到达时间。", "aɪ wʊd ɡɪv maɪ əˈraɪvəl taɪm", "I 主语＋would give 谓语＋my arrival time 宾语。")
add("leave_earlier", "I would leave earlier next time.", "下次我会更早出发。", "aɪ wʊd liv ˈɝliər nɛkst taɪm", "I 主语＋would leave 谓语；earlier 表示更早；next time 表示下次。")
add("task_example", "I would ask for an example.", "我会请对方举例或示范。", "aɪ wʊd æsk fər ən ɪɡˈzæmpəl", "I 主语＋would ask for 谓语短语＋an example 宾语。")
add("customer_need", "I would ask what they need.", "我会问他们需要什么。", "aɪ wʊd æsk wʌt ðeɪ nid", "I 主语＋would ask 谓语；what they need 整体作宾语。")
add("actual_help", "How can I help you?", "我能为您做些什么？", "haʊ kən aɪ hɛlp ju", "How 问方式；can 情态动词；I 主语＋help 谓语＋you 宾语。")
add("room_rules", "I would discuss our shared rules.", "我会一起商量共同生活的规则。", "aɪ wʊd dɪˈskʌs aʊr ʃɛrd rulz", "I 主语＋would discuss 谓语＋our shared rules 宾语。")
add("room_clean", "I would keep shared spaces clean.", "我会保持公共区域整洁。", "aɪ wʊd kip ʃɛrd ˈspeɪsɪz klin", "I 主语＋would keep 谓语＋shared spaces 宾语＋clean 宾语补足语。")
add("room_respect", "I would respect their habits.", "我会尊重他们的习惯。", "aɪ wʊd rɪˈspɛkt ðɛr ˈhæbɪts", "I 主语＋would respect 谓语＋their habits 宾语。")
add("budget", "I would make a weekly budget.", "我会做每周预算。", "aɪ wʊd meɪk ə ˈwikli ˈbʌdʒɪt", "I 主语＋would make 谓语＋a weekly budget 宾语；weekly 表示每周的。")
add("essentials", "I would pay for food and rent first.", "我会先支付吃饭和房租的费用。", "aɪ wʊd peɪ fər fud ænd rɛnt fɝst", "I 主语＋would pay for 谓语短语＋food and rent 宾语；first 表示首先。")
add("spending", "I would track my spending.", "我会记录开销。", "aɪ wʊd træk maɪ ˈspɛndɪŋ", "I 主语＋would track 谓语＋my spending 宾语。")
add("no_borrow", "I would spend less on optional activities.", "我会减少非必需活动的开销。", "aɪ wʊd spɛnd lɛs ɑn ˈɑpʃənəl ækˈtɪvətiz", "I 主语＋would spend 谓语；less 表示少花；on... 表示花费在哪方面。")
add("rest", "I would get some rest.", "我会休息一下。", "aɪ wʊd ɡɛt sʌm rɛst", "I 主语＋would get 谓语＋some rest 宾语。")
add("local_events", "I would join local cultural activities.", "我会参加当地的文化活动。", "aɪ wʊd dʒɔɪn ˈloʊkəl ˈkʌltʃərəl ækˈtɪvətiz", "I 主语＋would join 谓语＋local cultural activities 宾语。")
add("check_time_budget", "I would check my time and budget.", "我会核对时间和预算。", "aɪ wʊd tʃɛk maɪ taɪm ænd ˈbʌdʒɪt", "I 主语＋would check 谓语＋my time and budget 并列宾语。")
add("places_pending", "I have not chosen any places yet.", "我还没有选好具体去哪里。", "aɪ hæv nɑt ˈtʃoʊzən ˈɛni ˈpleɪsɪz jɛt", "I 主语＋have not chosen 现在完成时否定＋any places 宾语；yet 表示尚未。")
add("yes_try", "Yes, I would like to try.", "可以，我愿意尝试。", "jɛs aɪ wʊd laɪk tə traɪ", "Yes 先回应；I 主语；would like to 表示愿意；try 表示尝试。")
add("swim_free", "I like to swim in my free time.", "我空闲时喜欢游泳。", "aɪ laɪk tə swɪm ɪn maɪ fri taɪm", "I 主语＋like 谓语＋to swim 表示喜欢做的事；in my free time 说明时间。")
add("not_cert_work", "My certificate is not work experience.", "持有证书不等于有工作经验。", "maɪ sərˈtɪfɪkət ɪz nɑt wɝk ɪkˈspɪriəns", "My certificate 主语＋is not 系动词否定＋work experience 表语。")


def take(*keys):
    return [deepcopy(LINES[k]) for k in keys]


def branch(id, label, condition, sentences):
    return {"id": id, "label": label, "condition": condition,
            "confirmed": False, "sentences": deepcopy(sentences)}


LEGACY_SENTENCES = {
    (1, 1): "My name is Sam.",
    (2, 1): "I am a first-year student at Guangxi College for Preschool Education.",
    (2, 2): "My major is physical fitness training.",
    (2, 3): "I am a first-year student.",
    (3, 3): "I am willing to learn new skills.",
    (3, 5): "I work carefully and follow safety rules.",
    (4, 1): "I want to experience American culture.",
    (4, 2): "I want to improve my spoken English.",
    (5, 1): "Could you say that again, please?",
    (5, 2): "Could you speak more slowly?",
    (5, 4): "Could you show me how to do it?",
    (5, 5): "Let me make sure I understand.",
    (7, 4): "I would be happy to work with your team.",
    (8, 4): "I sometimes need more time to answer in English.",
    (8, 5): "I practice listening and speaking every day.",
    (9, 5): "During the program, I will work responsibly and join cultural activities.",
    (10, 4): "I will respect different cultures and local customs.",
    (10, 5): "If I cannot solve a problem, I will contact my supervisor or sponsor.",
    (12, 2): "I have a lifeguard certificate in China.",
    (12, 4): "I am open to other suitable jobs.",
    (13, 3): "I will observe carefully and ask questions politely.",
    (13, 4): "I want to share Chinese food, festivals, and traditions.",
    (14, 1): "After the program, I will return to China and continue my studies.",
}


def lesson(day, sentence, label):
    return {"day": day, "sentence": sentence, "title": label, "label": label,
            "en": LEGACY_SENTENCES[(day, sentence)],
            "relationship": "相关句型，不要求把原句逐字搬进回答"}


PROMPTS = [
    ("Please introduce yourself.", "请介绍你自己。"),
    ("What is your major?", "你的专业是什么？"),
    ("Which university do you study at?", "你在哪所学校就读？"),
    ("What are your hobbies?", "你的爱好是什么？"),
    ("What do you usually do in your free time?", "你空闲时通常做什么？"),
    ("What are your strengths?", "你的优点是什么？"),
    ("What kind of person are you?", "你是一个什么样的人？"),
    ("Do you have any work experience?", "你有工作经验吗？"),
    ("Have you ever worked in customer service?", "你做过顾客服务工作吗？"),
    ("Have you ever worked in a restaurant, hotel, or store?", "你在餐厅、酒店或商店工作过吗？"),
    ("What did you learn from your previous job?", "你从以前的工作中学到了什么？"),
    ("How do you deal with difficult customers?", "你会如何应对难沟通的顾客？"),
    ("Can you work under pressure?", "你能在有压力的情况下工作吗？"),
    ("Can you work as part of a team?", "你能与团队一起工作吗？"),
    ("Why do you want to join the Summer Work Travel program?", "你为什么想参加 SWT 项目？"),
    ("Why do you want to go to the United States?", "你为什么想去美国？"),
    ("What do you expect to gain from this program?", "你希望从这个项目中获得什么？"),
    ("What will you do if you meet difficulties in the U.S.?", "如果在美国遇到困难，你会怎么办？"),
    ("How will you improve your English during the program?", "你会如何在项目期间提高英语？"),
    ("What would you like to share with Americans about China?", "你想和美国人分享中国的哪些事物？"),
    ("What would you do if a customer complained?", "如果顾客投诉，你会怎么办？"),
    ("What would you do if you were late for work?", "如果上班迟到，你会怎么办？"),
    ("What would you do if your supervisor gave you a difficult task?", "如果主管交给你一项困难的任务，你会怎么办？"),
    ("How would you help a customer who needs assistance?", "你会如何帮助需要协助的顾客？"),
    ("What would you do if you made a mistake at work?", "如果在工作中犯错，你会怎么办？"),
    ("Have you ever traveled alone?", "你独自旅行过吗？"),
    ("Can you live with roommates from different countries?", "你能和来自不同国家的室友一起生活吗？"),
    ("How will you manage your money in the U.S.?", "你会如何管理在美国期间的钱？"),
    ("What will you do on your days off?", "你休息日会做什么？"),
    ("What places would you like to visit in the United States?", "你想去美国的哪些地方看看？"),
]

# Titles, answer intent and Chinese cue cards must remain visibly different
# from a sentence lesson. Learner can change wording while keeping the meaning.
CARDS = [
    ("自我介绍", "让对方迅速知道你是谁，不把所有题的答案都塞进自介。", ["Sam＋大一", "学校", "体育体能训练"], ("name", "year", "school", "major")),
    ("专业", "先回答专业，再补一句学生身份即可。", ["体育体能训练", "目前大一"], ("major", "year")),
    ("学校", "回答你真实就读的学校；题目说 university，不代表要把专科说成大学。", ["广西幼儿师范高等专科学校", "大一"], ("school", "year")),
    ("爱好", "说真实爱好，加一个与自己有关的小细节。", ["游泳", "中国救生员证"], ("swimming", "certificate")),
    ("空闲时间", "说实际会做的事；不要虚构每天练多久。", ["空闲喜欢游泳", "目前在准备 SWT"], ("swim_free", "preparing")),
    ("优点", "选一个符合自己的优点；被追问例子时只能用真事。", ["选择真实优点", "说具体会怎样做"], ()),
    ("性格", "简单描述自己，不必背一串高级形容词。", ["选符合自己的性格", "用一个行为解释"], ()),
    ("是否有工作经验", "先准确回答有没有；持证不等于当过救生员。", ["是否真的工作过", "有：岗位与任务；无：愿意学习"], ()),
    ("顾客服务经历", "只回答顾客服务经历，不用中国救生员证代替工作经历。", ["是否做过顾客服务", "有：真实职责；无：如实说明"], ()),
    ("餐厅、酒店或商店经历", "针对题目列出的场所回答，不把旅行入住算工作。", ["有没有在这些地方工作过", "选择一个真实岗位或说明没有"], ()),
    ("从以前工作学到什么", "先确认是否有以前的工作；没有就纠正前提，不编故事。", ["有无以前的工作", "有：学到一件事；无：说明尚无经验"], ()),
    ("难沟通的顾客", "给出处理顺序：先听、弄清问题、职责内处理或求助。", ["冷静并听", "询问问题", "需要时找主管"], ("service_calm", "ask_problem", "ask_supervisor")),
    ("工作压力", "不保证自己永远不紧张；说在忙乱中怎样处理任务。", ["会尽力", "一次一件事", "需要时求助"], ("try_best", "one_task", "help")),
    ("团队合作", "说合作动作，不编一段过去的团队经历。", ["听队友", "做好自己负责的事", "能力范围内帮忙"], ("team_listen", "team_task", "team_help")),
    ("为什么参加 SWT", "回答为什么选这个项目：工作、练英语、文化交流。", ["项目包括工作与交流", "工作中练英语", "了解文化"], ("work_culture", "work_english", "learn_culture")),
    ("为什么选择美国", "解释对美国文化的真实兴趣；不要把短期项目说成长期工作。", ["对美国文化感兴趣", "想了解日常生活", "想提高英语"], ("culture_interest", "life", "english")),
    ("希望获得什么", "重点是自己希望进步的能力，不重复整段‘为什么美国’。", ["更好地听懂别人", "表达更清楚", "提高技能"], ("understand_people", "speak_clearly", "skills")),
    ("在美国遇到困难", "说先冷静，再向合适的人求助；区分工作问题和项目问题。", ["先冷静", "工作找主管", "项目事务找赞助机构"], ("calm", "work_help", "program_help")),
    ("项目期间提高英语", "题目问方法，要说行动，不能只说‘想提高英语’。", ["每天练", "尝试简短交流", "记下实用词"], ("daily_practice", "short_talk", "write_new")),
    ("分享中国文化", "挑一个你真正愿意介绍的具体内容；美食只是可选例子。", ["选一种中国事物", "简单说明", "准备一个具体例子"], ()),
    ("顾客投诉", "先听清投诉，不争吵，也不越权承诺退款。", ["冷静听", "职责范围内帮助", "找主管"], ("service_calm", "help_within_role", "ask_supervisor")),
    ("上班迟到", "说明补救动作：立即联系、道歉解释、告知预计到达时间。", ["马上通知主管", "解释并道歉", "报预计到达时间"], ("late_call", "late_reason", "late_time")),
    ("主管给了困难任务", "先确认指示、请求示范，不懂就不猜着做。", ["认真听", "请示范", "确认后开始"], ("listen", "task_example", "check_first")),
    ("帮助顾客", "先问需要什么，再在职责范围内帮忙；不知道就求助。", ["询问需要", "职责内帮助", "必要时找主管"], ("customer_need", "help_within_role", "ask_supervisor")),
    ("工作中犯错", "不要隐瞒；先告知主管，再安全补救并吸取教训。", ["告知主管", "安全补救", "避免重复犯错"], ("tell_supervisor", "fix_safe", "learn_mistake")),
    ("独自旅行经历", "只问独自旅行，不是泛问出国或去过哪里。", ["有没有独自旅行", "有：真实地点；无：如实说明"], ()),
    ("跨国室友", "回答怎么一起生活，不用刻板印象描述其他国家的人。", ["商量规则", "保持公共区域整洁", "尊重习惯"], ("room_rules", "room_clean", "room_respect")),
    ("管理预算", "给出可执行的预算方法，不编收入、余额或父母资助金额。", ["每周预算", "先付食宿", "记开销"], ("budget", "essentials", "spending")),
    ("休息日计划", "说短期项目内的合理活动；这些是可调整的计划例子，不是已经订好的行程。", ["休息", "文化活动", "核对时间与预算"], ("rest", "local_events", "check_time_budget")),
    ("想参观哪些地方", "有真实想去的地方再说；未决定也可以如实回答。", ["是否已决定想去哪里", "地点与理由，或尚未决定", "考虑时间与预算"], ()),
]

UNKNOWN_NUMBERS = {6, 7, 8, 9, 10, 11, 20, 26, 30}
PRIORITY_NUMBERS = {1, 2, 3, 8, 15, 16, 17, 18, 19, 22, 23, 25}
CATEGORY_RANGES = [(7, "个人介绍"), (14, "工作经验"), (20, "SWT 项目"), (25, "工作场景"), (30, "美国生活")]
QUESTIONS = []
for n, ((en, zh), (title, intent, scaffold, keys)) in enumerate(zip(PROMPTS, CARDS), 1):
    QUESTIONS.append({
        "id": f"{n:02d}", "title": title, "question": en, "questionZh": zh,
        "category": next(label for end, label in CATEGORY_RANGES if n <= end),
        "sourceNumbers": [n], "sourceQuestions": [n],
        "priority": "先练" if n in PRIORITY_NUMBERS else "再练",
        "examinerIntent": intent, "intent": intent, "scaffold": scaffold,
        "short": take(*keys), "extra": [], "variants": [], "followups": [],
        "branches": [], "requiresConfirmation": n in UNKNOWN_NUMBERS,
        "readyForAutoplay": bool(keys), "answerType": "short-beginner" if keys else "confirm-facts-first",
        "keywords": [], "relatedLessons": [],
        "learningGoal": "听懂当前问题，用自己的 2—4 个短句切题回答，再接一个追问。",
        "connectionTip": "句尾自然停顿，再说下一句。无需强行连音，也不用为了凑时长加复杂句。",
        "note": "这是根据参考题库编写的短答示例，不是唯一标准答案，也不保证面试出现原题。",
    })


def q(n):
    return QUESTIONS[n - 1]


for n in (6, 7):
    q(n)["branches"] = [
        branch("patient", "有责任心、有耐心（符合我才选）", "只有你认为这两个评价真实符合自己时才选择；追问例子时说真事。", take("responsible", "learn", "safety")),
        branch("learning", "愿意学习（符合我才选）", "只有确实愿意学习并接受指导时选择，不当作已核实的人格评价。", take("learn", "listen", "try_improve")),
    ]

for n, no_key, label in [(8, "no_work", "没有工作经验"), (9, "no_service", "没做过顾客服务"), (10, "no_places", "没在这些地方工作过"), (11, "no_work", "没有以前的工作")]:
    q(n)["branches"] = [
        branch("no", label + "（真实才选）", "请核对真实经历；未提供经历不等于没有经历。", take(no_key, "learn")),
        branch("yes", "有经历：先补真实信息", "只使用真实做过的岗位和任务；不要把持证当成工作经历。", [
            template("I worked as a [job].", "我做过[真实岗位]。"),
            template("I learned to [skill]." if n == 11 else "I helped with [task].", "我学会了[真实技能]。" if n == 11 else "我协助做[真实任务]。"),
        ]),
    ]
    q(n)["note"] = "尚未知道你的真实工作经历。先选符合事实的分支；方括号没填好的模板不能播放或评分。"
q(20)["branches"] = [
    branch("food", "我愿意分享中国美食", "这是一个可选交流话题，只有你愿意介绍时才选；不要说成自己会做很多菜。", take("share_food", "explain_food")),
    branch("custom", "我想介绍别的内容", "填写自己熟悉而且愿意分享的内容。", [template("I would like to share [topic].", "我想分享[内容]。"), template("I could explain [detail].", "我可以介绍[细节]。")]),
]
q(26)["branches"] = [
    branch("no", "没有独自旅行过（真实才选）", "独自旅行和一般旅行不同；核对后再选。", take("no_solo", "preparing")),
    branch("yes", "独自旅行过：先补真实信息", "只说真实独自去过的地方和做过的准备。", [template("I traveled alone to [place].", "我独自去过[地方]。"), template("I planned [detail].", "我提前安排了[真实事项]。")]),
]
q(30)["branches"] = [
    branch("pending", "还没选好（真实才选）", "只有你确实尚未决定想参观哪些地方时才选。", take("places_pending", "check_time_budget")),
    branch("chosen", "有想去的地方：先补信息", "想去不等于已订行程；只填你真正感兴趣的地点和原因。", [template("I would like to visit [place].", "我想参观[地方]。"), template("I want to see [reason].", "我想看看[事物或景观]。"), *take("check_time_budget")]),
]
q(13)["note"] = "这是处理压力的方法，不是声称你完全不会紧张。如果压力影响安全，应立即求助。"
q(14)["note"] = "这些是假设的合作动作。被问过去的团队例子时，需要另外讲真实发生过的事。"
q(27)["note"] = "这是共同生活的方法示例，不代表你已经和外国室友同住过；如有真实限制，应如实说明。"
q(29)["note"] = "这是一种可调整的休息日计划。只保留你真正想做的活动，不编订票或已安排的行程。"

# Different wording must keep the same intent. Adjacent topics with a different
# intent are follow-ups, not alternate recordings of the same question.
VARIANTS = {
    1: ("Could you tell me about yourself?", "你能介绍一下自己吗？"),
    2: ("What do you study?", "你学什么专业？"),
    3: ("What is the name of your college?", "你的学校叫什么？"),
    4: ("What do you like doing?", "你喜欢做什么？"),
    8: ("Have you worked before?", "你以前工作过吗？"),
    15: ("Why are you interested in SWT?", "你为什么对 SWT 感兴趣？"),
    16: ("Why did you choose the U.S.?", "你为什么选择美国？"),
    17: ("What do you hope to gain from SWT?", "你希望从 SWT 中获得什么？"),
    18: ("How would you handle problems in the U.S.?", "你会如何处理在美国遇到的问题？"),
    19: ("How would you practice English during SWT?", "你会如何在 SWT 期间练英语？"),
    25: ("How would you handle a mistake at work?", "你会怎样处理工作中的错误？"),
}
for n, (en, zh) in VARIANTS.items():
    q(n)["variants"] = [{"en": en, "zh": zh}]


def follow(n, en, zh, hint, keys=()):
    q(n)["followups"].append({"en": en, "zh": zh, "hint": hint,
                              "answer": take(*keys), "assessmentMode": "free"})


def follow_card(n, target, hint):
    other = q(target)
    q(n)["followups"].append({"en": other["question"], "zh": other["questionZh"],
        "hint": hint, "answer": deepcopy(other["short"]), "relatedQuestionId": other["id"],
        "requiresConfirmation": other["requiresConfirmation"], "assessmentMode": "free"})


follow_card(1, 2, "只回答专业，不要重新背完整自介。")
follow_card(2, 3, "这次问学校，先说校名。")
follow_card(3, 2, "学校与专业是不同问题，听到 major 就说专业。")
follow(4, "Do you have a lifeguard certificate?", "你有救生员证吗？", "只说明中国证书，不能说已经获得美国执业资格。", ("certificate", "requirements"))
follow_card(5, 4, "爱好可以只说游泳，不必把空闲活动整段重复。")
follow(6, "Can you give me an example?", "你能举个例子吗？", "说一个真实行为：发生什么＋你做什么。没有核实例子，不能编故事。")
follow(7, "How do you respond to advice?", "别人给建议时你会怎么做？", "说明听建议和改进的方法。", ("listen", "try_improve"))
follow_card(8, 11, "有工作经历才谈以前学到什么；没有经历先纠正前提。")
follow_card(9, 12, "没有经历也可以回答假设场景，但用 would，不要伪装成往事。")
follow_card(10, 24, "从有没有经历转到你会怎么帮顾客。")
follow_card(11, 14, "说合作方式即可，不编过去团队故事。")
follow(12, "What if you cannot solve the problem?", "如果你解决不了这个问题呢？", "向主管求助，不私自做超出职责的承诺。", ("ask_supervisor",))
follow(13, "What would you do when you feel stressed?", "你感到有压力时会怎么做？", "先说具体动作，不用保证自己从来不紧张。", ("calm", "help"))
follow(14, "What if you disagree with a coworker?", "如果你和同事意见不同呢？", "先听，再礼貌解释，必要时求助。", ("listen_first", "explain", "help"))
follow_card(15, 17, "问收获，转到听懂别人、表达清楚等能力。")
follow(16, "What will you do after the program?", "项目结束后你会做什么？", "你的已确认安排：回中国继续读书，具体日期未定。", ("return", "studies"))
follow_card(17, 19, "从目标转到方法：怎样练，而不是再说想提高。")
follow(18, "What if you cannot understand someone?", "如果你听不懂别人呢？", "可以直接说一句请求慢速或重复的自救句。", ("slow_request", "repeat_request"))
follow(19, "What if someone speaks too fast?", "如果有人说得太快呢？", "直接练会说这句请求，不需要长篇解释。", ("slow_request",))
follow(20, "Can you give me an example?", "你能举个例子吗？", "如果选了美食，说自己熟悉的一道菜；不是所有人都必须选番茄炒蛋。")
follow(21, "Would you promise a refund?", "你会直接承诺退款吗？", "先遵守职责和规定，不能擅自承诺。", ("help_within_role", "ask_supervisor"))
follow(22, "How would you avoid being late again?", "你怎样避免再次迟到？", "给一个具体改进动作。", ("leave_earlier", "ask_schedule"))
follow(23, "What if the instructions are unclear?", "如果指示不清楚呢？", "请示范或重复，确认后再开始。", ("example_request", "no_guess"))
follow(24, "What would you say to the customer?", "你会直接对顾客说什么？", "切换成对顾客讲话，不是继续解释我会如何。", ("actual_help",))
follow(25, "What if there is a safety risk?", "如果有安全风险呢？", "先停止不安全的操作，再告诉主管。", ("unsafe", "tell_supervisor"))
follow_card(26, 18, "这是未来遇到困难的处理方式，不需要编一个旅行事故。")
follow(27, "What if your roommate is noisy?", "如果室友很吵怎么办？", "平静、礼貌地沟通共同规则。", ("calm", "room_rules", "not_argue"))
follow(28, "What if you spend too much?", "如果花钱太多怎么办？", "检查开销并削减非必需活动，别编借款承诺。", ("spending", "no_borrow"))
follow_card(29, 30, "想去的地方需要符合真实兴趣；还没决定可以说明。")
follow(30, "When will you return to China?", "你什么时候回中国？", "项目结束回国继续读书已确认，准确日期没有确定；不要编日历或机票。", ("return", "studies", "dates_pending"))

# These links were checked against the original 14-day course, not against
# the V20 overlay. They are related material, intentionally not an identical
# copy of every interview answer. Sentence numbers are one-based.
RELATIONS = {
    1: [lesson(1, 1, "姓名"), lesson(2, 3, "大一身份"), lesson(2, 2, "专业")],
    2: [lesson(2, 2, "专业")], 3: [lesson(2, 1, "学校与学生身份")],
    6: [lesson(3, 3, "愿意学习"), lesson(3, 5, "认真与安全")],
    7: [lesson(3, 3, "愿意学习")],
    12: [lesson(10, 5, "遇到问题求助")],
    13: [lesson(10, 5, "不能解决时求助")],
    14: [lesson(7, 4, "愿意和团队工作")],
    15: [lesson(4, 1, "体验文化"), lesson(4, 2, "提高英语")],
    16: [lesson(4, 1, "美国文化")],
    17: [lesson(4, 2, "英语目标")],
    18: [lesson(10, 5, "主管或赞助机构")],
    19: [lesson(8, 5, "练听力和口语"), lesson(5, 2, "请求慢一点")],
    20: [lesson(13, 4, "分享中国事物：只选自己愿意说的")],
    21: [lesson(10, 5, "联系主管")],
    23: [lesson(5, 4, "请求示范"), lesson(5, 1, "请求重复")],
    24: [lesson(5, 5, "确认自己理解正确")],
    25: [lesson(10, 5, "遇到问题联系主管")],
    27: [lesson(10, 4, "尊重文化和习惯"), lesson(13, 3, "礼貌询问")],
    29: [lesson(9, 5, "参与文化活动")],
    30: [lesson(14, 1, "结束后回国读书")],
}
for n, links in RELATIONS.items():
    q(n)["relatedLessons"] = links
for item in QUESTIONS:
    item["keywords"] = item["scaffold"][:]


SUPPLEMENTAL_QUESTIONS = []
for old_id, new_id, title in [("05", "s01", "补充：岗位与中国救生员证"), ("07", "s02", "补充：英语困难与改进"), ("22", "s03", "补充：项目结束回国读书"), ("24", "s04", "补充：参加日期尚未确定")]:
    item = deepcopy(next(x for x in previous.QUESTIONS if x["id"] == old_id))
    item.update({"id": new_id, "title": title, "sourceNumbers": [], "sourceQuestions": [],
                 "category": "个人补充", "priority": "先练" if old_id == "22" else "再练",
                 "examinerIntent": item.get("note", "按已确认个人信息回答，未知信息先确认。"),
                 "intent": item.get("note", "按已确认个人信息回答。"),
                 "scaffold": {"05": ["想做救生员", "中国证书", "核实岗位要求"], "07": ["英语仍有困难", "练短答", "已经能脱稿自介"], "22": ["项目结束回中国", "继续读书", "具体日期未定"], "24": ["尚需确认日期", "核对校历", "询问机构"]}[old_id],
                 "relatedLessons": {"05": [lesson(12, 2, "中国救生员证"), lesson(12, 4, "其他合适岗位")], "07": [lesson(8, 4, "回答英语需要时间"), lesson(8, 5, "练听说")], "22": [lesson(14, 1, "回国继续读书")], "24": []}[old_id]})
    SUPPLEMENTAL_QUESTIONS.append(item)

RESCUE_PHRASES = deepcopy(previous.RESCUE_PHRASES)
KNOWN_INTRO = deepcopy(previous.KNOWN_INTRO)
KNOWN_INTRO["note"] = "你已经能说的自我介绍继续保留；每天只快速复测，不把全部训练时间花在重新背自介。"
SOURCE_NOTES = [{"title": "你提供的 SWT 英语口测题库（参考）", "type": "user-provided-reference",
    "note": "北京中惠大洋文化交流有限公司，一页参考题库，共 30 个问题、5 类。本课程保留题号；中文释义、短答、追问和训练安排为教学编写。参考题不等于保证出现的考试原题。"}]
TRAINING_PLAN = {
    "title": "听懂题 → 组织短答 → 接追问",
    "method": "每天保底练 1 个新问题、复测 1 个旧问题。看短答、看中文要点、脱稿各回答一遍；最多修 5 个表达缺口。熟句回原句子课复习，口测主线练回答，不重做句子课。有 90 或 120 分钟时，先完成复测，再按精力选练第 2 个新问题。",
    "defaultQuestionId": "15", "recommendedQuestionIds": ["15", "16", "17", "18", "19", "08", "22", "23", "25", "s03"],
    "rotationNote": "以下每组是候选题，不是每天必须完成两道新题。先选 1 道新题，并复测昨天 1 道；另一道留到下一次，有 90 或 120 分钟且完成复测后才选练。",
    "daily60": [
        {"minutes": 10, "task": "脱稿复测昨天 1 题；自介已经会了，只快速复测，不重新背长稿。"},
        {"minutes": 10, "task": "听今天 1 个新问题，弄懂中文意思和 2—3 个回答要点。"},
        {"minutes": 15, "task": "先看短答连说一次，再只看中文要点回答一次；只有卡住的句型才回原句子课复习。"},
        {"minutes": 10, "task": "录音回听，结合识别文本最多找 5 个缺口；只修最影响理解的 1—2 处。"},
        {"minutes": 15, "task": "完成第 3 遍脱稿回答，接一个追问；再把新旧两题换顺序听题回答，保存一条脱稿录音。"},
    ],
    "successCriteria": ["知道问题在问什么", "约 3 秒内开始回答或请求重复", "2—4 个简单句切题即可，不为凑时长说废话", "只说真实情况或明确的假设做法", "能接一个追问，不会时会求助"],
    "assessmentLimit": "跟读只提供识别文字匹配分，不是音素发音诊断。随机口答允许不同说法，不按标准答案逐字打分；回看转写与自己的中文要点判断是否切题。",
    "days": [
        {"day": 1, "questions": ["15", "16"], "focus": "区分为什么参加项目与为什么选美国"},
        {"day": 2, "questions": ["17", "19"], "focus": "区分想获得什么与具体怎么练"},
        {"day": 3, "questions": ["08", "18"], "focus": "真实经历与遇到困难求助"},
        {"day": 4, "questions": ["23", "25"], "focus": "困难任务与工作犯错"},
        {"day": 5, "questions": ["21", "24"], "focus": "顾客投诉与顾客帮助"},
        {"day": 6, "questions": ["22", "14"], "focus": "迟到补救与团队合作"},
        {"day": 7, "questions": ["s03", "27"], "focus": "回国读书与室友生活；随机抽旧题"},
    ],
}


def all_sentences():
    for item in QUESTIONS + SUPPLEMENTAL_QUESTIONS:
        yield from item["short"]
        yield from item["extra"]
        for f in item["followups"]:
            yield from f.get("answer", [])
        for b in item["branches"]:
            yield from b["sentences"]
    yield from RESCUE_PHRASES
    yield from KNOWN_INTRO["sentences"]
    yield from KNOWN_INTRO["optional"]


def validate_curriculum():
    assert [item["id"] for item in QUESTIONS] == [f"{n:02d}" for n in range(1, 31)]
    seen = {}
    for line in all_sentences():
        assert line["id"] == sentence_id(line["en"])
        assert line["en"] and line["zh"] and line["grammar"] and line["chunks"]
        if "[" in line["en"]:
            assert line["needsPersonalization"] and not line["ipa"]
        else:
            assert line["ipa"] and line["pronunciation"]
        original = seen.setdefault(line["id"], line["en"])
        assert original == line["en"]
    for n, item in enumerate(QUESTIONS, 1):
        assert item["sourceNumbers"] == [n] and item["question"] == PROMPTS[n - 1][0]
        assert 2 <= len(item["scaffold"]) <= 3
        assert bool(item["short"]) == item["readyForAutoplay"]
        assert item["requiresConfirmation"] == (n in UNKNOWN_NUMBERS)
        assert (2 <= len(item["short"]) <= 4) or (not item["short"] and item["branches"])
        for line in item["short"]:
            count = len(re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", line["en"]))
            assert count <= 8 or "Guangxi College for Preschool Education" in line["en"], line["en"]
        assert item["followups"] and all(f["hint"] and f["assessmentMode"] == "free" for f in item["followups"])
        for b in item["branches"]:
            assert b["condition"] and b["confirmed"] is False
        for link in item["relatedLessons"]:
            assert 1 <= link["day"] <= 14 and 1 <= link["sentence"] <= 5
    return True


def export_payload():
    validate_curriculum()
    return {"version": VERSION, "profile": PROFILE, "questions": QUESTIONS,
            "supplementalQuestions": SUPPLEMENTAL_QUESTIONS,
            "rescuePhrases": RESCUE_PHRASES, "knownIntro": KNOWN_INTRO,
            "plan": TRAINING_PLAN, "sources": SOURCE_NOTES,
            "audioPolicy": "只播放已确认事实或明确假设的示例。未知经历和兴趣先选真实分支；方括号模板不能合成或评分。口测主线练问答，原 14 天句子课保留原模板与内容。",
            "ipaNote": "宽式美式音标只辅助读音；文字匹配分不是发音诊断。"}


validate_curriculum()
if __name__ == "__main__":
    import sys
    if "--json" in sys.argv:
        print(json.dumps(export_payload(), ensure_ascii=False, indent=2))
    else:
        print(f"{VERSION}: {len(QUESTIONS)} PDF questions + {len(SUPPLEMENTAL_QUESTIONS)} personal supplements; {len({s['id'] for s in all_sentences()})} sentence units")
