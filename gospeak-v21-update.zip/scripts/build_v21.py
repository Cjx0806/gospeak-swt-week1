"""Interview workbench release; preserve the original sentence-course shell."""
import argparse
import asyncio
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

from build_v18_listening import Speech, _clip_key, _synthesize_all, ENGLISH_VOICE
from build_v19 import word_maps, all_sentence_groups
from v21_curriculum import QUESTIONS, SUPPLEMENTAL_QUESTIONS, PROFILE, TRAINING_PLAN, SOURCE_NOTES, RESCUE_PHRASES, KNOWN_INTRO

ROOT = Path(__file__).resolve().parents[1]
TOKENS = r"U\.S\.|[A-Za-z]+(?:['’-][A-Za-z]+)*"


async def synthesize_missing(requested):
    import edge_tts
    from mutagen.mp3 import MP3
    # Bound every attempt; an empty service stream must not occupy a worker
    # for minutes. Later rounds retry only missing clips, never successful ones.
    semaphore = asyncio.Semaphore(4)
    cache=ROOT/'.audio-cache-v18'
    paths={clip:cache/f'{_clip_key(clip)}.mp3' for clip in requested}
    for attempt in range(1,7):
        pending=[clip for clip,path in paths.items() if not path.is_file() or not path.stat().st_size]
        if not pending: break
        print(f'Speech round {attempt}: {len(pending)} missing clips',flush=True)
        failures=[]
        async def one(clip):
            async with semaphore:
                output=paths[clip]
                temporary=output.with_name(f'.{output.stem}.{os.getpid()}.v21.part.mp3')
                try:
                    stream=edge_tts.Communicate(clip.text,clip.voice,rate=clip.rate,connect_timeout=5,receive_timeout=10)
                    await asyncio.wait_for(stream.save(str(temporary)),timeout=12)
                    assert MP3(temporary).info.length > 0
                    temporary.replace(output)
                except Exception as error:
                    failures.append((clip,type(error).__name__))
                finally:
                    temporary.unlink(missing_ok=True)
        await asyncio.gather(*(one(clip) for clip in pending))
        print(f'Speech round {attempt}: {len(pending)-len(failures)} complete, {len(failures)} pending',flush=True)
    failed=[clip.text for clip,path in paths.items() if not path.is_file() or not path.stat().st_size]
    if failed: raise RuntimeError('Speech still incomplete: '+repr(failed))
    return paths


def build(site, skip_audio=False):
    questions, rescue, intro = copy.deepcopy((QUESTIONS + SUPPLEMENTAL_QUESTIONS, RESCUE_PHRASES, KNOWN_INTRO))
    requested, words, joined = {}, set(), {}
    lexicon = word_maps()
    for name in ('word-extra-v20.json', 'word-extra-v21.json'):
        path = ROOT / 'assets' / name
        if path.exists(): lexicon.update(json.loads(path.read_text()))

    def audio(text, collect_words=True):
        if collect_words:
            words.update(w.lower().replace('’', "'") for w in re.findall(TOKENS, re.sub(r'\[[^]]*\]', '', text)))
        if not text.strip() or re.search(r'\[|\]|____', text): return None
        speeches=[Speech(text.replace('SWT','S W T'),voice,'-5%') for voice in (ENGLISH_VOICE,'en-US-AvaNeural')]
        def available(clip):
            key=_clip_key(clip)
            candidates=[site/f'audio/v{v}/{key}.mp3' for v in (19,20,21)]+[ROOT/'.audio-cache-v18'/f'{key}.mp3']
            return any(p.is_file() and p.stat().st_size for p in candidates)
        # Preserve existing Emma clips. New clips use Ava after the same
        # service's Emma voice repeatedly returned empty audio in this release.
        speech = next((clip for clip in speeches if available(clip)),speeches[1])
        path = next((f'./audio/v{version}/{_clip_key(speech)}.mp3' for version in (19, 20, 21)
                     if (site / f'audio/v{version}/{_clip_key(speech)}.mp3').is_file()),
                    f'./audio/v21/{_clip_key(speech)}.mp3')
        if not (site / path).is_file(): requested[speech] = site / path
        return {'normal': path, 'slow': path, 'slowRate': 0.78, 'voice':speech.voice}

    def paragraph(lines):
        if not lines or any(re.search(r'\[|\]|____',s['en']) for s in lines): return None
        if len(lines)==1: return lines[0]['audio']
        content=' '.join(s['en'] for s in lines)
        speech=Speech(content.replace('SWT','S W T'),ENGLISH_VOICE,'-5%')
        key=_clip_key(speech)
        cache=ROOT/'.audio-cache-v18'/f'{key}.mp3'
        if any((site/f'audio/v{v}/{key}.mp3').is_file() for v in (19,20,21)) or (cache.is_file() and cache.stat().st_size):
            return audio(content,False)
        sources=[s['audio']['normal'] for s in lines]
        digest=hashlib.sha256(('v21-joined-250ms:'+json.dumps(sources)).encode()).hexdigest()[:24]
        target=f'./audio/v21/joined-{digest}.mp3'
        joined[target]=sources
        return {'normal':target,'slow':target,'slowRate':.78,'construction':'US-English sentence clips with 250ms between sentences'}

    for line in rescue + intro['sentences'] + intro.get('optional', []): line['audio'] = audio(line['en'])
    intro['fullAudio'] = paragraph(intro['sentences'])
    for q in questions:
        q['questionAudio'] = audio(q['question'],False)
        for item in q.get('variants', []) + q.get('followups', []):
            item['audio'] = audio(item['en'],False)
            for line in item.get('answer', []): line['audio'] = audio(line['en'])
            item['answerAudio'] = paragraph(item.get('answer', []))
        for group in all_sentence_groups(q):
            for line in group: line['audio'] = audio(line['en'])
        for item, lines in [(q, q.get('short', []))] + [(b, b['sentences']) for b in q.get('branches', [])]:
            item['fullAudio'] = paragraph(lines)
            # V21 practices whole answers, not V20's redundant cumulative ladder.
            item['cumulativeAudio'] = []

    used, unknown = {}, []
    for word in sorted(words):
        data = dict(lexicon.get(word, {}))
        if not data.get('ipa') or not data.get('zh'): unknown.append(word)
        existing = f'./audio/words/{word}.mp3'
        data['src'] = existing if (site/existing).is_file() else audio(word.replace('swt', 'S W T').replace('u.s.', 'U S'))['normal']
        used[word] = data
    print('Missing vocabulary annotations:', ', '.join(unknown), flush=True)
    print(f'New audio clips: {len(requested)}; vocabulary: {len(used)}', flush=True)
    if not skip_audio:
        if unknown: raise ValueError('Annotate missing words before final build')
        paths = asyncio.run(synthesize_missing(requested))
        for speech, target in requested.items():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(paths[speech], target)
        import imageio_ffmpeg
        for target,sources in joined.items():
            output=site/target
            if output.is_file() and output.stat().st_size: continue
            output.parent.mkdir(parents=True,exist_ok=True)
            command=[imageio_ffmpeg.get_ffmpeg_exe(),'-hide_banner','-loglevel','error','-y']
            for src in sources: command+=['-i',str(site/src)]
            filters=[]
            for index in range(len(sources)):
                filters.append(f'[{index}:a]aresample=24000'+(',apad=pad_dur=0.25' if index<len(sources)-1 else '')+f'[a{index}]')
            filters.append(''.join(f'[a{i}]' for i in range(len(sources)))+f'concat=n={len(sources)}:v=0:a=1[out]')
            command+=['-filter_complex',';'.join(filters),'-map','[out]','-codec:a','libmp3lame','-b:a','48k',str(output)]
            subprocess.run(command,check=True)
    payload = {'version':'v21', 'profile':PROFILE, 'questions':questions, 'plan':TRAINING_PLAN,
               'rescuePhrases':rescue, 'knownIntro':intro, 'sources':SOURCE_NOTES, 'lexicon':used,
               'speechNote':'静态美式合成音：保留已有 Emma 音频；新增采用同一微软服务的 Ava。部分整段由对应单句音频连接，句间留 0.25 秒。不是教师真人录音。',
               'audioReady':all(p.is_file() and p.stat().st_size for p in requested.values()) and all((site/p).is_file() and (site/p).stat().st_size for p in joined)}
    (site/'interview-v21.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2)+'\n')
    patch_site(site)
    return payload


def patch_site(site):
    for name in ('mainline-v21.js', 'mainline-v21.css', 'recorder-v19.js', 'recorder-v19.css', 'listening-v18.js', 'listening-v18.css', 'audio-recovery.js'):
        shutil.copy2(ROOT/'assets'/name, site/'assets'/name)
    # Only advance the shell's service-worker URL: preserve all 70 lessons and their UI.
    legacy = site/'assets/index-C6MAz4Oq.js'
    legacy.write_text(re.sub(r'\./sw\.js\?v=[\d.]+', './sw.js?v=21', legacy.read_text()))
    html = (site/'index.html').read_text()
    html = re.sub(r'mainline-v(?:19|20)\.(css|js)', r'mainline-v21.\1', html)
    html = re.sub(r'GoSpeak SWT V[\d.]+', 'GoSpeak SWT V21', html)
    html = html.replace('V20 · 逐句学 → 连句说 → 随机答', 'V21 · 句子课练基础，口测主线练应答')
    html = re.sub(r'(src|href)="(\./assets/[^"?]+\.(?:js|css))(?:\?v=[^" ]+)?"', r'\1="\2?v=21"', html)
    (site/'index.html').write_text(html)
    manifest = json.loads((site/'manifest.webmanifest').read_text())
    manifest.update(name='GoSpeak SWT V21 · Sam 口测应答训练', description='原句子课保留；30道参考题的短答、减提示训练、录音复盘与随机追问。')
    (site/'manifest.webmanifest').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    worker = (site/'sw.js').read_text()
    worker = re.sub(r'interview-v(?:19|20)\.json', 'interview-v21.json', worker)
    worker = re.sub(r'mainline-v(?:19|20)\.', 'mainline-v21.', worker)
    worker = re.sub(r"u.searchParams.set\('v', '[\d.]+'\)", "u.searchParams.set('v', '21')", worker)
    digest = hashlib.sha256()
    for p in sorted([site/'index.html', site/'interview-v21.json', *list((site/'assets').glob('*.js')), *list((site/'assets').glob('*.css'))]): digest.update(p.read_bytes())
    worker = re.sub(r"const VERSION = '[^']+';", f"const VERSION = 'gospeak-independent-v21-{digest.hexdigest()[:12]}';", worker)
    (site/'sw.js').write_text(worker)
    print('V21 built: original lesson shell intact; independent interview workbench.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('site', type=Path, nargs='?', default=ROOT/'_site')
    parser.add_argument('--skip-audio', action='store_true')
    args = parser.parse_args()
    build(args.site, args.skip_audio)
