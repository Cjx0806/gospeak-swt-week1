"""Contract and teaching-content checks for the separate interview track."""
import json
from pathlib import Path
import re
import unittest

import v21_curriculum as course


class InterviewCurriculumTests(unittest.TestCase):
    def test_exact_reference_coverage(self):
        self.assertEqual(len(course.QUESTIONS), 30)
        self.assertEqual([q["id"] for q in course.QUESTIONS], [f"{n:02d}" for n in range(1, 31)])
        self.assertEqual([q["sourceNumbers"] for q in course.QUESTIONS], [[n] for n in range(1, 31)])
        self.assertEqual(len({q["category"] for q in course.QUESTIONS}), 5)
        for i, q in enumerate(course.QUESTIONS):
            self.assertEqual(q["question"], course.PROMPTS[i][0])
            self.assertEqual(q["questionZh"], course.PROMPTS[i][1])
            self.assertTrue(q["examinerIntent"])
            self.assertTrue(2 <= len(q["scaffold"]) <= 3)

    def test_simple_default_answers(self):
        for q in course.QUESTIONS + course.SUPPLEMENTAL_QUESTIONS:
            for s in q["short"]:
                words = re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", s["en"])
                self.assertTrue(len(words) <= 8 or "Guangxi College for Preschool Education" in s["en"], s["en"])
                self.assertNotIn("[", s["en"])

    def test_correct_confirmed_profile(self):
        text = json.dumps(course.PROFILE, ensure_ascii=False)
        self.assertIn("Sam", text)
        self.assertIn("physical fitness training", text)
        self.assertIn("广西幼儿师范高等专科学校", text)
        self.assertNotRegex(text.lower(), r"junxi|business|sports art")
        intro = " ".join(s["en"] for s in course.q(1)["short"])
        self.assertIn("Sam", intro)
        self.assertIn("first-year", intro)
        self.assertIn("physical fitness training", intro)
        return_card = next(q for q in course.SUPPLEMENTAL_QUESTIONS if q["id"] == "s03")
        self.assertIn("I will continue my studies.", [s["en"] for s in return_card["short"]])
        self.assertIn("My travel dates are not confirmed yet.", [s["en"] for s in return_card["short"]])

    def test_unknown_facts_never_become_default_answers(self):
        for n in course.UNKNOWN_NUMBERS:
            q = course.q(n)
            self.assertTrue(q["requiresConfirmation"])
            self.assertFalse(q["readyForAutoplay"])
            self.assertEqual(q["short"], [])
            self.assertTrue(q["branches"])
            for b in q["branches"]:
                self.assertIs(b["confirmed"], False)
                self.assertTrue(b["condition"])
        self.assertEqual(course.q(26)["branches"][0]["sentences"][0]["en"], "I have not traveled alone yet.")
        self.assertEqual(course.q(8)["branches"][0]["sentences"][0]["en"], "I have no work experience yet.")
        # Do not silently convert 'no part-time work' into 'no work of any sort'.
        self.assertNotIn("I have not worked part-time yet.", [s["en"] for s in course.q(8)["branches"][0]["sentences"]])

    def test_templates_have_no_fabricated_pronunciation(self):
        for s in course.all_sentences():
            self.assertEqual(s["id"], course.sentence_id(s["en"]))
            if "[" in s["en"]:
                self.assertTrue(s["needsPersonalization"])
                self.assertEqual(s["ipa"], "")
            else:
                self.assertTrue(s["ipa"])
                self.assertTrue(s["grammar"])

    def test_no_duplicate_identity_metadata(self):
        seen = {}
        for s in course.all_sentences():
            old = seen.setdefault(s["id"], s)
            self.assertEqual(old, s)

    def test_interview_intents_are_not_collapsed(self):
        answers = [" ".join(s["en"] for s in course.q(n)["short"]) for n in (15, 16, 17, 19)]
        self.assertEqual(len(set(answers)), 4)
        self.assertIn("It includes work and cultural exchange.", answers[0])
        self.assertIn("I am interested in American culture.", answers[1])
        self.assertIn("I want to understand people better.", answers[2])
        self.assertIn("I would try short conversations.", answers[3])
        self.assertIn("alone", course.q(26)["question"])
        self.assertIn("customer service", course.q(9)["question"])

    def test_followups_are_free_answers_not_script_matching(self):
        for q in course.QUESTIONS:
            self.assertTrue(q["followups"])
            for f in q["followups"]:
                self.assertEqual(f["assessmentMode"], "free")
                self.assertTrue(f["hint"])
                self.assertIsInstance(f["answer"], list)
        self.assertEqual(course.q(24)["followups"][0]["answer"][0]["en"], "How can I help you?")
        self.assertEqual(course.q(6)["followups"][0]["answer"], [])

    def test_original_lesson_links_match_published_course(self):
        asset = Path(__file__).resolve().parents[1] / "_site/assets/index-C6MAz4Oq.js"
        text = asset.read_text()
        # Inspect the original legacy 14x5 course at the start of the bundle,
        # not a duplicate string elsewhere in a new interview component.
        start = text.index("var e=[")
        lesson_data = text[start:]
        phrases = re.findall(r"\{en:`([^`]+)`,zh:", lesson_data)[:70]
        self.assertEqual(len(phrases), 70)
        for q in course.QUESTIONS + course.SUPPLEMENTAL_QUESTIONS:
            for link in q["relatedLessons"]:
                self.assertEqual(phrases[(link["day"] - 1) * 5 + link["sentence"] - 1], link["en"])
                self.assertIn("相关句型", link["relationship"])

    def test_plan_is_new_not_same_sentence_bank_takeover(self):
        valid_ids = {q["id"] for q in course.QUESTIONS + course.SUPPLEMENTAL_QUESTIONS}
        self.assertEqual(sum(task["minutes"] for task in course.TRAINING_PLAN["daily60"]), 60)
        for day in course.TRAINING_PLAN["days"]:
            self.assertTrue(set(day["questions"]).issubset(valid_ids))
        self.assertEqual(course.TRAINING_PLAN["defaultQuestionId"], "15")
        text = json.dumps(course.TRAINING_PLAN, ensure_ascii=False)
        self.assertNotIn("同题句子课和连答共用短句", text)
        self.assertIn("不重做句子课", text)
        self.assertIn("1 个新问题、复测 1 个旧问题", text)
        self.assertIn("看短答、看中文要点、脱稿", text)
        self.assertIn("90 或 120 分钟", text)
        self.assertTrue(course.validate_curriculum())

    def test_json_export(self):
        out = json.loads(json.dumps(course.export_payload(), ensure_ascii=False))
        self.assertEqual(out["version"], "v21")
        self.assertEqual(len(out["questions"]), 30)
        self.assertEqual(len(out["supplementalQuestions"]), 4)


if __name__ == "__main__":
    unittest.main()
