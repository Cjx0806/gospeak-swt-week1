"""Release V28 without rebuilding or changing the verified lesson/audio assets."""
import hashlib
import re
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / '_site'

def mainline(source):
    listener = "  window.addEventListener('sam-recorder-saved',recordSaved);"
    assert source.count(listener)==1
    return source.replace(listener, listener+"\n  window.addEventListener('sam-recognition-complete',recordSaved);").replace(
        '已录这一遍。先回听，修正一处卡点，再继续；次数不代表答对。','已完成这一遍。看反馈，选一个词再练。').replace(
        '已录这一遍。先回听，再继续。','已完成这一遍，可以继续。').replace(
        '听和看不计完成；至少留下一次自己的回答。','开口完成这一遍，再继续。')

def build():
    with ZipFile(ROOT/'gospeak-v27-update.zip') as archive:
        def previous(name): return archive.read('_site/'+name).decode()
        html = previous('index.html').replace('V27 ·','V28 ·')
        for name in ('recorder-v19.js','mainline-v21.js'):
            html = html.replace(name+'?v=22&design=27', name+'?v=22&design=28')
        (SITE/'index.html').write_text(html)
        (SITE/'assets/mainline-v21.js').write_text(mainline(previous('assets/mainline-v21.js')))
        worker = previous('sw.js').replace('return u.href;', """if(/(mainline-v21.js|recorder-v19.js)$/.test(u.pathname))u.searchParams.set('design','28'); return u.href;""")
    recorder = (ROOT/'assets/recorder-v28.js').read_bytes()
    (SITE/'assets/recorder-v19.js').write_bytes(recorder)
    digest = hashlib.sha256(recorder+html.encode()+(SITE/'assets/mainline-v21.js').read_bytes()).hexdigest()[:12]
    (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+digest,worker))
    files = ['_site/index.html','_site/sw.js','_site/assets/mainline-v21.js','_site/assets/recorder-v19.js',
             'assets/recorder-v28.js','scripts/build_v28.py','scripts/verify_v22.py','scripts/test_practice_v26.cjs']
    with ZipFile(ROOT/'gospeak-v28-update.zip','w',ZIP_DEFLATED) as archive:
        for name in files: archive.write(ROOT/name,name)
    workflow = ROOT/'.github/workflows/pages.yml'
    config = workflow.read_text().replace('Deploy 快乐出村计划 V27','Deploy 快乐出村计划 V28')
    if 'unzip -q -o gospeak-v28-update.zip' not in config:
        config = config.replace('unzip -q -o gospeak-v27-update.zip -d .','unzip -q -o gospeak-v27-update.zip -d .\n          unzip -q -o gospeak-v28-update.zip -d .')
    workflow.write_text(config)

if __name__=='__main__': build()
