"""V23 presentation-only release; preserves V22 curriculum and audio bindings."""
from pathlib import Path
import shutil
import colorsys, hashlib, json, re, zipfile
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'_site'
css=(ROOT/'assets/polish-v22.css').read_text()
def neutral(match):
    h=match.group()[1:]
    if len(h)!=6:return match.group()
    r,g,b=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    hue,light,sat=colorsys.rgb_to_hls(r,g,b)
    if .18<hue<.48:
        if light>.82:return '#f3f4f6'
        if light>.63:return '#ccd2dd'
        if light>.4:return '#667085'
        return '#175cff' if sat>.25 else '#172033'
    return match.group()
css=re.sub(r'#[0-9a-fA-F]{6}\b',neutral,css)
css+='''
/* V23 · Focused training studio */
:root { --ink:#141821; --muted:#596273; --cream:#f3f4f6; --paper:#fff; --green:#175cff; --orange:#175cff; --lime:#edf2ff; --kp-line:#dce0e7; --kp-soft:#f4f5f8; --kp-radius:6px; }
html, body { background:#f3f4f6; }
.topbar { max-width:none; background:#141821; color:#fff; padding-inline:max(24px,calc((100% - 1080px)/2)); border-bottom:0; gap:14px 24px; }
.brand b,.brand i { color:#fff; font-weight:750; letter-spacing:.02em; }
.brand > span { background:#175cff; border-radius:4px; }
.install-button { background:#262d3a; color:#e9edf6; border-color:#424a59; border-radius:4px; }
.app-nav { gap:8px; padding-bottom:0; scrollbar-color:#677182 #141821; }
.app-nav button { color:#bbc3d2; background:transparent; border-radius:0; border-bottom:3px solid transparent; min-height:48px; padding:10px 14px; }
.app-nav button.active { background:transparent; color:#fff; border-bottom-color:#5087ff; }
.app-nav button:hover { color:#fff; background:#252e40; }
#sam-audio-recovery { max-width:none!important; background:#e9ecf2!important; padding:5px max(24px,calc((100% - 1080px)/2))!important; }
#sam-audio-recovery button { color:#384354!important; }
.sam21-app { border:0; border-radius:0; padding:32px; background:#fff; box-shadow:0 1px 0 #dce0e7; }
.sam21-header { border-bottom:3px solid #141821; padding-bottom:22px; }
.sam21-header h1 { font-size:40px; font-weight:800; line-height:1.22; letter-spacing:-.035em; }
.sam21-header h1::before { content:'听懂 · 开口 · 回答'; display:block; color:#175cff; font-size:13px; font-weight:700; letter-spacing:.12em; margin-bottom:12px; }
.sam21-subtitle { margin-bottom:0; }
.sam21-app button { border-radius:5px; min-height:48px; font-weight:650; }
.sam21-app button.sam21-primary { background:#175cff!important; color:#fff!important; border-color:#175cff!important; box-shadow:none; }
.sam21-modes { padding:0; border-bottom:1px solid #dce0e7; gap:0; }
.sam21-modes button { border:0; border-bottom:3px solid transparent; background:#fff; color:#596273; border-radius:0; }
.sam21-modes button[aria-pressed="true"] { background:#fff; color:#175cff; border-bottom-color:#175cff; }
.sam21-question { background:#f4f5f8; border-radius:0; border-left:4px solid #175cff; padding:24px; }
.sam21-question h2,.sam21-question h2:not([lang]) { font-size:30px; font-weight:750; line-height:1.38; }
.sam21-question-tools button { background:#fff; border-color:#d3dae6; color:#175cff; }
.sam21-question-tools button[aria-pressed="true"] { background:#175cff; color:#fff; }
.sam22-post-intro { padding:18px 0; }
.sam22-post-intro-actions { gap:10px; }
.sam22-listening-first { padding-top:8px; }
.sam22-listening-first h3 { font-size:21px; font-weight:750; }
.sam22-meaning-options button { border-radius:5px; border-color:#dce0e7; background:#fff; color:#172033; }
.sam22-meaning-options button[aria-pressed="true"] { background:#edf2ff; color:#1747be; border-color:#175cff; }
.sam21-rounds button[aria-pressed="true"] { background:#175cff; color:#fff; }
.sam21-progress,.sam21-note,.sam21-related,.sam-recorder__score,.feedback { background:#f3f5f9; }
.sam21-related,.sam21-reference,.sam21-output,.sam-recorder { border-radius:5px; }
.lesson { border:0; border-radius:0; padding:32px; box-shadow:0 1px 0 #dce0e7; }
.lesson-head { padding-bottom:20px; border-bottom:3px solid #141821; }
.lesson-head h2 { font-size:30px; font-weight:800; }
.sentence { background:#f4f5f8; border-radius:0; border-left:4px solid #175cff; padding:24px; }
.sentence h3 { font-size:30px; font-weight:750; }
.sentence button { background:#175cff; color:#fff; border-radius:5px; }
.language,.practice,.word { border-radius:5px; }
.word.playing { background:#edf2ff; }
.grammar-grid div { background:#f4f5f8; border-left-color:#9caac4; }
.practice button,.sam-recorder button.sam-recorder__start { background:#175cff; color:#fff; }
.days .active { background:#141821; border-color:#141821; }
.days .active b { background:#175cff; }
@media(min-width:1000px) { .coach-layout.sam21-coach-host,.layout,.days { max-width:1020px; } .sam21-app { padding:40px 48px; } .sam22-post-intro-actions button { min-width:180px; } }
@media(max-width:600px) { .topbar { padding:16px 16px 0; } .brand b { font-size:19px; } .app-nav button { padding:12px 10px; } .coach-layout.sam21-coach-host,.layout { padding:16px 12px 72px; } .sam21-app,.lesson { padding:22px 16px; } .sam21-header h1 { font-size:33px; } .sam21-question { padding:20px 16px; } .sam21-question h2,.sam21-question h2:not([lang]),.sentence h3 { font-size:26px; } .sentence { padding:18px 14px; } .sam22-post-intro-actions button { flex:1 1 140px; } .sam21-question-tools { display:flex; flex-wrap:wrap; } .sam21-question-tools button { flex:1 1 120px; } }
@media(prefers-reduced-motion:reduce) { *,*::before,*::after { animation:none!important; transition:none!important; scroll-behavior:auto!important; } }
'''
(ROOT/'assets/design-v23.css').write_text(css)
(SITE/'assets/design-v23.css').write_text(css)
html=(SITE/'index.html').read_text()
if 'design-v23.css' not in html:html=html.replace('</head>','<link rel="stylesheet" href="./assets/design-v23.css?v=22">\n</head>')
html=html.replace('#173d2e','#141821').replace('V22 · 三周句子课','V23 · 快乐出村计划')
(SITE/'index.html').write_text(html)
sw=(SITE/'sw.js').read_text()
if 'design-v23.css' not in sw:sw=sw.replace("'assets/polish-v22.css'","'assets/polish-v22.css', 'assets/design-v23.css'")
sw=re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+hashlib.sha256(css.encode()).hexdigest()[:12],sw)
(SITE/'sw.js').write_text(sw)
manifest=json.loads((SITE/'manifest.webmanifest').read_text());manifest.update(theme_color='#141821',background_color='#f3f4f6')
for icon in manifest['icons']:icon['src']=icon['src'].replace('v=22','v=23')
(SITE/'manifest.webmanifest').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
font='/System/Library/Fonts/STHeiti Medium.ttc'
for size,name in ((192,'icon-192.png'),(512,'icon-512.png'),(180,'apple-touch-icon.png')):
    im=Image.new('RGB',(size,size),'#141821');d=ImageDraw.Draw(im)
    d.rectangle((size*.13,size*.76,size*.87,size*.84),fill='#175cff')
    d.text((size/2,size*.43),'出',font=ImageFont.truetype(font,int(size*.52)),fill='white',anchor='mm');im.save(SITE/name)
paths=[SITE/p for p in ('index.html','sw.js','manifest.webmanifest','assets/design-v23.css','icon-192.png','icon-512.png','apple-touch-icon.png')]
paths.extend([ROOT/'scripts/build_v23.py',ROOT/'assets/design-v23.css'])
cards_source=ROOT.parents[1]/'outputs/swt-cards'
carddir=SITE/'study-cards';carddir.mkdir(exist_ok=True)
for p in list(cards_source.glob('Sam-SWT-??.png'))+list(cards_source.glob('*.zip')):
    shutil.copy2(p,carddir/p.name);paths.append(carddir/p.name)
gallery='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sam 的 8 张口测学习卡｜快乐出村计划</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f4f6;color:#141821;font:17px/1.7 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}header,main{max-width:1400px;margin:auto;padding:24px}h1{font-size:clamp(27px,4vw,44px);line-height:1.3}a{color:#175cff}nav{display:flex;gap:24px;flex-wrap:wrap}.cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}img{width:100%;display:block}figure{margin:0}figcaption{padding:8px} @media(max-width:650px){.cards{grid-template-columns:1fr}header,main{padding:16px}}</style><header><a href="./?v=23">← 返回快乐出村计划</a><h1>先听懂，再回答。</h1><p>8 类基础口测题，每句英文配中文。点开图片放大；长按图片可保存。先练题意，再遮住答案开口。</p><nav><a href="./study-cards/Sam-SWT-8张学习卡.zip" download>下载全部 8 张高清学习卡</a></nav></header><main class="cards">'''
titles=['学校与专业','为什么参加 SWT','为什么选择美国','意向救生员岗位','游泳能力','听不懂时怎么办','父母是否支持','回国继续读书']
for n,title in enumerate(titles,1):
    gallery+=f'<figure><a href="./study-cards/Sam-SWT-{n:02}.png"><img src="./study-cards/Sam-SWT-{n:02}.png" alt="第{n}张：{title}，英语问法、中文理解与Sam的简单回答" loading="lazy"></a><figcaption>{n:02} · {title}</figcaption></figure>'
gallery+='</main></html>'
(SITE/'cards.html').write_text(gallery);paths.append(SITE/'cards.html')
with zipfile.ZipFile(ROOT/'gospeak-v23-update.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(ROOT))
workflow=ROOT/'.github/workflows/pages.yml';text=workflow.read_text().replace('Deploy 快乐出村计划 V22','Deploy 快乐出村计划 V23')
if 'unzip -q -o gospeak-v23-update.zip' not in text:text=text.replace('unzip -q -o gospeak-v22-update.zip -d .','unzip -q -o gospeak-v22-update.zip -d .\n          unzip -q -o gospeak-v23-update.zip -d .')
workflow.write_text(text)
print('V23 visual release built; V22 learning engine and recording logic unchanged.')
