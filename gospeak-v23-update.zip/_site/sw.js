const VERSION = 'gospeak-independent-v22-f03f51c2627d';
const BASE = self.registration.scope;
const phraseAudio = Array.from({ length: 70 }, (_, index) => `audio/p${String(index + 1).padStart(2, '0')}.mp3`);
const coachAudio = Array.from({ length: 14 }, (_, index) => `audio/coach/q${String(index + 1).padStart(2, '0')}.mp3`);
const shadowAudio = Array.from({ length: 14 }, (_, index) => {
  const day = String(index + 1).padStart(2, '0');
  return [`audio/shadow/d${day}-full.mp3`, ...Array.from({ length: 4 }, (_, lineIndex) => `audio/shadow/d${day}-l${lineIndex + 1}.mp3`)];
}).flat();
const core = ['./', 'manifest.webmanifest', 'swt-daily-reminders.ics', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png'].map((path) => new URL(path, BASE).href);

// V18_PLAYER_CORE
core.push(...['listening-v18.json', 'assets/listening-v18.js', 'assets/listening-v18.css'].map((path) => new URL(path, BASE).href));

// V19_CORE
core.push(...["interview-v21.json", "assets/mainline-v21.js", "assets/mainline-v21.css", "assets/recorder-v19.js", "assets/recorder-v19.css"].map(path => new URL(path, BASE).href));
core.push(...['assets/audio-recovery.js', 'assets/polish-v22.css', 'assets/design-v23.css', 'lesson-audio-v22.json'].map(path => new URL(path, BASE).href));
// V19_VERSIONED_CACHE
core.splice(0, core.length, ...core.map(href => { const u = new URL(href); if (u.href !== BASE) u.searchParams.set('v', '22'); return u.href; }));
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(VERSION).then((cache) => cache.addAll(core)));
  self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== VERSION && key.startsWith('gospeak-independent-')).map((key) => caches.delete(key)))));
  self.clients.claim();
});
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  // V18_RANGE_BYPASS
  const requestUrl = new URL(event.request.url);
  if (event.request.headers.has('range') || requestUrl.pathname.includes('/audio/')) {
    // Do not call respondWith: let the browser perform a native network/Range request.
    return;
  }
  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).then((response) => {
      if (response.ok) caches.open(VERSION).then((cache) => cache.put(new URL('./', BASE).href, response.clone()));
      return response;
    }).catch(() => caches.match(new URL('./', BASE).href)));
    return;
  }
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {
    if (response.ok) caches.open(VERSION).then((cache) => cache.put(event.request, response.clone()));
    return response;
  }).catch(() => undefined)));
});
