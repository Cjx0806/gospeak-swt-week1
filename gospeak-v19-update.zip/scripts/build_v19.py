#!/usr/bin/env python3
"""Build Sam's fact-checked oral interview UI and static speech assets.

The learner explicitly approved sending these course texts to Microsoft Edge
TTS on 2026-10-10. No photos, learner recordings or identity documents are sent.
The deployed application only downloads static audio; it contains no TTS key.
"""
import argparse
import asyncio
import copy
import hashlib
import json
from pathlib import Path
import re
import shutil

from build_v18_listening import Speech, _clip_key, _synthesize_all, ENGLISH_VOICE
from v19_curriculum import QUESTIONS, PROFILE, TRAINING_PLAN, SOURCE_NOTES, RESCUE_PHRASES, KNOWN_INTRO

ROOT = Path(__file__).resolve().parents[1]


def word_maps():
    dictionary = ROOT / 'assets/word-base-v19.json'
    if dictionary.is_file():
        result = json.loads(dictionary.read_text())
    else:
        source = (ROOT.parents[1] / 'gospeak-mainland-week1/src/language-data.ts').read_text()
        result = {}
        for const, field in [('wordMeanings', 'zh'), ('wordPhonetics', 'ipa')]:
            body = source.split('const ' + const + ':', 1)[1].split('};', 1)[0]
            for quoted, bare, value in re.findall(r"(?:'([^']+)'|\b([a-z][a-zA-Z]*)):\s*'([^']*)'", body):
                result.setdefault(quoted or bare, {})[field] = value
        result.pop('junxi', None)
        dictionary.write_text(json.dumps(result, ensure_ascii=False, indent=2))
    result.update({
        'sam': {'ipa': 'sæm', 'zh': 'Sam（英文名）'},
        'u.s.': {'ipa': 'ˌjuː ˈes', 'zh': '美国（United States 的缩写）'},
        'guangxi': {'ipa': 'ɡwɑːŋˈʃiː', 'zh': '广西（中文专名近似提示）'},
        'preschool': {'ipa': 'ˈpriːskuːl', 'zh': '学前教育的'},
        'education': {'ipa': 'ˌedʒəˈkeɪʃən', 'zh': '教育'},
        'physical': {'ipa': 'ˈfɪzɪkəl', 'zh': '身体的；体能的'},
        'fitness': {'ipa': 'ˈfɪtnəs', 'zh': '体能；健康'},
        'first-year': {'ipa': 'ˈfɝːst jɪr', 'zh': '大一的'},
        'confirmed': {'ipa': 'kənˈfɝːmd', 'zh': '已确认的'},
        'exact': {'ipa': 'ɪɡˈzækt', 'zh': '确切的'},
        'dates': {'ipa': 'deɪts', 'zh': '日期'},
        'passport': {'ipa': 'ˈpæspɔːrt', 'zh': '护照'},
        'part-time': {'ipa': 'ˌpɑːrt ˈtaɪm', 'zh': '兼职的'},
        'swim': {'ipa': 'swɪm', 'zh': '游泳'},
        'meters': {'ipa': 'ˈmiːtərz', 'zh': '米'},
        'hobbies': {'ipa': 'ˈhɑːbiz', 'zh': '爱好'},
        'hobby': {'ipa': 'ˈhɑːbi', 'zh': '爱好'},
        'dish': {'ipa': 'dɪʃ', 'zh': '一道菜'},
        'recommend': {'ipa': 'ˌrekəˈmend', 'zh': '推荐'},
        'dumplings': {'ipa': 'ˈdʌmplɪŋz', 'zh': '饺子'},
        'vegetables': {'ipa': 'ˈvedʒtəbəlz', 'zh': '蔬菜'},
        'meat': {'ipa': 'miːt', 'zh': '肉'},
        'nineteen': {'ipa': 'ˌnaɪnˈtiːn', 'zh': '十九'},
        'years': {'ipa': 'jɪrz', 'zh': '年；岁'},
        'old': {'ipa': 'oʊld', 'zh': '岁的；年老的'},
    })
    result.pop('junxi', None)
    try:
        from v19_lexicon import EXTRA_WORDS
        result.update(EXTRA_WORDS)
    except ImportError:
        pass
    return result


def all_sentence_groups(q):
    yield q.get('short', [])
    yield q.get('extra', [])
    for b in q.get('branches', []):
        yield b.get('sentences', [])


def prepare(site, skip_audio):
    questions = copy.deepcopy(QUESTIONS)
    rescue = copy.deepcopy(RESCUE_PHRASES)
    known_intro = copy.deepcopy(KNOWN_INTRO)
    requested = {}

    def audio(text):
        text = text.strip()
        if not text or re.search(r'\[|\]|____', text):
            return None  # never synthesize unresolved personal placeholders
        speech = Speech(text.replace('SWT', 'S W T'), ENGLISH_VOICE, '-5%')
        path = f'./audio/v19/{_clip_key(speech)}.mp3'
        requested[speech] = site / path
        pair = {'normal': path, 'slow': path, 'slowRate': 0.78}
        slow = Speech(speech.text, ENGLISH_VOICE, '-22%')
        if (ROOT / '.audio-cache-v18' / f'{_clip_key(slow)}.mp3').is_file():
            slow_path = f'./audio/v19/{_clip_key(slow)}.mp3'
            requested[slow] = site / slow_path
            pair.update(slow=slow_path, slowRate=1)
        return pair

    lexicon = word_maps()
    words = set()
    for line in rescue + known_intro['sentences'] + known_intro.get('optional', []):
        line['audio'] = audio(line['en'])
        words.update(w.lower() for w in re.findall(r"[A-Za-z]+(?:-[A-Za-z]+)?", line['en']))
    known_intro['fullAudio'] = audio(' '.join(s['en'] for s in known_intro['sentences']))
    for q in questions:
        q['questionAudio'] = audio(q['question'])
        for item in q.get('variants', []) + q.get('followups', []):
            item['audio'] = audio(item['en'])
            for line in item.get('answer', []):
                line['audio'] = audio(line['en'])
                words.update(w.lower() for w in re.findall(r"[A-Za-z]+(?:-[A-Za-z]+)?", line['en']))
        for group in all_sentence_groups(q):
            for line in group:
                line['audio'] = audio(line['en'])
                without_slots = re.sub(r'\[[^]]*\]', '', line['en'])
                words.update(w.lower() for w in re.findall(r"U\.S\.|[A-Za-z]+(?:['’-][A-Za-z]+)*", without_slots))
        short = q.get('short', [])
        q['fullAudio'] = audio(' '.join(s['en'] for s in short))
        q['expandedAudio'] = audio(' '.join(s['en'] for s in short + q.get('extra', []))) if short else None
        q['cumulativeAudio'] = [audio(' '.join(s['en'] for s in short[:i])) for i in range(1, len(short) + 1)]
        for b in q.get('branches', []):
            b['fullAudio'] = audio(' '.join(s['en'] for s in b.get('sentences', [])))
            b['cumulativeAudio'] = [audio(' '.join(s['en'] for s in b['sentences'][:i])) for i in range(1, len(b.get('sentences', [])) + 1)]

    # Preserve existing sentence-course pronunciation while changing the name.
    legacy = {
        'audio/p01.mp3': 'My name is Sam.',
        'audio/shadow/d01-l1.mp3': 'Hello, my name is Sam.',
        'audio/shadow/d01-full.mp3': 'Hello, my name is Sam. I am a first-year student at Guangxi College for Preschool Education. I am responsible and willing to learn. I have a Chinese lifeguard certificate.',
        'audio/shadow/d14-l1.mp3': 'Hello, my name is Sam. I am a first-year student at Guangxi College for Preschool Education.',
        'audio/shadow/d14-full.mp3': 'Hello, my name is Sam. I am a first-year student at Guangxi College for Preschool Education. I joined SWT to improve my English and experience American culture. I am responsible, hardworking, and willing to learn. I am ready to work with a team and handle new challenges.',
        'audio/words/sam.mp3': 'Sam',
    }
    legacy_audio = {name: audio(text) for name, text in legacy.items()}
    unknown = []
    used_lexicon = {}
    for word in sorted(words):
        data = dict(lexicon.get(word, {}))
        if not data.get('zh') or not data.get('ipa'):
            unknown.append(word)
        path = f'./audio/words/{word}.mp3'
        if not (site / path).is_file() or word == 'sam':
            speech = Speech(word.replace('swt', 'S W T').replace('u.s.', 'U S'), ENGLISH_VOICE, '-5%')
            path = f'./audio/v19/{_clip_key(speech)}.mp3'
            requested[speech] = site / path
        data['src'] = path
        used_lexicon[word] = data

    print('Vocabulary requiring additional annotations:', ', '.join(unknown), flush=True)
    if not skip_audio:
        cache = ROOT / '.audio-cache-v18'
        cache.mkdir(exist_ok=True)
        paths = asyncio.run(_synthesize_all(requested, cache, 10))
        for speech, target in requested.items():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(paths[speech], target)
        for filename, pair in legacy_audio.items():
            shutil.copy2(site / pair['normal'], site / filename)
    else:
        missing = [str(path) for path in requested.values() if not path.is_file()]
        if missing:
            print(f'UI-only build: {len(missing)} unavailable audio files. Do not publish.', flush=True)
    payload = {'version': 'v19', 'profile': PROFILE, 'questions': questions, 'plan': TRAINING_PLAN, 'rescuePhrases': rescue, 'knownIntro': known_intro,
               'sources': SOURCE_NOTES, 'lexicon': used_lexicon,
               'audioReady': all(path.is_file() for path in requested.values())}
    (site / 'interview-v19.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    patch_site(site)
    return payload


def patch_site(site):
    replacements = {
        'Chen Junxi': 'Sam', '陈俊熙': 'Sam', 'Junxi': 'Sam', 'junxi': 'sam',
        '俊熙': 'Sam', 'JUN-xi': 'SAM', 'ˈdʒuːn ʃiː': 'sæm', 'dʒuːn ʃiː': 'sæm',
        'Me=e=>new URL(e,document.baseURI).href': 'Me=e=>{let u=new URL(e,document.baseURI);if(u.pathname.includes(`/audio/`))u.searchParams.set(`v`,`19.1`);return u.href}',
        'navigator.serviceWorker.register(`./sw.js`)': 'navigator.serviceWorker.register(`./sw.js?v=19.1`,{updateViaCache:`none`})',
        '30天口测': '新概念英语第一册',
        'NEW CONCEPT × SWT ORAL SPRINT': 'NEW CONCEPT ENGLISH · BOOK 1',
        '30天，不是刷完视频。<br>是把英语说出来。': '新概念英语第一册<br>视频讲解与基础补充',
        '24天完成《新概念英语一册》首轮，4天回炉，2天SWT模考。每天90—120分钟；极忙时保住60分钟核心训练。': '配合哔哩哔哩分集学习课文、单词和语法。这是基础补充，不是本月口测主线；考前优先完成 SWT 问答录音，再按表达缺口选学 10—15 分钟。原有30天进度保留，不要求现在赶完。',
        '30天新概念与SWT训练计划': '新概念英语第一册学习目录',
        '新概念只是材料，口测回答才是结果': '补充迁移练习（选做）',
        '24天扫完144课框架，最后6天把最常用句型迁移到SWT。一个月后继续滚动复习，而不是宣布“全册毕业”。': '先用已学课文补足当日表达缺口；口测前不以刷完144课为目标。考后再按基础学习进度继续复习。',
        '已按你的真实资料填写；姓名拼写如与护照不同，以护照为准。每句话说完短暂停顿。': 'Sam 是你确认的英文称呼；正式报名和签证资料仍使用证件姓名。每句话说完短暂停顿。',
    }
    for path in (site / 'assets').glob('index*.js'):
        text = path.read_text()
        for old, new in replacements.items():
            text = text.replace(old, new)
        path.write_text(text)

    page = site / 'index.html'
    html = page.read_text()
    html = re.sub(r'\s*<script src="\./mainline-v17-profile.js"></script>', '', html)
    html = re.sub(r'\s*<link rel="stylesheet" href="\./mainline-v17-profile.css">', '', html)
    html = html.replace('GoSpeak SWT V18', 'GoSpeak SWT V19')
    html = html.replace('30天口测冲刺', 'Sam 机构口测随机问答与新概念英语第一册')
    for name in ['recorder-v19', 'mainline-v19']:
        for ext in ['js', 'css']:
            src = ROOT / 'assets' / f'{name}.{ext}'
            if src.is_file():
                shutil.copy2(src, site / 'assets' / src.name)
        if f'./assets/{name}.css' not in html:
            html = html.replace('</head>', f'<link rel="stylesheet" href="./assets/{name}.css">\n</head>')
        if f'./assets/{name}.js' not in html:
            html = html.replace('</body>', f'<script src="./assets/{name}.js" defer></script>\n</body>')
    # Existing installs use cache-first assets. A new page alone does not
    # invalidate them, so version active references before the first render.
    html = re.sub(r'(src|href)="(\./assets/[^"?]+\.(?:js|css))(?:\?v=[^" ]+)?"', r'\1="\2?v=19.1"', html)
    page.write_text(html)
    manifest_path = site / 'manifest.webmanifest'
    manifest = json.loads(manifest_path.read_text())
    manifest.update(name='GoSpeak SWT V19 · Sam 机构口测', description='随机听题、分层回答、连续中英字幕听练与本地录音。')
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    for path in [site / 'listening-v18.json', site / 'audio/v18/manifest.json']:
        payload = json.loads(path.read_text())
        payload['version'] = 'v19'
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    # Hash every active text asset so a preexisting iPad gets the new course,
    # player and curriculum together. Audio remains native Range/network.
    hashed = hashlib.sha256()
    for p in sorted([page, site / 'interview-v19.json', site / 'listening-v18.json', *list((site / 'assets').glob('*.js')), *list((site / 'assets').glob('*.css'))]):
        hashed.update(p.read_bytes())
    worker = (site / 'sw.js').read_text()
    worker = re.sub(r"const VERSION = '[^']+';", f"const VERSION = 'gospeak-independent-v19-{hashed.hexdigest()[:12]}';", worker)
    worker = worker.replace("requestUrl.pathname.includes('/audio/v18/')", "requestUrl.pathname.includes('/audio/')")
    marker = '// V19_CORE'
    worker = re.sub(r'// V19_CORE\ncore.push\(.*?\);\n', '', worker)
    extra = ['interview-v19.json', 'assets/mainline-v19.js', 'assets/mainline-v19.css', 'assets/recorder-v19.js', 'assets/recorder-v19.css']
    worker = worker.replace("self.addEventListener('install'", marker + '\ncore.push(...' + json.dumps(extra) + '.map(path => new URL(path, BASE).href));\n' + "self.addEventListener('install'", 1)
    cache_marker = '// V19_VERSIONED_CACHE'
    if cache_marker not in worker:
        worker = worker.replace("self.addEventListener('install'", cache_marker + "\ncore.splice(0, core.length, ...core.map(href => { const u = new URL(href); if (u.href !== BASE) u.searchParams.set('v', '19.1'); return u.href; }));\nself.addEventListener('install'", 1)
    (site / 'sw.js').write_text(worker)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('site', type=Path)
    parser.add_argument('--skip-audio', action='store_true')
    args = parser.parse_args()
    prepare(args.site, args.skip_audio)
