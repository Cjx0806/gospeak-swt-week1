/* Offline legacy-player/recovery integration. Never requests audio or a mic. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const listeners = new Map(), timers = new Map(), activeResources = new Set(), events = [];
let timerID = 0, created = 0, maximumResources = 0, renders = 0, fetches = 0;
let behavior = () => Promise.resolve(), recording = false, recoveryClick, synthesisCancels = 0;
const notice = { textContent: '' };
class FakeAudio {
  constructor(src) {
    created++; this.src = src; this.paused = true; this.currentTime = 0; this.readyState = 0;
    this.playCalls = 0; this.loadCalls = 0;
    activeResources.add(this); maximumResources = Math.max(maximumResources, activeResources.size);
  }
  play() { this.playCalls++; this.paused = false; return behavior(); }
  pause() { this.paused = true; }
  removeAttribute(name) { if (name === 'src') { this.src = ''; activeResources.delete(this); } }
  load() { this.loadCalls++; }
}
const media = [{ paused: false, pause() { this.paused = true; } }];
const bar = {
  querySelector(selector) {
    return selector === '[role="status"]' ? notice : { addEventListener(name, fn) { assert.equal(name, 'click'); recoveryClick = fn; } };
  }
};
const window = {
  __samMainlineV19: { isRecording() { return recording; } },
  speechSynthesis: { cancel() { synthesisCancels++; } },
  addEventListener(name, fn) { (listeners.get(name) || (listeners.set(name, []), listeners.get(name))).push(fn); },
  dispatchEvent(event) { events.push(event); for (const fn of listeners.get(event.type) || []) fn(event); }
};
const sandbox = {
  A: null, D: '', E: '', window, Audio: FakeAudio, Promise,
  Me(value) { return 'https://example.test/' + value; }, $() { renders++; },
  document: { getElementById() { return bar; }, querySelectorAll() { return media; } },
  CustomEvent: class { constructor(type, options) { this.type = type; this.detail = options.detail; } },
  setTimeout(fn) { const id = ++timerID; timers.set(id, fn); return id; }, clearTimeout(id) { timers.delete(id); },
  fetch() { fetches++; return Promise.resolve(); }
};
const base = path.join(__dirname, '../assets');
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(base, 'legacy-audio-stability.js'), 'utf8'), sandbox);
vm.runInContext(fs.readFileSync(path.join(base, 'audio-recovery.js'), 'utf8'), sandbox);
function play(key = 'word') { sandbox.J(key + '.mp3', 1, key); }
function flushTimer(id) { const fn = timers.get(id); assert(fn, 'timer is registered'); timers.delete(id); fn(); }
async function settle() { await Promise.resolve(); await Promise.resolve(); await Promise.resolve(); }

(async function () {
  for (let i = 0; i < 200; i++) play('word-' + i);
  await settle();
  assert.equal(maximumResources, 1, 'rapid taps never leave more than one active source');
  assert.equal(activeResources.size, 1); assert.equal(timers.size, 1);
  assert.equal(sandbox.D, 'word-199'); assert.equal(sandbox.A.loop, true);
  const last = sandbox.A;
  sandbox.q(false);
  assert.equal(activeResources.size, 0); assert.equal(timers.size, 0);
  assert.equal(last.src, ''); assert.equal(last.loadCalls, 1, 'stopping unloads the media resource');
  assert.equal(last.onerror, null); assert.equal(last.onwaiting, null);
  const beforePrefetch = created;
  sandbox.Pe(Array.from({ length: 300 }, (_, i) => 'prefetch-' + i + '.mp3'));
  assert.equal(created, beforePrefetch, 'the former day warmer allocates no audio players');
  assert.equal(fetches, 0, 'the former day warmer issues no eager fetch storm');

  behavior = () => Promise.reject(new Error('NotAllowedError'));
  play('retry'); await settle();
  assert.equal(sandbox.A, null); assert.equal(sandbox.D, '');
  assert(notice.textContent.includes('再点一次'));
  behavior = () => Promise.resolve();
  const beforeRetry = created;
  play('retry'); assert.equal(created, beforeRetry + 1, 'first tap after rejection starts a real retry');
  assert.equal(sandbox.D, 'retry');
  sandbox.A.onplaying(); assert.equal(timers.size, 0, 'playing clears the initial load watchdog');
  sandbox.q(false);

  let rejectOld;
  behavior = () => new Promise((_, reject) => { rejectOld = reject; });
  play('old'); const old = sandbox.A, oldError = old.onerror;
  behavior = () => Promise.resolve(); play('new'); const current = sandbox.A;
  rejectOld(new Error('aborted')); oldError(); await settle();
  assert.equal(sandbox.A, current, 'old async failure cannot silence a newer tap');
  assert.equal(sandbox.D, 'new'); assert.equal(activeResources.size, 1);
  assert.equal(old.src, '');

  window.dispatchEvent({ type: 'gospeak-playback-request', detail: { owner: 'legacy-lesson' } });
  assert.equal(sandbox.A, current, 'a player does not stop its own request');
  window.dispatchEvent({ type: 'gospeak-playback-request', detail: { owner: 'mainline-v19' } });
  assert.equal(sandbox.A, null, 'mainline playback stops the detached legacy player');
  assert.equal(activeResources.size, 0); assert.equal(timers.size, 0);

  behavior = () => new Promise(() => {});
  play('hung'); flushTimer(sandbox.samLegacyTimer);
  assert.equal(sandbox.A, null, 'a never-settling play request is released after its deadline');
  assert(notice.textContent.includes('恢复声音'));
  behavior = () => Promise.resolve(); play('recover');
  recoveryClick();
  assert.equal(sandbox.A, null, 'recovery event stops the detached legacy Audio');
  assert.equal(activeResources.size, 0); assert.equal(timers.size, 0);
  assert.equal(media[0].paused, true); assert.equal(synthesisCancels, 1);
  assert(notice.textContent.includes('学习记录和已保存录音不变'));
  assert(events.some(event => event.type === 'gospeak-playback-request' && event.detail.owner === 'recovery'));

  play('before-recording'); window.dispatchEvent({ type: 'sam-recorder-start' });
  assert.equal(sandbox.A, null, 'recording starts with no sample playing');
  recording = true; const beforeBlocked = created; play('blocked');
  assert.equal(created, beforeBlocked, 'sample playback does not contaminate a recording');
  const resetsBeforeRecording = events.filter(event => event.detail && event.detail.owner === 'recovery').length;
  recoveryClick(); assert(/麦克风|录音/.test(notice.textContent));
  assert.equal(events.filter(event => event.detail && event.detail.owner === 'recovery').length, resetsBeforeRecording, 'recovery does not silently interrupt the user recording');
  recording = false; play('leave'); window.dispatchEvent({ type: 'pagehide' });
  assert.equal(sandbox.A, null); assert.equal(activeResources.size, 0); assert.equal(timers.size, 0);
  assert(renders > 0);
  console.log('PASS: rapid tap resource bound, unload cleanup, no prefetch flood, immediate failure retry, stale async guards, cross-player ownership, timeout release, recovery integration, recording/pagehide safety.');
})().catch(error => { console.error(error); process.exitCode = 1; });
