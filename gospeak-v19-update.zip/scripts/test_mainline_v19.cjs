/* Offline UI/data regression tests. No browser microphone or network access. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const cp = require('node:child_process');
const assert = require('node:assert/strict');

const repository = path.resolve(__dirname, '..');
const playerPath = path.join(repository, 'assets/mainline-v19.js');
let source = fs.readFileSync(playerPath, 'utf8');
const boundary = source.indexOf("  window.addEventListener('sam-recorder-start'");
assert(boundary > 0, 'test harness must stop before registering browser listeners');
source = source.slice(0, boundary) +
  'window.test={state,shortLines,registerAudio,questionHtml,answerHtml,chainHtml,extraHtml,followupHtml,knownIntroHtml,planHtml,navigationHtml,playButton,variants,practiceVariantIndex,isRelatedVariant,render,wordsHtml};})();';

const sandbox = {
  window: {}, document: {baseURI:'https://example.test/'},
  localStorage: {getItem(){return null;},setItem(){}}, URL, clearTimeout
};
vm.runInNewContext(source, sandbox, {filename:playerPath});
const t = sandbox.window.test;
const python = process.env.PYTHON || process.env.PYTHON3 || 'python3';
const payload = cp.execFileSync(python, ['-c',
  'import sys,json;sys.path.insert(0,sys.argv[1]);import v19_curriculum as c;print(json.dumps(c.export_payload()))',
  path.join(repository,'scripts')], {encoding:'utf8'});
t.state.data = JSON.parse(payload);
t.state.questions = t.state.data.questions;
assert.equal(t.state.questions.length,24);

const content = {innerHTML:''};
t.state.root = {querySelector(selector){return selector === '[data-sam-content]' ? content : {textContent:''};}, querySelectorAll(){return [];}};
let relatedVariants = 0;
for (const question of t.state.questions) {
  t.state.selected=question.id;
  t.state.variant=0; t.state.followup=0; t.state.hint=0; t.state.mode='learn'; t.state.chain=1;
  const html=[t.questionHtml(question),t.answerHtml(question),t.chainHtml(question),t.extraHtml(question),t.followupHtml(question),t.knownIntroHtml(question)].join('');
  assert(!html.includes('undefined'), question.id+' must not leak undefined into the UI');
  assert(html.includes(question.question), question.id+' must show its question');
  if (!question.short.length) {
    assert(html.includes('先核实事实'),question.id+' must have a fact gate');
    assert(!t.answerHtml(question).includes('完整回答 · 听一遍'),question.id+' must not invent a complete answer');
  }
  t.state.hint=2;
  const hidden=t.answerHtml(question);
  if (question.short.length) {
    assert(!hidden.includes(question.short[0].en),question.id+' hidden answer must not leak');
    assert(hidden.includes('现在轮到你回答'));
  } else {
    assert(hidden.includes('不会答：看真实条件分支'),question.id+' unknown fact must still have a rescue entry');
  }

  const variants=t.variants(question);
  for(let sample=0; sample<=100; sample++) {
    const index=t.practiceVariantIndex(question,sample/100);
    assert(!variants[index].hint,question.id+' random/mock must exclude different-intent questions');
  }
  variants.forEach((variant,index) => {
    if(!variant.hint)return;
    relatedVariants++;
    t.state.variant=index; t.state.mode='learn'; t.state.hint=0;
    t.render();
    assert(t.isRelatedVariant(question));
    assert(content.innerHTML.includes('不能照搬主问题答案'),question.id+' must warn against answer reuse');
    assert(content.innerHTML.includes(variant.hint),question.id+' must show its specific guidance');
    assert(!content.innerHTML.includes('完整回答 · 听一遍'),question.id+' must hide base full-answer audio UI');
    assert(!content.innerHTML.includes('逐句累加'),question.id+' must hide base cumulative answer');
    assert(!content.innerHTML.includes('你已经会说的自我介绍'),question.id+' must hide unrelated known intro');
    assert.equal(t.state.recorderTargets.length,1,question.id+' gets one free-response recorder');
    assert.equal(t.state.recorderTargets[0].expectedText,'',question.id+' must not compare against the base answer');
    assert(t.state.recorderTargets[0].id.endsWith('variant-'+index));
    const baseText=question.short.map(line=>line.en).join(' ');
    if(baseText) assert(!Object.values(t.state.clips).some(clip=>clip.text===baseText),question.id+' must not register base answer playback');
    t.state.mode='mock';
    assert(t.questionHtml(question).includes('disabled title="相关追问请在精练模式中单独练习"'));
  });
}
assert(relatedVariants>0,'fixture must contain different-intent variants');

const slowKey=t.registerAudio({normal:'a.mp3',slow:'a.mp3',slowRate:0.78},'test',true);
assert.equal(t.state.clips[slowKey].rate,0.78);
assert(t.playButton({normal:'bad.mp3'},'I have [number] years.',false).includes('disabled'));
t.state.selected='01';t.state.variant=0;t.state.hint=0;t.state.mode='learn';
assert(t.knownIntroHtml(t.state.questions[0]).includes('保温入口'));
assert.equal((t.navigationHtml().match(/<option /g)||[]).length,24);
assert(t.planHtml().includes('第1天'));
t.state.data.lexicon={'u.s.':{ipa:'ˌjuː ˈes',zh:'美国',src:'us.mp3'}};
t.state.clips={};
const words=t.wordsHtml('I am interested in U.S. culture.');
assert(words.includes('▶ U.S.'));
assert(Object.values(t.state.clips).some(clip=>clip.text==='U.S.'&&clip.src==='us.mp3'));
assert(!Object.values(t.state.clips).some(clip=>clip.text==='U'||clip.text==='S'));
console.log('PASS: 24 questions; '+relatedVariants+' different-intent variants isolated; random/mock intent safety; hidden answers; fact gates; rescue entries; known intro; plan; slow rate; U.S. token; placeholder audio block.');
