"""Standalone, fact-safe 14-module SWT curriculum for GoSpeak V18.

Biographical statements are restricted to facts confirmed by the learner.
Workplace scenarios use ``if``/``would`` language and therefore teach an
answering strategy without inventing a past job, incident, or achievement.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Iterable


VERSION = "v18"
ENGLISH_VOICE = "en-US-EmmaNeural"
CHINESE_VOICE = "zh-CN-XiaoxiaoNeural"


@dataclass(frozen=True)
class Sentence:
    en: str
    zh: str


@dataclass(frozen=True)
class Module:
    id: str
    slug: str
    title: str
    question: str
    question_zh: str
    connections: tuple[str, ...]
    fact_ids: tuple[str, ...]
    sentences: tuple[Sentence, ...]


CONFIRMED_FACTS = (
    {"id": "name", "zh": "学习和交流使用的英文名是 Sam；不替代护照姓名。", "en": "The learner uses the English name Sam."},
    {
        "id": "school",
        "zh": "就读于广西幼儿师范高等专科学校（课程使用 Guangxi College for Preschool Education）。",
        "en": "The learner studies at Guangxi College for Preschool Education.",
    },
    {"id": "year", "zh": "目前是大一学生。", "en": "The learner is a first-year student."},
    {
        "id": "major",
        "zh": "专业是体育体能训练（课程使用 physical fitness training）。",
        "en": "The learner's major is physical fitness training.",
    },
    {
        "id": "certificate",
        "zh": "持有中国游泳救生员证；不声称该证书等同美国资质。",
        "en": "The learner has a Chinese lifeguard certificate; no U.S. equivalence is claimed.",
    },
    {
        "id": "goals",
        "zh": "已确认目标是体验美国文化、提升英语。",
        "en": "The confirmed goals are to experience American culture and improve English.",
    },
    {"id": "return", "zh": "项目结束后回国继续在原学校读书；具体日期未定。", "en": "After the program, Sam will return to China and continue his studies; exact dates are unconfirmed."},
)

UNCONFIRMED_FACTS = (
    "护照状态、号码或办理进度",
    "兼职或其他工作经历",
    "既往旅行经历",
    "可以工作的具体日期、时段或排班",
    "可游泳的具体距离或成绩",
    "具体回国和返校日期",
)

SAFETY_NOTICE = (
    "个人资料只使用 Sam 本人确认的英文名、学校、年级、专业、中国救生员证、目标及回国继续读书的计划。"
    "岗位情景统一使用条件句，不把假设写成真实经历；未确认资料必须先核对，不能猜测。"
)

MODES = (
    {
        "id": "teaching",
        "title": "教学精听",
        "description": "英中对照后逐句听慢速、正常、自然语速，并留出动态跟读空白。",
    },
    {
        "id": "review",
        "title": "纯英文复习",
        "description": "只听英文问题和整段答案的慢速、标准、自然连读，不再逐句或播放中文。",
    },
    {
        "id": "mock",
        "title": "模拟口测",
        "description": "听题后准备三秒、独立作答三十秒，再听一次自然参考答案。",
    },
)


def S(en: str, zh: str) -> Sentence:
    """Keep the curriculum declarations compact without hiding field names."""

    return Sentence(en=en, zh=zh)


MODULES = (
    Module(
        "01",
        "survival-phrases",
        "口测保命句",
        "What can you say if you need more time or do not hear a question clearly?",
        "没听清或需要一点时间时，你可以怎么说？",
        ("请求重复", "请求慢速", "确认理解", "争取思考时间", "致谢"),
        (),
        (
            S("Could you please repeat the question?", "您可以重复一下问题吗？"),
            S("Could you please speak a little more slowly?", "您可以说慢一点吗？"),
            S("Let me make sure I understand the question.", "请让我确认自己理解了这个问题。"),
            S("Please give me a few seconds to think.", "请给我几秒钟思考。"),
            S("Let me answer that carefully, please.", "请让我认真回答。"),
            S("Thank you for your patience.", "谢谢您的耐心。"),
        ),
    ),
    Module(
        "02",
        "self-introduction",
        "真实自我介绍",
        "Please introduce yourself briefly.",
        "请简单介绍一下你自己。",
        ("姓名", "学校与年级", "专业", "中国证书", "项目目标"),
        ("name", "school", "year", "major", "certificate", "goals"),
        (
            S("Hello, you can call me Sam.", "你好，你可以叫我 Sam。"),
            S(
                "I am a first-year student at Guangxi College for Preschool Education.",
                "我是广西幼儿师范高等专科学校的大一学生。",
            ),
            S("My major is physical fitness training.", "我的专业是体育体能训练。"),
            S("I have a Chinese lifeguard certificate.", "我有中国游泳救生员证。"),
            S("I try to be responsible, and I am willing to learn.", "我会努力负责，也愿意学习。"),
            S(
                "I want to experience American culture and improve my English.",
                "我想体验美国文化并提升英语。",
            ),
        ),
    ),
    Module(
        "03",
        "study-and-certificate",
        "学校、专业与证书",
        "Could you tell me about your school, major, and qualifications?",
        "你可以介绍一下学业和资质吗？",
        ("学校", "年级", "专业", "中国证书", "准确边界"),
        ("school", "year", "major", "certificate"),
        (
            S(
                "I study at Guangxi College for Preschool Education.",
                "我就读于广西幼儿师范高等专科学校。",
            ),
            S("I am a first-year student there.", "我在那里读大一。"),
            S("My major is physical fitness training.", "我的专业是体育体能训练。"),
            S("I also have a Chinese lifeguard certificate.", "我也有中国游泳救生员证。"),
            S(
                "My certificate is from China, so I understand that I may need additional training in the United States.",
                "我的证书来自中国，因此我明白在美国可能还需要额外培训。",
            ),
        ),
    ),
    Module(
        "04",
        "why-swt-and-america",
        "为什么参加 SWT、为什么去美国",
        "Why do you want to join the SWT program in the United States?",
        "你为什么想参加美国的 SWT 项目？",
        ("参加 SWT", "体验美国文化", "提升英语", "真实目标", "学习机会"),
        ("goals",),
        (
            S("I want to join the SWT program for two clear reasons.", "我想参加 SWT 项目有两个明确原因。"),
            S("I want to experience American culture.", "我想体验美国文化。"),
            S("I also want to improve my English.", "我也想提升英语。"),
            S("These are my two main goals.", "这是我的两个主要目标。"),
            S("I would use the program as a chance to learn.", "我会把这个项目当作一次学习机会。"),
        ),
    ),
    Module(
        "05",
        "program-goals-and-plan",
        "项目目标与计划",
        "What are your goals and plans for the program?",
        "你参加项目的目标和计划是什么？",
        ("两项目标", "日常使用英语", "逐步学习", "遵守规则", "聚焦项目"),
        ("goals",),
        (
            S("My plan has two clear goals.", "我的计划有两个明确目标。"),
            S("I want to experience American culture and improve my English.", "我想体验美国文化并提升英语。"),
            S("During the program, I would use English as much as I can.", "项目期间，我会尽可能多使用英语。"),
            S("I would learn from daily situations step by step.", "我会从日常情境中一步一步学习。"),
            S("I would follow the program and workplace rules.", "我会遵守项目和工作场所的规则。"),
        ),
    ),
    Module(
        "06",
        "careful-strengths",
        "优点与工作态度",
        "What strengths would you bring to a workplace?",
        "你能为工作场所带来哪些优点？",
        ("谨慎表述", "愿意学习", "耐心", "重视安全", "团队做法"),
        (),
        (
            S("I try to be responsible in what I do.", "我做事时会努力负责。"),
            S("I am willing to learn and follow instructions.", "我愿意学习并遵守指示。"),
            S("I try to stay patient when solving a problem.", "解决问题时，我会努力保持耐心。"),
            S("Safety is important to me.", "安全对我很重要。"),
            S("In a team, I would listen and do my part.", "在团队中，我会倾听并做好自己的部分。"),
        ),
    ),
    Module(
        "07",
        "english-weakness",
        "英语弱点与改进",
        "What is a weakness you are working on?",
        "你正在改进的一个弱点是什么？",
        ("英语仍在提升", "理解可能较慢", "请求重复", "每日练习计划", "先确认再行动"),
        ("goals",),
        (
            S("My English is still improving.", "我的英语还在提升中。"),
            S("Sometimes I may need more time to understand a question.", "有时我可能需要更多时间理解问题。"),
            S("If that happened, I would politely ask for repetition.", "如果出现这种情况，我会礼貌地请求重复。"),
            S("My plan is to practice English every day.", "我的计划是每天练习英语。"),
            S("I would make sure I understood before I acted.", "行动前，我会确认自己已经理解。"),
        ),
    ),
    Module(
        "08",
        "job-and-lifeguard-boundary",
        "岗位与中国救生员证",
        "What kind of position would you consider?",
        "你会考虑什么样的岗位？",
        ("合适岗位", "中国证书", "不等同美国资质", "先满足要求", "接受必要培训"),
        ("certificate",),
        (
            S(
                "I am interested in lifeguarding, but I am also open to other suitable positions.",
                "我对救生员岗位感兴趣，但也愿意考虑其他合适的岗位。",
            ),
            S("For lifeguarding, I have a Chinese lifeguard certificate.", "关于救生员岗位，我有中国游泳救生员证。"),
            S(
                "I understand that my Chinese certificate may not meet U.S. employer requirements.",
                "我明白，我的中国证书可能不符合美国雇主的要求。",
            ),
            S("I would check every requirement before accepting that role.", "接受那个岗位前，我会核对所有要求。"),
            S(
                "I am willing to complete any required local training or certification.",
                "我愿意完成任何必要的当地培训或认证。",
            ),
        ),
    ),
    Module(
        "09",
        "mistake-at-work",
        "犯错时的工作态度",
        "What would you do if you made a mistake at work?",
        "如果在工作中犯错，你会怎么做？",
        ("承认", "及时报告", "听取指示", "补救", "吸取教训"),
        (),
        (
            S("If I made a mistake, I would admit it quickly.", "如果我犯了错，我会尽快承认。"),
            S("I would report it to the right person.", "我会向合适的负责人报告。"),
            S("I would listen carefully to the instructions.", "我会认真听取指示。"),
            S("I would help correct the problem safely.", "我会安全地协助纠正问题。"),
            S("Then I would learn from the mistake and avoid repeating it.", "之后我会吸取教训，避免再次犯错。"),
        ),
    ),
    Module(
        "10",
        "supervisor-language-barrier",
        "听不懂主管时",
        "What would you do if you did not understand your supervisor?",
        "如果没有听懂主管的话，你会怎么做？",
        ("保持冷静", "请求重复", "请求慢速", "复述确认", "开始前确认"),
        (),
        (
            S("If I did not understand, I would stay calm.", "如果没有听懂，我会保持冷静。"),
            S("I would ask my supervisor to repeat the instruction.", "我会请主管重复指示。"),
            S("I could also ask them to speak more slowly.", "我也可以请对方说慢一点。"),
            S("I would repeat the key instruction back to confirm it.", "我会复述关键指示来确认。"),
            S("I would make sure I understood before starting the task.", "开始任务前，我会确认自己已经理解。"),
        ),
    ),
    Module(
        "11",
        "customer-complaint",
        "处理顾客投诉",
        "What would you do if a customer complained?",
        "如果顾客投诉，你会怎么做？",
        ("保持冷静", "认真倾听", "礼貌回应", "遵循流程", "必要时找主管"),
        (),
        (
            S("If a customer complained, I would stay calm and polite.", "如果顾客投诉，我会保持冷静和礼貌。"),
            S("I would listen carefully without arguing.", "我会认真倾听，不与顾客争辩。"),
            S("I would apologize for the problem and clarify the facts.", "我会为问题致歉并确认事实。"),
            S("I would follow the workplace procedure.", "我会遵循工作场所的处理流程。"),
            S("If it was beyond my role, I would ask a supervisor for help.", "如果超出我的职责，我会请主管协助。"),
        ),
    ),
    Module(
        "12",
        "coworker-conflict",
        "同事冲突与团队合作",
        "What would you do if you disagreed with a coworker?",
        "如果你和同事意见不一致，你会怎么做？",
        ("冷静沟通", "倾听", "说明观点", "共同方案", "必要时请主管协助"),
        (),
        (
            S("If I disagreed with a coworker, I would speak calmly.", "如果我和同事意见不一致，我会冷静沟通。"),
            S("I would listen to their point of view first.", "我会先听对方的观点。"),
            S("Then I would explain my view clearly and respectfully.", "然后我会清楚、尊重地说明自己的观点。"),
            S("I would try to find a solution that supported the task.", "我会努力寻找有利于任务的解决办法。"),
            S("If needed, I would ask a supervisor to help.", "如有需要，我会请主管协助。"),
        ),
    ),
    Module(
        "13",
        "emergency-safety",
        "紧急情况与安全",
        "What would you do in an emergency at work?",
        "工作中遇到紧急情况，你会怎么做？",
        ("保持冷静", "遵循流程", "呼叫帮助", "不超出训练范围", "报告"),
        (),
        (
            S("In an emergency, I would stay calm and check the situation.", "遇到紧急情况时，我会保持冷静并查看情况。"),
            S("I would follow the emergency procedure and instructions.", "我会遵循紧急流程和指示。"),
            S("I would call trained staff or emergency services as required.", "我会按要求呼叫受过训练的人员或紧急服务。"),
            S("I would not act beyond my training.", "我不会超出自己的训练范围行动。"),
            S("Afterward, I would report what happened accurately.", "事后我会准确报告发生的情况。"),
        ),
    ),
    Module(
        "14",
        "culture-and-summary",
        "文化适应与综合总结",
        "How would you adapt to cultural differences and complete the program?",
        "你会如何适应文化差异并完成项目？",
        ("文化目标", "观察与提问", "尊重规则", "完成项目", "真实背景总结"),
        ("school", "year", "major", "certificate", "goals"),
        (
            S("I want to experience American culture and improve my English.", "我想体验美国文化并提升英语。"),
            S("If something felt unfamiliar, I would observe and ask politely.", "如果遇到不熟悉的事物，我会观察并礼貌提问。"),
            S("I would respect local and workplace rules.", "我会尊重当地和工作场所的规则。"),
            S(
                "To complete the program, I would stay organized and ask for help when needed.",
                "为了顺利完成项目，我会保持有条理，并在需要时寻求帮助。",
            ),
            S(
                "I am a first-year student majoring in physical fitness training, and I have a Chinese lifeguard certificate.",
                "我是体育体能训练专业的大一学生，并持有中国游泳救生员证。",
            ),
        ),
    ),
)


# These phrases would turn an unconfirmed detail into a biographical claim.
# Teaching conditional workplace behavior is intentionally allowed.
FORBIDDEN_SPOKEN_MARKERS = (
    "my passport",
    "我的护照",
    "i worked part-time",
    "i have worked part-time",
    "我做过兼职",
    "my work schedule is",
    "我的排班是",
    "i have traveled",
    "i traveled to",
    "我去过美国",
    "i can swim 100",
    "i can swim 200",
    "i can swim 500",
    "我能游100",
    "我能游200",
    "我能游500",
    "my chinese certificate is valid in the united states",
    "我的中国证书在美国有效",
)


def iter_spoken_text(modules: Iterable[Module] = MODULES) -> Iterable[str]:
    for module in modules:
        yield module.question
        yield module.question_zh
        for sentence in module.sentences:
            yield sentence.en
            yield sentence.zh


def validate_curriculum(modules: tuple[Module, ...] = MODULES) -> None:
    """Validate shape, answer length, and high-risk unsupported claims."""

    errors: list[str] = []
    expected_ids = [f"{number:02d}" for number in range(1, 15)]
    actual_ids = [module.id for module in modules]
    if len(modules) != 14:
        errors.append(f"expected 14 modules, found {len(modules)}")
    if actual_ids != expected_ids:
        errors.append(f"module IDs must be 01..14 in order, found {actual_ids}")

    allowed_fact_ids = {fact["id"] for fact in CONFIRMED_FACTS}
    seen_slugs: set[str] = set()
    for module in modules:
        if module.slug in seen_slugs:
            errors.append(f"duplicate slug: {module.slug}")
        seen_slugs.add(module.slug)
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", module.slug):
            errors.append(f"invalid slug for module {module.id}: {module.slug}")
        if not module.title or not module.question or not module.question_zh:
            errors.append(f"module {module.id} has a blank title or question")
        if not 4 <= len(module.sentences) <= 6:
            errors.append(f"module {module.id} must contain 4-6 answer sentences")
        word_count = sum(
            len(re.findall(r"[A-Za-z]+(?:-[A-Za-z]+)?", sentence.en))
            for sentence in module.sentences
        )
        if not 40 <= word_count <= 90:
            errors.append(f"module {module.id} answer has {word_count} words; expected 40-90")
        unknown_facts = set(module.fact_ids) - allowed_fact_ids
        if unknown_facts:
            errors.append(f"module {module.id} uses unknown fact IDs: {sorted(unknown_facts)}")
        for index, sentence in enumerate(module.sentences, 1):
            if not sentence.en.strip() or not sentence.zh.strip():
                errors.append(f"module {module.id} sentence {index} is blank")

    searchable = "\n".join(iter_spoken_text(modules)).casefold()
    for marker in FORBIDDEN_SPOKEN_MARKERS:
        if marker.casefold() in searchable:
            errors.append(f"unconfirmed claim appears in spoken text: {marker!r}")

    if errors:
        raise ValueError("Invalid V18 curriculum:\n- " + "\n- ".join(errors))


validate_curriculum()


if __name__ == "__main__":
    validate_curriculum()
    sentence_count = sum(len(module.sentences) for module in MODULES)
    print(f"{VERSION}: {len(MODULES)} modules, {sentence_count} answer sentences; validation passed")
