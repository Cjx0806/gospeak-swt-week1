#!/usr/bin/env python3
"""Build GoSpeak V18 continuous-listening audio and integrate its player.

Usage from the repository root::

    python scripts/build_v18_listening.py _site
    python scripts/build_v18_listening.py _site --skip-audio

The audio build deliberately uses Edge TTS only for speech and ffmpeg only for
precomposition.  Browsers therefore receive one seekable MP3 per module/mode,
plus one uninterrupted collection MP3 per mode; no runtime clip stitching is
required on iPad or while the screen is locked.
"""

from __future__ import annotations

import argparse
import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Iterable, Optional, Sequence, Union

from v18_curriculum import (
    CHINESE_VOICE,
    CONFIRMED_FACTS,
    ENGLISH_VOICE,
    MODES,
    MODULES,
    SAFETY_NOTICE,
    UNCONFIRMED_FACTS,
    VERSION,
    Module,
    validate_curriculum,
)


AUDIO_RELATIVE_ROOT = Path("audio/v18")
MANIFEST_RELATIVE_PATH = AUDIO_RELATIVE_ROOT / "manifest.json"
PUBLIC_MANIFEST_RELATIVE_PATH = Path("listening-v18.json")
PLAYER_FILENAMES = ("listening-v18.js", "listening-v18.css")
SERVICE_WORKER_VERSION = "gospeak-independent-v18-continuous-listening"


@dataclass(frozen=True)
class Speech:
    text: str
    voice: str
    rate: str


@dataclass(frozen=True)
class Silence:
    seconds: float


Clip = Union[Speech, Silence]


@dataclass(frozen=True)
class ModeTiming:
    slow_gap: float
    normal_gap: float
    natural_gap: float
    whole_gap: float


MODE_TIMINGS = {
    "teaching": ModeTiming(4.8, 4.2, 5.5, 6.0),
}


def _spoken_english(text: str) -> str:
    """Give Edge TTS pronunciation hints without changing visible curriculum."""

    return text.replace("SWT", "S W T")


def _spoken_chinese(text: str) -> str:
    return text.replace("SWT", "S W T")


def _speech(text: str, voice: str, rate: str) -> Speech:
    if voice == ENGLISH_VOICE:
        text = _spoken_english(text)
    elif voice == CHINESE_VOICE:
        text = _spoken_chinese(text)
    return Speech(text=text, voice=voice, rate=rate)


def _word_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z]+(?:-[A-Za-z]+)?", text))


def _follow_gap(text: str, base_seconds: float) -> float:
    """Give long sentences enough time to be repeated aloud at a safe pace."""

    return round(max(base_seconds, _word_count(text) / 1.8 + 1.0), 3)


def _teaching_plan(module: Module) -> tuple[Clip, ...]:
    timing = MODE_TIMINGS["teaching"]
    clips: list[Clip] = [
        _speech(f"第{int(module.id)}模块，{module.title}。教学精听。", CHINESE_VOICE, "+0%"),
        Silence(0.8),
        _speech(module.question, ENGLISH_VOICE, "+2%"),
        Silence(0.8),
        _speech(module.question_zh, CHINESE_VOICE, "+0%"),
        Silence(1.4),
    ]
    # Teaching alone uses the full required bilingual five-pass pattern.
    for sentence in module.sentences:
        clips.extend(
            (
                _speech(sentence.en, ENGLISH_VOICE, "-5%"),
                Silence(0.6),
                _speech(sentence.zh, CHINESE_VOICE, "+0%"),
                Silence(0.9),
                _speech(sentence.en, ENGLISH_VOICE, "-25%"),
                Silence(_follow_gap(sentence.en, timing.slow_gap)),
                _speech(sentence.en, ENGLISH_VOICE, "-5%"),
                Silence(_follow_gap(sentence.en, timing.normal_gap)),
                _speech(sentence.en, ENGLISH_VOICE, "+5%"),
                Silence(_follow_gap(sentence.en, timing.natural_gap)),
            )
        )
    whole_answer = " ".join(sentence.en for sentence in module.sentences)
    clips.extend(
        (
            _speech("最后听完整回答。依次是慢速、正常语速和自然连读。", CHINESE_VOICE, "+0%"),
            Silence(1.0),
            _speech(whole_answer, ENGLISH_VOICE, "-20%"),
            Silence(timing.whole_gap),
            _speech(whole_answer, ENGLISH_VOICE, "-5%"),
            Silence(timing.whole_gap),
            _speech(whole_answer, ENGLISH_VOICE, "+5%"),
            Silence(timing.whole_gap),
        )
    )
    return tuple(clips)


def _review_plan(module: Module) -> tuple[Clip, ...]:
    whole_answer = " ".join(sentence.en for sentence in module.sentences)
    return (
        _speech(f"Module {int(module.id)}. English review.", ENGLISH_VOICE, "+0%"),
        Silence(0.8),
        _speech(module.question, ENGLISH_VOICE, "+2%"),
        Silence(2.0),
        _speech(whole_answer, ENGLISH_VOICE, "-20%"),
        Silence(2.0),
        _speech(whole_answer, ENGLISH_VOICE, "-5%"),
        Silence(2.0),
        _speech(whole_answer, ENGLISH_VOICE, "+5%"),
        Silence(2.0),
    )


def _mock_plan(module: Module) -> tuple[Clip, ...]:
    whole_answer = " ".join(sentence.en for sentence in module.sentences)
    return (
        _speech(f"Module {int(module.id)}. Mock interview.", ENGLISH_VOICE, "+0%"),
        Silence(0.8),
        _speech(module.question, ENGLISH_VOICE, "+5%"),
        Silence(3.0),
        _speech("Please begin.", ENGLISH_VOICE, "+0%"),
        Silence(30.0),
        _speech("Here is a reference answer.", ENGLISH_VOICE, "+0%"),
        Silence(0.8),
        _speech(whole_answer, ENGLISH_VOICE, "+5%"),
        Silence(3.0),
    )


def build_track_plan(module: Module, mode_id: str) -> tuple[Clip, ...]:
    """Return a deterministic, genuinely mode-specific long-track plan."""

    if mode_id == "teaching":
        return _teaching_plan(module)
    if mode_id == "review":
        return _review_plan(module)
    if mode_id == "mock":
        return _mock_plan(module)
    raise ValueError(f"unknown listening mode: {mode_id}")


def _clip_key(clip: Speech) -> str:
    payload = "\0".join((clip.voice, clip.rate, clip.text)).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:24]


def _run(command: Sequence[str], *, description: str) -> None:
    try:
        subprocess.run(command, check=True, text=True, capture_output=True)
    except subprocess.CalledProcessError as error:
        detail = (error.stderr or error.stdout or "").strip()
        raise RuntimeError(f"{description} failed: {detail}") from error


def _make_silence(ffmpeg: str, seconds: float, output: Path) -> None:
    _run(
        (
            ffmpeg,
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "anullsrc=r=24000:cl=mono",
            "-t",
            f"{seconds:.3f}",
            "-ar",
            "24000",
            "-ac",
            "1",
            "-b:a",
            "48k",
            output.as_posix(),
        ),
        description=f"creating {seconds:g}s silence",
    )


def _concat_file_line(path: Path) -> str:
    escaped = path.resolve().as_posix().replace("'", "'\\''")
    return f"file '{escaped}'\n"


def _concat_mp3(ffmpeg: str, inputs: Sequence[Path], output: Path, work_dir: Path) -> None:
    if not inputs:
        raise ValueError(f"no inputs supplied for {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    list_name = hashlib.sha256(output.as_posix().encode("utf-8")).hexdigest()[:16]
    # Concatenate decoded PCM, not MP3 packets: encoder delay must not slowly
    # move the bilingual sentence cues out of sync with the audible speech.
    raw_path = work_dir / f"concat-{list_name}.pcm"
    with raw_path.open("wb") as raw:
        for path in inputs:
            pcm = _decoded_pcm(ffmpeg, path, work_dir)
            with pcm.open("rb") as stream:
                shutil.copyfileobj(stream, raw)
    temporary_output = output.with_name(f".{output.stem}.building.mp3")
    _run(
        (
            ffmpeg,
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "s16le",
            "-ar", "24000", "-ac", "1",
            "-i",
            raw_path.as_posix(),
            "-vn",
            "-ar",
            "24000",
            "-ac",
            "1",
            "-b:a",
            "48k",
            temporary_output.as_posix(),
        ),
        description=f"precomposing {output.name}",
    )
    temporary_output.replace(output)
    raw_path.unlink()


def _decoded_pcm(ffmpeg: str, path: Path, work_dir: Path) -> Path:
    key = hashlib.sha256(path.resolve().as_posix().encode()).hexdigest()[:24]
    decoded = work_dir / f"decoded-{key}.pcm"
    if not decoded.is_file():
        _run((ffmpeg, "-v", "error", "-y", "-i", str(path), "-f", "s16le",
              "-ar", "24000", "-ac", "1", str(decoded)), description="decoding audio for exact timing")
    return decoded


def _cue(module: Module, clip: Clip, start: float, end: float, previous: Optional[dict]) -> dict:
    if isinstance(clip, Silence):
        payload = dict(previous or {"kind": "gap", "en": "", "zh": "准备／跟读空白", "lineIndex": None})
    else:
        payload = {"kind": "instruction", "en": "", "zh": "", "lineIndex": None}
        if clip.text in (_spoken_english(module.question), _spoken_chinese(module.question_zh)):
            payload.update(kind="question", en=module.question, zh=module.question_zh)
        else:
            for i, sentence in enumerate(module.sentences):
                if clip.text in (_spoken_english(sentence.en), _spoken_chinese(sentence.zh)):
                    payload.update(kind="line", en=sentence.en, zh=sentence.zh, lineIndex=i)
                    break
            else:
                whole = " ".join(s.en for s in module.sentences)
                if clip.text == _spoken_english(whole):
                    payload.update(kind="answer", en=whole, zh="".join(s.zh for s in module.sentences))
                elif clip.voice == ENGLISH_VOICE:
                    payload["en"] = clip.text
                else:
                    payload["zh"] = clip.text
    payload.update(start=round(start, 3), end=round(end, 3))
    return payload


def _duration_seconds(ffprobe: Optional[str], path: Path) -> float:
    if ffprobe:
        try:
            result = subprocess.run(
                (
                    ffprobe,
                    "-v",
                    "error",
                    "-show_entries",
                    "format=duration",
                    "-of",
                    "default=noprint_wrappers=1:nokey=1",
                    path.as_posix(),
                ),
                check=True,
                text=True,
                capture_output=True,
            )
            return round(float(result.stdout.strip()), 3)
        except (subprocess.CalledProcessError, ValueError):
            pass
    try:
        from mutagen.mp3 import MP3
    except ImportError as error:
        raise RuntimeError(
            f"could not read audio duration for {path}; install ffprobe or mutagen"
        ) from error
    try:
        return round(float(MP3(path.as_posix()).info.length), 3)
    except Exception as error:
        raise RuntimeError(f"could not read MP3 duration for {path}") from error


async def _synthesize_all(
    speeches: Iterable[Speech], output_dir: Path, concurrency: int
) -> dict[Speech, Path]:
    try:
        import edge_tts
    except ImportError as error:
        raise RuntimeError("edge-tts is required unless --skip-audio is used") from error

    unique_speeches = tuple(dict.fromkeys(speeches))
    semaphore = asyncio.Semaphore(concurrency)
    results: dict[Speech, Path] = {}
    completed = 0
    total = len(unique_speeches)

    async def synthesize(clip: Speech) -> None:
        nonlocal completed
        output = output_dir / f"{_clip_key(clip)}.mp3"
        results[clip] = output
        if output.is_file() and output.stat().st_size:
            completed += 1
            if completed % 5 == 0 or completed == total:
                print(f"Speech cache/TTS: {completed}/{total} unique clips", flush=True)
            return
        async with semaphore:
            for attempt in range(1, 4):
                temporary = output.with_name(
                    f".{output.stem}.{os.getpid()}.part.mp3"
                )
                try:
                    communicator = edge_tts.Communicate(
                        clip.text,
                        clip.voice,
                        rate=clip.rate,
                    )
                    await communicator.save(temporary.as_posix())
                    if not temporary.is_file() or not temporary.stat().st_size:
                        raise RuntimeError("Edge TTS returned an empty file")
                    temporary.replace(output)
                    completed += 1
                    if completed % 5 == 0 or completed == total:
                        print(f"Speech cache/TTS: {completed}/{total} unique clips", flush=True)
                    return
                except Exception:
                    temporary.unlink(missing_ok=True)
                    if attempt == 3:
                        raise
                    await asyncio.sleep(float(attempt))

    await asyncio.gather(*(synthesize(clip) for clip in unique_speeches))
    return results


def _module_directory(module: Module) -> Path:
    return Path("modules") / f"{module.id}-{module.slug}"


def _public_audio_path(relative_path: Path) -> str:
    return "./" + (AUDIO_RELATIVE_ROOT / relative_path).as_posix()


def build_audio(
    site_root: Path, *, concurrency: int, cache_dir: Path
) -> tuple[dict[tuple[str, str], float], dict[str, float], dict[tuple[str, str], float]]:
    """Build module/collection MP3s and return durations plus collection offsets."""

    ffmpeg_override = os.environ.get("GOSPEAK_FFMPEG")
    ffmpeg = shutil.which(ffmpeg_override) if ffmpeg_override else shutil.which("ffmpeg")
    ffprobe = shutil.which("ffprobe")
    if not ffmpeg:
        hint = "GOSPEAK_FFMPEG" if ffmpeg_override else "PATH or GOSPEAK_FFMPEG"
        raise RuntimeError(f"audio build requires ffmpeg via {hint}")

    plans = {
        (module.id, mode["id"]): build_track_plan(module, mode["id"])
        for module in MODULES
        for mode in MODES
    }
    speeches = (
        clip
        for plan in plans.values()
        for clip in plan
        if isinstance(clip, Speech)
    )
    silence_lengths = sorted(
        {
            clip.seconds
            for plan in plans.values()
            for clip in plan
            if isinstance(clip, Silence)
        }
    )

    audio_root = site_root / AUDIO_RELATIVE_ROOT
    audio_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".v18-build-", dir=audio_root) as temporary:
        work_dir = Path(temporary)
        silence_dir = work_dir / "silence"
        silence_dir.mkdir()
        cache_dir.mkdir(parents=True, exist_ok=True)
        speech_paths = asyncio.run(_synthesize_all(speeches, cache_dir, concurrency))
        silence_paths: dict[float, Path] = {}
        for seconds in silence_lengths:
            path = silence_dir / f"silence-{int(round(seconds * 1000)):05d}ms.mp3"
            _make_silence(ffmpeg, seconds, path)
            silence_paths[seconds] = path

        module_paths: dict[tuple[str, str], Path] = {}
        for module in MODULES:
            for mode in MODES:
                mode_id = mode["id"]
                output = audio_root / _module_directory(module) / f"{mode_id}.mp3"
                inputs = [
                    speech_paths[clip] if isinstance(clip, Speech) else silence_paths[clip.seconds]
                    for clip in plans[(module.id, mode_id)]
                ]
                _concat_mp3(ffmpeg, inputs, output, work_dir)
                cursor = 0.0
                cues = []
                for clip, source in zip(plans[(module.id, mode_id)], inputs):
                    seconds = _decoded_pcm(ffmpeg, source, work_dir).stat().st_size / 48000
                    cues.append(_cue(module, clip, cursor, cursor + seconds, cues[-1] if cues else None))
                    cursor += seconds
                output.with_suffix(".cues.json").write_text(json.dumps(cues, ensure_ascii=False), encoding="utf-8")
                module_paths[(module.id, mode_id)] = output

        collection_paths: dict[str, Path] = {}
        for mode in MODES:
            mode_id = mode["id"]
            output = audio_root / "collections" / f"{mode_id}.mp3"
            inputs = [module_paths[(module.id, mode_id)] for module in MODULES]
            _concat_mp3(ffmpeg, inputs, output, work_dir)
            collection_paths[mode_id] = output

    module_durations = {
        key: _duration_seconds(ffprobe, path) for key, path in module_paths.items()
    }
    collection_durations = {
        mode_id: _duration_seconds(ffprobe, path)
        for mode_id, path in collection_paths.items()
    }
    offsets: dict[tuple[str, str], float] = {}
    for mode in MODES:
        mode_id = mode["id"]
        cursor = 0.0
        for module in MODULES:
            offsets[(module.id, mode_id)] = round(cursor, 3)
            cue_path = module_paths[(module.id, mode_id)].with_suffix('.cues.json')
            cues = json.loads(cue_path.read_text())
            cursor += cues[-1]['end'] if cues else module_durations[(module.id, mode_id)]
    return module_durations, collection_durations, offsets


def inspect_existing_audio(
    site_root: Path,
) -> tuple[dict[tuple[str, str], float], dict[str, float], dict[tuple[str, str], float]]:
    """Describe existing audio during --skip-audio, without requiring ffmpeg."""

    ffprobe = shutil.which("ffprobe")
    module_durations: dict[tuple[str, str], float] = {}
    collection_durations: dict[str, float] = {}
    for module in MODULES:
        for mode in MODES:
            mode_id = mode["id"]
            path = (
                site_root
                / AUDIO_RELATIVE_ROOT
                / _module_directory(module)
                / f"{mode_id}.mp3"
            )
            if path.is_file():
                module_durations[(module.id, mode_id)] = _duration_seconds(ffprobe, path)
    for mode in MODES:
        mode_id = mode["id"]
        path = site_root / AUDIO_RELATIVE_ROOT / "collections" / f"{mode_id}.mp3"
        if path.is_file():
            collection_durations[mode_id] = _duration_seconds(ffprobe, path)

    offsets: dict[tuple[str, str], float] = {}
    for mode in MODES:
        mode_id = mode["id"]
        cursor = 0.0
        complete = all((module.id, mode_id) in module_durations for module in MODULES)
        if complete:
            for module in MODULES:
                offsets[(module.id, mode_id)] = round(cursor, 3)
                cue_path = (site_root / AUDIO_RELATIVE_ROOT / _module_directory(module) / f'{mode_id}.cues.json')
                cues = json.loads(cue_path.read_text()) if cue_path.is_file() else []
                cursor += cues[-1]['end'] if cues else module_durations[(module.id, mode_id)]
    return module_durations, collection_durations, offsets


def make_manifest(
    site_root: Path,
    module_durations: dict[tuple[str, str], float],
    collection_durations: dict[str, float],
    offsets: dict[tuple[str, str], float],
) -> dict[str, object]:
    modes: list[dict[str, object]] = []
    for mode in MODES:
        mode_id = mode["id"]
        relative = Path("collections") / f"{mode_id}.mp3"
        disk_path = site_root / AUDIO_RELATIVE_ROOT / relative
        modes.append(
            {
                **mode,
                "all": {
                    "src": _public_audio_path(relative),
                    "built": disk_path.is_file(),
                    "durationSeconds": collection_durations.get(mode_id),
                },
            }
        )

    modules: list[dict[str, object]] = []
    for module in MODULES:
        tracks: dict[str, object] = {}
        module_relative = _module_directory(module)
        for mode in MODES:
            mode_id = mode["id"]
            relative = module_relative / f"{mode_id}.mp3"
            disk_path = site_root / AUDIO_RELATIVE_ROOT / relative
            tracks[mode_id] = {
                "src": _public_audio_path(relative),
                "built": disk_path.is_file(),
                "durationSeconds": module_durations.get((module.id, mode_id)),
                "cues": json.loads(disk_path.with_suffix(".cues.json").read_text(encoding="utf-8")) if disk_path.with_suffix(".cues.json").is_file() else [],
            }
        modules.append(
            {
                "id": module.id,
                "slug": module.slug,
                "title": module.title,
                "question": module.question,
                "questionZh": module.question_zh,
                "connections": list(module.connections),
                "factIds": list(module.fact_ids),
                "lines": [
                    {"en": sentence.en, "zh": sentence.zh}
                    for sentence in module.sentences
                ],
                "fullAnswer": " ".join(sentence.en for sentence in module.sentences),
                "fullAnswerZh": "".join(sentence.zh for sentence in module.sentences),
                "tracks": tracks,
                "offsets": {
                    mode["id"]: offsets.get((module.id, mode["id"])) for mode in MODES
                },
            }
        )

    return {
        "version": VERSION,
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "voices": {"english": ENGLISH_VOICE, "chinese": CHINESE_VOICE},
        "audioPattern": {
            "teaching": {
                "sentenceOrder": [
                    "english-preview",
                    "chinese",
                    "english-slow",
                    "english-normal",
                    "english-natural",
                ],
                "ending": [
                    "full-answer-slow",
                    "full-answer-normal",
                    "full-answer-natural",
                ],
            },
            "review": {
                "language": "English only",
                "sequence": [
                    "question-natural",
                    "full-answer-slow",
                    "full-answer-normal",
                    "full-answer-natural",
                ],
                "gapSeconds": 2,
            },
            "mock": {
                "prepareSeconds": 3,
                "answerSeconds": 30,
                "ending": ["full-answer-natural"],
            },
            "followAlongSilence": "max(baseSeconds, wordCount / 1.8 + 1)",
        },
        "modes": modes,
        "modules": modules,
        "safety": {
            "confirmedFacts": list(CONFIRMED_FACTS),
            "unconfirmedFacts": list(UNCONFIRMED_FACTS),
            "notice": SAFETY_NOTICE,
        },
    }


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    temporary = path.with_name(f".{path.name}.building")
    temporary.write_text(encoded, encoding="utf-8")
    temporary.replace(path)


def write_manifests(site_root: Path, manifest: dict[str, object]) -> None:
    """Write byte-identical canonical and root-level player manifests."""

    _write_json(site_root / MANIFEST_RELATIVE_PATH, manifest)
    _write_json(site_root / PUBLIC_MANIFEST_RELATIVE_PATH, manifest)


def copy_player_assets(repository_root: Path, site_root: Path) -> None:
    source_dir = repository_root / "assets"
    missing = [name for name in PLAYER_FILENAMES if not (source_dir / name).is_file()]
    if missing:
        raise FileNotFoundError(
            "missing V18 player assets: "
            + ", ".join((source_dir / name).as_posix() for name in missing)
        )
    destination_dir = site_root / "assets"
    destination_dir.mkdir(parents=True, exist_ok=True)
    for name in PLAYER_FILENAMES:
        shutil.copy2(source_dir / name, destination_dir / name)


def inject_player(index_path: Path) -> bool:
    html = index_path.read_text(encoding="utf-8")
    original = html
    html = html.replace("GoSpeak SWT V12", "GoSpeak SWT V18")
    html = html.replace("GoSpeak SWT V17", "GoSpeak SWT V18")
    if "./assets/listening-v18.css" not in html:
        if "</head>" not in html:
            raise RuntimeError(f"cannot inject V18 stylesheet into {index_path}")
        html = html.replace(
            "</head>",
            '  <link rel="stylesheet" href="./assets/listening-v18.css">\n  </head>',
            1,
        )
    if "./assets/listening-v18.js" not in html:
        if "</body>" not in html:
            raise RuntimeError(f"cannot inject V18 player into {index_path}")
        html = html.replace(
            "</body>",
            '  <script src="./assets/listening-v18.js" defer></script>\n  </body>',
            1,
        )
    if html != original:
        index_path.write_text(html, encoding="utf-8")
        return True
    return False


def patch_month_end_countdown(site_root: Path) -> int:
    """Turn V17's expired exam countdown into a neutral month-end marker."""

    changed = 0
    fixed_declaration = re.compile(
        r"const\s+start\s*=\s*new Date\(2026\s*,\s*8\s*,\s*18\s*\)\s*,\s*"
        r"target\s*=\s*new Date\(2026\s*,\s*8\s*,\s*30\s*,\s*23\s*,\s*59\s*,\s*59\s*\)\s*;"
    )
    dynamic_declaration = (
        "const v18Now = new Date(), "
        "start = new Date(v18Now.getFullYear(), v18Now.getMonth(), 1), "
        "target = new Date(v18Now.getFullYear(), v18Now.getMonth() + 1, 0, 23, 59, 59);"
    )
    for path in (*site_root.rglob("*.js"), *site_root.rglob("*.html")):
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        updated = fixed_declaration.sub(dynamic_declaration, text)
        updated = re.sub(r"目标\s*9月30日", "本月口测", updated)
        updated = re.sub(
            r"天后口测\s*<br>\s*本月口测",
            "天到月底<br>具体口测日期以机构通知为准",
            updated,
        )
        if updated != text:
            path.write_text(updated, encoding="utf-8")
            changed += 1
    return changed


def patch_webmanifest(path: Path) -> bool:
    """Keep the installed PWA name aligned with the visible V18 release."""

    if not path.is_file():
        raise FileNotFoundError(f"web app manifest not found: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as error:
        raise RuntimeError(f"could not read web app manifest: {path}") from error
    original = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    payload["name"] = "GoSpeak SWT V18 连续听练口测冲刺"
    payload["description"] = (
        "无需 GPT 登录的 SWT 口测学习站：14 个事实安全模块、连续听练、跟读与模拟。"
    )
    updated = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    if updated == original:
        return False
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return True


def _service_worker_fingerprint(site_root: Path) -> str:
    """Hash player inputs while ignoring the manifest's build timestamp."""

    digest = hashlib.sha256()
    manifest_path = site_root / PUBLIC_MANIFEST_RELATIVE_PATH
    digest.update(b"manifest\0")
    if manifest_path.is_file():
        raw_manifest = manifest_path.read_bytes()
        try:
            payload = json.loads(raw_manifest.decode("utf-8"))
            if isinstance(payload, dict):
                payload = dict(payload)
                payload.pop("generatedAt", None)
            canonical = json.dumps(
                payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
            digest.update(canonical)
        except (UnicodeDecodeError, json.JSONDecodeError):
            digest.update(raw_manifest)
    else:
        digest.update(b"missing:listening-v18.json")

    for name in PLAYER_FILENAMES:
        relative = Path("assets") / name
        path = site_root / relative
        digest.update(b"\0asset\0")
        digest.update(relative.as_posix().encode("utf-8"))
        digest.update(b"\0")
        if path.is_file():
            digest.update(path.read_bytes())
        else:
            digest.update(b"missing")
    return digest.hexdigest()[:10]


def patch_service_worker(service_worker: Path) -> bool:
    text = service_worker.read_text(encoding="utf-8")
    original = text
    cache_version = f"{SERVICE_WORKER_VERSION}-{_service_worker_fingerprint(service_worker.parent)}"
    text, version_count = re.subn(
        r"const VERSION = ['\"][^'\"]+['\"]\s*;",
        f"const VERSION = '{cache_version}';",
        text,
        count=1,
    )
    if version_count != 1:
        raise RuntimeError(f"could not update cache version in {service_worker}")
    # This Pages origin may host unrelated apps.  Only retire older GoSpeak
    # caches instead of deleting every cache registered on the origin.
    text = text.replace(
        "keys.filter((key) => key !== VERSION)",
        "keys.filter((key) => key !== VERSION && key.startsWith('gospeak-independent-'))",
    )

    core_marker = "// V18_PLAYER_CORE"
    text = text.replace(
        "['listening-v18.json', 'listening-v18.js', 'listening-v18.css']",
        "['listening-v18.json', 'assets/listening-v18.js', 'assets/listening-v18.css']",
    )
    if core_marker not in text:
        install_marker = "self.addEventListener('install'"
        if install_marker not in text:
            raise RuntimeError(f"could not find install handler in {service_worker}")
        extra_core = (
            f"{core_marker}\n"
            "core.push(...['listening-v18.json', 'assets/listening-v18.js', 'assets/listening-v18.css']"
            ".map((path) => new URL(path, BASE).href));\n\n"
        )
        text = text.replace(install_marker, extra_core + install_marker, 1)

    range_marker = "// V18_RANGE_BYPASS"
    legacy_range_guard = (
        f"  {range_marker}\n"
        "  if (event.request.headers.has('range')) {\n"
        "    event.respondWith(fetch(event.request));\n"
        "    return;\n"
        "  }"
    )
    current_bypass_guard = (
        f"  {range_marker}\n"
        "  const requestUrl = new URL(event.request.url);\n"
        "  if (event.request.headers.has('range') || requestUrl.pathname.includes('/audio/v18/')) {\n"
        "    // Do not call respondWith: let the browser perform a native network/Range request.\n"
        "    return;\n"
        "  }"
    )
    text = text.replace(legacy_range_guard, current_bypass_guard)
    if range_marker not in text:
        get_marker = "  if (event.request.method !== 'GET') return;"
        if get_marker not in text:
            raise RuntimeError(f"could not find fetch GET guard in {service_worker}")
        bypass_guard = f"{get_marker}\n{current_bypass_guard}"
        text = text.replace(get_marker, bypass_guard, 1)

    if text != original:
        service_worker.write_text(text, encoding="utf-8")
        return True
    return False


def validate_v17_base(site_root: Path) -> None:
    """Refuse a silent V12 fallback if the preceding V17 build step did not run."""

    index_path = site_root / "index.html"
    if not index_path.is_file():
        raise FileNotFoundError(f"site index not found: {index_path}")
    html = index_path.read_text(encoding="utf-8")
    if './assets/mainline-v19.js' in html:
        if not (site_root / 'interview-v19.json').is_file():
            raise RuntimeError('V19 mainline is present but its course data is missing')
        return
    for name in ("mainline-v17-profile.js", "mainline-v17-profile.css"):
        path = site_root / name
        if not path.is_file() or not path.stat().st_size:
            raise RuntimeError(f"V17 base artifact is missing or empty: {path}")
        if html.count(f"./{name}") != 1:
            raise RuntimeError(f"index must reference ./{name} exactly once")


def integrate_site(repository_root: Path, site_root: Path) -> None:
    index_path = site_root / "index.html"
    service_worker = site_root / "sw.js"
    validate_v17_base(site_root)
    if not service_worker.is_file():
        raise FileNotFoundError(f"service worker not found: {service_worker}")
    copy_player_assets(repository_root, site_root)
    inject_player(index_path)
    patch_month_end_countdown(site_root)
    patch_webmanifest(site_root / "manifest.webmanifest")
    patch_service_worker(service_worker)


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build and integrate GoSpeak V18 continuous-listening audio."
    )
    parser.add_argument("site", type=Path, help="Path to the extracted _site directory")
    parser.add_argument(
        "--skip-audio",
        action="store_true",
        help="validate data/integration and write manifests without calling Edge TTS or ffmpeg",
    )
    parser.add_argument(
        "--jobs",
        type=int,
        default=6,
        help="maximum concurrent Edge TTS requests (default: 6)",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    if args.jobs < 1 or args.jobs > 16:
        raise ValueError("--jobs must be between 1 and 16")

    validate_curriculum()
    site_root = args.site.resolve()
    if not site_root.is_dir():
        raise NotADirectoryError(f"site directory not found: {site_root}")
    repository_root = Path(__file__).resolve().parent.parent
    validate_v17_base(site_root)

    if args.skip_audio:
        module_durations, collection_durations, offsets = inspect_existing_audio(site_root)
    else:
        module_durations, collection_durations, offsets = build_audio(
            site_root,
            concurrency=args.jobs,
            cache_dir=repository_root / ".audio-cache-v18",
        )

    manifest = make_manifest(
        site_root,
        module_durations=module_durations,
        collection_durations=collection_durations,
        offsets=offsets,
    )
    write_manifests(site_root, manifest)
    integrate_site(repository_root, site_root)

    built_modules = sum(
        1
        for module in MODULES
        for mode in MODES
        if (module.id, mode["id"]) in module_durations
    )
    action = "validated (audio skipped)" if args.skip_audio else "built"
    print(
        f"V18 {action}: {len(MODULES)} modules, "
        f"{built_modules}/{len(MODULES) * len(MODES)} module tracks present"
    )
    print(f"manifest: {site_root / PUBLIC_MANIFEST_RELATIVE_PATH}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, NotADirectoryError, RuntimeError, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(1)
