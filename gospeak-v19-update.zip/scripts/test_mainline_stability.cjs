/* Deterministic media/DOM lifecycle checks; no microphone or network. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const listeners = new Map(), frames = [], timers = new Map();
let timerID = 0, created = 0, behavior = () => Promise.resolve(), statusText = '';
class FakeAudio {
  constructor() { created++; this.paused = true; this.currentTime = 0; this.readyState = 0; this.playCalls = 0; this.loads = 0; this.removes = 0; }
  play() { this.playCalls++; this.paused = false; return behavior(); }
  pause() { this.paused = true; }
  removeAttribute(name) { if (name === 'src') { this.src = ''; this.removes++; } }
  load() { this.loads++; this.currentTime = 0; }
}
const document = {
  baseURI: 'https://example.test/', readyState: 'loading', documentElement: {},
  querySelector() { return null; }, querySelectorAll() { return []; }, addEventListener() {}
};
const window = {
  addEventListener(name, fn) { (listeners.get(name) || (listeners.set(name, []), listeners.get(name))).push(fn); },
  dispatchEvent(event) { for (const fn of listeners.get(event.type) || []) fn(event); },
  requestAnimationFrame(fn) { frames.push(fn); }
};
const sandbox = {
  window, document, Audio: FakeAudio, URL, Promise,
  localStorage: { getItem() { return null; }, setItem() {} },
  CustomEvent: class { constructor(type, options) { this.type = type; this.detail = options.detail; } },
  MutationObserver: class { constructor(callback) { this.callback = callback; } observe() {} },
  setTimeout(fn) { const id = ++timerID; timers.set(id, fn); return id; },
  clearTimeout(id) { timers.delete(id); }
};
const file = path.join(__dirname, '../assets/mainline-v19.js');
const source = fs.readFileSync(file, 'utf8').replace(/\}\)\(\);\s*$/, 'window.test={state,playClip,stopSound,mountRecorders,mount,scheduleMount};})();');
vm.runInNewContext(source, sandbox, { filename: file });
const t = window.test;
const root = {
  querySelector() { return { set textContent(value) { statusText = value; } }; },
  querySelectorAll() { return []; }, contains(node) { return node === root; }
};
t.state.root = root;
function play(key = 'sentence') { t.playClip({ src: 'example.mp3', text: 'I am Sam.', rate: 1 }, key, null, false); }
function tick(id) { const fn = timers.get(id); assert(fn, 'timer exists'); timers.delete(id); fn(); }
async function settle() { await Promise.resolve(); await Promise.resolve(); await Promise.resolve(); }

(async function () {
  for (let i = 0; i < 100; i++) play('word-' + i);
  await settle();
  assert.equal(created, 1, 'rapid word taps reuse exactly one media element');
  assert.equal(t.state.audioKey, 'word-99');
  const element = t.state.audioElement;
  assert.equal(element.removes, 99, 'every superseded source is released');
  t.stopSound();
  assert.equal(t.state.audio, null); assert.equal(element.src, '');
  assert.equal(element.onended, null); assert.equal(element.onerror, null);
  assert.equal(timers.size, 0, 'stop cancels pending repeat and loading work');

  behavior = () => Promise.reject(new Error('NotAllowedError'));
  play('retry'); await settle();
  assert.equal(t.state.audioKey, '', 'rejected play cannot leave an active toggle trap');
  assert.equal(t.state.audio, null);
  const beforeRetry = element.playCalls;
  behavior = () => Promise.resolve();
  play('retry'); await settle();
  assert.equal(element.playCalls, beforeRetry + 1, 'the very next tap actually retries');
  assert.equal(t.state.audioKey, 'retry');
  t.stopSound();

  let resolvePending;
  behavior = () => new Promise(resolve => { resolvePending = resolve; });
  play('hung');
  tick(t.state.audioWatchdog);
  assert.equal(t.state.audio, null, 'a hung media request times out without trapping the UI');
  const timeoutMessage = statusText;
  assert(timeoutMessage.includes('超时'));
  resolvePending(); await settle();
  assert.equal(statusText, timeoutMessage, 'late fulfillment cannot revive an abandoned attempt');

  let rejectOld;
  behavior = () => new Promise((_, reject) => { rejectOld = reject; });
  play('old');
  behavior = () => Promise.resolve(); play('new'); await settle();
  rejectOld(new Error('aborted')); await settle();
  assert.equal(t.state.audioKey, 'new', 'old rejection cannot stop newer playback');
  element.onwaiting();
  const progressWatchdog = t.state.audioWatchdog;
  element.currentTime = 1;
  tick(progressWatchdog);
  assert.equal(t.state.audioKey, 'new', 'progressing playback is not falsely timed out');
  element.paused = true; element.onpause();
  assert.equal(t.state.audio, null, 'an OS/browser pause releases the stale active button');

  t.state.loop = 3;
  const beforeLoop = element.playCalls;
  play('repeat'); await settle();
  for (let i = 0; i < 2; i++) { element.onended(); tick(t.state.audioTimer); await settle(); }
  element.onended();
  assert.equal(element.playCalls - beforeLoop, 3, 'finite repeat plays exactly the requested count');
  assert.equal(t.state.audio, null);
  t.state.loop = 0; play('forever'); await settle(); element.onended();
  window.dispatchEvent({ type: 'gospeak-playback-request', detail: { owner: 'listening-v18' } });
  assert.equal(t.state.audio, null); assert.equal(timers.size, 0, 'another player cancels the pending repeat');
  t.state.loop = 1;

  let mounted = 0, destroyed = 0;
  window.SamRecorder = { mount() { mounted++; return { destroy() { destroyed++; return Promise.resolve(); }, isRecording() { return false; } }; } };
  const details = { tagName: 'DETAILS', open: false, parentElement: root };
  function recorderNode(parent) {
    const attrs = { 'data-sam-recorder': '0' };
    return { parentElement: parent, getAttribute(name) { return attrs[name]; }, setAttribute(name, value) { attrs[name] = value; } };
  }
  const hiddenNode = recorderNode(details), visibleNode = recorderNode(root);
  root.querySelectorAll = () => [hiddenNode, visibleNode];
  t.state.recorderTargets = [{ id: 'test' }];
  t.mountRecorders(); assert.equal(mounted, 1, 'closed details do not initialize recorders');
  t.mountRecorders(); assert.equal(mounted, 1, 'visible recorders only initialize once');
  details.open = true; t.mountRecorders(); assert.equal(mounted, 2, 'opening details enables its recorder once');
  root.querySelectorAll = () => [];
  play('before-navigation'); await settle();
  t.mount();
  assert.equal(destroyed, 2, 'leaving the mainline cleans up all mounted recorders');
  assert.equal(t.state.recorders.length, 0); assert.equal(t.state.audio, null);
  t.mount(); assert.equal(destroyed, 2, 'repeated detached checks do not repeatedly destroy resources');

  for (let i = 0; i < 100; i++) t.scheduleMount([{ target: {} }]);
  assert.equal(frames.length, 1, 'mutation bursts coalesce to one mount check per frame');
  frames.shift()();
  t.scheduleMount([{ target: root }]);
  assert.equal(frames.length, 0, 'internal mainline updates do not schedule remounts');
  assert.equal(created, 1, 'all playback scenarios retained one reusable audio element');
  console.log('PASS: rapid taps, resource release, immediate rejection retry, timeout recovery, stale promises, buffering progress, bounded repeats, cross-player stop, lazy recorders, navigation cleanup, coalesced mutations.');
})().catch(error => { console.error(error); process.exitCode = 1; });
