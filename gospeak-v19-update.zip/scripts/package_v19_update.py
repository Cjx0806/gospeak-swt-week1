"""Small post-release overlay for cache-safe V19 upgrades; no audio copied."""
from pathlib import Path
import zipfile
from verify_v19 import verify

root = Path(__file__).resolve().parents[1]
site = root / '_site'
verify(site)
paths = [site / name for name in ('index.html','sw.js','manifest.webmanifest','interview-v19.json','listening-v18.json','audio/v18/manifest.json')]
paths += list((site/'assets').glob('*.js')) + list((site/'assets').glob('*.css'))
paths += [p for folder in ('assets','scripts') for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.startswith('.')]
with zipfile.ZipFile(root/'gospeak-v19-update.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(set(paths)):
        archive.write(p,p.relative_to(root))
assert (root/'gospeak-v19-update.zip').stat().st_size < 1_500_000
print('Cache-safe overlay:', (root/'gospeak-v19-update.zip').stat().st_size)
