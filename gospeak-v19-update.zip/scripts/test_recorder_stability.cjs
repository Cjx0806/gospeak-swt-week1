'use strict';
// Offline browser mocks only. No real microphone, network, or user recordings.
const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const { join } = require('node:path');
const vm = require('node:vm');

class Element {
  constructor() {
    this.children = new Map(); this.listeners = new Map(); this.open = false;
    this.textContent = ''; this.innerHTML = ''; this.hidden = false;
    this.disabled = false; this.checked = false; this.style = {};
    this.firstElementChild = { style: {} }; this.attributes = {};
    this.classList = { add() {}, remove() {} };
  }
  querySelector(selector) { if (!this.children.has(selector)) this.children.set(selector, new Element()); return this.children.get(selector); }
  addEventListener(name, fn) { this.listeners.set(name, fn); }
  removeEventListener(name) { this.listeners.delete(name); }
  setAttribute(name, value) { this.attributes[name] = value; }
  removeAttribute(name) { delete this.attributes[name]; }
  pause() {}
  load() {}
  scrollIntoView() {}
}

const records = new Map(), tracks = [], meterBuffers = [], frames = new Map();
let opens = 0, reads = 0, now = 0, frameSequence = 0, getMedia = null;
function stream() {
  const track = { stopped: false, stop() { this.stopped = true; } };
  tracks.push(track); return { getTracks: () => [track] };
}
class FakeRecorder {
  static isTypeSupported(type) { return type === 'audio/mp4'; }
  constructor(mediaStream) { this.stream = mediaStream; this.state = 'inactive'; this.mimeType = 'audio/mp4'; }
  start() { this.state = 'recording'; }
  stop() {
    this.state = 'inactive';
    queueMicrotask(() => { this.ondataavailable({ data: new Blob(['test'], { type: this.mimeType }) }); this.onstop(); });
  }
}
class FakeContext {
  constructor() { this.state = 'running'; }
  createMediaStreamSource() { return { connect() {}, disconnect() {} }; }
  createAnalyser() { return { fftSize: 1024, getByteTimeDomainData(buffer) { meterBuffers.push(buffer); buffer.fill(130); } }; }
  close() { this.state = 'closed'; return Promise.resolve(); }
}
const db = {
  objectStoreNames: { contains: () => true },
  close() {},
  transaction() {
    const tx = {};
    tx.objectStore = () => ({
      getAll() { reads++; const request = {}; queueMicrotask(() => { request.result = [...records.values()]; request.onsuccess(); }); return request; },
      put(record) { records.set(record.key, record); queueMicrotask(() => tx.oncomplete?.()); },
      delete(key) { records.delete(key); queueMicrotask(() => tx.oncomplete?.()); }
    });
    return tx;
  }
};
const root = {
  document: new Element(), isSecureContext: true,
  navigator: { mediaDevices: { getUserMedia: () => getMedia ? getMedia() : Promise.resolve(stream()) } },
  MediaRecorder: FakeRecorder, AudioContext: FakeContext,
  indexedDB: { open() { opens++; const request = {}; queueMicrotask(() => { request.result = db; request.onsuccess(); }); return request; } },
  performance: { now: () => now }, URL: { createObjectURL: () => 'blob:local-test', revokeObjectURL() {} },
  setTimeout, clearTimeout, setInterval, clearInterval,
  requestAnimationFrame(callback) { const id = ++frameSequence; frames.set(id, callback); return id; },
  cancelAnimationFrame(id) { frames.delete(id); },
  addEventListener() {}, removeEventListener() {}, dispatchEvent() {}
};
vm.runInNewContext(readFileSync(join(__dirname, '../assets/recorder-v19.js'), 'utf8'), {
  window: root, Blob, Uint8Array, Promise, Date, Math,
  CustomEvent: class { constructor(type, init) { this.type = type; this.detail = init.detail; } }
});
const flush = () => new Promise(resolve => setTimeout(resolve, 0));
const make = id => {
  const container = new Element();
  return { container, api: root.SamRecorder.mount(container, { id, expectedText: 'I am Sam.', kind: 'sentence' }),
    el: name => container.querySelector('.sam-recorder__' + name) };
};
const toggle = (widget, open) => { widget.el('history').open = open; widget.el('history').listeners.get('toggle')(); };
const tickFrame = time => { now = time; const pending = [...frames.values()]; frames.clear(); pending.forEach(callback => callback(time)); };

(async () => {
  for (let i = 0; i < 18; i++) records.set('old-' + i, {
    key: 'old-' + i, targetId: 'q' + (i % 6), createdAt: i, duration: 3,
    blob: new Blob(['old mock audio'], { type: 'audio/mp4' })
  });
  const widgets = Array.from({ length: 16 }, (_, i) => make('q' + i));
  await flush();
  assert.equal(opens, 0, 'mounting many collapsed widgets must not open IndexedDB');
  assert.equal(reads, 0, 'mounting does not load or clone all recording Blobs');
  toggle(widgets[0], true); toggle(widgets[1], true); toggle(widgets[2], true);
  toggle(widgets[2], false); // Closing while the shared read is in progress.
  await flush();
  assert.equal(reads, 1, 'concurrent open histories share one getAll call');
  assert.match(widgets[0].el('history-list').innerHTML, /查看 \/ 回听/);
  assert.equal(widgets[2].el('history-list').innerHTML, '', 'late history data cannot repopulate a closed widget');
  toggle(widgets[0], false);
  assert.equal(widgets[0].el('history-list').innerHTML, '', 'closing releases rendered history');
  toggle(widgets[0], true); await flush();
  assert.equal(reads, 2, 'no permanent Blob cache: reopening performs one fresh read');
  for (const widget of widgets) await widget.api.destroy();

  const pending = make('permission-cancel'); let grantOld;
  getMedia = () => new Promise(resolve => { grantOld = resolve; });
  const oldStart = pending.api.start();
  assert.equal(pending.api.isRecording(), true);
  assert.equal(pending.el('stop').disabled, false, 'permission wait has an enabled cancel control');
  await pending.api.stop();
  assert.equal(pending.api.isRecording(), false, 'cancel immediately frees playback and other exercises');
  assert.match(pending.el('status').textContent, /继续点读/);
  getMedia = null;
  await pending.api.start();
  const newTrack = tracks.at(-1);
  const oldStream = stream(); grantOld(oldStream); await oldStart;
  assert.equal(oldStream.getTracks()[0].stopped, true, 'late grant from canceled request is stopped');
  assert.equal(newTrack.stopped, false, 'late grant cannot stop the newer recording');
  assert.equal(pending.api.isRecording(), true);

  const initialSamples = meterBuffers.length;
  for (let time = 10; time < 100; time += 10) tickFrame(time);
  assert.equal(meterBuffers.length, initialSamples, 'meter is throttled instead of mutating the DOM every frame');
  tickFrame(100);
  assert.equal(meterBuffers.length, initialSamples + 1);
  assert.equal(meterBuffers.at(-1), meterBuffers.at(-2), 'meter reuses one byte buffer');
  now += 3000; await pending.api.stop(); await pending.api.destroy();
  assert(tracks.every(track => track.stopped));
  assert.equal(frames.size, 0, 'all animation callbacks canceled after recording');

  const rejection = make('late-rejection'); let rejectOld;
  getMedia = () => new Promise((resolve, reject) => { rejectOld = reject; });
  const rejectedStart = rejection.api.start(); await rejection.api.stop();
  getMedia = null; await rejection.api.start();
  rejectOld({ name: 'NotAllowedError' }); await rejectedStart;
  assert.equal(rejection.api.isRecording(), true, 'late rejection cannot cancel a new capture');
  assert.match(rejection.el('status').textContent, /正在录音/);
  now += 3000; await rejection.api.stop(); await rejection.api.destroy();
  assert(tracks.every(track => track.stopped));
  console.log('Recorder stability passed: lazy histories, shared Blob reads, closed-history cleanup, cancellable permissions, late grant/rejection isolation, throttled reusable meter, capture cleanup.');
})().catch(error => { console.error(error); process.exitCode = 1; });
