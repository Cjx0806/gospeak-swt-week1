"""Package explicitly scoped static assets for GitHub's 25 MB upload limit."""
import hashlib
import json
from pathlib import Path
import zipfile
from verify_v19 import verify

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / '_site'
verify(SITE)

def archive(name, paths, base):
    output = ROOT / name
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=5) as z:
        for p in sorted(paths):
            if p.is_file(): z.write(p,p.relative_to(base))
    assert output.stat().st_size < 25_000_000, (name,output.stat().st_size)
    with zipfile.ZipFile(output) as z: assert z.testzip() is None
    print(name, output.stat().st_size, hashlib.sha256(output.read_bytes()).hexdigest())

archive('gospeak-v19-site.zip', [p for p in SITE.rglob('*') if p.is_file()
    and 'audio/v18/' not in p.relative_to(SITE).as_posix()
    and not p.name.startswith('mainline-v17') and 'junxi' not in p.name.lower()
    and not any(part.startswith('.') or part.endswith(' 2') for part in p.relative_to(SITE).parts)], SITE)
archive('gospeak-v19-listening-modules.zip', list((SITE/'audio/v18/modules').rglob('*')) + [SITE/'audio/v18/manifest.json'], SITE)
archive('gospeak-v19-listening-collections.zip', list((SITE/'audio/v18/collections').rglob('*')), SITE)
archive('gospeak-v19-source.zip', [p for d in ('assets','scripts') for p in (ROOT/d).rglob('*')
    if p.is_file() and '__pycache__' not in p.parts and not p.name.startswith('.')], ROOT)
