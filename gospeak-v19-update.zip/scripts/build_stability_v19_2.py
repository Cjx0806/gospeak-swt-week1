"""Apply a small, reproducible stability hotfix to the verified V19.1 site."""
from pathlib import Path
import hashlib
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / '_site'

def build():
    for name in ['mainline-v19.js', 'recorder-v19.js', 'listening-v18.js', 'audio-recovery.js']:
        shutil.copy2(ROOT / 'assets' / name, SITE / 'assets' / name)
    legacy = SITE / 'assets/index-C6MAz4Oq.js'
    source = legacy.read_text()
    start = source.index('/* V19.2 replacement') if '/* V19.2 replacement' in source else source.index('function q(e=!0)')
    end = source.index('function Fe()', start)
    source = source[:start] + (ROOT / 'assets/legacy-audio-stability.js').read_text() + '\n' + source[end:]
    source = source.replace('./sw.js?v=19.1', './sw.js?v=19.2')
    legacy.write_text(source)
    page = SITE / 'index.html'
    html = page.read_text()
    html = re.sub(r'\?v=19\.[12](?=["\'])', '?v=19.2', html)
    html = html.replace('GoSpeak SWT V19｜', 'GoSpeak SWT V19.2｜')
    if 'id="sam-audio-recovery"' not in html:
        html = html.replace('<div id="app"></div>', '''<aside id="sam-audio-recovery" aria-label="声音帮助" style="max-width:1200px;margin:8px auto;padding:10px 16px;background:#edf6ef;border-radius:12px;font:14px/1.5 system-ui;color:#173d2e;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><span><b>V19.2 · 播放稳定修复</b></span><button type="button" style="min-height:44px;border:1px solid #173d2e;border-radius:9px;background:white;color:#173d2e;padding:8px 14px;font:inherit">声音没反应？恢复声音</button><span role="status" aria-live="polite">加载时会显示提示，不用反复连点。</span></aside>\n    <div id="app"></div>''')
    if './assets/audio-recovery.js' not in html:
        html = html.replace('</body>', '<script src="./assets/audio-recovery.js?v=19.2" defer></script>\n</body>')
    page.write_text(html)
    # Updating must not download 154 obsolete audio files (they bypass the SW
    # on playback anyway). Only core text/UI assets are required for install.
    sw = SITE / 'sw.js'
    worker = sw.read_text().replace("'19.1'", "'19.2'")
    worker = worker.replace(", ...phraseAudio, ...coachAudio, ...shadowAudio", '')
    if 'assets/audio-recovery.js' not in worker:
        worker = worker.replace('// V19_VERSIONED_CACHE', "core.push(new URL('assets/audio-recovery.js', BASE).href);\n// V19_VERSIONED_CACHE")
    digest = hashlib.sha256(''.join(p.read_text() for p in sorted((SITE/'assets').glob('*.js'))).encode()).hexdigest()[:12]
    worker = re.sub(r"const VERSION = '[^']+';", f"const VERSION = 'gospeak-independent-v19.2-{digest}';", worker)
    sw.write_text(worker)
    print('V19.2 stability hotfix prepared; existing audio and saved practice IDs preserved.')

if __name__ == '__main__':
    build()
