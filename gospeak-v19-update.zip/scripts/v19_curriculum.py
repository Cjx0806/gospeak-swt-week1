"""Sam's fact-aware SWT agency interview bank (V19).

These are original, short teaching examples, not guaranteed interview answers.
Only confirmed biography is put in the default spoken answers.  A hypothetical
workplace response describes a possible action, not past work experience.
An empty ``short`` answer is intentional: the learner must choose and verify a
``branches`` answer first.  Never flatten unconfirmed branches into an autoplay
playlist.  Square-bracket slots must be filled before speech or assessment.
"""

from __future__ import annotations

import json
import re

VERSION = "v19"

PROFILE = {
    "englishName": "Sam",
    "englishNameIpa": "sæm",
    "schoolZh": "广西幼儿师范高等专科学校",
    "schoolEn": "Guangxi College for Preschool Education",
    "schoolNameNote": "沿用课程中的英文校名；正式材料请以学校提供的英文名称为准。Guangxi 按中文地名读音表达。",
    "majorZh": "体育体能训练",
    "majorEn": "physical fitness training",
    "yearZh": "大一",
    "yearEn": "first-year student",
    "certificateZh": "中国国职游泳救生员证",
    "certificateEn": "a Chinese lifeguard certificate",
    "goals": ["体验美国文化", "提高英语"],
    "currentAbility": "可以完成简单的脱稿自我介绍；其余题目需要听题、接话和追问训练。",
    "returnPlan": "本人确认：项目结束后回中国，继续在广西幼儿师范高等专科学校读书；具体日期尚未确定。",
    "returnPlanEn": "I will return to China after the program and continue my studies.",
    "photoSelfReport": {"age": 19, "likesSwimming": True, "trainingTopics": ["safe exercise", "fitness", "teamwork"], "traits": ["responsible", "patient", "willing to learn"]},
    "namePrivacyNote": "英文称呼使用 Sam；不把英文名当护照法律姓名。照片中的中文姓名拼写不用于替换或公开法律身份。",
    "notConfirmed": ["具体口测日期", "学校开学日期与具体回国行程", "父母态度", "护照状态", "兼职经历", "旅行经历", "连续游泳距离", "具体工作日期", "毕业后的职业计划"],
}

SOURCE_NOTES = [
    {
        "title": "U.S. Department of State — BridgeUSA Summer Work Travel",
        "url": "https://j1visa.state.gov/programs/summer-work-travel/",
        "checkedOn": "2026-10-10",
        "summary": "官方将暑期接触美国人及其生活方式列为 SWT 的交流目的；参加者需具备在英语环境中互动的能力，并在本国学校开学前回国。",
        "teachingImplication": "说想了解文化、和当地人交流并不等同于有滞留意图。用 during the program 说明情境；被问到后续计划时如实回答，不编造返校日期、机票或家庭约束。机构口测与签证面谈不是同一次考核。",
    }
]

TRAINING_PLAN = {
    "title": "SWT 机构口测冲刺：从会背自介，到听懂随机提问",
    "deadlineNote": "本月口测，具体日期待 Sam 确认；不伪造倒计时。",
    "method": "每天 2 个新主题＋2 个旧题；每个新题先练 2—3 句短答，再按需加 1—2 句。不要一天背完 24 篇。",
    "daily60": [
        {"minutes": 10, "task": "不看答案，复测昨天 2 题；自我介绍只复习一次，不再占用大半时间。"},
        {"minutes": 10, "task": "听今天 2 题的不同问法；先辨认问什么，再用中文说出答题方向。"},
        {"minutes": 15, "task": "每题理解 2—3 句短答，补最多 5 个表达缺口，分句慢速跟读后回到标准速。"},
        {"minutes": 15, "task": "同题回答 3 遍：看句子→只看关键词→不看稿；第三遍录音。"},
        {"minutes": 10, "task": "随机抽问和追问；回听录音，只改最影响理解的 1—2 个问题，再录一遍。"},
    ],
    "extra30": "增加听不同问法、昨日脱稿复测和随机模拟，不增加大量新视频或大段新答案。",
    "extra60": "额外做两轮 15 分钟随机模拟、15 分钟录音对照、15 分钟薄弱题复测。",
    "days": [
        {"day": 1, "new": ["02", "03"], "review": ["01", "20"], "focus": "区分 why America 与 why SWT；自介只保温。"},
        {"day": 2, "new": ["04", "05"], "review": ["02", "03"], "focus": "目标、具体行动、岗位证书边界。"},
        {"day": 3, "new": ["06", "07"], "review": ["04", "05"], "focus": "优缺点不空喊；补真实例子。"},
        {"day": 4, "new": ["08", "09"], "review": ["06", "07"], "focus": "听不懂与犯错：先确认，再行动。"},
        {"day": 5, "new": ["10", "11"], "review": ["08", "09"], "focus": "同事冲突、压力与困难。"},
        {"day": 6, "new": ["12", "23"], "review": ["10", "11"], "focus": "文化差异与最感兴趣的部分。"},
        {"day": 7, "new": [], "review": ["02", "03", "05", "08", "09", "10"], "focus": "不加新题，打乱顺序模拟；记录最多 5 个缺口。"},
        {"day": 8, "new": ["13", "16"], "review": ["12", "23"], "focus": "核实爱好和菜品，练具体表达。"},
        {"day": 9, "new": ["14", "15"], "review": ["13", "16"], "focus": "兼职和旅行只用本人真实经历；无经历也能如实回答。"},
        {"day": 10, "new": ["17", "18"], "review": ["14", "15"], "focus": "核实家庭支持、护照状态。"},
        {"day": 11, "new": ["19", "20"], "review": ["17", "18"], "focus": "游泳能力、专业和年级，数字不能猜。"},
        {"day": 12, "new": ["21", "22"], "review": ["19", "20"], "focus": "核实毕业方向与项目结束后的真实安排。"},
        {"day": 13, "new": ["24"], "review": ["02", "05", "08", "22"], "focus": "核实可工作日期；混合问法与追问。"},
        {"day": 14, "new": [], "review": ["01", "03", "06", "09", "12", "22"], "focus": "两轮随机模拟，所有题先短答再展开；剩余薄弱题进入下一轮。"},
    ],
    "ifLessThanSevenDays": "先练 02—12、22 的真实计划和 24 的真实日期；其余题先核实中文事实并练一句直接回答，不硬背长稿。",
    "successCriteria": ["听懂当前问题而非机械背稿", "约 3 秒内开始回应或使用澄清句", "短答切题，展开后可连贯说约 20—40 秒", "不编造经历，关键个人信息准确", "能接一个追问；不懂时会请求重复或解释"],
    "assessmentLimit": "浏览器转写只能帮助核对识别到的词，不能可靠诊断某个音素是否标准；自动识别失败不等于发音错误，识别成功也不等于口音满分。",
}


def S(en, zh, ipa="", chunks=None, grammar="", pronunciation=""):
    return {"en": en, "zh": zh, "ipa": ipa, "chunks": chunks or [en], "grammar": grammar, "pronunciation": pronunciation}


def P(en, zh):
    return {"en": en, "zh": zh}


def B(id, label, condition, sentences):
    return {"id": id, "label": label, "condition": condition, "sentences": sentences, "confirmed": False}


def Q(id, title, question, questionZh, variants, short, extra, followups, keywords,
      note="", requiresConfirmation=None, priority=1, branches=None):
    return {
        "id": id, "title": title, "question": question, "questionZh": questionZh,
        "variants": [P(*p) for p in variants], "short": short, "extra": extra,
        "followups": [P(*p) for p in followups], "keywords": keywords, "note": note,
        "requiresConfirmation": requiresConfirmation or [], "priority": priority,
        "branches": branches or [], "readyForAutoplay": bool(short),
    }


QUESTIONS = [
    Q("01", "自我介绍：保温，不再从零重背", "Please introduce yourself briefly.", "请简单介绍一下你自己。",
      [("Could you tell me a little about yourself?", "可以简单介绍一下你自己吗？"),
       ("How would you introduce yourself?", "你会怎样介绍自己？"),
       ("Please tell me your name, school, and major.", "请告诉我你的名字、学校和专业。")],
      [S("Hello, my name is Sam.", "你好，我叫 Sam。", "həˈloʊ | maɪ neɪm ɪz sæm", ["Hello,", "my name is Sam."], "Hello 是招呼语；my name 主语＋is 系动词＋Sam 表语。", "Sam /sæm/：嘴张开，结尾双唇闭合发 /m/，不要读成 same /seɪm/。"),
       S("I am a first-year student at Guangxi College for Preschool Education.", "我是广西幼儿师范高等专科学校的大一学生。", "aɪ æm ə ˈfɝst jɪr ˈstudənt | ət ɡwɑŋˈʃi ˈkɑlɪdʒ fər ˈpriskul ˌɛdʒəˈkeɪʃən", ["I am a first-year student", "at Guangxi College for Preschool Education."], "I 主语＋am 系动词＋a first-year student 表语；at... 补充学校。", "先连好 I am a，再在 student 后轻停；Guangxi 是中文地名，音标仅为近似提示。"),
       S("My major is physical fitness training.", "我的专业是体育体能训练。", "maɪ ˈmeɪdʒər ɪz ˈfɪzɪkəl ˈfɪtnəs ˈtreɪnɪŋ", ["My major is", "physical fitness training."], "My major 主语＋is 系动词＋physical fitness training 表语。", "physical 的 ph 发 /f/；training 重读前半部分。")],
      [S("I also have a Chinese lifeguard certificate.", "我也有中国游泳救生员证。"),
       S("I want to experience American culture and improve my English.", "我想体验美国文化并提高英语。")],
      [("What is your major?", "你的专业是什么？"), ("Why do you want to join SWT?", "你为什么想参加 SWT？")],
      ["Sam", "first-year student", "physical fitness training", "Chinese lifeguard certificate"],
      "你已经能脱稿自介，今天只录一遍保温。姓名 Sam 只用于英文称呼，不修改护照法律姓名。需要更完整时再加证书和目标两句。", priority=2),

    Q("02", "为什么选择美国", "Why did you choose the United States?", "你为什么选择美国？",
      [("Why do you want to go to America?", "你为什么想去美国？"),
       ("What interests you about the United States?", "美国的什么让你感兴趣？"),
       ("Why are you interested in American culture?", "你为什么对美国文化感兴趣？")],
      [S("I am interested in American culture.", "我对美国文化感兴趣。", "aɪ æm ˈɪntrəstɪd ɪn əˈmɛrɪkən ˈkʌltʃər", ["I am interested in", "American culture."], "I 主语＋am 系动词＋interested in American culture 表语。", "interested in 连成一个句块；culture 第一音节重读。"),
       S("During the program, I want to learn about daily life there.", "项目期间，我想了解那里的日常生活。", "ˈdʊrɪŋ ðə ˈproʊɡræm | aɪ wɑnt tə lɝn əˈbaʊt ˈdeɪli laɪf ðɛr", ["During the program,", "I want to learn about daily life there."], "During the program 时间状语；I 主语＋want 谓语＋to learn... 不定式补语。", "during the program 说明项目期间；daily life 不要逐字长停顿。"),
       S("I also want to improve my English through daily conversations.", "我也想通过日常交流提高英语。", "aɪ ˈɔlsoʊ wɑnt tə ɪmˈpruv maɪ ˈɪŋɡlɪʃ | θru ˈdeɪli ˌkɑnvərˈseɪʃənz", ["I also want to improve my English", "through daily conversations."], "I 主语；also 状语；want 谓语；to improve... 补语；through... 方式状语。", "through 的 th /θ/ 轻咬舌尖；不是 /s/。")],
      [S("For example, I would talk with coworkers during breaks.", "例如，我会在休息时和同事交流。")],
      [("What would you like to learn about?", "你具体想了解什么？"), ("What will you do after the program?", "项目结束后你会做什么？")],
      ["American culture", "during the program", "daily life", "daily conversations"],
      "了解文化、接触当地人符合 SWT 交流目的，并不自动等于滞留。这里加上项目期间的范围，不编造回国行程；后续安排请去第 22 题确认。没有任何一句话能保证面试结果。"),

    Q("03", "为什么参加 SWT，而不只是旅游", "Why do you want to join the SWT program?", "你为什么想参加 SWT 项目？",
      [("Why are you applying for SWT?", "你为什么报名 SWT？"),
       ("Why did you choose this program?", "你为什么选择这个项目？"),
       ("Why SWT instead of a regular holiday?", "为什么选择 SWT 而不只是普通旅游？")],
      [S("I want to experience American culture and improve my English.", "我想体验美国文化并提高英语。", "aɪ wɑnt tə ɪkˈspɪriəns əˈmɛrɪkən ˈkʌltʃər | ænd ɪmˈpruv maɪ ˈɪŋɡlɪʃ", ["I want to experience American culture", "and improve my English."], "I 主语＋want 谓语；to experience... 和 improve... 是由 and 连接的两个目标。", "两个目标在 and 处衔接，不必重新说 I want to。"),
       S("SWT offers a chance to use English in a work setting.", "SWT 提供了在工作情境中使用英语的机会。", "ˌɛs ˌdʌbəlju ˈti ˈɔfərz ə tʃæns | tə juz ˈɪŋɡlɪʃ ɪn ə wɝk ˈsɛtɪŋ", ["SWT offers a chance", "to use English in a work setting."], "SWT 主语＋offers 谓语＋a chance 宾语；to use... 后置修饰 chance。", "SWT 逐个字母读；动词 use 结尾是 /z/。"),
       S("That is what makes this program interesting to me.", "这就是这个项目吸引我的地方。", "ðæt ɪz wʌt meɪks ðɪs ˈproʊɡræm ˈɪntrəstɪŋ tə mi", ["That is", "what makes this program interesting to me."], "That 主语＋is 系动词＋what... 表语从句。", "That is 连起来；重读 interesting。")],
      [S("I would follow the workplace rules and learn from feedback.", "我会遵守工作规则，并从反馈中学习。")],
      [("How is this different from a vacation?", "这和度假有什么不同？"), ("What do you hope to gain?", "你希望获得什么？")],
      ["culture", "English", "work setting", "learn from feedback"],
      "这题重点是项目形式如何帮助你的目标，不要与“为什么美国”完全复制。work setting 指项目中的工作场景，不是长期职业移居计划。"),

    Q("04", "项目目标与具体计划", "What are your goals and plans for the program?", "你对项目有什么目标和计划？",
      [("What do you hope to gain from SWT?", "你希望从 SWT 获得什么？"),
       ("How will you make the most of the program?", "你会怎样充分利用这次项目？"),
       ("What would you do during the program?", "项目期间你会做些什么？")],
      [S("My goals are to improve my English and learn about American culture.", "我的目标是提高英语并了解美国文化。", "maɪ ɡoʊlz ɑr tə ɪmˈpruv maɪ ˈɪŋɡlɪʃ | ænd lɝn əˈbaʊt əˈmɛrɪkən ˈkʌltʃər", ["My goals are to improve my English", "and learn about American culture."], "My goals 主语＋are 系动词＋两个不定式目标作表语。"),
       S("I would practice speaking every day and ask questions when needed.", "我会每天练习口语，在需要时提问。", "aɪ wʊd ˈpræktɪs ˈspikɪŋ ˈɛvri deɪ | ænd æsk ˈkwɛstʃənz wɛn ˈnidɪd", ["I would practice speaking every day", "and ask questions when needed."], "I 主语；would 表示设想；practice 与 ask 是并列动词；every day 时间状语。", "practice 后接 speaking，不说 practice to speak。"),
       S("I would also follow my work schedule and the program rules.", "我也会遵守工作安排和项目规则。", "aɪ wʊd ˈɔlsoʊ ˈfɑloʊ maɪ wɝk ˈskɛdʒul | ænd ðə ˈproʊɡræm rulz", ["I would also follow my work schedule", "and the program rules."], "I 主语＋would follow 谓语＋两个并列宾语。")],
      [S("In my free time, I would join suitable cultural activities.", "空闲时，我会参加合适的文化活动。")],
      [("How will you practice English?", "你会怎样练习英语？"), ("How will you know you have improved?", "你怎样判断自己进步了？")],
      ["two goals", "practice every day", "ask questions", "follow rules"],
      "这是可以采用的行动计划，不声称你已经完成这些行动。先确认愿意执行，再把 would 改成更坚定的 I plan to。"),

    Q("05", "岗位选择与中国救生员证", "What kind of job are you interested in?", "你对什么岗位感兴趣？",
      [("Would you like to work as a lifeguard?", "你想做救生员吗？"),
       ("Do you have any relevant qualifications?", "你有相关资质吗？"),
       ("Would you consider another suitable position?", "你愿意考虑其他合适岗位吗？")],
      [S("I am interested in lifeguarding, but I am open to other suitable jobs.", "我对救生员工作感兴趣，但也愿意考虑其他合适的岗位。", "aɪ æm ˈɪntrəstɪd ɪn ˈlaɪfɡɑrdɪŋ | bət aɪ æm ˈoʊpən tə ˈʌðər ˈsutəbəl dʒɑbz", ["I am interested in lifeguarding,", "but I am open to other suitable jobs."], "两个 I am... 主系表句；but 表示转折；open to 表示愿意考虑。"),
       S("I have a Chinese lifeguard certificate.", "我有中国游泳救生员证。", "aɪ hæv ə tʃaɪˈniz ˈlaɪfɡɑrd sərˈtɪfɪkət", ["I have", "a Chinese lifeguard certificate."], "I 主语＋have 谓语＋a Chinese lifeguard certificate 宾语；Chinese 是前置定语。", "certificate 重读 /tɪ/；名词词尾 /kət/，不是 /keɪt/。"),
       S("I would check the U.S. requirements and complete the required training.", "我会核实美国的要求，并完成所需培训。", "aɪ wʊd tʃɛk ðə ˌju ˈɛs rɪˈkwaɪrmənts | ænd kəmˈplit ðə rɪˈkwaɪrd ˈtreɪnɪŋ", ["I would check the U.S. requirements", "and complete the required training."], "I 主语；would check 和 complete 并列谓语，各有宾语。")],
      [S("I would only accept a role that I am qualified to do.", "我只会接受自己具备相应资格的岗位。")],
      [("Is your certificate accepted by the employer?", "雇主认可你的证书吗？"), ("How far can you swim without stopping?", "你能连续游多远？")],
      ["lifeguarding", "Chinese certificate", "check requirements", "other suitable jobs"],
      "中国证书不应被说成自动等同美国认可资质；具体岗位、培训和认证要求需赞助机构与雇主确认。若问是否已被认可，未核实就说 I need to check with the employer. 不能猜。"),

    Q("06", "优点、性格与适合项目的品质", "What are your strengths?", "你的优点是什么？",
      [("How would you describe your personality?", "你会怎样描述自己的性格？"),
       ("What qualities would you bring to the program?", "你能给项目带来什么品质？"),
       ("Why do you think you would be a good participant?", "你为什么认为自己适合参加？")],
      [S("I try to be responsible and willing to learn.", "我努力做到有责任心，也愿意学习。", "aɪ traɪ tə bi rɪˈspɑnsəbəl | ænd ˈwɪlɪŋ tə lɝn", ["I try to be responsible", "and willing to learn."], "I 主语＋try 谓语；to be... 补语；responsible 与 willing... 是并列表语。", "responsible 重读 /spɑn/；不要每个音节用同样力度。"),
       S("If I am not sure about a task, I would ask before acting.", "如果不确定怎样做任务，我会先问清楚再行动。", "ɪf aɪ æm nɑt ʃʊr əˈbaʊt ə tæsk | aɪ wʊd æsk bɪˈfɔr ˈæktɪŋ", ["If I am not sure about a task,", "I would ask before acting."], "If... 条件状语从句；主句 I 主语＋would ask 谓语；before acting 时间状语。"),
       S("I would listen to feedback and work on my mistakes.", "我会听取反馈并改进自己的错误。", "aɪ wʊd ˈlɪsən tə ˈfidbæk | ænd wɝk ɑn maɪ mɪˈsteɪks", ["I would listen to feedback", "and work on my mistakes."], "I 主语；would listen 与 work 是并列谓语；work on 表示着手改进。")],
      [S("I have a Chinese lifeguard certificate, so safety is important in my training.", "我有中国救生员证，因此安全是我相关训练中的重要内容。")],
      [("Can you give me a real example?", "能给我一个真实例子吗？"), ("How do you respond to feedback?", "你怎样对待反馈？")],
      ["try to be responsible", "ask first", "listen to feedback"],
      "这里说努力做到的态度，不替你编造带队、救人或工作业绩。若被追问具体例子，请先用中文补充一个真实的上课、训练或团队经历。"),

    Q("07", "缺点与改善方法", "What is a weakness you are working on?", "你正在改善的一个缺点是什么？",
      [("What would you like to improve about yourself?", "你想改善自己哪方面？"),
       ("How will you work on your weakness during the program?", "项目期间你会怎样改善缺点？"),
       ("What is difficult for you when speaking English?", "说英语时什么对你比较难？")],
      [S("I sometimes need time to find the right words in English.", "有时我需要一些时间才能找到合适的英语表达。", "aɪ ˈsʌmtaɪmz nid taɪm | tə faɪnd ðə raɪt wɝdz ɪn ˈɪŋɡlɪʃ", ["I sometimes need time", "to find the right words in English."], "I 主语；sometimes 频率状语；need 谓语＋time 宾语；to find... 说明需要时间做什么。"),
       S("I practice short answers, and I plan to record myself.", "我练习短回答，也计划录下自己的声音。", "aɪ ˈpræktɪs ʃɔrt ˈænsərz | ænd aɪ plæn tə rɪˈkɔrd maɪˈsɛlf", ["I practice short answers,", "and I plan to record myself."], "两个 I 主语；practice 和 plan 分别是谓语；to record 是 plan 的不定式补语；myself 是反身代词宾语。"),
       S("If I do not understand, I ask for clarification.", "如果不理解，我会请求对方解释清楚。", "ɪf aɪ du nɑt ˌʌndərˈstænd | aɪ æsk fər ˌklærəfəˈkeɪʃən", ["If I do not understand,", "I ask for clarification."], "If... 条件从句；主句 I 主语＋ask for 谓语短语＋clarification 宾语。", "clarification 可以先换成 help；正式跟读再逐步练完整词。")],
      [S("My goal is to answer more clearly, not just more quickly.", "我的目标是回答得更清楚，而不只是更快。")],
      [("What progress have you made?", "你取得了什么进步？"), ("What would you do if you still could not understand?", "如果还是听不懂，你会怎么办？")],
      ["find the right words", "practice short answers", "ask for clarification"],
      "你已确认能脱稿自我介绍，可真实补充 I can now introduce myself without reading. 录音表达为下一步计划，不冒充已有录音经历。不要假装流利，也不必反复贬低自己。"),

    Q("08", "语言不通：听懂与表达自救", "What would you do if you could not express yourself clearly?", "如果不能清楚表达自己的想法，你会怎么办？",
      [("What if you do not understand your supervisor?", "如果你听不懂主管的话怎么办？"),
       ("How would you deal with a language barrier?", "你会怎样应对语言障碍？"),
       ("What would you do if someone spoke too fast?", "如果别人说得太快怎么办？")],
      [S("I would stay calm and use simple words.", "我会保持冷静，使用简单的词。", "aɪ wʊd steɪ kɑm | ænd juz ˈsɪmpəl wɝdz", ["I would stay calm", "and use simple words."], "I 主语；would stay 系动词结构＋calm 表语；use 谓语＋simple words 宾语。"),
       S("If I did not understand, I would ask them to repeat it slowly.", "如果没听懂，我会请对方慢一点重复。", "ɪf aɪ dɪd nɑt ˌʌndərˈstænd | aɪ wʊd æsk ðɛm tə rɪˈpit ɪt ˈsloʊli", ["If I did not understand,", "I would ask them to repeat it slowly."], "If... 假设条件；I 主语＋would ask 谓语＋them 宾语＋to repeat... 宾语补足语。"),
       S("I would check the meaning before starting the task.", "开始任务之前，我会确认意思。", "aɪ wʊd tʃɛk ðə ˈminɪŋ | bɪˈfɔr ˈstɑrtɪŋ ðə tæsk", ["I would check the meaning", "before starting the task."], "I 主语＋would check 谓语＋the meaning 宾语；before... 时间状语。")],
      [S("Could you please say that again more slowly?", "请您再慢一点说一遍好吗？"),
       S("Do you mean I should do this first?", "您的意思是我应该先做这个吗？")],
      [("What exactly would you say?", "你具体会怎么说？"), ("Would you start if you were still unsure?", "如果仍不确定，你会直接开始吗？")],
      ["stay calm", "simple words", "repeat slowly", "check first"],
      "不要只会描述策略，还要把展开区的两句实际说出来。安全相关工作不能靠猜或只依赖翻译软件。"),

    Q("09", "犯错影响同事怎么办", "What would you do if your mistake affected a coworker?", "如果你的错误影响了同事，你会怎么办？",
      [("How would you handle a mistake at work?", "你会怎样处理工作错误？"),
       ("What if you did something wrong?", "如果你做错了事呢？"),
       ("How would you respond after causing a problem for your team?", "给团队带来问题后你会怎样回应？")],
      [S("I would admit the mistake and apologize to my coworker.", "我会承认错误，并向同事道歉。", "aɪ wʊd ədˈmɪt ðə mɪˈsteɪk | ænd əˈpɑlədʒaɪz tə maɪ ˈkoʊwɝkər", ["I would admit the mistake", "and apologize to my coworker."], "I 主语；would admit 和 apologize 并列谓语；apologize to 后接道歉对象。"),
       S("I would tell my supervisor and help fix the problem safely.", "我会告诉主管，并安全地协助解决问题。", "aɪ wʊd tɛl maɪ ˈsupərvaɪzər | ænd hɛlp fɪks ðə ˈprɑbləm ˈseɪfli", ["I would tell my supervisor", "and help fix the problem safely."], "I 主语；would tell 与 help 并列谓语；safely 方式状语。"),
       S("Then I would learn how to avoid the same mistake.", "之后我会学习怎样避免相同错误。", "ðɛn aɪ wʊd lɝn | haʊ tə əˈvɔɪd ðə seɪm mɪˈsteɪk", ["Then I would learn", "how to avoid the same mistake."], "Then 顺序状语；I 主语＋would learn 谓语＋how to avoid... 宾语。")],
      [S("I would not hide the problem or blame someone else.", "我不会隐瞒问题，也不会责怪别人。")],
      [("What would you do first?", "你首先会做什么？"), ("How would you stop it from happening again?", "你会怎样避免它再次发生？")],
      ["admit", "apologize", "tell supervisor", "avoid repeating"],
      "这是假设题，不等于你有工作经历。涉及安全风险时，应先停止危险操作并及时报告，不能为了补救越权行动。"),

    Q("10", "同事冲突与团队合作", "What would you do if you disagreed with a coworker?", "如果和同事意见不一致，你会怎么办？",
      [("How would you handle a conflict at work?", "你会怎样处理工作中的冲突？"),
       ("What if a coworker had a different opinion?", "如果同事有不同意见呢？"),
       ("How would you solve a disagreement in a team?", "你会怎样解决团队分歧？")],
      [S("I would stay calm and listen to their point of view.", "我会保持冷静，听对方的观点。", "aɪ wʊd steɪ kɑm | ænd ˈlɪsən tə ðɛr pɔɪnt əv vju", ["I would stay calm", "and listen to their point of view."], "I 主语；would stay calm 主系表；listen to 后接倾听的对象。"),
       S("Then I would explain my view politely and look for a solution.", "然后我会礼貌说明自己的观点，并寻找解决办法。", "ðɛn aɪ wʊd ɪkˈspleɪn maɪ vju pəˈlaɪtli | ænd lʊk fər ə səˈluʃən", ["Then I would explain my view politely", "and look for a solution."], "I 主语；would explain 和 look for 并列谓语；politely 方式状语。"),
       S("If we could not agree, I would ask a supervisor for help.", "如果无法达成一致，我会请主管帮忙。", "ɪf wi kʊd nɑt əˈɡri | aɪ wʊd æsk ə ˈsupərvaɪzər fər hɛlp", ["If we could not agree,", "I would ask a supervisor for help."], "If... 条件从句；ask someone for help 表示向某人求助。")],
      [S("I would focus on the task, not on blaming the person.", "我会把重点放在任务上，而不是责怪对方。")],
      [("What if the coworker was still upset?", "如果同事还是很生气呢？"), ("When would you ask your supervisor for help?", "什么时候你会请主管帮助？")],
      ["listen first", "explain politely", "solution", "ask for help"],
      "不要背成所有问题都立即上报或只会道歉；先沟通，无法解决或涉及安全、骚扰等情形再及时按流程求助。"),

    Q("11", "最大困难、压力与应对", "What challenges might you face in the United States?", "你在美国可能遇到什么困难？",
      [("What do you think will be your biggest challenge?", "你觉得最大的挑战是什么？"),
       ("What is your biggest source of stress now?", "你目前最大的压力来源是什么？"),
       ("How would you deal with a difficult situation?", "你会怎样处理困难情境？")],
      [S("Understanding fast English may be a challenge for me.", "听懂很快的英语可能是我的一个挑战。", "ˌʌndərˈstændɪŋ fæst ˈɪŋɡlɪʃ | meɪ bi ə ˈtʃælɪndʒ fər mi", ["Understanding fast English", "may be a challenge for me."], "Understanding fast English 动名词短语作主语；may be 系动词结构＋a challenge 表语。"),
       S("I would ask people to repeat important information.", "我会请别人重复重要信息。", "aɪ wʊd æsk ˈpipəl | tə rɪˈpit ɪmˈpɔrtənt ˌɪnfərˈmeɪʃən", ["I would ask people", "to repeat important information."], "I 主语＋would ask 谓语＋people 宾语＋to repeat... 宾补。"),
       S("I would take things step by step and ask for help when needed.", "我会一步一步处理，并在需要时求助。", "aɪ wʊd teɪk θɪŋz stɛp baɪ stɛp | ænd æsk fər hɛlp wɛn ˈnidɪd", ["I would take things step by step", "and ask for help when needed."], "I 主语；take 与 ask 并列谓语；step by step 方式状语。")],
      [S("Right now, I am preparing for my English interview.", "目前我在为英语口测做准备。")],
      [("How are you preparing for that challenge?", "你怎样为这个挑战做准备？"), ("Who could you ask for help?", "你可以向谁求助？")],
      ["fast English", "important information", "step by step", "help"],
      "如果问的是现在的压力，先说口测准备，再讲做法；如果问未来困难，用 may/would。不要不听题就背同一段。"),

    Q("12", "中美文化差异与适应", "What differences might you notice between daily life in China and the United States?", "你可能注意到中美日常生活有哪些差异？",
      [("How would you adapt to a different culture?", "你会怎样适应不同文化？"),
       ("What do you think is different about life in America?", "你认为美国生活有什么不同？"),
       ("Can you handle living in a different place?", "你能应对在不同地方生活吗？")],
      [S("There may be differences in food and everyday habits.", "饮食和日常习惯可能会有不同。", "ðɛr meɪ bi ˈdɪfərənsɪz | ɪn fud ænd ˈɛvriˌdeɪ ˈhæbɪts", ["There may be differences", "in food and everyday habits."], "There may be 表示可能存在；differences 是存在的内容；in... 说明方面。"),
       S("I know people are different, so I would not make assumptions.", "我知道人与人不同，因此不会想当然。", "aɪ noʊ ˈpipəl ɑr ˈdɪfərənt | soʊ aɪ wʊd nɑt meɪk əˈsʌmpʃənz", ["I know people are different,", "so I would not make assumptions."], "前句 I know 后接宾语从句；so 连接结果分句。"),
       S("I would observe, ask politely, and respect local rules.", "我会观察、礼貌提问并尊重当地规则。", "aɪ wʊd əbˈzɝv | æsk pəˈlaɪtli | ænd rɪˈspɛkt ˈloʊkəl rulz", ["I would observe,", "ask politely,", "and respect local rules."], "I 主语；would 后有 observe/ask/respect 三个并列谓语。")],
      [S("If something was unfamiliar, I would ask what was appropriate.", "遇到不熟悉的事情时，我会询问怎样做合适。")],
      [("Could you give an example?", "你能举个例子吗？"), ("What would you do if you did not know a local custom?", "如果不懂当地习俗你会怎么做？")],
      ["food and habits", "people are different", "observe", "ask politely"],
      "不要把“中国人都怎样、美国人都怎样”当成事实。用 may 表示可能；举例可说先询问工作休息安排，不编造美国亲身经历。"),

    Q("13", "爱好与日常活动", "What do you like to do in your free time?", "空闲时你喜欢做什么？",
      [("What are your hobbies?", "你的爱好是什么？"),
       ("How do you spend your free time?", "你怎样度过空闲时间？"),
       ("Do you enjoy sports?", "你喜欢运动吗？")],
      [S("I enjoy swimming in my free time.", "我空闲时喜欢游泳。", "aɪ ɪnˈdʒɔɪ ˈswɪmɪŋ ɪn maɪ fri taɪm", ["I enjoy swimming", "in my free time."], "I 主语＋enjoy 谓语＋swimming 动名词宾语；in... 时间状语。"),
       S("I also have a Chinese lifeguard certificate.", "我也有中国游泳救生员证。", "aɪ ˈɔlsoʊ hæv ə tʃaɪˈniz ˈlaɪfɡɑrd sərˈtɪfɪkət", ["I also have", "a Chinese lifeguard certificate."], "I 主语；also 状语；have 谓语＋a Chinese lifeguard certificate 宾语。")],
      [S("I study physical fitness training at college.", "我在大学学习体育体能训练。")],
      [("Why do you enjoy that?", "你为什么喜欢它？"), ("How often do you do it?", "你多久做一次？")],
      ["enjoy + doing", "because", "how often"],
      "你提供的熟练稿中已写明喜欢游泳，所以默认保留这个爱好；喜欢的具体原因和每周次数不能替你编造。下方分支用于按真实情况补充，不必重新背一套爱好答案。", ["喜欢的具体原因", "实际频率"], 2,
      [B("swimming", "如果你确实把游泳当作爱好", "本人确认喜欢游泳，且以下理由符合真实感受。", [
          S("I enjoy swimming in my free time.", "我空闲时喜欢游泳。", "aɪ ɪnˈdʒɔɪ ˈswɪmɪŋ ɪn maɪ fri taɪm", ["I enjoy swimming", "in my free time."], "I 主语＋enjoy 谓语＋swimming 动名词宾语；in... 时间状语。"),
          S("It helps me stay active and relax.", "它帮助我保持活力并放松。", "ɪt hɛlps mi steɪ ˈæktɪv ænd rɪˈlæks", ["It helps me", "stay active and relax."], "It 主语＋helps 谓语＋me 宾语＋stay... 宾语补足语。")]),
       B("custom", "填写你的其他真实爱好", "替换所有方括号，不能照读占位符。", [S("I enjoy [activity] because [reason].", "我喜欢[活动]，因为[原因]。")])]),

    Q("14", "兼职或工作经历", "Have you had a part-time job?", "你做过兼职吗？",
      [("Do you have any work experience?", "你有工作经历吗？"),
       ("Have you worked before?", "你以前工作过吗？"),
       ("Could you tell me about a job you have done?", "能讲讲你做过的一份工作吗？")], [], [],
      [("What were your responsibilities?", "你的职责是什么？"), ("What did you learn from that experience?", "你从那段经历中学到了什么？")],
      ["have / have not", "part-time", "responsibilities", "learned"],
      "没有工作经历不必编造。持有救生员证不能自动写成做过救生员。追问职责时有经历才回答；无经历可以谈学习态度。", ["是否有兼职经历", "岗位和职责"], 2,
      [B("no", "如果没有工作经历", "Sam 确认从未工作或兼职。", [
          S("I have not had a part-time job yet.", "我还没有做过兼职。", "aɪ hæv nɑt hæd ə ˈpɑrt taɪm dʒɑb jɛt", ["I have not had", "a part-time job yet."], "I 主语＋have not had 现在完成时否定谓语＋a part-time job 宾语；yet 表示尚未。"),
          S("I am willing to learn and follow instructions.", "我愿意学习并遵守指示。", "aɪ æm ˈwɪlɪŋ tə lɝn | ænd ˈfɑloʊ ɪnˈstrʌkʃənz", ["I am willing to learn", "and follow instructions."], "I 主语＋am 系动词＋willing... 表语。")]),
       B("yes", "如果做过兼职", "只填写真实岗位、职责和收获。", [S("Yes, I worked part-time as a [job].", "做过，我曾兼职做[岗位]。"), S("My main task was [task].", "我的主要任务是[任务]。"), S("I learned to [skill].", "我学会了[技能]。")])]),

    Q("15", "旅行经历、最喜欢的城市和原因", "Have you traveled to other cities or countries?", "你去其他城市或国家旅行过吗？",
      [("Have you ever been overseas?", "你出过国吗？"),
       ("Which city that you have visited do you like best?", "去过的城市中你最喜欢哪个？"),
       ("Could you tell me about a trip you took?", "能讲讲你的一次旅行吗？")], [], [],
      [("Why did you like that place?", "你为什么喜欢那个地方？"), ("What did you do there?", "你在那里做了什么？")],
      ["visited", "city / country", "because", "one real activity"],
      "国外旅行与国内旅行是不同问题；没有出国不等于没有去过其他城市。选择与你被问的范围一致的真实分支。", ["国内旅行经历", "出境经历", "喜欢的城市及原因"], 2,
      [B("domestic", "有国内旅行经历", "填写真实去过的城市、活动及原因。", [S("I have visited [city] in China.", "我去过中国的[城市]。"), S("I liked it because [reason].", "我喜欢那里，因为[原因]。"), S("I [past-tense activity] there.", "我在那里[做过的活动]。")]),
       B("no-overseas", "如果从未出国，且正在回答出境问题", "Sam 确认没有出境经历；不要用这句否认真实的国内旅行。", [S("I have not been overseas yet.", "我还没有出过国。", "aɪ hæv nɑt bɪn ˌoʊvərˈsiz jɛt", ["I have not been overseas yet."], "I 主语＋have not been 现在完成时否定谓语；overseas 地点状语。"), S("I am preparing carefully for the SWT program.", "我正在认真为 SWT 项目做准备。")]),
       B("overseas", "如果确实出过国", "只填写真实国家及经历。", [S("Yes, I have been to [country].", "是的，我去过[国家]。"), S("I went there for [purpose].", "我去那里是为了[目的]。")])]),

    Q("16", "向美国朋友推荐一道中国菜", "What Chinese dish would you recommend?", "你会推荐哪一道中国菜？",
      [("Could you recommend a Chinese dish to an American friend?", "能向一位美国朋友推荐一道中国菜吗？"),
       ("What Chinese food would you like to introduce?", "你想介绍什么中国食物？"),
       ("What is special about the dish you recommend?", "你推荐的菜有什么特点？")], [], [],
      [("What is it made with?", "它用什么做的？"), ("Is it spicy?", "它辣吗？")],
      ["recommend", "ingredients", "taste", "ask preferences"],
      "推荐是你的选择，不是假装所有美国人都爱某道菜。下面番茄炒蛋只是易表达的可选示例；不需要声称自己会做。", ["愿意推荐的菜品"], 2,
      [B("tomato-egg", "如果你愿意推荐番茄炒蛋", "这是你认可的推荐，能解释食材即可。", [
          S("I would recommend stir-fried tomatoes and eggs.", "我会推荐番茄炒蛋。", "aɪ wʊd ˌrɛkəˈmɛnd ˈstɝ fraɪd təˈmeɪtoʊz ænd ɛɡz", ["I would recommend", "stir-fried tomatoes and eggs."], "I 主语＋would recommend 谓语＋菜名作宾语。"),
          S("It is a simple dish with tomatoes and eggs.", "它是一道用番茄和鸡蛋做的简单菜。", "ɪt ɪz ə ˈsɪmpəl dɪʃ | wɪð təˈmeɪtoʊz ænd ɛɡz", ["It is a simple dish", "with tomatoes and eggs."], "It 主语＋is 系动词＋a simple dish 表语；with... 后置修饰 dish。"),
          S("I would ask about their food preferences first.", "我会先问问对方的饮食偏好。", "aɪ wʊd æsk əˈbaʊt ðɛr fud ˈprɛfərənsɪz fɝst", ["I would ask about", "their food preferences first."], "I 主语＋would ask about 谓语短语＋their food preferences 宾语。")]),
       B("custom", "我想推荐别的菜", "填写熟悉的菜，不要直接读方括号。", [S("I would recommend [dish].", "我会推荐[菜名]。"), S("It is made with [ingredients].", "它用[食材]做成。"), S("It tastes [taste].", "它尝起来[味道]。")])]),

    Q("17", "父母是否支持", "Do your parents support your participation in SWT?", "父母支持你参加 SWT 吗？",
      [("How does your family feel about the program?", "你的家人怎么看这个项目？"),
       ("Have you discussed SWT with your parents?", "你和父母讨论过 SWT 吗？"),
       ("What concerns does your family have?", "你的家人有什么担忧？")], [], [],
      [("What did you tell them about the program?", "你跟他们介绍了项目的哪些内容？"), ("How would you stay in touch with them?", "你会怎样与他们保持联系？")],
      ["support", "discuss", "concerns", "stay in touch"],
      "父母支持与否不能由课程替你决定；不要为了所谓回国约束力编造家庭承诺。也不要把家庭关系细节过度公开。", ["家人是否支持", "已沟通的内容"], 2,
      [B("yes", "如果父母确实支持", "Sam 已与父母沟通并获支持。", [S("Yes, my parents support my participation.", "是的，父母支持我参加。", "jɛs | maɪ ˈpɛrənts səˈpɔrt maɪ pɑrˌtɪsəˈpeɪʃən", ["Yes,", "my parents support my participation."], "my parents 主语＋support 谓语＋my participation 宾语。"), S("I would keep in touch with them regularly.", "我会与他们定期保持联系。")]),
       B("discussing", "如果仍在沟通", "家庭仍在讨论，而非已经同意。", [S("We are still discussing the details.", "我们还在讨论具体细节。", "wi ɑr stɪl dɪˈskʌsɪŋ ðə ˈditeɪlz", ["We are still discussing", "the details."], "We 主语＋are discussing 现在进行时谓语＋the details 宾语。"), S("I want to explain the program clearly and answer their questions.", "我想把项目解释清楚，并回答他们的问题。")])]),

    Q("18", "护照与准备情况", "Do you have a passport?", "你有护照吗？",
      [("Have you applied for a passport?", "你申请护照了吗？"),
       ("Is your passport ready?", "你的护照准备好了吗？"),
       ("What travel documents have you prepared?", "你已经准备了哪些旅行证件？")], [], [],
      [("When does it expire?", "它什么时候到期？"), ("What do you still need to prepare?", "你还需要准备什么？")],
      ["passport", "applied", "not yet", "check the date"],
      "只核对状态及需要准备的材料，不把证件号码放入公开网站。到期日必须查看证件，不能从练习示例抄一个日期。", ["护照状态"], 2,
      [B("ready", "如果已持有效护照", "已核对护照真实状态。", [S("Yes, I have a passport.", "是的，我有护照。", "jɛs | aɪ hæv ə ˈpæspɔrt", ["Yes,", "I have a passport."], "I 主语＋have 谓语＋a passport 宾语。")]),
       B("applied", "如果已经申请，仍在等待", "申请确实已提交。", [S("I have applied for one and am waiting for it.", "我已经申请了，正在等待领取。", "aɪ hæv əˈplaɪd fər wʌn | ænd æm ˈweɪtɪŋ fər ɪt", ["I have applied for one", "and am waiting for it."], "前半现在完成时 have applied；后半现在进行时 am waiting。")]),
       B("not-yet", "如果还没有护照，也未申请", "按真实进度选择。", [S("Not yet. I need to apply for one.", "还没有，我需要申请一本。", "nɑt jɛt | aɪ nid tə əˈplaɪ fər wʌn", ["Not yet.", "I need to apply for one."], "Not yet 是简短否定；I 主语＋need 谓语＋to apply... 补语。")])]),

    Q("19", "游泳距离与技能边界", "How far can you swim without stopping?", "你能连续游多远？",
      [("How many meters can you swim?", "你能游多少米？"),
       ("Which swimming strokes can you use?", "你会哪些泳姿？"),
       ("How would you describe your swimming ability?", "你会怎样描述自己的游泳能力？")], [], [],
      [("When did you last test that distance?", "你上次测试这个距离是什么时候？"), ("Have you completed the employer's swim test?", "你通过雇主的游泳测试了吗？")],
      ["meters", "without stopping", "recent test", "requirements"],
      "证书不能替代准确泳距，也不能替代雇主测试。需实际、安全地测过再填数字；课程不提供水中独自训练指导。", ["实测连续泳距", "会的泳姿", "雇主测试状态"], 2,
      [B("measured", "如果有近期实测距离", "只填真实距离；是否不停顿必须准确。", [S("I can swim [number] meters without stopping.", "我能连续不停地游[数字]米。"), S("I can swim [strokes].", "我会[泳姿]。")]),
       B("not-measured", "如果没有近期测过连续距离", "确实不知道当前准确泳距时使用。", [S("I have not tested my maximum distance recently.", "我最近没有测试自己的最大连续游泳距离。", "aɪ hæv nɑt ˈtɛstɪd maɪ ˈmæksəməm ˈdɪstəns ˈrisəntli", ["I have not tested my maximum distance", "recently."], "I 主语＋have not tested 现在完成时否定谓语＋my maximum distance 宾语；recently 时间状语。"), S("I would check the swim test requirements before applying for a lifeguard role.", "申请救生员岗位前，我会核实游泳测试要求。")])]),

    Q("20", "学校、年级与专业", "What do you study, and what year are you in?", "你学什么专业，现在读几年级？",
      [("What is your major?", "你的专业是什么？"),
       ("Which college do you attend?", "你在哪所学校就读？"),
       ("Are you a first-year student?", "你是大一学生吗？")],
      [S("I am a first-year student.", "我是大一学生。", "aɪ æm ə ˈfɝst jɪr ˈstudənt", ["I am a first-year student."], "I 主语＋am 系动词＋a first-year student 表语。"),
       S("I study physical fitness training.", "我学习体育体能训练。", "aɪ ˈstʌdi ˈfɪzɪkəl ˈfɪtnəs ˈtreɪnɪŋ", ["I study", "physical fitness training."], "I 主语＋study 谓语＋physical fitness training 宾语。"),
       S("My college is Guangxi College for Preschool Education.", "我的学校是广西幼儿师范高等专科学校。", "maɪ ˈkɑlɪdʒ ɪz | ɡwɑŋˈʃi ˈkɑlɪdʒ fər ˈpriskul ˌɛdʒəˈkeɪʃən", ["My college is", "Guangxi College for Preschool Education."], "My college 主语＋is 系动词＋校名作表语。", "学校名称较长，可以先准确说出，再连贯练习；不把学校类型改成 university。")],
      [S("My training is about safe exercise, fitness, and teamwork.", "我的训练内容涉及安全运动、体能和团队合作。")],
      [("Why did you choose this major?", "你为什么选这个专业？"), ("What do you learn in your classes?", "你在课上学习什么？")],
      ["first-year", "physical fitness training", "college"],
      "专业使用你最新确认的体育体能训练，不再出现商科或体育艺术表演。展开句沿用照片中你熟悉的训练内容；选择专业的原因尚未确认，被追问时补你的真实理由。", priority=2),

    Q("21", "毕业后的打算", "What are your plans after graduation?", "你毕业后有什么打算？",
      [("What kind of work would you like to do in the future?", "你未来想做什么工作？"),
       ("Have you decided on a career?", "你决定职业方向了吗？"),
       ("How could this experience help your future plans?", "这段经历能怎样帮助你的未来计划？")], [], [],
      [("Why are you interested in that field?", "你为什么对那个领域感兴趣？"), ("What would you need to learn first?", "你首先还需要学习什么？")],
      ["after graduation", "not decided yet", "field", "skills"],
      "你是大一，不必虚构明确工作或已签约单位。SWT 岗位偏好不自动等于毕业职业目标；先确认自己的真实方向。", ["毕业后的真实打算"], 2,
      [B("exploring", "如果你确实还没决定具体职业", "承认尚在探索，而不是假装已经有安排。", [S("I have not decided on a specific job yet.", "我还没有决定具体做什么工作。", "aɪ hæv nɑt dɪˈsaɪdɪd ɑn ə spəˈsɪfɪk dʒɑb jɛt", ["I have not decided on", "a specific job yet."], "I 主语＋have not decided on 谓语短语＋a specific job 宾语。"), S("I want to build my skills while I study.", "我想在学习期间提高自己的技能。")]),
       B("direction", "如果已有真实职业方向", "只填自己真实考虑的领域，不填虚构的雇主承诺。", [S("After graduation, I would like to work in [field].", "毕业后，我想从事[领域]的工作。"), S("I am interested in it because [reason].", "我对此感兴趣，因为[原因]。")])]),

    Q("22", "项目结束后：真实回国与学业安排", "What will you do after the program?", "项目结束后你会做什么？",
      [("When will you return to China?", "你什么时候回中国？"),
       ("When does your next semester begin?", "你的下学期什么时候开始？"),
       ("How does SWT fit with your studies?", "SWT 与你的学业怎样衔接？")],
      [S("I will return to China after the program and continue my studies.", "项目结束后，我会回中国继续学业。", "aɪ wɪl rɪˈtɝn tə ˈtʃaɪnə ˈæftər ðə ˈproʊɡræm | ænd kənˈtɪnju maɪ ˈstʌdiz", ["I will return to China after the program", "and continue my studies."], "I 主语；will return 和 continue 并列谓语；after the program 时间状语。", "continue 重读第二音节；studies 词尾 /z/ 轻轻带出。"),
       S("My exact travel dates are not confirmed yet.", "我的具体出行日期还没有确定。", "maɪ ɪɡˈzækt ˈtrævəl deɪts | ɑr nɑt kənˈfɝmd jɛt", ["My exact travel dates", "are not confirmed yet."], "My exact travel dates 主语；are not confirmed 被动语态否定；yet 表示尚未。"),
       S("I will check my college calendar before finalizing my plans.", "最终确定行程之前，我会核对学校校历。", "aɪ wɪl tʃɛk maɪ ˈkɑlɪdʒ ˈkælɪndər | bɪˈfɔr ˈfaɪnəlaɪzɪŋ maɪ plænz", ["I will check my college calendar", "before finalizing my plans."], "I 主语＋will check 谓语＋my college calendar 宾语；before... 时间状语。")],
      [S("I will continue studying at Guangxi College for Preschool Education.", "我会继续在广西幼儿师范高等专科学校读书。")],
      [("Have you checked your college calendar?", "你核对学校校历了吗？"), ("What will you do when you return?", "你回来后会做什么？")],
      ["after the program", "return to China", "continue my studies", "confirmed dates"],
      "你已明确确认项目结束后回中国，在原学校继续读书，默认答案可以如实表达。具体日期未定就说未定，不编机票、开学日期或工作安排。BridgeUSA 要求在本国学校开学前回国，安排日期时须核实；无需在每道文化题里反复插入回国口号。", ["学校开学日期", "拟回国时间"], 1,
      [B("return-study", "仅在你真实计划回国继续学业时使用", "Sam 确认此计划；日期另行核实，绝不自动填入。", [
          S("After the program, I plan to return to China and continue my studies.", "项目结束后，我计划回中国继续学业。", "ˈæftər ðə ˈproʊɡræm | aɪ plæn tə rɪˈtɝn tə ˈtʃaɪnə ænd kənˈtɪnju maɪ ˈstʌdiz", ["After the program,", "I plan to return to China and continue my studies."], "After... 时间状语；I 主语＋plan 谓语＋to return... 补语；and 连接回国与继续学业。"),
          S("I need to be back before my next semester starts.", "我需要在下学期开学前回来。", "aɪ nid tə bi bæk | bɪˈfɔr maɪ nɛkst səˈmɛstər stɑrts", ["I need to be back", "before my next semester starts."], "I 主语＋need 谓语＋to be back 补语；before 引导时间状语从句。")]),
       B("dates-pending", "回国继续学业计划真实，但具体日期仍未核实", "只能在计划已确认、只是日期未确认时使用。", [
          S("I plan to return to China to continue my studies.", "我计划回中国继续学业。"),
          S("I still need to confirm the dates with my college and sponsor.", "我仍需要和学校及赞助机构确认日期。")])]),

    Q("23", "项目中最感兴趣的部分", "Which part of the program interests you most?", "项目的哪一部分最让你感兴趣？",
      [("What are you most looking forward to?", "你最期待什么？"),
       ("What attracts you most about SWT?", "SWT 最吸引你的是什么？"),
       ("What would be the most valuable part for you?", "对你来说最有价值的部分是什么？")],
      [S("I am most interested in using English in everyday situations.", "我最感兴趣的是在日常情境中使用英语。", "aɪ æm moʊst ˈɪntrəstɪd ɪn ˈjuzɪŋ ˈɪŋɡlɪʃ | ɪn ˈɛvriˌdeɪ ˌsɪtʃuˈeɪʃənz", ["I am most interested in using English", "in everyday situations."], "I 主语＋am 系动词＋interested... 表语；in 后接 using 动名词。"),
       S("I want to understand people and express my ideas more clearly.", "我想听懂别人，也更清楚地表达自己的想法。", "aɪ wɑnt tə ˌʌndərˈstænd ˈpipəl | ænd ɪkˈsprɛs maɪ aɪˈdiəz mɔr ˈklɪrli", ["I want to understand people", "and express my ideas more clearly."], "I 主语＋want 谓语；to understand 与 express 是并列目标。"),
       S("Learning about American culture is also important to me.", "了解美国文化对我来说也很重要。", "ˈlɝnɪŋ əˈbaʊt əˈmɛrɪkən ˈkʌltʃər | ɪz ˈɔlsoʊ ɪmˈpɔrtənt tə mi", ["Learning about American culture", "is also important to me."], "Learning... 动名词短语主语＋is 系动词＋important 表语；to me 说明对谁重要。")],
      [S("For example, I would like to understand everyday conversations at work.", "例如，我想听懂工作中的日常交流。")],
      [("Why is that important to you?", "那为什么对你重要？"), ("Can you give me a specific example?", "能给一个具体例子吗？")],
      ["everyday English", "understand people", "express my ideas", "culture"],
      "课程根据你确认的英语与文化目标给出示例；如果你真实的最期待项不同，请替换第一句。回答不要扩大成在美国长期找工作。"),

    Q("24", "可工作日期与排班沟通", "When would you be available for the program?", "你什么时候可以参加项目？",
      [("What are your available work dates?", "你可工作的日期是什么？"),
       ("When does your summer vacation start and end?", "你的暑假什么时候开始和结束？"),
       ("Would you be able to follow the agreed work schedule?", "你能遵守商定的工作安排吗？")], [], [],
      [("Have you confirmed those dates with your college?", "你和学校确认这些日期了吗？"), ("What would you do if there was a scheduling problem?", "如果排班有问题你会怎么办？")],
      ["available from / to", "college calendar", "agreed schedule", "confirm"],
      "不要承诺无限工时或任意日期。可工作时间应与学校假期和项目授权相符；遇到不清楚的安排先向机构核实。这里只练沟通，不给个人签证或就业法律结论。", ["学校暑假时间", "项目和工作日期", "排班限制"], 2,
      [B("confirmed", "如果日期已经核实", "填入学校与项目均允许的真实日期。", [S("I am available from [start date] to [end date].", "我从[开始日期]到[结束日期]可以参加。"), S("I have checked these dates with my college.", "我已和学校核实这些日期。")]),
       B("pending", "如果具体日期尚未核实", "只有尚未确认时使用，不冒充已确认。", [S("I still need to confirm my available dates.", "我仍需要确认可以参加的具体日期。", "aɪ stɪl nid tə kənˈfɝm maɪ əˈveɪləbəl deɪts", ["I still need to confirm", "my available dates."], "I 主语；still 状语；need 谓语＋to confirm... 补语。"), S("I will check my college calendar and discuss the dates with my sponsor.", "我会核对校历，并与赞助机构讨论日期。")])]),
]

RESCUE_PHRASES = [
    S("Could you please repeat the question?", "请您重复一下问题好吗？", "kʊd ju pliz rɪˈpit ðə ˈkwɛstʃən", ["Could you please", "repeat the question?"], "Could you please＋动词原形，是礼貌请求。"),
    S("Could you please speak a little more slowly?", "请您说慢一点好吗？", "kʊd ju pliz spik ə ˈlɪtəl mɔr ˈsloʊli", ["Could you please speak", "a little more slowly?"], "more slowly 比较级副词修饰 speak；a little 表示一点。"),
    S("What does that word mean?", "那个词是什么意思？", "wʌt dʌz ðæt wɝd min", ["What does that word mean?"], "What 提问含义；does 助动词；that word 主语；mean 谓语。"),
    S("Let me think for a moment.", "请让我想一下。", "lɛt mi θɪŋk fər ə ˈmoʊmənt", ["Let me think", "for a moment."], "Let＋me 宾语＋think 宾语补足语；for a moment 时间状语。"),
]

# Keep the learner's already-fluent wording as a maintenance track.  It is not
# a demand to replace his memorized introduction, and it does not assert an
# unrestricted weekend/holiday work commitment.  Details come from his photo.
KNOWN_INTRO = {
    "title": "你已经会说的自我介绍：只微调，不推倒重背",
    "note": "保留学校、专业、救生员和学习英语等熟悉句块；去掉冗长开场和反复报名字。年龄若要说，应为 I am 19 years old.；是否愿意及能够周末工作，应按项目期间实际排班另答。照片中的中文姓名拼写不在公开课复述。",
    "sentences": [
        S("Hello, thank you for your time. You can call me Sam.", "你好，谢谢您抽出时间。您可以叫我 Sam。", "həˈloʊ | θæŋk ju fər jər taɪm | ju kən kɔl mi sæm", ["Hello, thank you for your time.", "You can call me Sam."], "You 主语＋can call 谓语＋me 宾语＋Sam 宾语补足语。"),
        S("I am a first-year student at Guangxi College for Preschool Education.", "我是广西幼儿师范高等专科学校的大一学生。", "aɪ æm ə ˈfɝst jɪr ˈstudənt | ət ɡwɑŋˈʃi ˈkɑlɪdʒ fər ˈpriskul ˌɛdʒəˈkeɪʃən", ["I am a first-year student", "at Guangxi College for Preschool Education."], "I 主语＋am 系动词＋a first-year student 表语；at... 补充学校。"),
        S("My major is physical fitness training.", "我的专业是体育体能训练。", "maɪ ˈmeɪdʒər ɪz ˈfɪzɪkəl ˈfɪtnəs ˈtreɪnɪŋ", ["My major is", "physical fitness training."], "My major 主语＋is 系动词＋专业名作表语。"),
        S("I like swimming, and I have a Chinese lifeguard certificate.", "我喜欢游泳，也有中国游泳救生员证。", "aɪ laɪk ˈswɪmɪŋ | ænd aɪ hæv ə tʃaɪˈniz ˈlaɪfɡɑrd sərˈtɪfɪkət", ["I like swimming,", "and I have a Chinese lifeguard certificate."], "and 连接 I like... 和 I have... 两个主谓宾分句。"),
        S("I am responsible, patient, and willing to learn new skills.", "我有责任心、有耐心，也愿意学习新技能。", "aɪ æm rɪˈspɑnsəbəl | ˈpeɪʃənt | ænd ˈwɪlɪŋ tə lɝn nu skɪlz", ["I am responsible,", "patient,", "and willing to learn new skills."], "I 主语＋am 系动词＋三个并列表语。"),
        S("Now I am learning English for Summer Work Travel.", "现在我正在为 Summer Work Travel 学习英语。", "naʊ aɪ æm ˈlɝnɪŋ ˈɪŋɡlɪʃ | fər ˈsʌmər wɝk ˈtrævəl", ["Now I am learning English", "for Summer Work Travel."], "Now 时间状语；I 主语＋am learning 现在进行时谓语＋English 宾语；for... 目的状语。"),
    ],
    "optional": [S("My training is about safe exercise, fitness, and teamwork.", "我的训练涉及安全运动、体能和团队合作。")],
}

# Follow-up rescue is deliberately smaller than the main answer.  ``hint``
# explains the intent in Chinese; ``answer`` is supplied only where biography
# is confirmed or the sentence clearly describes hypothetical future conduct.
# A missing answer is not a UI bug: ask for the learner's true fact first.
FOLLOWUP_SUPPORT = {
    "01": [
        ("只回答专业即可，不必把整个自介重背一遍。", [("My major is physical fitness training.", "我的专业是体育体能训练。")]),
        ("切换到参加项目的目的：文化＋英语；不要继续讲姓名。", [("I want to experience American culture and improve my English.", "我想体验美国文化并提高英语。")]),
    ],
    "02": [
        ("说一个具体范围，如日常交流或工作中的沟通，不必夸大对美国的了解。", [("I would like to learn about daily life and workplace communication.", "我想了解日常生活和工作中的沟通。")]),
        ("这是问项目之后，不是继续问去美国的理由；使用你已确认的回国读书计划。", [("I will return to China and continue my studies.", "我会回中国继续学业。")]),
    ],
    "03": [
        ("说明 SWT 有项目内工作与文化交流，不只是观光；不要说要去长期找工作。", [("It includes work and cultural exchange, not just sightseeing.", "它包含工作和文化交流，而不只是观光。")]),
        ("说你想获得的能力或认识：听懂别人、清楚表达、了解文化。", [("I hope to communicate more clearly in English and learn about American culture.", "我希望能用英语交流得更清楚，并了解美国文化。")]),
    ],
    "04": [
        ("从目标转成行动：你打算怎样练，而不只是说 improve English。", [("I would use simple English in daily conversations.", "我会在日常交流中使用简单英语。"), ("I would ask questions when I did not understand.", "听不懂时我会提问。")]),
        ("用可以观察的结果判断进步：听懂问题、不看稿回答；不用承诺一个不真实的高分。", [("I would check whether I can understand questions and answer without reading.", "我会检查自己能否听懂问题并不看稿回答。")]),
    ],
    "05": [
        ("这在问雇主是否已认可，不是问有没有中国证书；目前没核实就直接说需要核实。", [("I need to check with the employer.", "我需要向雇主核实。"), ("My certificate is from China.", "我的证书来自中国。")]),
        ("说近期实测的连续泳距和是否停顿；没有测过就去第 19 题选择真实分支，不猜数字。", []),
    ],
    "06": [
        ("先补一个真的上课、训练或合作例子：当时什么事→你做了什么→结果。没有素材前不要编工作或救人经历。", []),
        ("不是问优点名称，而是问收到反馈后怎么做：听清→有疑问就问→改进。", [("I would listen carefully and ask questions if needed.", "我会认真听，必要时提问。"), ("Then I would try to improve.", "然后我会努力改进。")]),
    ],
    "07": [
        ("你已有真实进步：可以不看稿自我介绍；不要声称已经听懂所有题。", [("I can now introduce myself without reading.", "现在我可以不看稿介绍自己。"), ("I still need practice with other questions.", "其他问题我仍需要练习。")]),
        ("不是再说一次 speak slowly 就结束；可请对方换个说法或给例子，任务不懂不能直接做。", [("I would ask them to explain it another way.", "我会请对方换一种方式解释。"), ("I would not start a task until I understood it.", "没理解任务之前，我不会开始。")]),
    ],
    "08": [
        ("现在要直接说出自救句，不是继续描述 I would ask。", [("Could you please say that again more slowly?", "请您再慢一点说一遍好吗？"), ("What does that word mean?", "那个词是什么意思？")]),
        ("明确回答不会盲目开始，再给做法；不是承诺自己从不犯错。", [("No. I would ask for help before starting.", "不会。我会先求助再开始。")]),
    ],
    "09": [
        ("先分清是否有危险；有风险先停止危险操作并报告，不越权修理。", [("If there was a safety risk, I would stop the unsafe action and tell my supervisor.", "如果有安全风险，我会停止不安全的操作并告诉主管。")]),
        ("给防止重复的方法，而不是只说 I am sorry：听清正确做法、再确认。", [("I would review the instructions and check anything I was unsure about.", "我会复习操作指示，并确认不清楚的地方。")]),
    ],
    "10": [
        ("避免跟着争吵；保持平静，无法继续沟通就按流程求助。", [("I would not argue with them.", "我不会与对方争吵。"), ("If we could not solve it calmly, I would ask for help.", "如果无法平静解决，我会求助。")]),
        ("When 在问什么情况下，不必报几点钟：无法解决、影响安全等情况。", [("I would ask for help if we could not solve the problem or if safety was involved.", "无法解决问题或涉及安全时，我会求助。")]),
    ],
    "11": [
        ("说你现在确实做的准备；你已会自介，可以说正在练短答，不必声称每天练了多少小时。", [("I am practicing short answers and listening to different questions.", "我在练短回答，并听不同的问题问法。")]),
        ("工作指令问主管；项目、住宿等问题联系赞助机构；不要所有事都只找同事。", [("For work tasks, I would ask my supervisor.", "工作任务方面，我会询问主管。"), ("For program issues, I would contact my sponsor.", "项目事务方面，我会联系赞助机构。")]),
    ],
    "12": [
        ("举可能的差异，不说所有美国人都一样；可以从时间安排入手。", [("Meal times may be different.", "用餐时间可能不同。"), ("I would ask about the schedule instead of guessing.", "我会询问时间安排，而不是猜测。")]),
        ("给可执行的礼貌做法：观察、提问、照合适规则做。", [("I would ask politely what was appropriate.", "我会礼貌询问怎样做合适。"), ("Then I would follow the guidance.", "然后我会按照指导去做。")]),
    ],
    "13": [
        ("你已确认喜欢游泳；现在补你自己的真实原因。放松、体能、乐趣都只是备选，不要替自己选一个假的理由。", []),
        ("How often 问频率，不是问泳距。请填真实的每周次数；没有固定频率可如实说不固定。", []),
    ],
    "14": [
        ("有工作经历才回答职责，用一个具体动作；如果没有，明确说没有兼职经历，而不是套用救生员工作经历。", []),
        ("根据同一段真实经历说收获。没有工作经历时可提出改谈学校经历，但不能把课堂包装成兼职。", []),
    ],
    "15": [
        ("用一个你真实体验过的理由，如景色或食物；不要把没去过的城市说成去过。", []),
        ("用过去时说一项实际活动。只有愿望就说想去，不能把计划改成已完成。", []),
    ],
    "16": [
        ("说你选的菜的两三种主要食材。若选择番茄炒蛋，食材是 tomatoes and eggs；如果换菜，答案也要换。", []),
        ("按你推荐的实际做法回答辣或不辣；不要断言同一道菜的所有做法都一样。", []),
    ],
    "17": [
        ("只说已经和父母谈过的内容；没谈过就别用 I told them。可以先补中文事实再生成英文。", []),
        ("给你真实愿意执行的联系方式和频率，不用为了面试夸大每天联系的承诺。", []),
    ],
    "18": [
        ("When 问到期日；查看护照后再答年月日，不猜测，也不用公开护照号码。", []),
        ("列一两项你确实仍未准备的材料或步骤；不知道要求时先向机构确认。", []),
    ],
    "19": [
        ("说实测时间；如果未测，就承认未测试，不虚构刚测过的距离。", []),
        ("这问美国雇主的具体测试是否通过，不能用中国证书替代；尚未测试就如实说尚未。", []),
    ],
    "20": [
        ("补你最初选择体育体能训练的真实原因，不让课程替你编家庭影响或职业承诺。", []),
        ("可以沿用照片里的真实内容：safe exercise, fitness, and teamwork；进一步课程名称需要你确认。", []),
    ],
    "21": [
        ("仅在你确实有该职业方向时给真实原因；尚未决定就直接说明还在探索。", []),
        ("根据自己的真实方向说需要补的技能，不编造你已报名某个证书或已得到工作。", []),
    ],
    "22": [
        ("Have you checked 问已经做过没有；你确认了回国计划，但未确认核对过校历。请如实选择，不能把将来会核对说成已经核对。", []),
        ("你已明确说回原校继续学业，可以直接回答；没有具体开学日期就不报日期。", [("I will continue my studies at Guangxi College for Preschool Education.", "我会继续在广西幼儿师范高等专科学校读书。")]),
    ],
    "23": [
        ("讲英语对你这次交流的具体价值：听懂和表达，不必堆抽象励志词。", [("Clear communication would help me learn and understand other people.", "清楚的沟通能帮助我学习并理解别人。")]),
        ("给一个项目内交流场景，不编你已经在那里工作过。", [("For example, I would like to understand instructions and ask questions clearly.", "例如，我想听懂指示并清楚地提问。")]),
    ],
    "24": [
        ("这是核实是否已经确认，不是表达愿望。日期未定就如实说需要确认，不能照念分支里的 have checked。", []),
        ("你可以先说明会及时沟通并核对商定安排；具体可接受的工时或时段需要真实确认，不能一概承诺。", []),
    ],
}

for question in QUESTIONS:
    for followup, (hint, examples) in zip(question["followups"], FOLLOWUP_SUPPORT[question["id"]]):
        followup["hint"] = hint
        followup["answer"] = [P(en, zh) for en, zh in examples]

# Closely related interview prompts do not always ask for the same answer.
# The UI should expose this cue during study, but hide it in mock-test mode.
VARIANT_HINTS = {
    "05": ["问是否想做救生员，先直接表态再说明证书。", "问资质，先说中国救生员证，不要先讲全部项目目标。", "问岗位灵活性，直接说愿意考虑其他合适岗位，不是无条件接受所有工作。"],
    "11": ["问预计最大的困难：快语速英语＋应对。", "问现在的压力：本月口测准备，别把未来情景当成已经发生。", "问困难时怎样做，重点给行动步骤。"],
    "15": ["overseas 是出境，不是国内旅游。", "问去过城市中最喜欢哪座，先说真实城市，再给原因。", "讲一段真实旅行，不把愿望当经历。"],
    "17": ["问家人态度，按真实情况选择分支。", "问是否已经讨论过，未讨论不能说已讨论。", "问具体担忧，不是简单问支持或反对；先补中文真实信息。"],
    "18": ["问是否申请，区分未申请、已申请和已拿到。", "问是否准备好，按当前证件状态答。", "问准备了哪些材料，不能把所有模板材料都说成已完成。"],
    "19": ["问具体米数，需要真实实测数字。", "问泳姿，回答真实会的泳姿，不报泳距。", "可以概括训练和中国证书，但不能因此声称通过美国雇主测试。"],
    "20": ["只问专业，一句 My major is... 就可以。", "只问学校，先说校名。", "是非问，先回答 Yes，再补 first-year student。"],
    "22": ["When 问回国时间，现日期未定，直接如实说未确定，不猜日期。", "问开学日期，需要核实校历；回国意图不能代替一个未确认日期。", "说回国继续读书并核对假期、行程，不编已获学校批准。"],
    "24": ["问工作起止日，不是问口测日期；需核实学校和项目安排。", "问暑假起止日，查学校校历，不能用往年或别校日期。", "只按实际可执行的商定安排回答，不无条件承诺任意工时。"],
}

for question in QUESTIONS:
    for variant, hint in zip(question["variants"], VARIANT_HINTS.get(question["id"], [])):
        variant["hint"] = hint


def validate_curriculum():
    assert len(QUESTIONS) == 24
    assert [q["id"] for q in QUESTIONS] == [f"{i:02d}" for i in range(1, 25)]
    for q in QUESTIONS:
        assert len(q["variants"]) == 3, q["id"]
        assert len(q["followups"]) == 2, q["id"]
        assert all(f.get("hint") and isinstance(f.get("answer"), list) for f in q["followups"]), q["id"]
        assert q["keywords"] and q["note"], q["id"]
        assert 2 <= len(q["short"]) <= 3 or (not q["short"] and q["branches"]), q["id"]
        assert len(q["extra"]) <= 2, q["id"]
        if not q["short"]:
            assert q["requiresConfirmation"] and not q["readyForAutoplay"], q["id"]
        for sentence in q["short"]:
            assert sentence["en"] and sentence["zh"] and sentence["ipa"], (q["id"], sentence)
            assert sentence["grammar"] and sentence["chunks"], (q["id"], sentence)
            assert "[" not in sentence["en"], (q["id"], sentence)
        for branch in q["branches"]:
            assert branch["confirmed"] is False and branch["condition"], q["id"]
    default_speech = "\n".join(s["en"] for q in QUESTIONS for s in q["short"] + q["extra"])
    for forbidden in ("Junxi", "business major", "sports art performance", "My parents support", "I worked part-time", "I have a passport", "I plan to return to China"):
        assert forbidden not in default_speech, forbidden
    assert not re.search(r"I can swim \d", default_speech)
    assert len(QUESTIONS[21]["short"]) == 3  # confirmed return intent, no invented date
    return True


def export_payload():
    validate_curriculum()
    return {
        "version": VERSION,
        "profile": PROFILE,
        "questions": QUESTIONS,
        "rescuePhrases": RESCUE_PHRASES,
        "plan": TRAINING_PLAN,
        "sources": SOURCE_NOTES,
        "knownIntro": KNOWN_INTRO,
        "audioPolicy": "默认播放 short/extra 及已确认或明确假设的 followup.answer。可预生成无占位符的 branches 音频，但本人核实并明确选择前不得播放；含方括号占位符的句子不得合成或评分。分支不并入公开默认合集。",
        "ipaNote": "宽式美式音标为辅助；自然语流会弱读连读。专名音标只作近似提示，不用音标取代听音。",
    }


validate_curriculum()

if __name__ == "__main__":
    import sys
    if "--json" in sys.argv:
        print(json.dumps(export_payload(), ensure_ascii=False, indent=2))
    else:
        ready = sum(q["readyForAutoplay"] for q in QUESTIONS)
        lines = sum(len(q["short"]) for q in QUESTIONS)
        print(f"{VERSION}: {len(QUESTIONS)} topics; {ready} default-answer topics; {lines} short-answer sentences; validation passed")
