/* Offline listening lifecycle tests; no network, microphone or real timers. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const filename = path.resolve(__dirname, '../assets/listening-v18.js');
let source = fs.readFileSync(filename, 'utf8');
source = source.replace('  restorePreferences();\n  startMounting();', '');
source = source.replace(/\}\)\(\);\s*$/, 'window.test={state,startMounting,ensureMounted,normalizeModules,normalizeModes,trackFor,fetchManifestWithTimeout,fetchFirstAvailable,playAudio,stopAudio,setupAudioInterlock,resolveAudioUrl,retryAudio};})();');

function harness() {
  let nextTimer = 0;
  const timers = new Map(), listeners = new Map(), nodes = new Map(), events = [], observers = [];
  const generic = () => ({textContent:'', hidden:true, disabled:false, setAttribute(){}, removeAttribute(){}, classList:{toggle(){}}, querySelector(){return generic();}});
  const root = {parentNode:null, contains(){return false;}, setAttribute(){}, querySelector(selector){if(!nodes.has(selector))nodes.set(selector,generic());return nodes.get(selector);}, querySelectorAll(){return [];}};
  const audio = {currentSrc:'https://example.test/audio/a.mp3?v=19.1', src:'https://example.test/audio/a.mp3?v=19.1', paused:true, ended:false, currentTime:8, duration:100, readyState:4, playbackRate:1,
    play(){this.paused=false;return Promise.resolve();}, pause(){this.paused=true;}, load(){this.loads=(this.loads||0)+1;}, loop:false};
  const document = {baseURI:'https://example.test/',readyState:'complete',documentElement:{},getElementById(){return null;},querySelector(){return null;},querySelectorAll(){return [];},addEventListener(){}};
  const window = {setTimeout(fn, delay){const id=++nextTimer;timers.set(id,{fn,delay});return id;},clearTimeout(id){timers.delete(id);},addEventListener(type,fn){if(!listeners.has(type))listeners.set(type,[]);listeners.get(type).push(fn);},dispatchEvent(event){events.push(event);for(const fn of listeners.get(event.type)||[])fn(event);}};
  const sandbox = {window,document,navigator:{},URL,Promise,AbortController,CustomEvent:class {constructor(type, init){this.type=type;this.detail=init.detail;}},MutationObserver:class {constructor(fn){this.fn=fn;observers.push(this);}observe(){}},fetch(){return Promise.reject(new Error('not configured'));},localStorage:{getItem(){return null;},setItem(){}},HTMLMediaElement:{HAVE_METADATA:1},Element:class {}};
  vm.runInNewContext(source,sandbox,{filename});
  const t=window.test;
  t.state.root=root;t.state.audio=audio;
  t.state.progress={disabled:false,max:'0',value:'0',style:{setProperty(){}}};
  t.state.manifest={};t.state.modes=t.normalizeModes({modes:[{id:'teaching',all:{src:'audio/a.mp3',built:true}}]});
  t.state.selection={kind:'all'};t.state.loadedUrl=audio.currentSrc;
  return {t,window,document,audio,root,nodes,sandbox,timers,events,observers,fireTimer(){const first=timers.entries().next().value;assert(first,'a timeout must exist');timers.delete(first[0]);first[1].fn();}};
}
const flush = async () => {for(let i=0;i<8;i++)await Promise.resolve();};
(async () => {
  let count=0;
  {
    const h=harness();
    h.t.state.modules=h.t.normalizeModules({modules:[{id:'01',tracks:{teaching:{src:'a.mp3',cues:[{start:2,end:3},{start:0,end:1},{start:-1,end:1}]}}}]});
    const one=h.t.trackFor({kind:'module',index:0});
    assert.equal(one,h.t.trackFor({kind:'module',index:0}),'track/cues must be reused, not allocated and sorted on every tick');
    assert.deepEqual(Array.from(one.cues,c=>c.start),[0,2]);
    assert(h.t.resolveAudioUrl('audio/a.mp3').endsWith('?v=19.1'));
    count+=3;
  }
  {
    const h=harness();h.sandbox.fetch=()=>Promise.resolve({ok:true,json:()=>Promise.resolve({version:'v19'})});
    assert.equal((await h.t.fetchFirstAvailable(['a','b'],0)).version,'v19','manifest must be parsed only once');
    assert.equal(h.timers.size,0,'successful fetch clears deadline');
    h.sandbox.fetch=()=>Promise.resolve({ok:true,json:()=>new Promise(()=>{})});
    const pending=h.t.fetchManifestWithTimeout('slow');await flush();h.fireTimer();
    await assert.rejects(pending,/网络较慢/,'JSON body stalls have a bounded timeout');
    count+=3;
  }
  {
    const h=harness();let rejectOld;
    h.audio.play=()=>new Promise((_,reject)=>{rejectOld=reject;});h.t.playAudio();
    h.audio.play=()=>Promise.resolve();h.t.playAudio();
    const status=h.nodes.get('[data-status]');const before=status.textContent;
    rejectOld(Object.assign(new Error('old request'),{name:'NotAllowedError'}));await flush();
    assert.equal(status.textContent,before,'old rejection cannot overwrite new playback status');
    assert.equal(h.timers.size,1,'only newest playback has a timeout');
    h.fireTimer();assert.equal(h.nodes.get('[data-action="retry"]').hidden,false,'pending play gets a visible retry');
    assert.match(status.textContent,/载入较慢/);count+=4;
  }
  {
    const h=harness();h.t.setupAudioInterlock();h.audio.paused=false;
    h.t.playAudio();assert.equal(h.audio.paused,false,'own playback request must not pause itself');
    const previous=h.t.state.playToken;
    h.window.dispatchEvent(new h.sandbox.CustomEvent('gospeak-playback-request',{detail:{owner:'mainline-v19'}}));
    assert.equal(h.audio.paused,true);assert(h.t.state.playToken>previous);assert.equal(h.timers.size,0);
    assert.equal(h.events.length,2,'receiving ownership does not dispatch recursively');count+=5;
  }
  {
    const h=harness();h.t.playAudio();h.t.stopAudio();assert.equal(h.t.state.playbackTimer,null);
    const retry=h.nodes.get('[data-action="retry"]');assert.equal(retry.hidden,true);
    h.t.state.pendingSeek=null;h.audio.currentTime=22;h.t.retryAudio();assert.equal(h.t.state.pendingSeek,22,'retry preserves listening position');assert.equal(h.audio.loads,1);count+=4;
  }
  {
    const h=harness();const host={firstChild:{},insertBefore(node){node.parentNode=this;this.moves=(this.moves||0)+1;}};
    h.document.getElementById=id=>id==='oral-mainline'?host:null;h.root.parentNode=host;
    h.t.startMounting();assert.equal(host.moves,undefined,'already mounted player must not reorder siblings');
    for(let i=0;i<1000;i++)h.observers[0].fn([{target:{}}]);
    assert.equal(h.timers.size,0,'ordinary subtitle/meter updates must not schedule remounts');
    h.root.parentNode=null;
    for(let i=0;i<1000;i++)h.observers[0].fn([{target:{}}]);
    assert.equal(h.timers.size,1,'host replacement burst coalesces to one task');h.fireTimer();
    assert.equal(host.moves,1);count+=4;
  }
  console.log('Listening stability: '+count+' assertions passed.');
})().catch(error=>{console.error(error);process.exitCode=1;});
