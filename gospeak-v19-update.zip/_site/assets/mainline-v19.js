/* Sam's SWT speaking practice: real answers, gradual prompts, local recordings. */
(function () {
  'use strict';
  if (window.__samMainlineV19) return;
  var state = { root: null, data: null, questions: [], selected: '', mode: 'learn', hint: 0,
    variant: 0, followup: -1, followupChinese: false, chain: 1, loop: 1, audio: null,
    audioToken: 0, audioTimer: null, audioKey: '', clips: {}, clipCounter: 0,
    recorders: [], recorderTargets: [], minutes: 60, mock: [], mockIndex: 0,
    mockDone: {}, counts: {}, lastPracticed: {}, seenEvents: {}, date: '', gaps: '', startDay: '', loading: false, busy: false };
  var STORE = 'gospeak-sam-v19-practice';
  try {
    var saved = JSON.parse(localStorage.getItem(STORE) || '{}');
    state.counts = saved.counts || {}; state.lastPracticed = saved.lastPracticed || {}; state.date = saved.date || ''; state.gaps = saved.gaps || ''; state.startDay=saved.startDay || '';
  } catch (_) { /* Local practice does not require storage. */ }
  window.__samMainlineV19 = { remount: mount, isRecording: isRecording };
  function esc(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) { return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]; }); }
  function dayKey() { var d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
  if(!state.startDay)state.startDay=dayKey();
  function persist() { try { localStorage.setItem(STORE, JSON.stringify({ counts:state.counts, lastPracticed:state.lastPracticed, date:state.date, gaps:state.gaps, startDay:state.startDay })); } catch (_) {} }
  function dayPlan() { var days=state.data && state.data.plan && state.data.plan.days || []; if(!days.length)return null;var elapsed=Math.max(0,Math.round((new Date(dayKey()+'T12:00:00')-new Date(state.startDay+'T12:00:00'))/86400000));return days[elapsed%days.length]; }
  function q() { return state.questions.find(function (item) { return item.id === state.selected; }) || state.questions[0]; }
  function lines(value) { return Array.isArray(value) ? value : value && Array.isArray(value.sentences) ? value.sentences : []; }
  function shortLines(item) { return lines(item.short || item.shortAnswer || item.sentences); }
  function fullText(item) { return shortLines(item).map(function (line) { return line.en; }).join(' '); }
  function label(item) { return item.title || item.topic || item.questionZh || item.question_zh || item.id; }
  function en(item) { return typeof item === 'string' ? item : item.en || item.question || item.q || ''; }
  function zh(item) { return typeof item === 'string' ? '' : item.zh || item.questionZh || item.question_zh || ''; }
  function status(text) { var node = state.root && state.root.querySelector('[data-sam-status]'); if (node) node.textContent = text; }
  function recordId(suffix) { return 'sam-v19:' + q().id + ':' + suffix; }
  function isRecording() { return state.recorders.some(function (rec) { return rec.isRecording && rec.isRecording(); }); }
  function safeToChange() { if (isRecording()) { status('请先停止并保存当前录音，再切题或改变提示。'); return false; } return true; }
  function note(text, css) { return '<p class="sam19-note ' + (css || '') + '">' + esc(text) + '</p>'; }

  function mount() {
    var host = document.querySelector('.coach-layout');
    var nav = document.querySelector('.app-nav [data-view="coach"]');
    if (nav && nav.textContent !== 'SWT口测主线') nav.textContent = 'SWT口测主线';
    var nce = document.querySelector('.app-nav [data-view="nce"]');
    if (nce && nce.textContent !== '新概念英语第一册') nce.textContent = '新概念英语第一册';
    if (!host) return;
    if (!state.root) {
      state.root = document.createElement('section'); state.root.id = 'oral-mainline'; state.root.className = 'sam19';
      state.root.innerHTML = '<div class="sam19-app"><header class="sam19-header"><div><p class="sam19-eyebrow">SAM · OCTOBER SWT INTERVIEW</p><h1>听懂问题，开口回答。</h1><p>你已能脱稿介绍自己。现在主攻换问法、真实短答与随机追问。</p></div><span class="sam19-version">V19</span></header><div class="sam19-date"><span data-sam-deadline>2026年10月机构口测 · 日期待确认</span><label>本机设置口测日 <input type="date" data-sam-date aria-label="实际口测日期"></label></div><p class="sam19-profile">英文名 <b>Sam</b> · 广西幼儿师范高等专科学校 · 大一 · 体育体能训练 · 中国游泳救生员证</p><div data-sam-content><p>正在读取个人口测课程…</p></div><p class="sam19-status" data-sam-status role="status">不编经历，不把语音识别当发音考试。</p></div>';
      state.root.addEventListener('click', handleClick);
      state.root.addEventListener('change', handleChange);
      state.root.addEventListener('input', function (event) {
        if (event.target.matches('[data-sam-gaps]')) { state.gaps = event.target.value; persist(); }
      });
      state.root.querySelector('[data-sam-date]').value = state.date;
      showDate();
    }
    if (state.root.parentNode !== host) host.insertBefore(state.root, host.firstChild);
    if (!state.data && !state.loading) load();
  }
  function showDate() {
    var text = '2026年10月机构口测 · 具体日期以机构通知为准';
    if (/^\d{4}-\d{2}-\d{2}$/.test(state.date)) {
      var target = new Date(state.date + 'T23:59:59'), days = Math.ceil((target.getTime() - Date.now()) / 86400000);
      text = '你设置的口测日：' + state.date + (days >= 0 ? ' · 还有 ' + days + ' 天' : ' · 日期已过，请核对');
    }
    state.root.querySelector('[data-sam-deadline]').textContent = text;
  }
  function load() {
    state.loading = true;
    fetch(new URL('interview-v19.json?v=19.1', document.baseURI).href, {cache:'no-cache'})
      .then(function (response) { if (!response.ok) throw new Error('HTTP ' + response.status); return response.json(); })
      .then(function (data) {
        if (!Array.isArray(data.questions) || !data.questions.length) throw new Error('课程清单为空');
        state.data = data; state.questions = data.questions; state.loading = false;
        var first = state.questions.find(function (item) { return item.id === 'why-swt' || item.id === '03'; }) || state.questions.filter(function (item) { return !/intro/i.test(item.id); }).sort(function (a,b) { return (a.priority || 99) - (b.priority || 99); })[0] || state.questions[0];
        state.selected = first.id; persist(); render(); status('今天先练参加 SWT 的目的，不再只反复练自我介绍。');
      }).catch(function (error) {
        state.loading = false;
        state.root.querySelector('[data-sam-content]').innerHTML = '<div class="sam19-empty"><h2>课程暂时没有载入</h2><p>' + esc(error.message) + '</p><button data-sam-action="retry">重新载入课程</button></div>';
      });
  }
  function planHtml() {
    var steps = [ ['review', '10分钟', '复测一道已练题', '优先最近练过的题，不看稿先录'], ['hear', '10分钟', '听懂不同问法', '同一题听3种问法'], ['two', '25分钟', '重点练2题', '中英→关键词→脱稿'], ['random', '10分钟', '随机题脱稿录音', '3秒内开口，不中断'], ['gap', '5分钟', '最多5个表达缺口', '明天先补这些'] ];
    var day=dayPlan(), route='';
    if(day){route='<div class="sam19-day-route"><b>第 '+day.day+' / 14 天建议 · 可按弱项调整</b>'+note(day.focus||'')+['new','review'].map(function(kind){return '<p>'+(kind==='new'?'新题':'复测')+'</p><div>'+((day[kind]||[]).map(function(id){var item=state.questions.find(function(x){return x.id===id;});return item?'<button data-sam-action="planned-question" data-value="'+esc(id)+'">'+esc(label(item))+'</button>':'';}).join('')||(kind==='new'?'今天不加新题':''))+'</div>';}).join('')+'</div>';}
    return '<details class="sam19-plan"><summary><span>今天怎么练'+(day?' · 第'+day.day+'天':'')+'</span><b>' + state.minutes + ' 分钟 · 每项都有入口</b></summary>'+route+'<div class="sam19-duration">' + [60,90,120].map(function (n) { return '<button data-sam-action="duration" data-value="' + n + '" aria-pressed="' + (state.minutes === n) + '">' + n + '分钟</button>'; }).join('') + '</div><ol>' + steps.map(function (s) { return '<li><span>' + s[1] + '</span><div><b>' + s[2] + '</b><small>' + s[3] + '</small></div><button data-sam-action="task-' + s[0] + '">进入</button></li>'; }).join('') + '</ol>' + (state.minutes > 60 ? note('增加的 ' + (state.minutes - 60) + ' 分钟只做旧题复测、听力和模拟，不加大量新视频。') : '') + note('完成标准是实际口头输出。录音次数只记录真实完成的录音，不用主观给自己打分。') + '</details>';
  }
  function navigationHtml() {
    var groups = {};
    state.questions.forEach(function (item) { var group = item.category || item.group || '口测题库'; (groups[group] || (groups[group] = [])).push(item); });
    return '<section class="sam19-nav"><label>选择口测题 <select data-sam-question aria-label="选择口测题">' + Object.keys(groups).map(function (group) { return '<optgroup label="' + esc(group) + '">' + groups[group].map(function (item) { return '<option value="' + esc(item.id) + '" ' + (item.id === state.selected ? 'selected' : '') + '>' + esc(label(item)) + '</option>'; }).join('') + '</optgroup>'; }).join('') + '</select></label><div><button data-sam-action="learn" class="' + (state.mode === 'learn' ? 'active' : '') + '">精练当前题</button><button data-sam-action="random">随机抽1题</button><button data-sam-action="mock">5题小模拟</button></div></section>';
  }
  function registerAudio(audio, text, slow) {
    var src = typeof audio === 'string' ? audio : audio && (slow ? audio.slow || audio.slowSrc || audio.normal || audio.src : audio.normal || audio.src);
    var key = 'clip-' + (++state.clipCounter); state.clips[key] = {src:src || '',text:text || '',rate:slow && audio && audio.slowRate ? Number(audio.slowRate) : 1}; return key;
  }
  function playButton(audio, text, slow, title, extra) {
    var key = registerAudio(audio, text, slow);
    var hasSlots = /\[[^\]]+\]/.test(text || '');
    return '<button type="button" data-sam-play="' + key + '" ' + (hasSlots ? 'disabled title="先填写真实信息，不能直接朗读占位符" ' : '') + (extra || '') + '>' + esc(hasSlots ? '先填写真实信息' : title || (slow ? '▶ 慢速跟读' : '▶ 正常语速')) + '</button>';
  }
  function audioRow(audio, text) { return '<div class="sam19-audio">' + playButton(audio,text,true) + playButton(audio,text,false) + '</div>'; }
  function variants(item) {
    var base = [{en:en(item),zh:zh(item),audio:item.questionAudio}];
    (item.variants || []).forEach(function (v) { if (en(v) && en(v) !== base[0].en) base.push(v); });
    return base;
  }
  function currentVariant(item) { var items=variants(item); return items[Math.min(state.variant,items.length-1)]; }
  function isRelatedVariant(item) { return Boolean(currentVariant(item).hint); }
  function practiceVariantIndex(item, sample) {
    // A hint marks a related question with a different intent, not a synonym.
    // Keep those out of randomized tests that compare against the base answer.
    var safe=variants(item).map(function(v,i){return v.hint?null:i;}).filter(function(i){return i!==null;});
    var value=Number.isFinite(sample)?sample:Math.random();
    return safe[Math.min(safe.length-1,Math.max(0,Math.floor(value*safe.length)))] || 0;
  }
  function questionHtml(item) {
    var vs = variants(item), current = vs[Math.min(state.variant,vs.length-1)], blind = state.mode !== 'learn';
    return '<section class="sam19-question" id="sam-question"><div class="sam19-kicker"><span>' + esc(label(item)) + '</span><b>' + (current.hint ? '相关追问 · 要换答题内容' : blind ? '先听问题，不看答案' : '先听懂问题') + '</b></div><h2 lang="en">' + esc(en(current)) + '</h2>' + (blind ? '<details><summary>听不懂？看中文题意</summary><p>' + esc(zh(current)) + '</p></details>' : '<p>' + esc(zh(current)) + '</p>') + audioRow(current.audio,en(current)) + (!blind && current.hint ? note(current.hint,'sam19-variant-hint') : '') + '<div class="sam19-variants"><span>主问题 / 同义问法 / 相关追问（不能套用原答案）</span>' + vs.map(function (v,i) { return '<button data-sam-action="variant" data-value="' + i + '" class="' + (state.variant === i ? 'active' : '') + '" '+(blind&&v.hint?'disabled title="相关追问请在精练模式中单独练习"':'')+'>'+(i===0?'主问题':v.hint?'相关追问 '+i:'同义问法 '+i)+'</button>'; }).join('') + '</div>' + (!blind && !current.hint && (item.intent || item.coachNote || item.note) ? note(item.intent || item.coachNote || item.note) : '') + '</section>';
  }
  function recorderHtml(id, text, title, kind) {
    var index = state.recorderTargets.length;
    state.recorderTargets.push({id:id,expectedText:text,title:title,kind:kind,onStart:stopSound});
    return '<div data-sam-recorder="' + index + '"></div>';
  }
  function lineHtml(line, index, prefix, includeRecorder) {
    var ipa = line.ipa || line.phonetic || '';
    return '<article class="sam19-line"><header><span>' + String(index+1).padStart(2,'0') + '</span><div><h3 lang="en">' + esc(line.en) + '</h3>' + (ipa ? '<p class="sam19-ipa">/' + esc(ipa) + '/</p>' : '') + '<p>' + esc(line.zh) + '</p></div></header>' + (line.chunks && line.chunks.length ? '<div class="sam19-chunks"><small>按意群停顿</small>' + line.chunks.map(function (chunk) { return '<span>' + esc(chunk) + '</span>'; }).join('<i>/</i>') + '</div>' : '') + audioRow(line.audio,line.en) + '<details class="sam19-language"><summary>单词点读 · 句子结构</summary>' + wordsHtml(line.en) + grammarHtml(line) + '</details>' + (includeRecorder ? recorderHtml(recordId(prefix+'-'+index),line.en,'第 '+(index+1)+' 句 · 录音与回听','sentence') : '') + '</article>';
  }
  function wordsHtml(text) {
    var lex = state.data.lexicon || {}, words = String(text || '').match(/U\.S\.|[A-Za-z]+(?:['’-][A-Za-z]+)*/g) || [];
    return '<div class="sam19-words">' + words.map(function (word) {
      var info = lex[word.toLowerCase()] || {}, key = registerAudio(info.src || info.audio,word,false);
      return '<button data-sam-play="' + key + '"><b>▶ ' + esc(word) + '</b><em>' + (info.ipa ? '/'+esc(info.ipa)+'/' : '') + '</em><span>' + esc(info.zh || info.meaning || '结合整句理解') + '</span></button>';
    }).join('') + '</div>';
  }
  function grammarHtml(line) {
    var g = line.grammar || {}, parts = g.parts || line.parts || [];
    if (typeof g === 'string') return note(g) + (line.pronunciation ? note('发音提示：' + line.pronunciation) : '');
    var title = g.pattern || line.pattern || '';
    return (title ? '<p class="sam19-pattern">' + esc(title) + '</p>' : '') + '<div class="sam19-grammar">' + parts.map(function (part) {
      var role = Array.isArray(part) ? part[1] : part.role || part.label || part.type;
      var text = Array.isArray(part) ? part[2] : part.text || part.en;
      var meaning = Array.isArray(part) ? part[3] : part.zh || part.meaning;
      return '<div><small>' + esc(role) + '</small><b>' + esc(text) + '</b><span>' + esc(meaning) + '</span></div>';
    }).join('') + '</div>' + (g.note || line.note ? note(g.note || line.note) : '');
  }
  function hintsHtml() { return '<div class="sam19-hints"><span>逐步离开答案</span>' + ['中英对照','只看关键词','完全隐藏'].map(function (text,i) { return '<button data-sam-action="hint" data-value="' + i + '" aria-pressed="' + (state.hint === i) + '">' + text + '</button>'; }).join('') + '</div>'; }
  function answerHtml(item) {
    var answer = shortLines(item), keys = item.keywords || item.memory || [], html = '';
    if (isRelatedVariant(item)) return '<section class="sam19-answer" id="sam-answer"><h2>这是相关追问，不能照搬主问题答案。</h2>' + note(currentVariant(item).hint,'sam19-caution') + note('先确认对方问的是原因、时间、做法还是例子，再回答自己的真实情况。这里不播放原题范文，也不拿它给你的回答判对错。') + recorderHtml(recordId('variant-'+state.variant),'','相关追问自由回答 · 不与原题范文比较','answer') + '<button data-sam-action="base-question">回到主问题与参考短答</button></section>';
    if (!answer.length) return '<section class="sam19-answer" id="sam-answer"><h2>先核实事实，再练你的回答</h2>' + note('这题没有替你填标准答案。需要确认：' + (item.requiresConfirmation || []).join('、') + '。下方条件答法只有在符合真实情况时才使用。','sam19-caution') + (state.hint!==0?'<button data-sam-action="hint" data-value="0">不会答：看真实条件分支</button>':'') + recorderHtml(recordId('free-answer'),'','按真实情况自由回答 · 不与范文对错比较','answer') + '</section>';
    if (state.hint === 2) html = '<div class="sam19-blind"><b>现在轮到你回答。</b><p>听到问题后尝试3秒内开口。说错也继续，用简单真话说20—40秒。</p><button data-sam-action="hint" data-value="1">卡住了：给我关键词</button></div>';
    else if (state.hint === 1) html = '<div class="sam19-keywords">' + keys.map(function (word) { return '<span>' + esc(word) + '</span>'; }).join('') + '<button data-sam-action="hint" data-value="0">还不会：看中英短答</button></div>';
    else html = '<div class="sam19-lines">' + answer.map(function (line,i) { return lineHtml(line,i,'short',true); }).join('') + '</div>';
    var count = state.counts[item.id] || 0;
    return '<section class="sam19-answer" id="sam-answer"><header><small>先把短答说稳，再补一条真实细节</small><h2>这道题，分三遍说。</h2></header>' + hintsHtml() + html + '<section class="sam19-whole"><h3>完整回答 · 听一遍，再自己说</h3>' + audioRow(item.fullAudio,fullText(item)) + '<p>第1遍看中英 → 第2遍只看关键词 → 第3遍完全脱稿</p><p class="sam19-record-count" data-sam-count>本题已实际录音 ' + count + ' 次（次数不代表口语合格）</p>' + recorderHtml(recordId('answer'),fullText(item),state.hint === 2 ? '完整脱稿录音' : '完整回答录音 · 练熟后请隐藏答案','answer') + '</section></section>';
  }
  function chainHtml(item) {
    var answer = shortLines(item); if (!answer.length) return '';
    state.chain = Math.min(Math.max(1,state.chain),answer.length);
    var subset = answer.slice(0,state.chain), text = subset.map(function (l) { return l.en; }).join(' ');
    var audio = (item.cumulativeAudio || [])[state.chain-1] || (state.chain === answer.length ? item.fullAudio : null);
    return '<details class="sam19-chain"><summary>句子会读，但连不起来？逐句累加</summary><div class="sam19-chain-steps">' + answer.map(function (_,i) { return '<button data-sam-action="chain" data-value="'+(i+1)+'" aria-pressed="'+(state.chain === i+1)+'">'+(i === 0 ? '第1句' : '前'+(i+1)+'句')+'</button>'; }).join('') + '</div><p class="sam19-chain-en" lang="en">' + esc(text) + '</p>' + audioRow(audio,text) + recorderHtml(recordId('chain-'+state.chain),text,'前 '+state.chain+' 句 · 连起来录音',state.chain === answer.length ? 'answer' : 'sentence') + '</details>';
  }
  function extraHtml(item) {
    var extra = lines(item.extra), branches = item.branches || [];
    var html = extra.length ? '<details class="sam19-extra"><summary>短答已说稳？展开补充句</summary>' + note('不必全背。只选与你真实情况一致的一句，听懂追问后再补充。') + extra.map(function (l,i) { return lineHtml(l,i,'extra',true); }).join('') + '</details>' : '';
    if (branches.length) html += '<details class="sam19-extra"><summary>按真实情况选答法 · 不自动替你选</summary>' + note('带 [方括号] 的是待填内容，不会朗读。先用中文写好真实信息发给我，再生成属于你的英文答案与音频。没有括号的答法也只在条件符合时使用。','sam19-caution') + branches.map(function (b,bi) { return '<section><h3>' + esc(b.label || b.title || b.when || '条件答法') + '</h3>' + (b.condition ? note(b.condition) : '') + lines(b.sentences || b.lines).map(function (l,i) { return lineHtml(l,i,'branch-'+bi,!/\[[^\]]+\]/.test(l.en)); }).join('') + '</section>'; }).join('') + '</details>';
    return html;
  }
  function followupHtml(item) {
    var qs = item.followups || [];
    var html = '<section class="sam19-followup" id="sam-followup"><header><h3>面试官还会追问</h3><button data-sam-action="followup" '+(!qs.length ? 'disabled' : '')+'>随机追问一句</button></header>';
    if (state.followup < 0 || !qs.length) return html + '<p>先听完主问题再回答，不提前背出整段。练熟主答后，抽一个追问。</p></section>';
    var question = qs[state.followup % qs.length];
    html += '<h4 lang="en">' + esc(en(question)) + '</h4>' + audioRow(question.audio,en(question)) + '<details><summary>看追问的中文意思</summary><p>' + esc(zh(question)) + '</p></details>';
    var answer = lines(question.answer || question.sentences), expected = answer.map(function (l) {return l.en;}).join(' ') || question.answerEn || '';
    if (answer.length || question.tip || question.hint || question.answerZh) html += '<details><summary>不会答？展开思路救援</summary>' + note(question.tip || question.hint || question.answerZh || '先直接回答，再补一个真实理由。') + answer.map(function (l) {return '<p lang="en">'+esc(l.en)+'</p><p>'+esc(l.zh)+'</p>'+audioRow(l.audio,l.en);}).join('') + '</details>';
    html += recorderHtml(recordId('followup-'+state.followup),expected,'追问回答 · 说自己的真话','answer');
    return html + '</section>';
  }
  function mockHtml() {
    if (state.mode !== 'mock') return '';
    var done = state.mock.filter(function (id) {return state.mockDone[id];}).length;
    return '<section class="sam19-mock"><header><b>5题小模拟 · 第 '+(state.mockIndex+1)+' / '+state.mock.length+' 题</b><span data-sam-mock-done>已录 '+done+' 题</span></header><p>每题先听问题，再录一段自己的回答。只有隐藏答案时完成录音才计入，不靠点按钮打卡。</p><button data-sam-action="mock-next" '+(!state.mockDone[state.selected] ? 'disabled' : '')+'>'+(state.mockIndex >= state.mock.length-1 ? '查看本次结果' : '已录完，进入下一题')+'</button></section>';
  }
  function knownIntroHtml(item) {
    var known = state.data.knownIntro;
    if (item.id !== '01' || !known || !lines(known.sentences).length) return '';
    var intro = lines(known.sentences), text = intro.map(function(line){return line.en;}).join(' ');
    return '<details class="sam19-extra sam19-known"><summary>你已经会说的自我介绍 · 保温入口</summary>' + note(known.note || '这段只需复习，不要求重新从零背起。') + intro.map(function(line,i){return lineHtml(line,i,'known',true);}).join('') + audioRow(known.fullAudio,text) + recorderHtml(recordId('known-intro'),text,'已掌握自介 · 每天只保温一遍','answer') + '</details>';
  }
  function render() {
    if (!state.data || !q()) return;
    stopSound();
    state.recorders.forEach(function (rec) { rec.destroy(); }); state.recorders=[]; state.recorderTargets=[];
    state.clips={}; state.clipCounter=0;
    var item = q(), baseAnswer = !isRelatedVariant(item);
    state.root.querySelector('[data-sam-content]').innerHTML = '<div class="sam19-shortcuts"><button data-sam-action="continuous">边做家务边听：连续听练 ↓</button><button data-sam-action="legacy">展开 / 收起旧版记录</button></div>' + planHtml() + navigationHtml() + '<div class="sam19-loop"><span>跟读播放次数</span>' + [1,3,0].map(function (n) {return '<button data-sam-action="loop" data-value="'+n+'" aria-pressed="'+(state.loop===n)+'">'+(n===0?'循环直到停止':n+'次')+'</button>';}).join('') + '<button data-sam-action="stop">■ 停止示范音</button></div>' + mockHtml() + questionHtml(item) + (baseAnswer&&state.hint===0 ? knownIntroHtml(item) : '') + answerHtml(item) + (baseAnswer&&state.hint===0 ? chainHtml(item)+extraHtml(item) : '') + (baseAnswer?followupHtml(item):'') + '<details class="sam19-gaps" id="sam-gaps"><summary>今天卡在哪里？最多记5个表达缺口</summary><p>写“想说什么却说不出”就行，不需要你给自己打分。明天先复测今天这题。</p><textarea data-sam-gaps rows="4" placeholder="例如：想说完成项目后回学校，但不会把句子连起来">'+esc(state.gaps)+'</textarea></details>';
    mountRecorders();
  }
  function mountRecorders() {
    state.root.querySelectorAll('[data-sam-recorder]').forEach(function (node) {
      if (window.SamRecorder && window.SamRecorder.mount) state.recorders.push(window.SamRecorder.mount(node,state.recorderTargets[Number(node.getAttribute('data-sam-recorder'))]));
      else node.innerHTML = note('录音组件尚未载入，请刷新重试；也可先用 iPad 语音备忘录完成口头输出。');
    });
  }
  function stopSound() {
    state.audioToken++; clearTimeout(state.audioTimer);
    if (state.audio) { state.audio.pause(); state.audio=null; }
    state.audioKey='';
    if (state.root) state.root.querySelectorAll('[data-sam-play]').forEach(function (b) { b.classList.remove('playing'); });
  }
  function staticAudioUrl(src) {
    var url=new URL(src,document.baseURI);
    // Static lesson files can retain an older spoken name in browser caches.
    // Never append query parameters to local recording/blob URLs.
    if(url.protocol==='https:'||url.protocol==='http:')url.searchParams.set('v','19.1');
    return url.href;
  }
  function playClip(clip, key, button, single) {
    if (clip && /\[[^\]]+\]/.test(clip.text || '')) {status('先填写真实信息，不朗读方括号占位内容。');return;}
    if (!clip || !clip.src) { status('这段示范音尚未生成。请先看文本练习；不会用旧音频冒充新内容。'); return; }
    if (isRecording()) { status('请先停止录音再播放示范，避免把示范声录进去。'); return; }
    if (state.audio && state.audioKey===key) { stopSound(); return; }
    stopSound(); document.querySelectorAll('audio,video').forEach(function (a) { if (!a.paused) a.pause(); });
    var continuous=document.querySelector('#swt-listening-v18 [data-audio]'); if (continuous) continuous.pause();
    var token=state.audioToken, played=0, limit=single ? 1 : state.loop;
    var audio = new Audio(staticAudioUrl(clip.src)); audio.playbackRate=clip.rate || 1; audio.preservesPitch=true; state.audio=audio; state.audioKey=key;
    if (button) button.classList.add('playing');
    audio.onended=function () { played++; if (token!==state.audioToken) return; if (limit===0 || played<limit) state.audioTimer=setTimeout(function () {if(token===state.audioToken){audio.currentTime=0;audio.play().catch(function(){status('请再点播放键继续。');});}},900); else stopSound(); };
    audio.onerror=function () { if(token===state.audioToken){stopSound();status('示范音加载失败，请检查网络后重试。');} };
    audio.play().then(function () {status('正在播放示范；点同一按钮或“停止示范音”可停止。');}).catch(function () {status('Safari需要你再点一次播放；若仍失败，请检查网络。');});
  }
  function playQuestion() {var vs=variants(q()), item=vs[Math.min(state.variant,vs.length-1)], key=registerAudio(item.audio,en(item),false);playClip(state.clips[key],key,null,true);}
  function focusSection(id) {var node=state.root.querySelector('#'+id);if(node){if(node.tagName==='DETAILS')node.open=true;node.scrollIntoView({behavior:'smooth',block:'start'});}}
  function choose(id,mode) {if(!safeToChange())return;stopSound();state.selected=id;state.mode=mode||'learn';state.hint=state.mode==='learn'?0:2;state.variant=state.mode==='learn'?0:practiceVariantIndex(q());state.followup=-1;state.chain=1;render();}
  function shuffled(items) {return items.map(function(item){return {item:item,r:Math.random()};}).sort(function(a,b){return a.r-b.r;}).map(function(x){return x.item;});}
  function handleChange(event) {
    var target=event.target;
    if(target.matches('[data-sam-date]')){state.date=target.value;persist();showDate();}
    if(target.matches('[data-sam-question]')){var value=target.value;if(safeToChange())choose(value,'learn');else target.value=state.selected;}
  }
  function handleClick(event) {
    var button=event.target.closest('button');if(!button||!state.root.contains(button)||button.disabled)return;
    if(button.hasAttribute('data-sam-play')){var key=button.getAttribute('data-sam-play');playClip(state.clips[key],key,button,false);return;}
    var action=button.getAttribute('data-sam-action'), value=button.getAttribute('data-value');if(!action)return;
    if(action==='stop'){stopSound();status('示范音已停止。');return;}
    if(action==='retry'){load();return;}
    if(!safeToChange())return;
    if(action==='duration'){state.minutes=Number(value);render();var plan=state.root.querySelector('.sam19-plan');if(plan)plan.open=true;}
    else if(action==='loop'){state.loop=Number(value);state.root.querySelectorAll('[data-sam-action="loop"]').forEach(function(b){b.setAttribute('aria-pressed',String(Number(b.getAttribute('data-value'))===state.loop));});}
    else if(action==='learn'){choose(state.selected,'learn');}
    else if(action==='random'){var pool=state.questions.filter(function(item){return item.id!==state.selected;});choose(shuffled(pool.length?pool:state.questions)[0].id,'random');playQuestion();}
    else if(action==='mock'){state.mock=shuffled(state.questions.filter(function(item){return shortLines(item).length;})).slice(0,5).map(function(item){return item.id;});state.mockIndex=0;state.mockDone={};choose(state.mock[0],'mock');playQuestion();}
    else if(action==='mock-next'){if(state.mockIndex<state.mock.length-1){state.mockIndex++;choose(state.mock[state.mockIndex],'mock');playQuestion();}else status('这轮已录完 '+Object.keys(state.mockDone).length+' 题。回听最卡的一题，明天再脱稿复测；录完不等于答案已合格。');}
    else if(action==='hint'){stopSound();state.hint=Number(value);render();focusSection('sam-answer');}
    else if(action==='variant'){var selectedVariant=variants(q())[Number(value)];if(!selectedVariant)return;if(state.mode!=='learn'&&selectedVariant.hint){status('这个追问与主问题答题内容不同，请先进入精练模式。');return;}state.variant=Number(value);render();playQuestion();}
    else if(action==='base-question'){state.variant=0;state.hint=0;render();focusSection('sam-question');}
    else if(action==='chain'){state.chain=Number(value);render();var chain=state.root.querySelector('.sam19-chain');if(chain)chain.open=true;}
    else if(action==='followup'){var fu=q().followups||[], options=fu.map(function(_,i){return i;}).filter(function(i){return i!==state.followup;});state.followup=options.length?options[Math.floor(Math.random()*options.length)]:0;render();var follow=fu[state.followup];if(follow){var fk=registerAudio(follow.audio,en(follow),false);playClip(state.clips[fk],fk,null,true);}focusSection('sam-followup');}
    else if(action==='task-review'){var trained=state.questions.filter(function(item){return state.counts[item.id];}).sort(function(a,b){return String(state.lastPracticed[b.id]||'').localeCompare(String(state.lastPracticed[a.id]||''));})[0];choose(trained?trained.id:state.selected,'random');playQuestion();}
    else if(action==='task-hear'){choose(state.selected,'learn');focusSection('sam-question');playQuestion();}
    else if(action==='task-two'){choose(state.selected,'learn');focusSection('sam-answer');status('先把这题说3遍，再从题库选另一道弱项。今天最多重点新增2题。');}
    else if(action==='task-random'){var r=shuffled(state.questions)[0];choose(r.id,'random');playQuestion();}
    else if(action==='task-gap'){focusSection('sam-gaps');}
    else if(action==='continuous'){var player=state.root.querySelector('#swt-listening-v18');if(player)player.scrollIntoView({behavior:'smooth',block:'start'});else status('连续听练正在载入，请稍后再试。');}
    else if(action==='legacy'){state.root.parentNode.classList.toggle('sam19-show-legacy');status('旧版记录仅供回看。当前训练请使用上方 Sam 口测主线。');}
    else if(action==='planned-question'){choose(value,'learn');focusSection('sam-question');}
  }
  window.addEventListener('sam-recorder-start',stopSound);
  window.addEventListener('sam-recorder-saved',function(event){
    var detail=event.detail||{}, id=String(detail.id||detail.targetId||''), time=detail.savedAt||detail.createdAt||Date.now();
    if(!id.startsWith('sam-v19:')||detail.kind!=='answer'||Number(detail.duration)<3)return;
    var parts=id.split(':'), questionId=parts[1]; if(parts[2]!=='answer')return;
    var key=id+':'+time;if(state.seenEvents[key])return;state.seenEvents[key]=true;
    state.counts[questionId]=(state.counts[questionId]||0)+1;state.lastPracticed[questionId]=dayKey();persist();
    if(state.mode==='mock'&&state.selected===questionId&&state.hint===2)state.mockDone[questionId]=true;
    var count=state.root&&state.root.querySelector('[data-sam-count]');if(count&&q().id===questionId)count.textContent='本题已实际录音 '+state.counts[questionId]+' 次（次数不代表口语合格）';
    var next=state.root&&state.root.querySelector('[data-sam-action="mock-next"]');if(next&&state.mockDone[questionId])next.disabled=false;
    var done=state.root&&state.root.querySelector('[data-sam-mock-done]');if(done)done.textContent='已录 '+Object.keys(state.mockDone).length+' 题';
    status('已保存实际录音。回听找一个最需要补的地方；下一遍减少提示。');
  });
  document.addEventListener('play',function(event){if(event.target!==state.audio)stopSound();},true);
  window.addEventListener('pagehide',stopSound);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
  new MutationObserver(function(records){if(records.some(function(record){return !state.root||!state.root.contains(record.target);}))mount();}).observe(document.documentElement,{childList:true,subtree:true});
})();
