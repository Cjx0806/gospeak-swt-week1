(function () {
  'use strict';
  var bar = document.getElementById('sam-audio-recovery');
  if (!bar) return;
  var status = bar.querySelector('[role="status"]');
  function say(message) { if (status.textContent !== message) status.textContent = message; }
  window.addEventListener('gospeak-audio-status', function (event) {
    if (event.detail && event.detail.message) say(event.detail.message);
  });
  bar.querySelector('button').addEventListener('click', function () {
    if (window.__samMainlineV19 && window.__samMainlineV19.isRecording()) {
      say('请先点录音里的「停止并回听」；若卡在权限等待，点「取消麦克风等待」，然后再恢复声音。'); return;
    }
    window.dispatchEvent(new CustomEvent('gospeak-playback-request', {detail:{owner:'recovery'}}));
    document.querySelectorAll('audio,video').forEach(function (media) { media.pause(); });
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    say('播放已重置。现在再点你要听的句子；学习记录和已保存录音不变。');
  });
})();
