const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{createRequire}=require('node:module');
let setup=fs.readFileSync(path.join(__dirname,'test_mainline_v25.cjs'),'utf8').split('\nt.render();')[0];
setup=setup.replace('q,recordSaved,stopSound','q,recordSaved,stopSound,bootReal,openingResult,session:()=>session');
function test(){
  sandbox.clearInterval=()=>{};sandbox.setInterval=()=>1;sandbox.window.confirm=()=>true;
  const mem=new Map();sandbox.localStorage.getItem=k=>mem.get(k);sandbox.localStorage.setItem=(k,v)=>mem.set(k,v);
  t.bootReal(data);t.render();click('exam-lobby');click('exam-start');const full=t.session().start;
  click('opening-lobby');assert(html.includes('四轮开场模拟'));click('exam-start');
  const s=t.session();assert.equal(s.turns.map(v=>v.id).join(),'intro,r35-home,r35-personality,r30-sales');
  const prior=s.turns.map(v=>v.variant);
  for(const [i,heard] of ["I'm Felix. I'm a student.",'I am easygoing and outgoing.','I am from Yulin, Guangxi.','I also helped a driving school find students.'].entries()){
    click('exam-next');assert.equal(s.index,i);assert(!html.includes('I bought and sold used phones.'));
    const opts=t.state.recorderTarget;assert.equal(opts.assessmentMode,'free');
    opts.onTake({duration:i===0?95:10,hasAudio:true,complete:true,transcript:heard});
    assert.equal(s.index,i);click('exam-next');
  }
  assert(html.includes('开场复盘')&&html.includes('家乡、性格')&&html.includes('开场得分 5 / 10'));assert(s.end);
  click('exam-start');const fresh=t.session();for(let i=1;i<4;i++)assert.notEqual(fresh.turns[i].variant,prior[i]);
  click('exam-lobby');assert.equal(t.session().start,full);assert.equal(t.session().turns.length,8);
  click('opening-lobby');click('exam-resume');t.state.recorderTarget.onTake({duration:95,complete:false,hasAudio:true,transcript:'Felix'});click('exam-next');click('exam-skip');click('exam-skip');click('exam-skip');
  assert(html.includes('识别不完整')&&html.includes('未作答')&&html.includes('开场分数待定'));
  const evaluate=(id,text,variant=0)=>t.openingResult({id,variant,seconds:2,heard:text,assessable:true}).label;
  assert.equal(evaluate('r35-home','Guangxi',1),'可以补全');assert.equal(evaluate('r35-home','Yulin',1),'答到点上');
  assert.equal(evaluate('r35-personality','I like swimming.'),'答偏了');
  assert.equal(evaluate('r30-sales','I want to work as a lifeguard.'),'答偏了');
  assert.equal(evaluate('r30-sales','Yes, I have.'),'可以补全');
  assert.equal(evaluate('r30-sales','I sold used phones.'),'答到点上');
  assert.equal(evaluate('r35-personality','I like outgoing people.'),'需核对');
  assert.equal(evaluate('r35-home','I worked in China.'),'需核对');
  assert.equal(evaluate('r30-sales','I sold phones and I want to be a swimming coach.'),'答到点上');
  console.log('PASS: opening order, independent sessions, wait for response, 95-second intro, alternate questions, transcript-based feedback, replays and unassessable turns.');
}
vm.runInNewContext(setup+'\n('+test.toString()+')();',{require:createRequire(__filename),__dirname,console,URL});
