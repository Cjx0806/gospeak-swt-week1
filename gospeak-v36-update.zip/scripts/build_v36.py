"""Add the four-turn opening simulation to the deployed interview engine."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,re
root=Path(__file__).resolve().parents[1];site=root/'_site'
def base(name):
    with ZipFile(root/'gospeak-v35-update.zip') as z:return z.read('_site/'+name).decode()
js=base('assets/mainline-v21.js')
def change(old,new):
    global js
    assert js.count(old)==1,old
    js=js.replace(old,new)
change("  let room=(typeof location!=='undefined'&&location.hash==='#exam')?", """  let openingMode=typeof location!=='undefined'&&location.hash==='#opening-exam';
  let room=(openingMode||(typeof location!=='undefined'&&location.hash==='#exam'))?""")
change("  try {session=JSON.parse(localStorage.getItem(examKey)", "  try {session=JSON.parse(localStorage.getItem(openingMode?'felix-opening-exam-v36':examKey)")
change("localStorage.setItem(examKey,JSON.stringify(session))","localStorage.setItem(openingMode?openingStorage:examKey,JSON.stringify(session))")
start=js.index('    if(!session||!Array.isArray(session.turns)')
end=js.index('session=null;',start)+len('session=null;')
js=js[:start]+'    if(!validExam(session))session=null;'+js[end:]
change('  function examLobby(){',(root/'assets/opening-exam-v36.js').read_text()+'\n  function examLobby(){')
change("    return '<section class=\"r30-room\"><header><h1>模拟考场", """    if(openingMode)return '<section class="r30-room"><header><h1>四轮开场模拟</h1><p>自我介绍 → 家乡 → 性格 → 工作经历</p></header>'+
      '<p>先听考官，每题用自己的话回答。说完点「完成回答」，再进入下一题。交卷后看哪题答偏、哪题还差一个细节。</p>'+
      (session?btn('exam-resume',session.end?'查看上次开场复盘':'继续上次开场模拟'):'')+
      btn('exam-start','开始四轮开场模拟',null,'r30-primary')+btn('exam-lobby','完整模拟考场')+'</section>';
    return '<section class="r30-room"><header><h1>模拟考场""")
change("      '<h3>选一位模拟考官", """      btn('opening-lobby','只练四轮开场')+'<h3>选一位模拟考官""")
change("    if(stage===1&&!follow&&['r35-home'", """    if(stage===1&&!follow&&['r30-intro','r35-home','r35-personality','r30-sales'].includes(item.id))content+=btn('opening-lobby','四轮开场模拟');
    if(stage===1&&!follow&&['r35-home'""")
change("if(session.end)return examReport();","if(session.end)return openingMode?openingReport():examReport();")
change("    else if(action==='exam-lobby'){room='lobby';clearInterval(clockTimer);render();}", """    else if(action==='exam-lobby'||action==='opening-lobby'){selectExam(action==='opening-lobby');}""")
change('session=makeSession(examiner);', 'session=openingMode?makeOpening(examiner,session):makeSession(examiner);')
change("session.index===session.turns.length-1?'交卷并复盘':'下一题 →'", "session.index===session.turns.length-1?'交卷并复盘':openingMode?'答完了，听下一问':'下一题 →'")
change("'#route','#opening'","'#route','#opening','#opening-exam'")
change("turn.heard=String(take.transcript||'').slice(0,1200);turn.assessable=!!take.complete&&!!turn.heard;", """const transcript=String(take.transcript||'');turn.heard=transcript.slice(0,8000);turn.assessable=!!take.complete&&!!turn.heard&&turn.heard===transcript;""")
html=base('index.html').replace('V35 ·','V36 ·').replace('mainline-v21.js?v=22&design=35','mainline-v21.js?v=22&design=36')
page=base('opening-listening.html').replace('<nav>','<nav><a href="./?v=36#opening-exam">四轮开场模拟</a>')
sw=base('sw.js').replace("endsWith('/mainline-v21.js'))u.searchParams.set('design','35')","endsWith('/mainline-v21.js'))u.searchParams.set('design','36')")
sw=re.sub(r'gospeak-independent-v22-[0-9a-f]{12}','gospeak-independent-v22-'+hashlib.sha256(js.encode()).hexdigest()[:12],sw)
outputs={'index.html':html,'assets/mainline-v21.js':js,'sw.js':sw,'opening-listening.html':page}
for name,value in outputs.items():(site/name).write_text(value)
with ZipFile(root/'gospeak-v36-update.zip','w',ZIP_DEFLATED) as z:
    for name in outputs:z.write(site/name,'_site/'+name)
    for name in ['scripts/test_v36.cjs','scripts/build_v36.py','assets/opening-exam-v36.js']:z.write(root/name,name)
