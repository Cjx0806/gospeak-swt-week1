  const openingIds=['intro','r35-home','r35-personality','r30-sales'];
  const openingTitles=['自我介绍','家乡','性格','工作经历'];
  const openingHints=[
    '先说你是谁，再补自己的学生身份、专业或兴趣。',
    '听到 from 或 hometown，报家乡。问哪座城市时，说玉林。',
    '用一个词说自己的性格，例如 easygoing 或 outgoing。',
    '说一件亲自做过的工作，例如买卖二手手机或帮驾校招生。'
  ];
  const openingStorage='felix-opening-exam-v36';
  function selectExam(opening){
    if(opening!==openingMode){
      saveExam();
      openingMode=opening;
      session=null;
      try{session=JSON.parse(localStorage.getItem(opening?openingStorage:examKey)||'null');}catch(_){}
      if(!validExam(session))session=null;
    }
    clearInterval(clockTimer);room='lobby';render();
  }
  function validExam(s){
    if(!s||!Array.isArray(s.turns)||!s.turns.length||!realData().profiles[s.profile])return false;
    if(openingMode&&s.turns.map(t=>t.id).join()!==openingIds.join())return false;
    return s.turns.every(t=>t.id==='intro'||realTopic(t.id));
  }
  function makeOpening(profile,prior){
    const turns=openingIds.map((id,i)=>{
      if(!i)return {id,variant:0};
      const choices=variants(realTopic(id)).map((_,n)=>n);
      const previous=prior?.turns?.[i]?.variant;
      const alternatives=choices.filter(v=>v!==previous);
      return {id,variant:pick(alternatives.length?alternatives:choices)};
    });
    return {profile,start:Date.now(),index:0,fixedThrough:turns.length,turns};
  }
  function openingResult(turn){
    const name=openingTitles[openingIds.indexOf(turn.id)];
    const advice=openingHints[openingIds.indexOf(turn.id)];
    function result(label,score,note){return {name,label,score,note};}
    if(!turn.seconds)return result('未作答',0,advice);
    if(!turn.assessable||!turn.heard)return result('识别不完整',null,'回听后重录这一题，目前无法判断是否切题。');
    const w=turn.heard.toLowerCase().replace(/[’']/g,"'").replace(/[^a-z0-9' ]/g,' ').replace(/\s+/g,' ').trim();
    const nameGiven=/\bfelix\b|\b(my name is|you can call me|i go by) \w+/.test(w);
    const identity=/\b(student|college|university|major|physical fitness training|first year)\b/.test(w);
    const home=/\byu ?lin\b/.test(w),region=/\b(guang ?xi|china)\b/.test(w);
    const traits=/\b(easy ?going|out ?going|cheerful|optimistic|positive|sociable|friendly|patient|shy|quiet|responsible|calm|kind|helpful)\b/;
    const personality=traits.test(w)&&(/(?:^|\b)(i am|i'm|i can be|i would say i'm|people (say i am|say i'm|describe me as))\b/.test(w)||w.split(' ').length<=5)&&!(/\b(i like|i want|my friend is|people are)\b/.test(w));
    const work=/\b(i (also |once |used to )?(bought|sold|sell|worked|helped|recruited|taught|sell and buy)|i('ve| have) (also )?(sold|worked|helped)|my (first |last )?job was|i was (a|an) (salesperson|cashier|coach|lifeguard|assistant)|i (also )?work (at|in|as|for))\b/.test(w);
    const workDetail=/\b(phones?|students?|sales|salesperson|cashier|coach|restaurant|store|shop|driving school|customers?|lifeguard)\b/.test(w);
    const specificWork=work&&workDetail;
    const homeStatement=(home||region)&&(/\b(from|hometown|grew up|born|home city)\b/.test(w)||/^(?:yu ?lin|guang ?xi|china|in|city|province|southern|south|of| )+$/.test(w));
    if(turn.id==='intro'){
      if((nameGiven&&[identity,personality,homeStatement,specificWork].some(Boolean))||(identity&&/\b(i am|i'm|i study|my major)\b/.test(w)&&/\b(study|major|training|college)\b/.test(w)))return result('答到点上',10,'说出了自己的身份和个人信息。');
      if(nameGiven||identity||personality||homeStatement||specificWork)return result('可以补全',6,advice);
    }else if(turn.id==='r35-home'){
      if(homeStatement&&home)return result('答到点上',10,'说出了家乡城市玉林。');
      if(homeStatement&&region)return turn.variant===0?result('答到点上',10,'回答了来自哪里。'):result('可以补全',6,'已经说了地区，这个问法还可以补上城市名 Yulin。');
      if(personality||specificWork)return result('答偏了',0,'这题问家乡。'+advice);
    }else if(turn.id==='r35-personality'){
      if(personality)return result('答到点上',10,'回答里有描述自己性格的词。');
      if(homeStatement||specificWork||/\bi (like|enjoy) (swimming|cycling)\b/.test(w))return result('答偏了',0,'这题问你是怎样的人。'+advice);
    }else{
      if(specificWork)return result('答到点上',10,'你说出了一项具体工作经历，一项就够。');
      if(work||/^(yes|yes i (do|have))$/.test(w))return result('可以补全',5,'再说你具体做过什么。'+advice);
      if(personality||homeStatement||/\b(want|would like) to (be|work)\b/.test(w))return result('答偏了',0,'考官问的是做过的工作。'+advice);
    }
    return result('需核对',null,'这段转写没有可靠匹配到已知要点。对照原题、回听自己的回答。'+advice);
  }
  function openingReport(){
    state.recorderTarget=null;
    const marks=session.turns.map(openingResult);
    const names=label=>marks.filter(m=>m.label===label).map(m=>m.name).join('、');
    const pending=marks.some(m=>m.score===null);
    const grade=pending?'开场分数待定':('开场得分 '+Number((marks.reduce((a,m)=>a+m.score,0)/4).toFixed(2))+' / 10');
    const rows=session.turns.map((turn,i)=>{
      const v=examQuestion(turn),m=marks[i];
      return '<li><div><b>'+esc(m.name)+' · '+esc(m.label)+'</b><small lang="en">'+esc(v.en)+'</small><small>'+esc(v.zh)+'</small><p>'+esc(m.note)+'</p>'+
        (turn.heard?'<details><summary>查看我的转写</summary><p lang="en">'+esc(turn.heard)+'</p></details>':'')+'</div><div>'+
        (turn.saved?btn('exam-replay','回听',i):'')+btn('real-retrain','逐句重练',turn.id==='intro'?'r30-intro':turn.id)+'</div></li>';
    }).join('');
    return '<section class="r30-room"><header><h1>开场复盘</h1><h2>'+esc(grade)+'</h2></header>'+
      ['答偏了','可以补全','未作答','识别不完整','需核对','答到点上'].filter(label=>names(label)).map(label=>'<p><strong>'+label+'</strong> · '+esc(names(label))+'</p>').join('')+
      '<p>按英文转写估算，每题等权。地名或换词可能需要回听核对。</p><div data-review-player></div><ol class="r30-results">'+rows+'</ol>'+
      btn('exam-start','换问法再来一场',null,'r30-primary')+btn('opening-lobby','开场模拟入口')+'</section>';
  }
