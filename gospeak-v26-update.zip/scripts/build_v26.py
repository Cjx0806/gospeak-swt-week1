"""Build V26 from the previously published V25 files."""
import hashlib
import re
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / '_site'

def replace_one(source, before, after):
    if source.count(before) != 1:
        raise ValueError('Unexpected release input: ' + before[:100])
    return source.replace(before, after)

def mainline(source):
    start = source.index("+detail25(line)+'<details class=")
    end = source.index('<div class="sam25-sentence-next">', start)
    source = source[:start] + "+'<section aria-label=\"录这一句\"><div data-sam-recorder></div></section>'+detail25(line)+'" + source[end:]
    start = source.index("    return '<details", source.index('  function joinedRecorder25'))
    end = source.index('\n  }', start)
    source = source[:start] + """    return '<section aria-label="录完整回答"><div data-sam-recorder></div></section>';""" + source[end:]
    edits = [
        ("playButton(line.audio,line.en,true,'▶ 慢速听这一句',true)+", ''),
        ("playButton(line.audio,line.en,false,'▶ 正常速度',true)+loop25(line.audio,line.en,'↻ 慢速循环跟读')",
         "loop25(line.audio,line.en,'▶ 慢速循环跟读')+playButton(line.audio,line.en,false,'▶ 正常语速循环',true)"),
        ("'▶ 慢速听完整回答',true", "'▶ 慢速循环 · 整段',true"),
        ("'▶ 正常听完整回答',true", "'▶ 正常语速循环 · 整段',true"),
        ("'▶ 听问题',true", "'▶ 正常语速循环听题',true"),
        ("'▶ 慢速听问题',true", "'▶ 慢速循环听题',true"),
        ("playButton(entry.src,word,false,word,true)", """'<b lang="en">'+esc(word)+'</b>'+playButton(entry.src,word,false,'正常语速循环',true)+playButton({slow:entry.src,slowRate:.78},word,true,'慢速循环',true)"""),
        ("+loop25(answerAudio(item,answer),text(answer),'↻ 整段慢速循环')", ''),
        ('limit=single?1:state.loop','limit=button||!single?0:1'),
        ('if(state.audio&&state.audioKey===key){stopSound();return;}','if(state.audio&&state.audioKey===key)return;'),
        ('Math.max(1200,(audio.duration||1)*700)','Math.min(2400,Math.max(900,(audio.duration||1)*500))'),
        ('state.audioKey=key;if(button)','state.audioKey=key;showLoopStop(limit===0);if(button)'),
        ("state.audioKey='';if(state.root)", "state.audioKey='';showLoopStop(false);if(state.root)"),
        ("status('正在播放。再点同一按钮或“停止示范音”可结束。');","status(limit===0?'正在循环点读。点「停止点读」结束。':'正在播放考官的问题。');"),
        ('正在加载示范音…再点同一按钮可取消。','正在载入音频…'),
        ('registerAudio(detail.src,detail.word,false);playClip(state.clips[key],key,null,true)',
         'registerAudio(detail.src,detail.word,false);playClip(state.clips[key],key,null,false)'),
        ('  function stopSound(message)', """  function showLoopStop(visible) {
    var control = state.root && state.root.querySelector('[data-loop-stop]');
    if (control) control.hidden = !visible;
  }
  function stopSound(message)"""),
        ('state.needsRender=true;return;}stopSound();',
         'state.needsRender=true;return;}var keepClip=preserveRecorder&&state.clips[state.audioKey];if(!keepClip)stopSound();'),
        ("state.root.querySelector('[data-sam-content]').innerHTML=body25(q());", """state.root.querySelector('[data-sam-content]').innerHTML=body25(q())+'<button type="button" class="swt-loop-stop" data-loop-stop data-sam-action="stop" hidden>■ 停止点读</button>';
    if (keepClip && state.audio) {
      var key = Object.keys(state.clips).find(function (id) {
        var clip = state.clips[id];
        return clip.text===keepClip.text && clip.src===keepClip.src && clip.rate===keepClip.rate;
      });
      state.audioKey = key || 'playing-previous-clip';
      showLoopStop(true);
      state.root.querySelectorAll('[data-sam-play]').forEach(function (button) {
        if (button.getAttribute('data-sam-play')===key) {
          button.classList.add('playing');
          button.setAttribute('aria-pressed','true');
        }
      });
    }""")
    ]
    for before, after in edits:
        source = replace_one(source, before, after)
    return source

def build():
    with ZipFile(ROOT / 'gospeak-v25-update.zip') as old:
        def previous(name): return old.read('_site/' + name).decode()
        html, worker = previous('index.html'), previous('sw.js')
        (SITE/'assets/mainline-v21.js').write_text(mainline(previous('assets/mainline-v21.js')))
    for src, dst in [('recorder-v26.js','recorder-v19.js'), ('practice-v26.css','practice-v26.css')]:
        (SITE/'assets'/dst).write_bytes((ROOT/'assets'/src).read_bytes())
    html = html.replace('V25 ·','V26 ·').replace('design=25','design=26')
    for name in ('recorder-v19.js', 'listening-v18.js'):
        html = html.replace(name+'?v=22', name+'?v=22&design=26')
    html = html.replace('cards.html?v=24','cards.html?v=26').replace('</head>', '<link rel="stylesheet" href="./assets/practice-v26.css?v=22">\n</head>')
    (SITE/'index.html').write_text(html)
    worker = worker.replace("if(u.pathname.endsWith('/assets/mainline-v21.js'))u.searchParams.set('design', '25');", "if(/\\/(mainline-v21|recorder-v19|listening-v18)\\.js$/.test(u.pathname))u.searchParams.set('design', '26');")
    worker = worker.replace('// V19_VERSIONED_CACHE', "core.push(new URL('assets/practice-v26.css',BASE).href);\n// V19_VERSIONED_CACHE")
    filenames = ['assets/mainline-v21.js','assets/recorder-v19.js','assets/practice-v26.css']
    digest = hashlib.sha256(b''.join((SITE/name).read_bytes() for name in filenames)).hexdigest()[:12]
    (SITE/'sw.js').write_text(re.sub(r'gospeak-independent-v22-[0-9a-f]{12}', 'gospeak-independent-v22-'+digest, worker))
    player = (ROOT/'assets/listening-v18.js').read_text().replace('loop: false,','loop: true,').replace('state.loop = stored.loop === true;', 'state.loop = stored.loopVersion === 26 ? stored.loop !== false : true;').replace('loop: state.loop,', 'loopVersion: 26, loop: state.loop,')
    (SITE/'assets/listening-v18.js').write_text(player)
    cards = (ROOT/'assets/cards-v24.html').read_text().replace('id="loop"', 'id="loop" checked').replace('<audio id="player"','<audio loop id="player"')
    (SITE/'cards.html').write_text(cards)
    paths = ['_site/'+name for name in filenames+['index.html','sw.js','assets/listening-v18.js','cards.html']]
    paths += ['scripts/build_v26.py','scripts/test_practice_v26.cjs','scripts/verify_v22.py','assets/recorder-v26.js','assets/practice-v26.css']
    with ZipFile(ROOT/'gospeak-v26-update.zip','w',ZIP_DEFLATED) as archive:
        for name in paths: archive.write(ROOT/name,name)
    workflow = ROOT/'.github/workflows/pages.yml'
    text = workflow.read_text().replace('Deploy 快乐出村计划 V25','Deploy 快乐出村计划 V26')
    if 'unzip -q -o gospeak-v26-update.zip' not in text:
        text = text.replace('unzip -q -o gospeak-v25-update.zip -d .','unzip -q -o gospeak-v25-update.zip -d .\n          unzip -q -o gospeak-v26-update.zip -d .')
        text = text.replace('node scripts/test_mainline_v25.cjs','node scripts/test_mainline_v25.cjs\n          node scripts/test_practice_v26.cjs')
    workflow.write_text(text)

if __name__ == '__main__': build()
